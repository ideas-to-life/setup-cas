"""Loosely coupled, adapter-based coding-agent telemetry collector.

Supports Antigravity, Claude Code, Codex, and custom adapters implementing
`CodingAgentTelemetryAdapter` without vendor lock-in or prompt leakage.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from cas_runner.orchestration.hud import DEFAULT_PRICING, MODEL_PRICING

logger = logging.getLogger(__name__)

_EXTRA_AGENT_PRICING: dict[str, tuple[float, float]] = {
    **MODEL_PRICING,
    "claude-sonnet-4": (3.00, 15.00),
    "claude-opus-4": (15.00, 75.00),
    "claude-3-7-sonnet": (3.00, 15.00),
    "gemini-4-hydrogen-high": (1.25, 10.00),
    "gemini-4-hydrogen-medium": (0.30, 2.50),
    "gemini-4-hydrogen-low": (0.15, 0.60),
    "gemini-4": (0.30, 2.50),
    "gemini-3": (0.30, 2.50),
    "gemini-2.5-pro": (1.25, 10.00),
    "gemini-2.5-flash": (0.15, 0.60),
    "gpt-4.1": (2.00, 8.00),
    "gpt-5": (1.25, 10.00),
    "o3": (2.00, 8.00),
    "o4-mini": (1.10, 4.40),
}


def _normalize_iso(ts: str | None) -> str:
    if not ts:
        return ""
    return str(ts).strip().replace("Z", "").split("+")[0]


def _parse_iso_epoch(ts: str | None) -> float | None:
    norm = _normalize_iso(ts)
    if not norm:
        return None
    try:
        return datetime.fromisoformat(norm).timestamp()
    except ValueError:
        return None


def _is_since_match(ts: str | None, since: str | None) -> bool:
    if not since:
        return True
    norm_ts = _normalize_iso(ts)
    norm_since = _normalize_iso(since)
    return bool(norm_ts and norm_ts >= norm_since)


def _infer_provider(model: str) -> str:
    m = model.lower()
    if "claude" in m:
        return "anthropic"
    if "gemini" in m:
        return "google"
    if any(k in m for k in ("gpt", "o1", "o3", "o4", "codex")):
        return "openai"
    if "deepseek" in m:
        return "deepseek"
    return "unknown"


def estimate_agent_cost_usd(
    model: str,
    prompt_tokens: int,
    cache_read_tokens: int,
    completion_tokens: int,
) -> float:
    """Estimate USD cost using CAS pricing tables (cache reads discounted 90%)."""
    m_low = model.lower()
    rates: tuple[float, float] | None = None
    for prefix, pair in _EXTRA_AGENT_PRICING.items():
        if prefix in m_low:
            rates = pair
            break
    if rates is None:
        rates = DEFAULT_PRICING
    in_rate, out_rate = rates
    uncached_in = max(0, prompt_tokens - cache_read_tokens)
    in_cost = (uncached_in / 1_000_000.0) * in_rate
    cache_cost = (cache_read_tokens / 1_000_000.0) * (in_rate * 0.1)
    out_cost = (completion_tokens / 1_000_000.0) * out_rate
    return round(in_cost + cache_cost + out_cost, 6)


def _matches_workspace(text_or_cwd: str, target_dir: Path) -> bool:
    resolved = str(target_dir.resolve())
    return resolved in text_or_cwd or target_dir.name in text_or_cwd


@dataclass(frozen=True)
class AgentTelemetrySpan:
    """Vendor-neutral normalized telemetry span from a coding-agent session."""

    agent: str
    session_id: str
    timestamp: str
    provider: str
    model: str
    prompt_tokens: int
    cache_read_tokens: int
    completion_tokens: int
    total_tokens: int
    cost_usd: float
    duration_s: float
    step_name: str

    def to_trace_span(self) -> dict[str, Any]:
        """Convert to OTel-compatible span dict for DashboardDataAccess aggregation."""
        epoch = _parse_iso_epoch(self.timestamp) or 0.0
        return {
            "name": self.step_name,
            "start_time": epoch,
            "end_time": epoch + max(0.0, self.duration_s),
            "status": "ok",
            "attributes": {
                "cas.source": "coding_agent",
                "cas.agent": self.agent,
                "cas.session_id": self.session_id,
                "cas.step_name": self.step_name,
                "llm.provider": self.provider,
                "llm.model": self.model,
                "llm.prompt_tokens": self.prompt_tokens,
                "llm.cache_read_tokens": self.cache_read_tokens,
                "llm.completion_tokens": self.completion_tokens,
                "llm.total_tokens": self.total_tokens,
                "llm.estimated_cost": self.cost_usd,
            },
        }


@runtime_checkable
class CodingAgentTelemetryAdapter(Protocol):
    """Protocol for pluggable coding-agent session telemetry adapters."""

    agent_name: str

    def collect(
        self, target_dir: Path, since: str | None = None
    ) -> list[AgentTelemetrySpan]:
        """Return normalized spans for `target_dir` at or after `since`."""
        ...


class AntigravityTelemetryAdapter:
    """Read-only adapter for Antigravity CLI/IDE `transcript.jsonl` logs."""

    agent_name = "antigravity"

    def __init__(self, root_dir: Path | None = None) -> None:
        self.root_dir = (
            root_dir
            if root_dir is not None
            else Path.home() / ".gemini" / "antigravity-cli" / "brain"
        )

    def collect(
        self, target_dir: Path, since: str | None = None
    ) -> list[AgentTelemetrySpan]:
        if not self.root_dir.is_dir():
            return []
        spans: list[AgentTelemetrySpan] = []
        for log_file in sorted(
            self.root_dir.glob("*/.system_generated/logs/transcript.jsonl")
        ):
            session_id = log_file.parents[2].name
            spans.extend(self._parse_session(log_file, session_id, target_dir, since))
        return spans

    def _parse_session(
        self,
        log_file: Path,
        session_id: str,
        target_dir: Path,
        since: str | None,
    ) -> list[AgentTelemetrySpan]:
        try:
            raw_lines = log_file.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []

        entries: list[dict[str, Any]] = []
        workspace_matched = False
        resolved_str = str(target_dir.resolve())
        for line in raw_lines:
            if not line.strip():
                continue
            if resolved_str in line:
                workspace_matched = True
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(obj, dict):
                entries.append(obj)

        if not workspace_matched:
            return []

        out: list[AgentTelemetrySpan] = []
        prev_epoch: float | None = None
        for entry in entries:
            ts = str(entry.get("created_at") or "")
            epoch = _parse_iso_epoch(ts)
            if entry.get("type") != "PLANNER_RESPONSE":
                if epoch is not None:
                    prev_epoch = epoch
                continue

            duration_s = (
                min(300.0, max(0.0, epoch - prev_epoch))
                if epoch is not None and prev_epoch is not None
                else 0.0
            )
            if epoch is not None:
                prev_epoch = epoch

            if not _is_since_match(ts, since):
                continue

            model = str(entry.get("model") or "unknown")
            in_tok = int(entry.get("input_tokens") or 0)
            cache_tok = int(entry.get("cache_read_tokens") or 0)
            prompt_tok = in_tok + cache_tok
            out_tok = int(entry.get("output_tokens") or 0)
            total_tok = prompt_tok + out_tok
            tools = entry.get("tool_calls") or []
            primary_tool = (
                str(tools[0].get("name") or "planner")
                if tools and isinstance(tools[0], dict)
                else "planner"
            )
            out.append(
                AgentTelemetrySpan(
                    agent=self.agent_name,
                    session_id=session_id,
                    timestamp=ts,
                    provider=_infer_provider(model),
                    model=model,
                    prompt_tokens=prompt_tok,
                    cache_read_tokens=cache_tok,
                    completion_tokens=out_tok,
                    total_tokens=total_tok,
                    cost_usd=estimate_agent_cost_usd(
                        model, prompt_tok, cache_tok, out_tok
                    ),
                    duration_s=round(duration_s, 2),
                    step_name=f"agent.antigravity.{primary_tool}",
                )
            )
        return out


class ClaudeCodeTelemetryAdapter:
    """Read-only adapter for Claude Code `~/.claude/projects/**/*.jsonl` logs."""

    agent_name = "claude-code"

    def __init__(self, root_dir: Path | None = None) -> None:
        self.root_dir = (
            root_dir if root_dir is not None else Path.home() / ".claude" / "projects"
        )

    def collect(
        self, target_dir: Path, since: str | None = None
    ) -> list[AgentTelemetrySpan]:
        if not self.root_dir.is_dir():
            return []
        spans: list[AgentTelemetrySpan] = []
        for log_file in sorted(self.root_dir.rglob("*.jsonl")):
            spans.extend(self._parse_session(log_file, target_dir, since))
        return spans

    def _parse_session(
        self, log_file: Path, target_dir: Path, since: str | None
    ) -> list[AgentTelemetrySpan]:
        try:
            raw_lines = log_file.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []

        encoded_dir = str(target_dir.resolve()).replace("/", "-")
        dir_matched = encoded_dir in str(log_file.parent)
        out: list[AgentTelemetrySpan] = []
        prev_epoch: float | None = None
        for line in raw_lines:
            if not line.strip():
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(entry, dict):
                continue

            cwd = str(entry.get("cwd") or "")
            if not dir_matched and cwd and not _matches_workspace(cwd, target_dir):
                continue
            if not dir_matched and not cwd:
                continue

            ts = str(entry.get("timestamp") or "")
            epoch = _parse_iso_epoch(ts)
            msg = entry.get("message")
            if not isinstance(msg, dict) or not isinstance(msg.get("usage"), dict):
                if epoch is not None:
                    prev_epoch = epoch
                continue

            duration_s = (
                min(300.0, max(0.0, epoch - prev_epoch))
                if epoch is not None and prev_epoch is not None
                else 0.0
            )
            if epoch is not None:
                prev_epoch = epoch

            if not _is_since_match(ts, since):
                continue

            usage = msg["usage"]
            model = str(msg.get("model") or "claude-unknown")
            in_tok = int(usage.get("input_tokens") or 0)
            cache_tok = int(usage.get("cache_read_input_tokens") or 0)
            prompt_tok = in_tok + cache_tok
            out_tok = int(usage.get("output_tokens") or 0)
            content = msg.get("content") or []
            tool_name = "turn"
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "tool_use":
                        tool_name = str(block.get("name") or "turn")
                        break
            out.append(
                AgentTelemetrySpan(
                    agent=self.agent_name,
                    session_id=log_file.stem,
                    timestamp=ts,
                    provider=_infer_provider(model),
                    model=model,
                    prompt_tokens=prompt_tok,
                    cache_read_tokens=cache_tok,
                    completion_tokens=out_tok,
                    total_tokens=prompt_tok + out_tok,
                    cost_usd=estimate_agent_cost_usd(
                        model, prompt_tok, cache_tok, out_tok
                    ),
                    duration_s=round(duration_s, 2),
                    step_name=f"agent.claude-code.{tool_name}",
                )
            )
        return out


class CodexTelemetryAdapter:
    """Read-only adapter for OpenAI Codex `~/.codex/sessions/**/*.jsonl` logs."""

    agent_name = "codex"

    def __init__(self, root_dir: Path | None = None) -> None:
        self.root_dir = (
            root_dir if root_dir is not None else Path.home() / ".codex" / "sessions"
        )

    def collect(
        self, target_dir: Path, since: str | None = None
    ) -> list[AgentTelemetrySpan]:
        if not self.root_dir.is_dir():
            return []
        spans: list[AgentTelemetrySpan] = []
        for log_file in sorted(self.root_dir.rglob("*.jsonl")):
            spans.extend(self._parse_session(log_file, target_dir, since))
        return spans

    def _parse_session(
        self, log_file: Path, target_dir: Path, since: str | None
    ) -> list[AgentTelemetrySpan]:
        try:
            raw_lines = log_file.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []

        session_id = log_file.stem
        workspace_matched = False
        entries: list[dict[str, Any]] = []
        for line in raw_lines:
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(obj, dict):
                continue
            entries.append(obj)
            if obj.get("type") == "session_meta":
                payload = obj.get("payload") or {}
                session_id = str(payload.get("id") or session_id)
                cwd = str(payload.get("cwd") or "")
                if cwd and _matches_workspace(cwd, target_dir):
                    workspace_matched = True

        if not workspace_matched:
            return []

        out: list[AgentTelemetrySpan] = []
        prev_epoch: float | None = None
        for entry in entries:
            ts = str(entry.get("timestamp") or "")
            epoch = _parse_iso_epoch(ts)
            payload = entry.get("payload")
            if (
                entry.get("type") != "event_msg"
                or not isinstance(payload, dict)
                or payload.get("type") != "token_count"
            ):
                if epoch is not None:
                    prev_epoch = epoch
                continue

            duration_s = (
                min(300.0, max(0.0, epoch - prev_epoch))
                if epoch is not None and prev_epoch is not None
                else 0.0
            )
            if epoch is not None:
                prev_epoch = epoch

            if not _is_since_match(ts, since):
                continue

            info = payload.get("info") or {}
            usage = info.get("last_token_usage") or info.get("total_token_usage") or {}
            model = str(payload.get("model") or info.get("model") or "gpt-4o")
            in_tok = int(usage.get("input_tokens") or 0)
            cache_tok = int(usage.get("cached_input_tokens") or 0)
            prompt_tok = in_tok + cache_tok
            out_tok = int(usage.get("output_tokens") or 0)
            out.append(
                AgentTelemetrySpan(
                    agent=self.agent_name,
                    session_id=session_id,
                    timestamp=ts,
                    provider=_infer_provider(model),
                    model=model,
                    prompt_tokens=prompt_tok,
                    cache_read_tokens=cache_tok,
                    completion_tokens=out_tok,
                    total_tokens=prompt_tok + out_tok,
                    cost_usd=estimate_agent_cost_usd(
                        model, prompt_tok, cache_tok, out_tok
                    ),
                    duration_s=round(duration_s, 2),
                    step_name="agent.codex.turn",
                )
            )
        return out


class CodingAgentTelemetryCollector:
    """Registry and aggregator over pluggable CodingAgentTelemetryAdapter instances."""

    def __init__(
        self, adapters: Sequence[CodingAgentTelemetryAdapter] | None = None
    ) -> None:
        self._adapters: list[CodingAgentTelemetryAdapter] = (
            list(adapters)
            if adapters is not None
            else [
                AntigravityTelemetryAdapter(),
                ClaudeCodeTelemetryAdapter(),
                CodexTelemetryAdapter(),
            ]
        )

    def register(self, adapter: CodingAgentTelemetryAdapter) -> None:
        """Register an additional coding-agent telemetry adapter."""
        self._adapters.append(adapter)

    def collect_trace_records(
        self, target_dir: Path, since: str | None = None
    ) -> dict[str, Any]:
        """Collect normalized trace dicts and per-agent summary across all adapters."""
        grouped: dict[tuple[str, str], list[AgentTelemetrySpan]] = {}
        agents_summary: dict[str, dict[str, Any]] = {}

        for adapter in self._adapters:
            try:
                spans = adapter.collect(target_dir, since=since)
            except Exception as exc:
                logger.warning(
                    "Coding-agent telemetry adapter '%s' failed: %s",
                    getattr(adapter, "agent_name", type(adapter).__name__),
                    exc,
                )
                continue

            for sp in spans:
                grouped.setdefault((sp.agent, sp.session_id), []).append(sp)
                entry = agents_summary.setdefault(
                    sp.agent,
                    {
                        "agent": sp.agent,
                        "sessions": set(),
                        "spans": 0,
                        "total_tokens": 0,
                        "cost_usd": 0.0,
                    },
                )
                entry["sessions"].add(sp.session_id)
                entry["spans"] += 1
                entry["total_tokens"] += sp.total_tokens
                entry["cost_usd"] += sp.cost_usd

        trace_records: list[dict[str, Any]] = []
        for (agent, session_id), spans in grouped.items():
            trace_records.append(
                {
                    "trace_id": f"{agent}:{session_id}",
                    "source": "coding_agent",
                    "agent": agent,
                    "timestamp": spans[0].timestamp,
                    "spans": [s.to_trace_span() for s in spans],
                }
            )

        agents_out = {
            name: {
                "agent": name,
                "sessions": len(val["sessions"]),
                "spans": val["spans"],
                "total_tokens": val["total_tokens"],
                "cost_usd": round(val["cost_usd"], 4),
            }
            for name, val in agents_summary.items()
        }
        return {"trace_records": trace_records, "agents": agents_out}
