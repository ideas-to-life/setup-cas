"""Zero-dependency local HTTP server for the CAS 5+1 Workspace Web Cockpit."""

from __future__ import annotations

import json
import re
import subprocess
import time
from datetime import UTC, datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import yaml

from cas_runner.dashboard.data_access import DashboardDataAccess
from cas_runner.governance.architecture_linter import ArchitectureLinter
from cas_runner.governance.control_bands import ControlBandsEngine
from cas_runner.governance.explain import (
    explain_adrs,
    explain_control_loops,
    explain_flows,
    explain_overview,
    extract_frontmatter,
    get_patterns_catalogue_path,
    load_patterns_catalogue,
)
from cas_runner.governance.intent_verifier import IntentVerifier
from cas_runner.governance.plan_router import PlanRouter
from cas_runner.governance.sdlc_profile import SDLCProfileResolver
from cas_runner.llm import get_llm_client
from cas_runner.steps.forensic.extractor import compute_package_coupling_metrics

STATIC_INDEX_PATH = Path(__file__).resolve().parent / "static" / "index.html"
_NEW_DEP_PATTERN = re.compile(r"(?i)^new_dependency:\s*([a-zA-Z0-9_-]+)$")


class CockpitService:
    """Read-only introspection and dry-run routing service backing `cas ui`."""

    def __init__(
        self,
        target_dir: Path | str = ".",
        project: str | None = None,
        cache_ttl_seconds: float = 10.0,
        port: int = 8080,
    ) -> None:
        self.target_dir = Path(target_dir).resolve()
        self.port = port
        self._explicit_project = bool(project)
        if project:
            self.project = project
        else:
            overview_proj = explain_overview(self.target_dir).get("project")
            inferred = self.target_dir.name
            self.project = str(overview_proj or inferred or "ideas-to-life-cas")
        self._cache_ttl = cache_ttl_seconds
        self._coupling_cache: tuple[float, list[dict[str, Any]]] | None = None
        self._bands_cache: tuple[float, Any] | None = None
        self._lint_cache: tuple[float, Any] | None = None
        self._sdlc_cache: tuple[float, dict[str, Any]] | None = None
        self._proposals_cache: dict[str, dict[str, Any]] | None = None
        self._recommendations_cache: dict[str, dict[str, Any]] | None = None
        self._data_access = DashboardDataAccess(
            project=self.project,
            target_dir=self.target_dir,
            cache_ttl_seconds=self._cache_ttl,
        )

    def _get_cached_coupling(self) -> list[dict[str, Any]]:
        now = time.monotonic()
        if (
            self._coupling_cache is not None
            and (now - self._coupling_cache[0]) < self._cache_ttl
        ):
            return self._coupling_cache[1]
        data = compute_package_coupling_metrics(self.target_dir)
        self._coupling_cache = (now, data)
        return data

    def _get_cached_bands(self) -> Any:
        now = time.monotonic()
        if (
            self._bands_cache is not None
            and (now - self._bands_cache[0]) < self._cache_ttl
        ):
            return self._bands_cache[1]
        report = ControlBandsEngine(target_dir=self.target_dir).evaluate()
        self._bands_cache = (now, report)
        return report

    def _get_cached_lint(self) -> Any:
        now = time.monotonic()
        if (
            self._lint_cache is not None
            and (now - self._lint_cache[0]) < self._cache_ttl
        ):
            return self._lint_cache[1]
        report = ArchitectureLinter(target_dir=self.target_dir).lint()
        self._lint_cache = (now, report)
        return report

    def warm_caches(self) -> None:
        """Pre-populate coupling, control-band, lint, sdlc, and lineage caches for sub-500ms responses."""
        self._get_cached_coupling()
        self._get_cached_bands()
        self._get_cached_lint()
        adr_data = explain_adrs(self.target_dir)
        ws_path = Path(adr_data.get("workspace_path", self.target_dir / "knowledge"))
        proj = str(adr_data.get("project", self.project))
        proj_dir = ws_path / "projects" / proj
        self._load_proposals_index(proj_dir)
        self._load_recommendations_index(proj_dir)
        self.get_sdlc_status()

    def _get_git_meta(self) -> dict[str, str]:
        branch = (
            SDLCProfileResolver(target_dir=self.target_dir).get_git_branch() or "main"
        )
        sha = "local"
        try:
            res = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                cwd=self.target_dir,
                capture_output=True,
                text=True,
                timeout=2,
                check=False,
            )
            if res.returncode == 0 and res.stdout.strip():
                sha = res.stdout.strip()
        except Exception:
            pass
        return {"branch": branch, "sha": sha}

    def _discover_sample_files(self, limit: int = 4) -> list[str]:
        """Discover representative source file paths inside self.target_dir for the simulator."""
        ignored = {
            ".git",
            ".venv",
            "venv",
            "node_modules",
            "__pycache__",
            ".pytest_cache",
            ".ruff_cache",
            "dist",
            "build",
        }
        samples: list[str] = []
        search_roots = [self.target_dir / "src", self.target_dir]
        seen: set[str] = set()
        for root in search_roots:
            if not root.is_dir():
                continue
            for p in sorted(root.rglob("*")):
                if not p.is_file():
                    continue
                rel = p.relative_to(self.target_dir)
                if any(part in ignored or part.startswith(".") for part in rel.parts):
                    continue
                if p.suffix not in {
                    ".py",
                    ".ts",
                    ".tsx",
                    ".js",
                    ".go",
                    ".rs",
                    ".java",
                    ".yaml",
                    ".yml",
                }:
                    continue
                rel_str = rel.as_posix()
                if rel_str not in seen:
                    seen.add(rel_str)
                    samples.append(rel_str)
                    if len(samples) >= limit:
                        return samples
        return samples

    def get_health(self) -> dict[str, Any]:
        """Return system health and 3 continuous control loops status."""
        overview = explain_overview(self.target_dir)
        loops = explain_control_loops(self.target_dir)
        bands = self._get_cached_bands()
        project_name = (
            self.project
            if self._explicit_project
            else overview.get("project", self.project)
        )
        return {
            "status": "ok",
            "project": project_name,
            "port": self.port,
            "git": self._get_git_meta(),
            "sample_files": self._discover_sample_files(),
            "target_dir": str(self.target_dir),
            "control_loops": loops,
            "counts": overview.get("counts", {}),
            "bands_summary": {
                "highest_band": bands.highest_band,
                "has_3sigma_breach": bands.has_3sigma_breach,
                "config_path": bands.config_path,
            },
        }

    def get_martin_metrics(self) -> dict[str, Any]:
        """Return live AST package coupling metrics and control bands."""
        raw_metrics = self._get_cached_coupling()
        packages = []
        for item in raw_metrics:
            distance = float(item.get("distance", 0.0))
            packages.append(
                {
                    "package": str(item.get("package", "")),
                    "ca": int(item.get("ca", 0)),
                    "ce": int(item.get("ce", 0)),
                    "instability": float(item.get("instability", 0.0)),
                    "abstractness": float(item.get("abstractness", 0.0)),
                    "distance": distance,
                    "zone_violation": distance > 0.5,
                }
            )
        packages.sort(key=lambda p: p["distance"], reverse=True)
        bands = self._get_cached_bands()
        return {
            "packages": packages,
            "flagged_count": sum(1 for p in packages if p["zone_violation"]),
            "control_bands": bands.to_dict(),
        }

    def get_economics_metrics(self) -> dict[str, Any]:
        """Return project-scoped reasoning economics, model breakdown, and step metrics."""
        return self._data_access.get_reasoning_economics()

    def get_performance_metrics(self) -> dict[str, Any]:
        """Return project-scoped step latency percentiles and bottleneck rankings."""
        return self._data_access.get_performance_metrics()

    def get_quality_metrics(self) -> dict[str, Any]:
        """Return project-scoped skill evals, trace evals, and ARCH-LINT compliance."""
        qual = dict(self._data_access.get_quality_metrics())
        lint = self._get_cached_lint()
        findings = getattr(lint, "findings", []) or []
        rules_summary: dict[str, int] = {}
        for f in findings:
            rule_id = str(
                getattr(f, "rule_id", None) or getattr(f, "code", "ARCH-LINT")
            )
            rules_summary[rule_id] = rules_summary.get(rule_id, 0) + 1
        qual["governance_lint"] = {
            "violation_count": len(findings),
            "compliant": len(findings) == 0,
            "rules": rules_summary,
        }
        return qual

    def get_adrs(self) -> dict[str, Any]:
        """Return unified Global + Project ADR catalog and 4-tier lineage counts."""
        adr_data = explain_adrs(self.target_dir)
        ws_path = Path(adr_data.get("workspace_path", self.target_dir / "knowledge"))
        proj = adr_data.get("project", self.project)
        proj_dir = ws_path / "projects" / proj

        proposals_file = (
            proj_dir / "proposed-patterns" / "structural-pattern-proposals.yaml"
        )
        recs_file = proj_dir / "governance" / "pattern-promotion-recommendations.yaml"
        decisions_dir = proj_dir / "governance" / "promotion-decisions"
        decision_count = (
            len(list(decisions_dir.glob("promotion-decision-*.yaml")))
            if decisions_dir.is_dir()
            else 0
        )

        return {
            "total": int(adr_data.get("total_adrs", 0)),
            "global_count": int(adr_data.get("global_count", 0)),
            "project_count": int(adr_data.get("project_count", 0)),
            "adrs": adr_data.get("adrs", []),
            "lineage_tiers": {
                "pattern_proposals_present": proposals_file.is_file(),
                "promotion_recommendations_present": recs_file.is_file(),
                "promotion_decisions_count": decision_count,
                "project_adrs_count": int(adr_data.get("project_count", 0)),
                "global_patterns_count": len(
                    load_patterns_catalogue(target_dir=self.target_dir)
                ),
            },
        }

    def get_patterns(self) -> dict[str, Any]:
        """Return all ratified patterns with invariants and anti-patterns."""
        catalogue = load_patterns_catalogue(target_dir=self.target_dir)
        patterns = [
            {
                "id": str(item.get("id", "")),
                "name": str(item.get("name", item.get("id", ""))),
                "category": str(item.get("category", "general")),
                "status": str(item.get("status", "ratified")),
                "invariants": list(item.get("invariants") or []),
                "anti_patterns": list(item.get("anti_patterns") or []),
            }
            for item in catalogue
        ]
        return {
            "total": len(patterns),
            "patterns": patterns,
        }

    def get_flows(self) -> dict[str, Any]:
        """Return all registered orchestration flows from registry.py."""
        flow_data = explain_flows(self.target_dir)
        return {
            "total": int(flow_data.get("total_flows", 0)),
            "flows": flow_data.get("flows", []),
        }

    def simulate_routing(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Simulate Path A/B/C routing in memory via PlanRouter without disk writes."""
        files = payload.get("files") or []
        patterns = payload.get("patterns") or []
        exception_id = payload.get("exception_id")

        if not isinstance(files, list) or not all(isinstance(f, str) for f in files):
            raise ValueError("'files' must be a list of strings")
        if not isinstance(patterns, list) or not all(
            isinstance(p, str) for p in patterns
        ):
            raise ValueError("'patterns' must be a list of strings")
        if exception_id is not None and not isinstance(exception_id, str):
            raise ValueError("'exception_id' must be a string or null")

        lines: list[str] = []
        if exception_id and exception_id.strip():
            lines.append(f"exception: {exception_id.strip()}")
        for pat in patterns:
            if pat.strip():
                lines.append(f"pattern: {pat.strip()}")
        for entry in files:
            stripped = entry.strip()
            if not stripped:
                continue
            dep_match = _NEW_DEP_PATTERN.match(stripped)
            if dep_match:
                lines.append(f"pattern: {dep_match.group(1)}")
            else:
                lines.append(stripped)

        router = PlanRouter(target_dir=self.target_dir, project=self.project)
        decision = router.route_plan_content("\n".join(lines), dry_run=True)

        return {
            "path": decision.path.value,
            "status": decision.status,
            "matched_patterns": decision.matched_patterns,
            "unmapped_dependencies": decision.unmapped_dependencies,
            "exception_record_path": decision.exception_record_path,
            "reasons": decision.reasons,
            "dry_run": True,
        }

    def get_c4_architecture(self) -> dict[str, Any]:
        """Return Level 2 containers and Level 3 internal components + wiring."""
        is_cas_host = (
            self.project == "ideas-to-life-cas"
            and (self.target_dir / "src" / "cas_runner").is_dir()
        )
        if not is_cas_host:
            return self._build_dynamic_c4_architecture()

        containers = {
            "cas_runner.cli": {
                "id": "cas_runner.cli",
                "title": "cas_runner.cli",
                "subtitle": "Unified CLI, Rich HUD & Local Web",
                "path": "src/cas_runner/cli.py",
                "color": "#38bdf8",
                "components": [
                    {
                        "id": "cli_main",
                        "name": "cli.main()",
                        "role": "Argparse & Command Dispatch",
                        "path": "src/cas_runner/cli.py",
                    },
                    {
                        "id": "cmd_run",
                        "name": "cmd_run",
                        "role": "Flow Execution Entrypoint",
                        "path": "src/cas_runner/cli.py",
                    },
                    {
                        "id": "cmd_governance",
                        "name": "cmd_governance",
                        "role": "Lint, Verify, Bands & Watch",
                        "path": "src/cas_runner/cli.py",
                    },
                    {
                        "id": "cmd_explain",
                        "name": "cmd_explain",
                        "role": "Read-Only Introspection CLI",
                        "path": "src/cas_runner/cli.py",
                    },
                    {
                        "id": "cmd_config",
                        "name": "cmd_config",
                        "role": "5-Tier Config Inspection",
                        "path": "src/cas_runner/cli.py",
                    },
                    {
                        "id": "cmd_ui",
                        "name": "cmd_ui",
                        "role": "Local Web Cockpit Server",
                        "path": "src/cas_runner/ui/server.py",
                    },
                    {
                        "id": "cmd_dashboard",
                        "name": "cmd_dashboard",
                        "role": "Adaptive Rich/MD Terminal HUD",
                        "path": "src/cas_runner/dashboard/cockpit.py",
                    },
                ],
                "edges": [
                    ["cli_main", "cmd_run", "dispatches"],
                    ["cli_main", "cmd_governance", "dispatches"],
                    ["cli_main", "cmd_explain", "dispatches"],
                    ["cli_main", "cmd_config", "dispatches"],
                    ["cli_main", "cmd_ui", "serves"],
                    ["cli_main", "cmd_dashboard", "renders"],
                ],
            },
            "cas_runner.governance": {
                "id": "cas_runner.governance",
                "title": "cas_runner.governance",
                "subtitle": "Linter, Verifier & Proportionate Router",
                "path": "src/cas_runner/governance/",
                "color": "#38bdf8",
                "components": [
                    {
                        "id": "architecture_linter",
                        "name": "architecture_linter",
                        "role": "AST Rules ARCH-LINT-001..004",
                        "path": "src/cas_runner/governance/architecture_linter.py",
                    },
                    {
                        "id": "plan_router",
                        "name": "plan_router",
                        "role": "Path A / B / C Classifier",
                        "path": "src/cas_runner/governance/plan_router.py",
                    },
                    {
                        "id": "diff_verifier",
                        "name": "diff_verifier",
                        "role": "3-Pass SDD/TDD Diff Gate",
                        "path": "src/cas_runner/governance/diff_verifier.py",
                    },
                    {
                        "id": "control_bands",
                        "name": "control_bands",
                        "role": "Western Electric 1-sigma/2-sigma/3-sigma",
                        "path": "src/cas_runner/governance/control_bands.py",
                    },
                    {
                        "id": "sdlc_profile",
                        "name": "sdlc_profile",
                        "role": ".cas/config.yaml Resolver",
                        "path": "src/cas_runner/governance/sdlc_profile.py",
                    },
                    {
                        "id": "explain",
                        "name": "explain",
                        "role": "Deterministic Discovery API",
                        "path": "src/cas_runner/governance/explain.py",
                    },
                ],
                "edges": [
                    ["sdlc_profile", "plan_router", "resolves artifacts"],
                    ["plan_router", "diff_verifier", "routes Path A/B/C"],
                    ["architecture_linter", "control_bands", "feeds violations"],
                    ["explain", "control_bands", "reads status"],
                ],
            },
            "cas_runner.steps": {
                "id": "cas_runner.steps",
                "title": "cas_runner.steps",
                "subtitle": "24 Flows, Step Registry & Contracts",
                "path": "src/cas_runner/steps/",
                "color": "#a855f7",
                "components": [
                    {
                        "id": "registry",
                        "name": "registry",
                        "role": "24 Declared Flow Pipelines",
                        "path": "src/cas_runner/steps/registry.py",
                    },
                    {
                        "id": "ingestion",
                        "name": "ingestion/",
                        "role": "Source & Repo Scanners",
                        "path": "src/cas_runner/steps/ingestion/",
                    },
                    {
                        "id": "forensic",
                        "name": "forensic/",
                        "role": "AST Coupling & Diagnostics",
                        "path": "src/cas_runner/steps/forensic/",
                    },
                    {
                        "id": "intent",
                        "name": "intent/",
                        "role": "AID & Spec Synthesis",
                        "path": "src/cas_runner/steps/intent/",
                    },
                    {
                        "id": "reconciler",
                        "name": "reconciler/",
                        "role": "Semantic Drift Reconciliation",
                        "path": "src/cas_runner/steps/reconciler/",
                    },
                ],
                "edges": [
                    ["registry", "ingestion", "orchestrates"],
                    ["ingestion", "forensic", "feeds AST"],
                    ["forensic", "reconciler", "detects drift"],
                    ["reconciler", "intent", "updates AID"],
                ],
            },
            "cas_runner.config": {
                "id": "cas_runner.config",
                "title": "cas_runner.config",
                "subtitle": "5-Tier Precedence Cascade (.cas/config.yaml)",
                "path": "src/cas_runner/config.py",
                "color": "#94a3b8",
                "components": [
                    {
                        "id": "load_config",
                        "name": "load_config()",
                        "role": "5-Tier Merge Entrypoint",
                        "path": "src/cas_runner/config.py",
                    },
                    {
                        "id": "config_cascade",
                        "name": "ConfigCascade",
                        "role": "Flag > Local > Global > Env > Default",
                        "path": "src/cas_runner/config.py",
                    },
                    {
                        "id": "llm_settings",
                        "name": "LLMSettings",
                        "role": "Provider-Agnostic Model Config",
                        "path": "src/cas_runner/config.py",
                    },
                    {
                        "id": "gov_settings",
                        "name": "GovernanceSettings",
                        "role": "Strict/Advisory & Bands Paths",
                        "path": "src/cas_runner/config.py",
                    },
                ],
                "edges": [
                    ["load_config", "config_cascade", "resolves"],
                    ["config_cascade", "llm_settings", "hydrates"],
                    ["config_cascade", "gov_settings", "hydrates"],
                ],
            },
            "knowledge/": {
                "id": "knowledge/",
                "title": "knowledge/",
                "subtitle": "Global Decisions, Project ADRs & AEMs",
                "path": "knowledge/",
                "color": "#34d399",
                "components": [
                    {
                        "id": "global_decisions",
                        "name": "global/decisions/",
                        "role": "Cross-Project Global ADRs",
                        "path": "knowledge/global/decisions/",
                    },
                    {
                        "id": "project_adrs",
                        "name": f"projects/{self.project}/adrs/",
                        "role": "Project Living ADRs (SSOT)",
                        "path": f"knowledge/projects/{self.project}/adrs/",
                    },
                    {
                        "id": "evolution_maps",
                        "name": "evolution-maps/",
                        "role": "Living AEM & Topology Maps",
                        "path": f"knowledge/projects/{self.project}/evolution-maps/",
                    },
                    {
                        "id": "promo_decisions",
                        "name": "promotion-decisions/",
                        "role": "4-Tier Lineage Decisions",
                        "path": f"knowledge/projects/{self.project}/governance/promotion-decisions/",
                    },
                ],
                "edges": [
                    ["promo_decisions", "project_adrs", "promotes to"],
                    ["project_adrs", "global_decisions", "elevates"],
                    ["project_adrs", "evolution_maps", "shapes"],
                ],
            },
            "src/cas_skills": {
                "id": "src/cas_skills",
                "title": "src/cas_skills",
                "subtitle": "39 Patterns & Continuous Evals",
                "path": "src/cas_skills/",
                "color": "#c084fc",
                "components": [
                    {
                        "id": "patterns_catalogue",
                        "name": "patterns-catalogue.yaml",
                        "role": "39 Ratified Invariants & Anti-Patterns",
                        "path": "src/cas_skills/patterns/patterns-catalogue.yaml",
                    },
                    {
                        "id": "evals",
                        "name": "evals/",
                        "role": "Deterministic Skill Eval Harness",
                        "path": "src/cas_skills/evals/",
                    },
                    {
                        "id": "skills",
                        "name": "skills/",
                        "role": "SKILL.md Prevention Contracts",
                        "path": "src/cas_skills/",
                    },
                ],
                "edges": [
                    ["patterns_catalogue", "skills", "enforces invariants"],
                    ["evals", "skills", "validates compliance"],
                ],
            },
        }
        return {
            "level": 2,
            "project": self.project,
            "boundary_label": "CAS PLATFORM RUNTIME BOUNDARY (Python 3.13+)",
            "containers": containers,
        }

    def _build_dynamic_c4_architecture(self) -> dict[str, Any]:
        """Dynamically project Level 2 containers and Level 3 components from self.target_dir."""
        palette = ["#38bdf8", "#a855f7", "#34d399", "#94a3b8", "#fbbf24", "#f472b6"]
        containers: dict[str, dict[str, Any]] = {}
        ignored = {
            ".git",
            ".venv",
            "venv",
            "node_modules",
            "__pycache__",
            ".pytest_cache",
            ".ruff_cache",
            "dist",
            "build",
        }

        coupling = self._get_cached_coupling()
        for idx, item in enumerate(coupling[:4]):
            pkg = str(item.get("package", "")).strip()
            if not pkg:
                continue
            pkg_rel = str(item.get("path") or pkg.replace(".", "/"))
            pkg_dir = self.target_dir / pkg_rel
            if not pkg_dir.is_dir() and (self.target_dir / "src" / pkg_rel).is_dir():
                pkg_dir = self.target_dir / "src" / pkg_rel
                pkg_rel = f"src/{pkg_rel}"
            comps: list[dict[str, Any]] = []
            if pkg_dir.is_dir():
                for py_file in sorted(pkg_dir.glob("*.py"))[:6]:
                    comp_id = f"{pkg}.{py_file.stem}".replace(".", "_")
                    comps.append(
                        {
                            "id": comp_id,
                            "name": py_file.name,
                            "role": f"Module in {pkg}",
                            "path": py_file.relative_to(self.target_dir).as_posix(),
                        }
                    )
            if not comps:
                comps.append(
                    {
                        "id": pkg.replace(".", "_"),
                        "name": pkg,
                        "role": "Discovered Python Package",
                        "path": pkg_rel,
                    }
                )
            edges = [
                [comps[i]["id"], comps[i + 1]["id"], "imports"]
                for i in range(len(comps) - 1)
            ]
            ca = int(item.get("ca", 0))
            ce = int(item.get("ce", 0))
            dist = float(item.get("distance", 0.0))
            containers[pkg] = {
                "id": pkg,
                "title": pkg,
                "subtitle": f"Ca={ca} Ce={ce} D={dist:.2f}",
                "path": pkg_rel,
                "color": palette[idx % len(palette)],
                "components": comps,
                "edges": edges,
            }

        if not containers:
            for idx, entry in enumerate(sorted(self.target_dir.iterdir())):
                if (
                    not entry.is_dir()
                    or entry.name in ignored
                    or entry.name.startswith(".")
                ):
                    continue
                files = [
                    f
                    for f in sorted(entry.rglob("*"))
                    if f.is_file() and not any(p in ignored for p in f.parts)
                ][:6]
                comps = [
                    {
                        "id": f"{entry.name}_{i}",
                        "name": f.name,
                        "role": f"Source in {entry.name}/",
                        "path": f.relative_to(self.target_dir).as_posix(),
                    }
                    for i, f in enumerate(files)
                ]
                containers[entry.name] = {
                    "id": entry.name,
                    "title": entry.name,
                    "subtitle": f"{len(files)} file(s) discovered",
                    "path": f"{entry.name}/",
                    "color": palette[idx % len(palette)],
                    "components": comps,
                    "edges": [],
                }
                if len(containers) >= 4:
                    break

        if (self.target_dir / ".cas").is_dir():
            containers[".cas/"] = {
                "id": ".cas/",
                "title": ".cas/ (Governance)",
                "subtitle": "Patterns, Rules, Bands & Hooks",
                "path": ".cas/",
                "color": "#c084fc",
                "components": [
                    {
                        "id": "cas_config",
                        "name": "config.yaml",
                        "role": "Project CAS Runtime Config",
                        "path": ".cas/config.yaml",
                    },
                    {
                        "id": "cas_patterns",
                        "name": "patterns-catalogue.yaml",
                        "role": "Target Repo Ratified Patterns",
                        "path": ".cas/patterns/patterns-catalogue.yaml",
                    },
                ],
                "edges": [["cas_config", "cas_patterns", "governs"]],
            }

        adr_summary = self.get_adrs()
        containers["knowledge/"] = {
            "id": "knowledge/",
            "title": "knowledge/ (SSOT)",
            "subtitle": f"{adr_summary['global_count']} Global + {adr_summary['project_count']} Project ADRs",
            "path": "knowledge/",
            "color": "#34d399",
            "components": [
                {
                    "id": "global_decisions",
                    "name": "global/decisions/",
                    "role": "Cross-Project Global ADRs",
                    "path": "knowledge/global/decisions/",
                },
                {
                    "id": "project_adrs",
                    "name": f"projects/{self.project}/adrs/",
                    "role": f"{self.project} Living ADRs (SSOT)",
                    "path": f"knowledge/projects/{self.project}/adrs/",
                },
            ],
            "edges": [["project_adrs", "global_decisions", "elevates"]],
        }

        return {
            "level": 2,
            "project": self.project,
            "boundary_label": f"{self.project.upper()} SYSTEM BOUNDARY",
            "containers": containers,
        }

    def _load_proposals_index(self, proj_dir: Path) -> dict[str, dict[str, Any]]:
        if self._proposals_cache is not None:
            return self._proposals_cache
        index: dict[str, dict[str, Any]] = {}
        prop_dir = proj_dir / "proposed-patterns"
        for fname in (
            "structural-pattern-proposals.yaml",
            "pattern-proposals.yaml",
            "agentic-pattern-proposals.yaml",
        ):
            fpath = prop_dir / fname
            if not fpath.is_file():
                continue
            try:
                loaded = yaml.safe_load(fpath.read_text(encoding="utf-8")) or {}
            except Exception:
                continue
            entries: list[Any] = []
            if isinstance(loaded, dict):
                for val in loaded.values():
                    if isinstance(val, list):
                        entries.extend(val)
            elif isinstance(loaded, list):
                entries = loaded
            for item in entries:
                if isinstance(item, dict):
                    pid = str(item.get("pattern_id") or item.get("id") or "")
                    if pid and pid not in index:
                        index[pid] = {"source": str(fpath), "data": item}
        self._proposals_cache = index
        return index

    def _load_recommendations_index(self, proj_dir: Path) -> dict[str, dict[str, Any]]:
        if self._recommendations_cache is not None:
            return self._recommendations_cache
        index: dict[str, dict[str, Any]] = {}
        recs_file = proj_dir / "governance" / "pattern-promotion-recommendations.yaml"
        if recs_file.is_file():
            try:
                loaded = yaml.safe_load(recs_file.read_text(encoding="utf-8")) or {}
                candidates = (
                    loaded.get("promotion_candidates", [])
                    if isinstance(loaded, dict)
                    else []
                )
                for item in candidates:
                    if isinstance(item, dict):
                        pid = str(item.get("pattern_id") or "")
                        if pid:
                            index[pid] = {"source": str(recs_file), "data": item}
            except Exception:
                pass
        self._recommendations_cache = index
        return index

    def get_adr_lineage(self, adr_id: str | None = None) -> dict[str, Any]:
        """Resolve the 5-tier governance lineage and artefact content for an ADR."""
        adr_data = explain_adrs(self.target_dir)
        adrs = adr_data.get("adrs", [])
        if not adrs:
            raise KeyError(adr_id or "default")

        selected: dict[str, Any] | None = None
        if adr_id:
            for item in adrs:
                if item.get("id") == adr_id:
                    selected = item
                    break
            if selected is None:
                raise KeyError(adr_id)
        else:
            for item in adrs:
                if item.get("id") == "adr-declarative-agent-command-registry":
                    selected = item
                    break
            if selected is None:
                selected = adrs[0]

        adr_file = Path(str(selected.get("file_path", "")))
        adr_content = adr_file.read_text(encoding="utf-8") if adr_file.is_file() else ""
        fm = extract_frontmatter(adr_content) if adr_content else {}

        pattern_id = str(
            fm.get("pattern_id")
            or fm.get("decision_target")
            or selected.get("decision_target")
            or str(selected.get("id", "")).removeprefix("adr-")
        )
        ws_path = Path(adr_data.get("workspace_path", self.target_dir / "knowledge"))
        proj = str(adr_data.get("project", self.project))
        proj_dir = ws_path / "projects" / proj

        # Tier 1: Proposal
        proposals_idx = self._load_proposals_index(proj_dir)
        prop_entry = proposals_idx.get(pattern_id)
        if prop_entry:
            tier_proposal = {
                "id": pattern_id,
                "present": True,
                "source": prop_entry["source"],
                "content": yaml.safe_dump(prop_entry["data"], sort_keys=False),
            }
        else:
            tier_proposal = {
                "id": f"PP ({pattern_id})",
                "present": False,
                "source": str(proj_dir / "proposed-patterns"),
                "content": f"# No structural pattern proposal entry found for '{pattern_id}'.\n# Global or standalone ADRs may originate directly from ARB/design reviews.",
            }

        # Tier 2: Recommendation
        recs_idx = self._load_recommendations_index(proj_dir)
        rec_entry = recs_idx.get(pattern_id)
        if rec_entry:
            tier_rec = {
                "id": f"recommendation-{pattern_id}",
                "present": True,
                "source": rec_entry["source"],
                "content": yaml.safe_dump(rec_entry["data"], sort_keys=False),
            }
        else:
            tier_rec = {
                "id": f"PR ({pattern_id})",
                "present": False,
                "source": str(
                    proj_dir / "governance" / "pattern-promotion-recommendations.yaml"
                ),
                "content": f"# No promotion recommendation entry found for '{pattern_id}'.",
            }

        # Tier 3: Promotion Decision
        source_dec = fm.get("source_decision") or f"promotion-decision-{pattern_id}"
        dec_file = (
            proj_dir / "governance" / "promotion-decisions" / f"{source_dec}.yaml"
        )
        if dec_file.is_file():
            tier_dec = {
                "id": str(source_dec),
                "present": True,
                "source": str(dec_file),
                "content": dec_file.read_text(encoding="utf-8"),
            }
        else:
            tier_dec = {
                "id": f"PD ({pattern_id})",
                "present": False,
                "source": str(dec_file),
                "content": f"# No promotion decision file found at {dec_file.name}.",
            }

        # Tier 4: Living ADR
        tier_adr = {
            "id": str(selected.get("id", "")),
            "present": bool(adr_content),
            "source": str(adr_file),
            "content": adr_content or "# ADR file content unavailable.",
        }

        # Tier 5: Global Pattern
        cat_source = str(get_patterns_catalogue_path(target_dir=self.target_dir))
        catalogue = load_patterns_catalogue(target_dir=self.target_dir)
        matched_pat = next(
            (p for p in catalogue if str(p.get("id", "")) == pattern_id),
            None,
        )
        if matched_pat:
            tier_pat = {
                "id": str(matched_pat.get("id", pattern_id)),
                "present": True,
                "source": cat_source,
                "content": yaml.safe_dump(matched_pat, sort_keys=False),
            }
        else:
            tier_pat = {
                "id": pattern_id,
                "present": False,
                "source": cat_source,
                "content": f"# No ratified global pattern in patterns-catalogue.yaml matching '{pattern_id}'.",
            }

        return {
            "adr_id": str(selected.get("id", "")),
            "pattern_id": pattern_id,
            "scope": str(selected.get("scope", "project")),
            "status": str(selected.get("status", "unknown")),
            "tiers": {
                "proposal": tier_proposal,
                "recommendation": tier_rec,
                "decision": tier_dec,
                "adr": tier_adr,
                "pattern": tier_pat,
            },
        }

    def get_explain_output(self, topic: str) -> dict[str, Any]:
        """Return deterministic CLI-formatted output for Quick Architecture Actions."""
        normalized = topic.strip().lower()
        if normalized == "flows":
            payload = explain_flows(self.target_dir)
            lines = [
                f"Registered Orchestration Flows ({payload.get('total_flows', 0)} total):",
                "",
            ]
            for f in payload.get("flows", []):
                steps = " -> ".join(f.get("steps", []))
                lines.append(
                    f"  - {f.get('name')} ({f.get('step_count', 0)} steps): {steps}"
                )
            output = "\n".join(lines)
            cmd = "cas explain flows"
            workspace = "flows"
        elif normalized == "control-loops":
            payload = explain_control_loops(self.target_dir)
            lines = [str(payload.get("overview", "CAS Control Loops")), ""]
            for lp in payload.get("loops", []):
                lines.append(f"  - {lp.get('name')} Loop: {lp.get('purpose')}")
                for mech in lp.get("mechanisms", []):
                    lines.append(f"      • {mech}")
            output = "\n".join(lines)
            cmd = "cas explain control-loops"
            workspace = "architecture"
        elif normalized == "adrs":
            payload = explain_adrs(self.target_dir)
            lines = [
                f"Unified Living ADR Registry ({payload.get('total_adrs', 0)} total: "
                f"{payload.get('global_count', 0)} Global, {payload.get('project_count', 0)} Project):",
                "",
            ]
            for a in payload.get("adrs", []):
                lines.append(
                    f"  - [{str(a.get('scope', 'project')).upper()}] {a.get('id')} "
                    f"({a.get('status', 'unknown')}): {a.get('title', '')}"
                )
            output = "\n".join(lines)
            cmd = "cas explain adrs --all"
            workspace = "decisions"
        elif normalized == "bands":
            bands = self._get_cached_bands().to_dict()
            lines = [
                f"Control Bands Evaluation ({bands.get('config_path', '.cas/bands.yaml')})",
                f"Highest Band: {bands.get('highest_band', 'ok')} | 3-sigma Breach: {bands.get('has_3sigma_breach', False)}",
                "",
            ]
            for res in bands.get("results", []):
                lines.append(
                    f"  - {res.get('metric')}: observed={res.get('observed_value')} "
                    f"[{res.get('band')}] (1-sigma={res.get('threshold_1sigma')}, 2-sigma={res.get('threshold_2sigma')}, 3-sigma={res.get('threshold_3sigma')}) -> action={res.get('action')}"
                )
                for diag in res.get("diagnostics", []):
                    lines.append(f"      • {diag}")
            output = "\n".join(lines)
            cmd = "cas governance check-bands"
            workspace = "health"
        else:
            raise ValueError(f"Unknown explain topic: {topic}")

        return {
            "topic": normalized,
            "command": cmd,
            "workspace": workspace,
            "output": output,
        }

    def get_sdlc_status(self) -> dict[str, Any]:
        """Return live 6-stage SDLC cockpit state from SDD artifacts, IntentVerifier, PlanRouter, and Linter."""
        now = time.monotonic()
        if (
            self._sdlc_cache is not None
            and (now - self._sdlc_cache[0]) < self._cache_ttl
        ):
            return self._sdlc_cache[1]

        resolver = SDLCProfileResolver(target_dir=self.target_dir)
        resolved = resolver.resolve()
        branch = resolver.get_git_branch()

        # Stage 1: Intent & Zero-Hallucination Evidence
        verifier = IntentVerifier(target_dir=self.target_dir)
        target_intent = verifier.resolve_target_file()
        if target_intent is not None:
            rep = verifier.verify_artifact(target_intent)
            intent_payload: dict[str, Any] = {
                "artifact_path": str(rep.artifact_path),
                "status": rep.artifact_status,
                "is_valid": bool(rep.is_valid),
                "valid_anchors_count": int(rep.valid_anchors_count),
                "blocking_questions_count": int(rep.blocking_questions_count),
                "anchors": [
                    {
                        "file": str(getattr(a, "file_path", "")),
                        "line": getattr(a, "line_number", None),
                        "valid": bool(getattr(a, "exists", False)),
                        "in_bounds": bool(getattr(a, "line_in_bounds", True)),
                    }
                    for a in rep.anchors[:15]
                ],
                "presumptions": [
                    {"text": str(getattr(p, "text", str(p)))}
                    for p in rep.presumptions[:10]
                ],
                "open_questions": [
                    {
                        "text": str(getattr(q, "text", str(q))),
                        "blocking": bool(getattr(q, "is_blocking", False)),
                    }
                    for q in rep.open_questions[:10]
                ],
            }
        else:
            intent_payload = {
                "artifact_path": None,
                "status": "missing",
                "is_valid": False,
                "valid_anchors_count": 0,
                "blocking_questions_count": 0,
                "anchors": [],
                "presumptions": [],
                "open_questions": [],
            }

        # Stage 3: Plan routing (dry-run)
        plan_rel = resolved.plan_files[0] if resolved.plan_files else None
        plan_payload: dict[str, Any] = {
            "file": plan_rel,
            "path": "Unrouted",
            "status": "pending",
            "matched_patterns": [],
            "missing_sections": list(resolved.missing_plan_sections),
        }
        if plan_rel and (self.target_dir / plan_rel).is_file():
            plan_text = (self.target_dir / plan_rel).read_text(encoding="utf-8")
            decision = PlanRouter(
                target_dir=self.target_dir, project=self.project
            ).route_plan_content(plan_text, dry_run=True)
            plan_payload["path"] = decision.path.value
            plan_payload["status"] = decision.status
            plan_payload["matched_patterns"] = list(decision.matched_patterns)

        # Stage 4: Tasks / TDD progress
        tasks_rel = resolved.tasks_files[0] if resolved.tasks_files else None
        tasks_total = 0
        tasks_done = 0
        if tasks_rel and (self.target_dir / tasks_rel).is_file():
            ttext = (self.target_dir / tasks_rel).read_text(encoding="utf-8")
            tasks_done = len(re.findall(r"(?m)^\s*-\s*\[[xX]\]", ttext))
            tasks_open = len(re.findall(r"(?m)^\s*-\s*\[\s\]", ttext))
            tasks_total = tasks_done + tasks_open
        tasks_payload = {
            "file": tasks_rel,
            "total": tasks_total,
            "completed": tasks_done,
            "remaining": max(0, tasks_total - tasks_done),
        }

        # Stage 5 & 6: Lint & Control Bands
        lint_report = self._get_cached_lint()
        lint_findings = [
            {
                "rule_id": str(getattr(f, "rule_id", "")),
                "severity": str(getattr(f, "severity", "warning")),
                "file": str(getattr(f, "file_path", "")),
                "line": getattr(f, "line", None),
                "message": str(getattr(f, "message", "")),
            }
            for f in getattr(lint_report, "findings", [])
        ]
        lint_payload = {
            "violation_count": len(lint_findings),
            "findings": lint_findings[:20],
        }
        bands = self._get_cached_bands()

        stage1_done = (
            bool(intent_payload["artifact_path"])
            and intent_payload["blocking_questions_count"] == 0
        )
        stage2_done = bool(resolved.spec_files) and len(lint_findings) == 0
        stage3_done = plan_payload["status"] == "approved"
        stage4_done = tasks_total > 0 and tasks_done == tasks_total

        stages = [
            {
                "stage": 1,
                "label": "1. Intent",
                "status": "completed" if stage1_done else "active",
                "sub": f"[A] {intent_payload['valid_anchors_count']} | [Q] {intent_payload['blocking_questions_count']}",
                "details": f"Artifact: {intent_payload['artifact_path'] or 'none'} (status: {intent_payload['status']})",
                "cli_command": "uv run cas governance verify-intent --target-dir .",
            },
            {
                "stage": 2,
                "label": "2. Design",
                "status": "completed"
                if stage2_done
                else ("active" if stage1_done else "pending"),
                "sub": f"Lint: {len(lint_findings)} err | {len(load_patterns_catalogue(target_dir=self.target_dir))} Pat",
                "details": f"Spec: {resolved.spec_files[0] if resolved.spec_files else 'none'} | Profile: {resolved.profile_name}",
                "cli_command": "uv run cas governance lint --target-dir .",
            },
            {
                "stage": 3,
                "label": "3. Plan",
                "status": "completed"
                if stage3_done
                else ("active" if stage2_done else "pending"),
                "sub": plan_payload["path"],
                "details": f"Plan: {plan_rel or 'none'} | Patterns: {', '.join(plan_payload['matched_patterns']) or 'none'}",
                "cli_command": "uv run cas governance route-plan --target-dir .",
            },
            {
                "stage": 4,
                "label": "4. Tasks / TDD",
                "status": "completed"
                if stage4_done
                else ("active" if stage3_done else "pending"),
                "sub": f"{tasks_done}/{tasks_total} Tasks"
                if tasks_total
                else "No tasks.md",
                "details": f"Tasks file: {tasks_rel or 'none'} ({tasks_done} completed, {max(0, tasks_total - tasks_done)} remaining)",
                "cli_command": 'uv run --active pytest -k "not trio"',
            },
            {
                "stage": 5,
                "label": "5. Verifier",
                "status": "active" if stage4_done else "pending",
                "sub": "3-Pass Critic",
                "details": "Runs Pass 1 (SDD/TDD alignment), Pass 2 (Security), Pass 3 (CAS Invariants & Linter).",
                "cli_command": "uv run cas governance verify-diff --target-dir .",
            },
            {
                "stage": 6,
                "label": "6. Maintain",
                "status": "completed" if not bands.has_3sigma_breach else "active",
                "sub": f"Bands: {bands.highest_band}",
                "details": f"Control Bands config: {bands.config_path} | 3-sigma breach: {bands.has_3sigma_breach}",
                "cli_command": "uv run cas governance check-bands --target-dir .",
            },
        ]

        payload = {
            "profile": resolved.profile_name,
            "branch": branch,
            "feature_dir": resolved.feature_dir,
            "artifacts": {
                "intent": resolved.intent_files[:5],
                "spec": resolved.spec_files,
                "plan": resolved.plan_files,
                "tasks": resolved.tasks_files,
                "tests": resolved.test_files[:10],
            },
            "intent": intent_payload,
            "plan": plan_payload,
            "tasks": tasks_payload,
            "lint": lint_payload,
            "stages": stages,
        }
        self._sdlc_cache = (now, payload)
        return payload

    def _resolve_feature_since(self, resolved: Any) -> str | None:
        """Resolve active feature start ISO timestamp from git branch commits or spec artifact mtime."""
        candidates: list[str] = []
        try:
            proc = subprocess.run(
                ["git", "log", "main..HEAD", "--format=%aI"],
                cwd=self.target_dir,
                capture_output=True,
                text=True,
                timeout=3,
                check=False,
            )
            if proc.returncode == 0 and proc.stdout.strip():
                lines = [ln.strip() for ln in proc.stdout.splitlines() if ln.strip()]
                if lines:
                    candidates.append(lines[-1])
        except Exception:
            pass

        artifact_paths = (
            list(getattr(resolved, "spec_files", []) or [])
            + list(getattr(resolved, "plan_files", []) or [])
            + list(getattr(resolved, "tasks_files", []) or [])
        )
        birthtimes: list[float] = []
        for rel in artifact_paths:
            p = self.target_dir / rel
            if p.is_file():
                try:
                    st = p.stat()
                    birthtimes.append(getattr(st, "st_birthtime", st.st_mtime))
                except OSError:
                    continue
        if birthtimes:
            dt = datetime.fromtimestamp(min(birthtimes), tz=UTC)
            candidates.append(dt.strftime("%Y-%m-%dT%H:%M:%S"))

        if not candidates:
            return None
        return min(candidates)

    def _build_sdlc_insight_cards(
        self, metrics: dict[str, Any], sdlc_status: dict[str, Any]
    ) -> list[dict[str, Any]]:
        """Build deterministic feature-SDLC economics, latency, and governance insight cards."""
        econ = metrics.get("economics", {})
        cards = self._build_step_insight_cards(econ, scope_label="feature")

        summary = econ.get("summary", {})
        if int(summary.get("trace_count") or 0) == 0:
            cards.append(
                {
                    "id": "sdlc-no-traces",
                    "severity": "Architecture",
                    "heuristic": "sdlc_zero_traces",
                    "title": "No Telemetry Recorded in Active Feature Window",
                    "description": "No reasoning traces matched the active feature window yet.",
                    "recommendation": "Run a CAS flow (`uv run cas run ...`) to capture model, token, and latency attribution for this feature.",
                    "target": sdlc_status.get("branch") or self.project,
                    "metric_value": 0,
                }
            )

        intent = sdlc_status.get("intent", {})
        blocking_q = int(intent.get("blocking_questions_count") or 0)
        if blocking_q > 0:
            cards.append(
                {
                    "id": "sdlc-blocking-questions",
                    "severity": "Warning",
                    "heuristic": "sdlc_blocking_questions",
                    "title": f"{blocking_q} Blocking [Q] Question(s) Open",
                    "description": "Unresolved blocking questions in the active spec/plan delay Stage 1-2 completion.",
                    "recommendation": "Resolve blocking [Q] items in the active specification before continuing implementation.",
                    "target": intent.get("artifact_path") or "spec",
                    "metric_value": blocking_q,
                }
            )

        tasks = sdlc_status.get("tasks", {})
        remaining = int(tasks.get("remaining") or 0)
        if remaining > 0:
            cards.append(
                {
                    "id": "sdlc-tasks-remaining",
                    "severity": "Optimization",
                    "heuristic": "sdlc_tasks_remaining",
                    "title": f"{remaining} Implementation Task(s) Remaining",
                    "description": f"{tasks.get('completed', 0)}/{tasks.get('total', 0)} tasks completed in {tasks.get('file') or 'tasks.md'}.",
                    "recommendation": "Continue TDD execution on remaining tasks and run `uv run cas governance verify-diff --target-dir .`.",
                    "target": tasks.get("file") or "tasks.md",
                    "metric_value": remaining,
                }
            )
        return cards

    def get_sdlc_metrics(self) -> dict[str, Any]:
        """Return active-feature-scoped economics, performance, and feature SDLC insights."""
        resolver = SDLCProfileResolver(target_dir=self.target_dir)
        resolved = resolver.resolve()
        branch = resolver.get_git_branch()
        feature_files = (
            resolved.spec_files or resolved.plan_files or resolved.tasks_files
        )
        feature_dir = str(Path(feature_files[0]).parent) if feature_files else None
        since = self._resolve_feature_since(resolved)
        metrics = self._data_access.get_feature_sdlc_metrics(
            branch=branch,
            feature_dir=feature_dir,
            since=since,
        )
        sdlc_status = self.get_sdlc_status()
        metrics["insights"] = self._build_sdlc_insight_cards(metrics, sdlc_status)
        return metrics

    def _build_deterministic_insight(
        self, workspace: str, context: dict[str, Any]
    ) -> str:
        """Synthesize actionable next-step guidance deterministically when LLM is unavailable."""
        if workspace == "sdlc":
            sdlc_ctx = context.get("sdlc", context)
            feat = context.get("feature_metrics", {}).get("economics_summary", {})
            lines = [
                f"Active Branch: {sdlc_ctx.get('branch', 'unknown')} (Profile: {sdlc_ctx.get('profile', 'auto')})",
                f"Feature Spend: ${float(feat.get('total_cost_usd', 0.0)):.4f} | {int(feat.get('total_tokens', 0)):,} tokens ({int(feat.get('trace_count', 0))} traces)",
                "",
                "Recommended Next Actions:",
            ]
            intent = sdlc_ctx.get("intent", {})
            plan = sdlc_ctx.get("plan", {})
            tasks = sdlc_ctx.get("tasks", {})
            lint = sdlc_ctx.get("lint", {})
            if intent.get("blocking_questions_count", 0) > 0:
                lines.append(
                    f"1. [Stage 1 - Intent] Resolve {intent['blocking_questions_count']} blocking [Q] question(s) in {intent.get('artifact_path')}."
                )
            elif lint.get("violation_count", 0) > 0:
                lines.append(
                    f"1. [Stage 2 - Design] Fix {lint['violation_count']} architecture lint violation(s) via `uv run cas governance lint --target-dir .`."
                )
            elif plan.get("status") != "approved":
                lines.append(
                    f"1. [Stage 3 - Plan] Plan routed as {plan.get('path')} ({plan.get('status')}). Review candidate ADR or exception before coding."
                )
            elif tasks.get("remaining", 0) > 0:
                lines.append(
                    f"1. [Stage 4 - Tasks/TDD] Complete {tasks['remaining']} remaining task(s) in {tasks.get('file')} following Red-Green-Refactor."
                )
            else:
                lines.append(
                    "1. [Stage 5 - Verifier] All tasks complete. Run `uv run cas governance verify-diff --target-dir .` and invoke the fresh-context verifier."
                )
            lines.append(
                '2. Run `uv run --active pytest -k "not trio"` and `uv run cas governance review-pr --target-dir .` before opening/merging PR.'
            )
            return "\n".join(lines)

        if workspace == "routing":
            sim = context.get("simulation", {})
            path_label = str(sim.get("path", "Path B"))
            unmapped = sim.get("unmapped_dependencies", [])
            matched = sim.get("matched_patterns", [])
            candidates = context.get("candidate_patterns", [])
            lines = [f"Routing Guidance for {path_label}:", ""]
            if path_label.startswith("Path A"):
                lines.append(
                    f"1. Already Path A (Governed Reuse) via {', '.join(matched) or 'ratified patterns'}. Proceed with TDD."
                )
            else:
                lines.append(
                    f"1. Unmapped dependencies ({', '.join(unmapped) or 'none'}) triggered {path_label}."
                )
                if candidates:
                    lines.append(
                        f"2. Closest ratified patterns in patterns-catalogue.yaml to reuse for Path A: {', '.join(candidates[:5])}."
                    )
                lines.append(
                    "3. Replace novel/unmapped tokens with an existing ratified pattern or draft a Candidate ADR (Path B) / exc-*.yaml (Path C)."
                )
            return "\n".join(lines)

        if workspace == "architecture":
            cid = str(context.get("container_id", "cas_runner"))
            comp_names = [c.get("name", "") for c in context.get("components", [])]
            edges = context.get("edges", [])
            metric = context.get("martin_metric") or {}
            lines = [
                f"Container Summary: `{cid}` ({context.get('subtitle', '')})",
                "",
                f"1. Components ({len(comp_names)}): {', '.join(comp_names) or 'none'}.",
                f"2. Internal Wiring: {len(edges)} declared dependency edge(s) within `{context.get('path', cid)}`.",
            ]
            if metric:
                lines.append(
                    f"3. Martin Coupling: Ca={metric.get('ca')}, Ce={metric.get('ce')}, "
                    f"I={float(metric.get('instability', 0.0)):.2f}, A={float(metric.get('abstractness', 0.0)):.2f}, "
                    f"D={float(metric.get('distance', 0.0)):.4f} ({'FLAGGED > 0.5' if metric.get('zone_violation') else 'OK'})."
                )
            else:
                lines.append(
                    "3. Boundary Health: Non-Python or top-level container; governed by CAS SSOT & patterns-catalogue.yaml."
                )
            return "\n".join(lines)

        # workspace == "health"
        pkgs = context.get("packages", [])
        flagged = [p for p in pkgs if p.get("zone_violation")]
        lines = [
            f"Forensic Coupling & Control Bands Summary ({len(flagged)} flagged package(s) with D > 0.50):",
            "",
        ]
        for idx, pkg in enumerate(flagged[:4], start=1):
            inst = float(pkg.get("instability", 0.0))
            abst = float(pkg.get("abstractness", 0.0))
            if abst > 0.5 and inst > 0.5:
                advice = "Zone of Uselessness (high A, high I): inline unused abstractions or add concrete implementations."
            elif abst < 0.3 and inst < 0.5:
                advice = "Zone of Pain (low A, low I): extract a Protocol/ABC boundary to decouple dependents."
            else:
                advice = "Rebalance afferent/efferent imports toward Main Sequence (A + I = 1)."
            lines.append(
                f"{idx}. `{pkg.get('package')}` (D={float(pkg.get('distance', 0.0)):.4f}, I={inst:.2f}, A={abst:.2f}) -> {advice}"
            )
        if not flagged:
            lines.append(
                "1. All packages sit within Main Sequence bounds (D <= 0.50). No structural refactoring required."
            )
        cb = context.get("control_bands", {})
        if cb.get("highest_band") != "ok":
            lines.append(
                f"- Control Band Alert: highest band is `{cb.get('highest_band')}`. Inspect code anchors and monitor trend."
            )
        for card in context.get("insight_cards", []):
            lines.append(
                f"- [{card.get('severity')}] {card.get('title')}: {card.get('recommendation')}"
            )
        return "\n".join(lines)

    def _build_step_insight_cards(
        self, economics: dict[str, Any], scope_label: str = "project"
    ) -> list[dict[str, Any]]:
        """Evaluate deterministic cost-dominator and latency-bottleneck heuristics on steps."""
        cards: list[dict[str, Any]] = []
        for step in economics.get("step_breakdown", []):
            share = float(step.get("cost_share_pct") or 0.0)
            if share > 35.0:
                cards.append(
                    {
                        "id": f"cost-{step.get('name')}",
                        "severity": "Optimization",
                        "heuristic": "cost_dominator",
                        "title": f"Cost Dominator: {step.get('name')}",
                        "description": f"Step '{step.get('name')}' consumes {share:.1f}% of total {scope_label} spend (${float(step.get('total_cost_usd', 0.0)):.4f}).",
                        "recommendation": "Enable prompt caching, trim context schema, or route to a lower-cost model tier.",
                        "target": str(step.get("name")),
                        "metric_value": share,
                    }
                )
            p90 = float(step.get("p90_latency_s") or 0.0)
            if p90 > 8.0:
                cards.append(
                    {
                        "id": f"latency-{step.get('name')}",
                        "severity": "Warning",
                        "heuristic": "latency_bottleneck",
                        "title": f"Latency Bottleneck: {step.get('name')}",
                        "description": f"Step '{step.get('name')}' has P90 latency of {p90:.2f}s (> 8.0s threshold).",
                        "recommendation": "Consider asynchronous delegation, parallel fan-out, or batch reduction.",
                        "target": str(step.get("name")),
                        "metric_value": p90,
                    }
                )
        return cards

    def _build_health_insight_cards(
        self,
        economics: dict[str, Any],
        quality: dict[str, Any],
        martin: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Evaluate deterministic Wave 8.1 heuristics across economics, latency, coupling, and evals."""
        cards = self._build_step_insight_cards(economics, scope_label="project")

        for pkg in martin.get("packages", []):
            dist = float(pkg.get("distance") or 0.0)
            if dist > 0.50 or pkg.get("zone_violation"):
                cards.append(
                    {
                        "id": f"coupling-{pkg.get('package')}",
                        "severity": "Architecture",
                        "heuristic": "martin_coupling",
                        "title": f"Coupling Drift: {pkg.get('package')}",
                        "description": f"Package '{pkg.get('package')}' has Martin distance D={dist:.2f} (> 0.50).",
                        "recommendation": "Extract a Protocol/ABC boundary or rebalance afferent/efferent dependencies.",
                        "target": str(pkg.get("package")),
                        "metric_value": dist,
                    }
                )

        evals = quality.get("evaluations", {})
        total_evals = int(evals.get("total_evals") or 0)
        pass_rate = float(evals.get("pass_rate_pct") or 100.0)
        if total_evals > 0 and pass_rate < 90.0:
            cards.append(
                {
                    "id": "eval-degradation",
                    "severity": "Warning",
                    "heuristic": "eval_degradation",
                    "title": f"Eval Pass Rate Degradation ({pass_rate:.1f}%)",
                    "description": f"Skill evaluation pass rate dropped to {pass_rate:.1f}% (< 90.0% target) across {total_evals} cases.",
                    "recommendation": "Run `uv run cas skills eval` and inspect failing assertions for prompt or provider drift.",
                    "target": self.project,
                    "metric_value": pass_rate,
                }
            )
        return cards

    def generate_insights(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Generate on-demand architect/developer recommendations via LiteLLMClient with deterministic fallback."""
        workspace = str(payload.get("workspace") or "").strip().lower()
        if workspace not in {"sdlc", "health", "routing", "architecture"}:
            raise ValueError(
                "'workspace' must be 'sdlc', 'health', 'routing', or 'architecture'"
            )

        user_ctx = (
            payload.get("context") if isinstance(payload.get("context"), dict) else {}
        )

        if workspace == "sdlc":
            sdlc_status = self.get_sdlc_status()
            sdlc_metrics = self.get_sdlc_metrics()
            context = {
                "sdlc": sdlc_status,
                "feature_metrics": {
                    "scope": sdlc_metrics.get("scope", {}),
                    "economics_summary": sdlc_metrics.get("economics", {}).get(
                        "summary", {}
                    ),
                    "models": sdlc_metrics.get("economics", {}).get("models", [])[:5],
                    "performance_overall": sdlc_metrics.get("performance", {}).get(
                        "overall", {}
                    ),
                },
                "insight_cards": sdlc_metrics.get("insights", []),
            }
            instruction = (
                "You are a CAS Enterprise Architect Copilot. Given the live 6-stage SDLC state and "
                "active feature reasoning economics/performance, provide 3 concise, prioritized next steps "
                "covering governance readiness, cost optimization, and latency."
            )
        elif workspace == "routing":
            catalogue = load_patterns_catalogue(target_dir=self.target_dir)
            candidate_ids = [str(p.get("id", "")) for p in catalogue if p.get("id")]
            context = {
                "simulation": user_ctx,
                "candidate_patterns": candidate_ids[:15],
            }
            instruction = (
                "You are a CAS Enterprise Architect Copilot. Given a Path A/B/C routing simulation result "
                "and ratified patterns from patterns-catalogue.yaml, explain which existing patterns fit best "
                "and how to adapt the change to qualify for Path A (Governed Reuse)."
            )
        elif workspace == "architecture":
            c4 = self.get_c4_architecture().get("containers", {})
            cid = str(user_ctx.get("container_id") or "cas_runner.governance")
            container = c4.get(cid) or next(iter(c4.values()), {})
            martin_pkgs = self.get_martin_metrics().get("packages", [])
            matched_metric = next(
                (
                    p
                    for p in martin_pkgs
                    if p.get("package") == cid
                    or cid.endswith(str(p.get("package", "")))
                ),
                None,
            )
            context = {
                "container_id": container.get("id", cid),
                "subtitle": container.get("subtitle", ""),
                "path": container.get("path", ""),
                "components": container.get("components", []),
                "edges": container.get("edges", []),
                "martin_metric": matched_metric,
            }
            instruction = (
                "You are a CAS Enterprise Architect Copilot. Summarize this C4 container's responsibilities, "
                "internal component wiring, and Martin coupling health in plain English for an engineer."
            )
        else:
            martin = self.get_martin_metrics()
            lint = self._get_cached_lint()
            economics = self.get_economics_metrics()
            quality = self.get_quality_metrics()
            insight_cards = self._build_health_insight_cards(economics, quality, martin)
            context = {
                "packages": martin.get("packages", [])[:8],
                "flagged_count": martin.get("flagged_count", 0),
                "control_bands": martin.get("control_bands", {}),
                "lint_violations": len(getattr(lint, "findings", [])),
                "economics_summary": economics.get("summary", {}),
                "eval_pass_rate_pct": quality.get("evaluations", {}).get(
                    "pass_rate_pct", 100.0
                ),
                "insight_cards": insight_cards,
            }
            instruction = (
                "You are a CAS Enterprise Architect Copilot. Given Robert C. Martin (Ca, Ce, I, A, D) metrics, "
                "Western Electric control bands, reasoning economics, and skill eval quality, explain what the architect/engineer should refactor or optimize."
            )

        prompt = f"Workspace: {workspace}\nLive CAS Telemetry JSON:\n{json.dumps(context, indent=2)}"
        cards_out = (
            context.get("insight_cards", []) if workspace in {"health", "sdlc"} else []
        )
        try:
            client = get_llm_client(target_dir=self.target_dir)
            response = client.generate(
                prompt,
                instruction=instruction,
                name=f"cockpit-insights-{workspace}",
            )
            raw_content = getattr(response, "content", None)
            if raw_content is None:
                raw_content = getattr(response, "text", "")
            text = str(raw_content or "").strip()
            if not text:
                raise RuntimeError("Empty LLM response")
            out: dict[str, Any] = {
                "workspace": workspace,
                "mode": "llm",
                "source": "llm",
                "model": str(getattr(client, "model_name", "llm")),
                "insight": text,
            }
            if workspace in {"health", "sdlc"}:
                out["insights"] = cards_out
            return out
        except Exception as exc:
            out = {
                "workspace": workspace,
                "mode": "deterministic-fallback",
                "source": "deterministic",
                "model": "deterministic-advisor",
                "insight": self._build_deterministic_insight(workspace, context),
                "fallback_reason": str(exc),
            }
            if workspace in {"health", "sdlc"}:
                out["insights"] = cards_out
            return out


class CockpitRequestHandler(BaseHTTPRequestHandler):
    """HTTP handler serving the offline 5+1 SPA and `/api/*` endpoints."""

    service: CockpitService

    def log_message(self, format: str, *args: Any) -> None:
        """Silence default stderr access logs during CLI/test execution."""
        return

    def _send_bytes(self, status: int, content_type: str, data: bytes) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _send_json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, indent=2).encode("utf-8")
        self._send_bytes(status, "application/json; charset=utf-8", body)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        if path in ("/", "/index.html"):
            if not STATIC_INDEX_PATH.is_file():
                self._send_json(
                    HTTPStatus.NOT_FOUND,
                    {"error": f"Static asset not found: {STATIC_INDEX_PATH}"},
                )
                return
            html_bytes = STATIC_INDEX_PATH.read_bytes()
            self._send_bytes(HTTPStatus.OK, "text/html; charset=utf-8", html_bytes)
            return

        if path == "/api/lineage":
            adr_id = (query.get("adr_id") or [None])[0]
            try:
                self._send_json(HTTPStatus.OK, self.service.get_adr_lineage(adr_id))
            except KeyError as exc:
                self._send_json(
                    HTTPStatus.NOT_FOUND, {"error": f"ADR not found: {exc.args[0]}"}
                )
            return

        if path == "/api/explain":
            topic = (query.get("topic") or ["flows"])[0]
            try:
                self._send_json(HTTPStatus.OK, self.service.get_explain_output(topic))
            except ValueError as exc:
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            return

        routes = {
            "/api/health": self.service.get_health,
            "/api/metrics/martin": self.service.get_martin_metrics,
            "/api/metrics/economics": self.service.get_economics_metrics,
            "/api/metrics/performance": self.service.get_performance_metrics,
            "/api/metrics/quality": self.service.get_quality_metrics,
            "/api/adrs": self.service.get_adrs,
            "/api/patterns": self.service.get_patterns,
            "/api/flows": self.service.get_flows,
            "/api/architecture/c4": self.service.get_c4_architecture,
            "/api/sdlc": self.service.get_sdlc_status,
            "/api/sdlc/metrics": self.service.get_sdlc_metrics,
        }
        handler = routes.get(path)
        if handler is None:
            self._send_json(HTTPStatus.NOT_FOUND, {"error": f"Not found: {path}"})
            return

        self._send_json(HTTPStatus.OK, handler())

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path not in ("/api/simulate-routing", "/api/insights"):
            self._send_json(HTTPStatus.NOT_FOUND, {"error": f"Not found: {path}"})
            return

        try:
            content_len = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._send_json(HTTPStatus.BAD_REQUEST, {"error": "Invalid Content-Length"})
            return

        raw_body = self.rfile.read(content_len) if content_len > 0 else b"{}"
        try:
            payload = json.loads(raw_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._send_json(HTTPStatus.BAD_REQUEST, {"error": f"Malformed JSON: {exc}"})
            return

        if not isinstance(payload, dict):
            self._send_json(
                HTTPStatus.BAD_REQUEST,
                {"error": "JSON payload must be an object"},
            )
            return

        try:
            if path == "/api/insights":
                result = self.service.generate_insights(payload)
            else:
                result = self.service.simulate_routing(payload)
        except ValueError as exc:
            self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            return

        self._send_json(HTTPStatus.OK, result)


class _CockpitHTTPServer(ThreadingHTTPServer):
    """ThreadingHTTPServer with SO_REUSEADDR enabled for fast local restarts."""

    allow_reuse_address = True


def create_server(
    target_dir: Path | str = ".",
    port: int = 8080,
    host: str = "127.0.0.1",
    project: str | None = None,
) -> ThreadingHTTPServer:
    """Create a configured ThreadingHTTPServer bound to ``host:port``."""
    service = CockpitService(target_dir=target_dir, project=project, port=port)
    service.warm_caches()

    class _BoundHandler(CockpitRequestHandler):
        pass

    _BoundHandler.service = service
    return _CockpitHTTPServer((host, port), _BoundHandler)
