"""GitHub Actions repository Variables & Secrets adapter backed by `gh` CLI."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

from cas_runner.config import CASConfig
from cas_runner.governance.env_checker import resolve_github_repo_slug

_VALID_GH_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

KNOWN_CAS_VARIABLES: tuple[tuple[str, str], ...] = (
    ("CAS_PROJECT", "Active CAS project identifier"),
    (
        "KNOWLEDGE_REPO_NAME",
        "Central CAS knowledge repository (e.g. cas-brain/knowledge)",
    ),
    (
        "CAS_PORTAL_REPO",
        "GitHub Pages repository for architecture portal publishing",
    ),
    ("CAS_PORTAL_CNAME", "Optional custom domain CNAME for architecture portal"),
)

KNOWN_CAS_SECRETS: tuple[tuple[str, str], ...] = (
    (
        "CAS_KNOWLEDGE_BRAIN",
        "Fine-grained PAT with read/write access to central knowledge repo",
    ),
    ("HF_TOKEN", "Hugging Face API token for CI reasoning steps"),
    ("GEMINI_API_KEY", "Google Gemini API key for CI reasoning steps"),
    ("CAS_SYNC_PAT", "PAT for managed steering sync pull requests"),
    (
        "CAS_PORTAL_TOKEN",
        "Token for publishing architecture portal to external GitHub Pages repo",
    ),
    ("CAS_DIST_TOKEN", "Token for publishing distribution releases"),
)


def validate_gh_name(name: str) -> str:
    """Validate a GitHub Actions variable or secret name."""
    cleaned = str(name or "").strip()
    if not cleaned or not _VALID_GH_NAME_RE.match(cleaned):
        raise ValueError(
            f"Invalid GitHub Actions name '{name}'. Must match ^[A-Za-z_][A-Za-z0-9_]*$."
        )
    return cleaned


def _resolve_repo_for_gh(target_dir: Path | str) -> str:
    slug = resolve_github_repo_slug(target_dir)
    if slug.startswith("<owner>/") or "/" not in slug:
        raise ValueError(
            "No GitHub 'origin' remote found for the active repository."
        )
    return slug


def _run_gh(
    args: list[str],
    *,
    input_data: str | None = None,
    timeout: int = 10,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["gh", *args],
        input=input_data,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )


def _check_gh_preconditions(target_dir: Path | str) -> tuple[bool, bool, str, str | None]:
    """Return `(gh_installed, authenticated, repo_slug, error_message)`."""
    slug = resolve_github_repo_slug(target_dir)
    if not shutil.which("gh"):
        return (
            False,
            False,
            slug,
            "GitHub CLI ('gh') is not installed or not in PATH.",
        )

    auth = _run_gh(["auth", "status"])
    if auth.returncode != 0:
        detail = (auth.stderr or auth.stdout or "").strip()
        msg = (
            f"GitHub CLI is not authenticated ({detail}). Run `gh auth login`."
            if detail
            else "GitHub CLI is not authenticated. Run `gh auth login`."
        )
        return True, False, slug, msg

    if slug.startswith("<owner>/") or "/" not in slug:
        return (
            True,
            True,
            slug,
            "No GitHub 'origin' remote found for the active repository.",
        )

    return True, True, slug, None


def _local_variable_suggestion(target_dir: Path | str, name: str) -> str:
    env_val = os.getenv(name)
    if env_val and env_val.strip():
        return env_val.strip()
    if name == "CAS_PROJECT":
        try:
            return CASConfig.resolve(target_dir=target_dir).config.project.name
        except Exception:
            return ""
    if name == "KNOWLEDGE_REPO_NAME":
        return "cas-brain/knowledge"
    return ""


def get_github_actions_state(target_dir: Path | str = ".") -> dict[str, Any]:
    """Return active repo slug, `gh` status, variables, secrets (names only), and CAS readiness."""
    available, authenticated, slug, err = _check_gh_preconditions(target_dir)
    variables: list[dict[str, Any]] = []
    secrets: list[dict[str, Any]] = []

    if available and authenticated and err is None:
        v_res = _run_gh(
            ["variable", "list", "-R", slug, "--json", "name,value,updatedAt"]
        )
        if v_res.returncode == 0 and v_res.stdout.strip():
            try:
                parsed_v = json.loads(v_res.stdout)
                if isinstance(parsed_v, list):
                    variables = parsed_v
            except json.JSONDecodeError:
                err = "Failed to parse `gh variable list` JSON output."
        elif v_res.returncode != 0:
            err = (v_res.stderr or v_res.stdout or "Failed to list GitHub variables.").strip()

        s_res = _run_gh(["secret", "list", "-R", slug, "--json", "name,updatedAt"])
        if s_res.returncode == 0 and s_res.stdout.strip():
            try:
                parsed_s = json.loads(s_res.stdout)
                if isinstance(parsed_s, list):
                    secrets = [
                        {"name": item.get("name", ""), "updatedAt": item.get("updatedAt", "")}
                        for item in parsed_s
                        if isinstance(item, dict)
                    ]
            except json.JSONDecodeError:
                err = err or "Failed to parse `gh secret list` JSON output."
        elif s_res.returncode != 0:
            err = err or (s_res.stderr or s_res.stdout or "Failed to list GitHub secrets.").strip()

    var_names = {str(v.get("name", "")) for v in variables}
    sec_names = {str(s.get("name", "")) for s in secrets}

    known_variables = [
        {
            "name": name,
            "description": desc,
            "configured_in_github": name in var_names,
            "local_suggestion": _local_variable_suggestion(target_dir, name),
        }
        for name, desc in KNOWN_CAS_VARIABLES
    ]

    known_secrets = [
        {
            "name": name,
            "description": desc,
            "configured_in_github": name in sec_names,
            "local_available": bool((os.getenv(name) or "").strip()),
        }
        for name, desc in KNOWN_CAS_SECRETS
    ]

    return {
        "available": available,
        "authenticated": authenticated,
        "repo": slug,
        "error": err,
        "variables": variables,
        "secrets": secrets,
        "known_variables": known_variables,
        "known_secrets": known_secrets,
    }


def _ensure_gh_ready(target_dir: Path | str) -> str:
    if not shutil.which("gh"):
        raise ValueError("GitHub CLI ('gh') is not installed or not in PATH.")
    return _resolve_repo_for_gh(target_dir)


def set_github_variable(
    target_dir: Path | str, name: str, value: str
) -> dict[str, Any]:
    """Create or update a repository-level GitHub Actions variable."""
    clean_name = validate_gh_name(name)
    slug = _ensure_gh_ready(target_dir)
    res = _run_gh(
        ["variable", "set", clean_name, "-R", slug],
        input_data=str(value if value is not None else ""),
    )
    if res.returncode != 0:
        raise ValueError(
            (res.stderr or res.stdout or f"Failed to set variable '{clean_name}'.").strip()
        )
    return {"status": "saved", "kind": "variable", "name": clean_name, "repo": slug}


def delete_github_variable(target_dir: Path | str, name: str) -> dict[str, Any]:
    """Delete a repository-level GitHub Actions variable."""
    clean_name = validate_gh_name(name)
    slug = _ensure_gh_ready(target_dir)
    res = _run_gh(["variable", "delete", clean_name, "-R", slug])
    if res.returncode != 0:
        raise ValueError(
            (res.stderr or res.stdout or f"Failed to delete variable '{clean_name}'.").strip()
        )
    return {"status": "deleted", "kind": "variable", "name": clean_name, "repo": slug}


def set_github_secret(
    target_dir: Path | str, name: str, value: str
) -> dict[str, Any]:
    """Create or update a repository-level GitHub Actions secret via stdin."""
    clean_name = validate_gh_name(name)
    if not isinstance(value, str) or not value:
        raise ValueError("Secret value must be a non-empty string.")
    slug = _ensure_gh_ready(target_dir)
    res = _run_gh(["secret", "set", clean_name, "-R", slug], input_data=value)
    if res.returncode != 0:
        raise ValueError(
            (res.stderr or res.stdout or f"Failed to set secret '{clean_name}'.").strip()
        )
    return {"status": "saved", "kind": "secret", "name": clean_name, "repo": slug}


def delete_github_secret(target_dir: Path | str, name: str) -> dict[str, Any]:
    """Delete a repository-level GitHub Actions secret."""
    clean_name = validate_gh_name(name)
    slug = _ensure_gh_ready(target_dir)
    res = _run_gh(["secret", "delete", clean_name, "-R", slug])
    if res.returncode != 0:
        raise ValueError(
            (res.stderr or res.stdout or f"Failed to delete secret '{clean_name}'.").strip()
        )
    return {"status": "deleted", "kind": "secret", "name": clean_name, "repo": slug}


def sync_from_local(
    target_dir: Path | str, kind: str, name: str
) -> dict[str, Any]:
    """Push a local environment variable or CASConfig value to GitHub Actions."""
    clean_kind = str(kind or "").lower().strip()
    clean_name = validate_gh_name(name)
    if clean_kind == "secret":
        val = (os.getenv(clean_name) or "").strip()
        if not val:
            raise ValueError(
                f"Local environment variable '{clean_name}' is not set."
            )
        return set_github_secret(target_dir, clean_name, val)
    if clean_kind == "variable":
        val = _local_variable_suggestion(target_dir, clean_name)
        if not val:
            raise ValueError(
                f"No local value or suggestion available for variable '{clean_name}'."
            )
        return set_github_variable(target_dir, clean_name, val)
    raise ValueError("Field 'kind' must be 'variable' or 'secret'.")
