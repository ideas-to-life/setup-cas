import glob
import json
import math
import time
from pathlib import Path
from typing import Any

from cas_runner.io import get_provider, get_telemetry_root


def _compute_percentile(values: list[float], pct: float) -> float:
    """Compute linear-interpolated percentile (0-100) for a non-empty list of floats."""
    if not values:
        return 0.0
    ordered = sorted(values)
    if len(ordered) == 1:
        return round(ordered[0], 4)
    rank = (pct / 100.0) * (len(ordered) - 1)
    lo = math.floor(rank)
    hi = min(lo + 1, len(ordered) - 1)
    frac = rank - lo
    return round(ordered[lo] + (ordered[hi] - ordered[lo]) * frac, 4)


class DashboardDataAccess:
    """
    Data access layer for the Governance Dashboard.
    Provides synthesized views of governance artifacts.
    When project is None, aggregates metrics across all onboarded projects in the workspace.
    """

    def __init__(
        self,
        project: str | None = None,
        target_dir: str | Path | None = None,
        cache_ttl_seconds: float = 10.0,
    ):
        self.project = project
        self.target_dir = (
            Path(target_dir).resolve() if target_dir else Path.cwd().resolve()
        )
        self.provider = get_provider()
        self._cache_ttl = cache_ttl_seconds
        self._telemetry_cache: tuple[float, str, dict[str, Any]] | None = None
        self._quality_cache: tuple[float, dict[str, Any]] | None = None

    def _get_project_ids(self) -> list[str]:
        if not hasattr(self.provider, "base"):
            return []
        p_dir = self.provider.base / "projects"
        if not p_dir.exists():
            return []
        return [p.name for p in sorted(p_dir.iterdir()) if p.is_dir()]

    def _parse_coverage_summary(
        self, latest_assessment: dict[str, Any] | None
    ) -> list[dict[str, str]]:
        if not latest_assessment:
            return []

        coverage_section = latest_assessment.get("sections", {}).get(
            "coverage_summary", ""
        )
        if not coverage_section:
            return []

        items = []
        for line in coverage_section.split("\n"):
            line = line.strip()
            if (
                not line.startswith("|")
                or "Architecture Work ID" in line
                or "---|---" in line
            ):
                continue
            parts = [
                p.strip().replace("**", "").replace("`", "") for p in line.split("|")
            ]
            if len(parts) >= 8:
                items.append(
                    {
                        "id": parts[1],
                        "title": parts[2],
                        "current_status": parts[3],
                        "recommended_status": parts[4],
                        "recommended_action": parts[5],
                        "coverage": parts[6],
                        "classification": parts[7],
                    }
                )
        return items

    def _parse_observations(
        self, latest_assessment: dict[str, Any] | None
    ) -> dict[str, int]:
        res = {
            "duplicate_work": 0,
            "oversized_work": 0,
            "runtime_cap_reviews": 0,
            "missing_lineage": 0,
        }
        if not latest_assessment:
            return res

        observations_section = latest_assessment.get("sections", {}).get(
            "appendix:_governance_observations", ""
        )
        if not observations_section:
            return res

        current_sub = None
        missing_lineage_mode = False

        for line in observations_section.split("\n"):
            line = line.strip()
            if line.startswith("### "):
                current_sub = line[4:].lower().strip()
                missing_lineage_mode = False
            elif (
                line.startswith("#### ")
                and current_sub == "oversized architecture work"
            ):
                res["oversized_work"] += 1
            elif line.startswith("-") and current_sub == "orphan runtime capabilities":
                if "cap-" in line:
                    res["runtime_cap_reviews"] += 1
            elif "missing lineage" in line.lower() or "missing_lineage" in line.lower():
                missing_lineage_mode = True
            elif line.startswith("- **") or line.startswith("* **"):
                missing_lineage_mode = False
            elif missing_lineage_mode and (
                line.startswith("-") or line.startswith("*")
            ):
                if "cap-" in line:
                    res["missing_lineage"] += 1
            elif "duplicate" in line.lower():
                res["duplicate_work"] += 1

        return res

    def _load_architecture_work(self) -> list[dict[str, Any]]:
        if self.project:
            return self.provider.load_architecture_work(self.project)
        work_items = []
        for pid in self._get_project_ids():
            work_items.extend(self.provider.load_architecture_work(pid))
        return work_items

    def _load_all_assessments(self) -> list[dict[str, Any]]:
        if not hasattr(self.provider, "base"):
            return []
        assessments = []
        if self.project:
            pattern = (
                self.provider.base / "projects" / self.project / "assessment" / "*.md"
            )
            files = sorted(glob.glob(str(pattern)), reverse=True)
            if files:
                parsed = self.provider._parse_markdown_with_frontmatter(files[0])
                if parsed:
                    assessments.append(parsed)
        else:
            for pid in self._get_project_ids():
                pattern = self.provider.base / "projects" / pid / "assessment" / "*.md"
                files = sorted(glob.glob(str(pattern)), reverse=True)
                if files:
                    parsed = self.provider._parse_markdown_with_frontmatter(files[0])
                    if parsed:
                        assessments.append(parsed)
        return assessments

    def _load_all_alignments(self) -> list[dict[str, Any]]:
        if not hasattr(self.provider, "base"):
            return []
        alignments = []
        if self.project:
            pattern = (
                self.provider.base / "projects" / self.project / "alignment" / "*.md"
            )
            files = sorted(glob.glob(str(pattern)), reverse=True)
            if files:
                parsed = self.provider._parse_markdown_with_frontmatter(files[0])
                if parsed:
                    alignments.append(parsed)
        else:
            for pid in self._get_project_ids():
                pattern = self.provider.base / "projects" / pid / "alignment" / "*.md"
                files = sorted(glob.glob(str(pattern)), reverse=True)
                if files:
                    parsed = self.provider._parse_markdown_with_frontmatter(files[0])
                    if parsed:
                        alignments.append(parsed)
        return alignments

    def _load_all_decisions(self) -> list[dict[str, Any]]:
        if not hasattr(self.provider, "base"):
            return []

        all_files = []
        global_pattern = str(self.provider.base / "global" / "decisions" / "*.md")
        all_files.extend(glob.glob(global_pattern))

        if self.project:
            proj_adrs_pattern = str(
                self.provider.base / "projects" / self.project / "adrs" / "*.md"
            )
            all_files.extend(glob.glob(proj_adrs_pattern))
            proj_decisions_pattern = str(
                self.provider.base / "projects" / self.project / "decisions" / "*.md"
            )
            all_files.extend(glob.glob(proj_decisions_pattern))
        else:
            for pid in self._get_project_ids():
                all_files.extend(
                    glob.glob(
                        str(self.provider.base / "projects" / pid / "adrs" / "*.md")
                    )
                )
                all_files.extend(
                    glob.glob(
                        str(
                            self.provider.base / "projects" / pid / "decisions" / "*.md"
                        )
                    )
                )

        decisions = []
        seen_files = set()

        for f in all_files:
            if f in seen_files or f.endswith("index.md"):
                continue
            seen_files.add(f)

            parsed = self.provider._parse_markdown_with_frontmatter(f)
            if not parsed:
                continue

            adr_project = parsed.get("project")

            if self.project is None or self.project in (
                "global",
                "cas-knowledge-workspace",
            ):
                decisions.append(parsed)
            elif (
                adr_project == self.project
                or f"projects/{self.project}/" in f.replace("\\", "/")
            ):
                decisions.append(parsed)

        return decisions

    def _extract_high_risk_findings(
        self, alignments: list[dict[str, Any]]
    ) -> list[str]:
        high_risks = []
        for alignment_report in alignments:
            if not alignment_report:
                continue
            raw_findings = alignment_report.get("sections", {}).get(
                "alignment_findings", ""
            )
            if not isinstance(raw_findings, str):
                continue
            lines = raw_findings.split("\n")
            for line in lines:
                line = line.strip()
                if line.startswith("- [HIGH]") or line.startswith("- [CRITICAL]"):
                    high_risks.append(line[8:].strip())
        return high_risks

    def get_health_indicators(self) -> dict[str, Any]:
        work_items = self._load_architecture_work()
        alignments = self._load_all_alignments()
        decisions = self._load_all_decisions()
        assessments = self._load_all_assessments()

        active_work = [
            w
            for w in work_items
            if w.get("status") in ["active", "in progress"]
            or w.get("lifecycle_state") == "active"
        ]

        pending_reviews = 0
        verify_evidence = 0
        duplicate_work = 0
        oversized_work = 0
        runtime_cap_reviews = 0
        missing_lineage = 0

        for ass in assessments:
            assessment_items = self._parse_coverage_summary(ass)
            pending_reviews += sum(
                1
                for item in assessment_items
                if "Promote" in item.get("recommended_action", "")
            )
            verify_evidence += sum(
                1
                for item in assessment_items
                if "Verify" in item.get("recommended_action", "")
            )
            debt_counts = self._parse_observations(ass)
            duplicate_work += debt_counts.get("duplicate_work", 0)
            oversized_work += debt_counts.get("oversized_work", 0)
            runtime_cap_reviews += debt_counts.get("runtime_cap_reviews", 0)
            missing_lineage += debt_counts.get("missing_lineage", 0)

        latest_date = None
        for a in alignments:
            d = a.get("frontmatter", {}).get("date")
            if d and (latest_date is None or d > latest_date):
                latest_date = d

        return {
            "active_work_count": len(active_work),
            "pending_decisions_count": len(
                [
                    d
                    for d in decisions
                    if d.get("decision", {}).get("status") == "proposed"
                ]
            ),
            "high_risk_findings": self._extract_high_risk_findings(alignments),
            "latest_alignment_date": latest_date,
            "pending_reviews_count": pending_reviews,
            "verify_evidence_count": verify_evidence,
            "duplicate_work_count": duplicate_work,
            "oversized_work_count": oversized_work,
            "runtime_cap_reviews_count": runtime_cap_reviews,
            "missing_lineage_count": missing_lineage,
        }

    def get_governance_metrics(self) -> dict[str, Any]:
        work_items = self._load_architecture_work()
        decisions = self._load_all_decisions()
        alignments = self._load_all_alignments()
        assessments = self._load_all_assessments()
        operational = self.get_operational_health()

        adr_stats = {}
        for d in decisions:
            gov = d.get("governance") if isinstance(d.get("governance"), dict) else {}
            dec = d.get("decision") if isinstance(d.get("decision"), dict) else {}
            status = (
                gov.get("forum_status")
                if gov.get("forum_decision_date")
                else (
                    dec.get("status")
                    or (
                        d.get("decision")
                        if isinstance(d.get("decision"), str)
                        else None
                    )
                    or d.get("status")
                    or "unknown"
                )
            )
            adr_stats[status] = adr_stats.get(status, 0) + 1

        risk_stats = {"high": 0, "medium": 0, "low": 0}
        for alignment in alignments:
            raw_findings = alignment.get("sections", {}).get("alignment_findings", "")
            if isinstance(raw_findings, str):
                for line in raw_findings.split("\n"):
                    line = line.strip()
                    if "[HIGH]" in line.upper() or "[CRITICAL]" in line.upper():
                        risk_stats["high"] += 1
                    elif "[MEDIUM]" in line.upper():
                        risk_stats["medium"] += 1
                    elif "[LOW]" in line.upper():
                        risk_stats["low"] += 1

        total = len(work_items)
        stable = 0
        ready_for_review = 0
        requires_evidence = 0
        awaiting_impl = 0
        evidence_counts = {"complete": 0, "substantial": 0, "partial": 0, "none": 0}

        all_assessment_items = []
        for ass in assessments:
            items = self._parse_coverage_summary(ass)
            if items:
                all_assessment_items.extend(items)

        if all_assessment_items:
            total = len(all_assessment_items)
            for item in all_assessment_items:
                action = item["recommended_action"].lower()
                status = item["current_status"].lower()
                rec_status = item["recommended_status"].lower()

                if "verify" in action:
                    requires_evidence += 1
                elif "remain done" in action or (
                    status == "done" and rec_status == "done"
                ):
                    stable += 1
                elif "promote" in action:
                    ready_for_review += 1
                else:
                    awaiting_impl += 1

                cov = item["coverage"].lower()
                if "complete" in cov:
                    evidence_counts["complete"] += 1
                elif "substantial" in cov:
                    evidence_counts["substantial"] += 1
                elif "partial" in cov:
                    evidence_counts["partial"] += 1
                else:
                    evidence_counts["none"] += 1
        else:
            active_work = [
                w
                for w in work_items
                if w.get("status") in ["active", "in progress"]
                or w.get("lifecycle_state") == "active"
            ]
            completed_work = [
                w
                for w in work_items
                if w.get("status") in ["done", "completed"]
                or w.get("lifecycle_state") == "completed"
            ]
            stable = len(completed_work)
            awaiting_impl = len(active_work)

        human_approval = {
            "pending_reviews": ready_for_review,
            "ready_for_completion": requires_evidence,
            "blocked": 0,
        }

        debt_counts = {
            "duplicate_work": 0,
            "oversized_work": 0,
            "runtime_cap_reviews": 0,
            "missing_lineage": 0,
        }
        for ass in assessments:
            obs = self._parse_observations(ass)
            for k, v in obs.items():
                debt_counts[k] = debt_counts.get(k, 0) + v

        governance_debt = {
            "duplicate_work": debt_counts.get("duplicate_work", 0),
            "oversized_work": debt_counts.get("oversized_work", 0),
            "runtime_cap_reviews": debt_counts.get("runtime_cap_reviews", 0),
            "missing_lineage": debt_counts.get("missing_lineage", 0),
        }

        return {
            "architecture_work": {
                "total": total,
                "stable": stable,
                "ready_for_review": ready_for_review,
                "requires_evidence_verification": requires_evidence,
                "awaiting_implementation": awaiting_impl,
            },
            "human_approval": human_approval,
            "governance_debt": governance_debt,
            "implementation_evidence": evidence_counts,
            "adr_distribution": adr_stats,
            "risk_counts": risk_stats,
            "operational": operational,
        }

    def get_operational_health(self) -> dict[str, Any]:
        import json

        trace_dir = get_telemetry_root()
        if self.project:
            trace_files = glob.glob(str(trace_dir / f"trace-{self.project}-*.json"))
        else:
            trace_files = glob.glob(str(trace_dir / "trace-*.json"))

        total_tokens = 0
        total_cost = 0.0
        step_metrics = {}

        for tf in trace_files:
            try:
                with open(tf) as f:
                    data = json.load(f)
                    for span in data.get("spans", []):
                        attrs = span.get("attributes", {})
                        tokens = attrs.get("llm.total_tokens", 0)
                        cost = attrs.get("llm.estimated_cost", 0.0)

                        total_tokens += tokens
                        total_cost += cost

                        name = span.get("name", "unknown")
                        if name not in step_metrics:
                            step_metrics[name] = {
                                "cost": 0.0,
                                "tokens": 0,
                                "latency": 0.0,
                                "count": 0,
                            }

                        m = step_metrics[name]
                        m["cost"] += cost
                        m["tokens"] += tokens
                        m["count"] += 1

                        start = span.get("start_time")
                        end = span.get("end_time")
                        if start and end:
                            m["latency"] += end - start
            except Exception:
                continue

        breakdown = []
        for name, m in step_metrics.items():
            breakdown.append(
                {
                    "name": name,
                    "avg_cost": round(m["cost"] / m["count"], 4)
                    if m["count"] > 0
                    else 0,
                    "avg_latency": round(m["latency"] / m["count"], 2)
                    if m["count"] > 0
                    else 0,
                    "total_cost": round(m["cost"], 4),
                    "count": m["count"],
                }
            )

        return {
            "total_recorded_cost": round(total_cost, 4),
            "total_tokens": total_tokens,
            "trace_count": len(trace_files),
            "step_breakdown": sorted(
                breakdown, key=lambda x: x["total_cost"], reverse=True
            ),
        }

    def get_recent_evolution(self, limit: int = 5) -> list[dict[str, Any]]:
        work_items = self._load_architecture_work()
        sorted_work = sorted(work_items, key=lambda x: x.get("date", ""), reverse=True)

        items = []
        for item in sorted_work[:limit]:
            if not item.get("summary"):
                sections = item.get("sections", {})
                fallback_keys = [
                    "summary",
                    "problem_statement",
                    "vision_driver",
                    "why_this_matters",
                    "current_state",
                ]
                summary_text = None
                for k in fallback_keys:
                    if sections.get(k):
                        summary_text = sections[k]
                        break

                if not summary_text:
                    details = item.get("details", "")
                    snippet = details.strip().split("\n\n")[0]
                    summary_text = snippet if snippet else "No description available."

                item["summary"] = summary_text

            items.append(item)

        return items

    def get_cross_artifact_insights(self) -> list[dict[str, Any]]:
        insights = []
        metrics = self.get_governance_metrics()

        active_work = (
            metrics["architecture_work"].get("ready_for_review", 0)
            + metrics["architecture_work"].get("requires_evidence_verification", 0)
            + metrics["architecture_work"].get("awaiting_implementation", 0)
        )
        accepted_adrs = metrics["adr_distribution"].get("accepted", 0)

        if active_work > 0 and accepted_adrs == 0:
            insights.append(
                {
                    "type": "imbalance",
                    "severity": "medium",
                    "description": "System has active architecture work but no accepted ADRs to guide implementation.",
                }
            )
        elif active_work > accepted_adrs * 2:
            insights.append(
                {
                    "type": "velocity",
                    "severity": "low",
                    "description": f"Architecture work ({active_work}) is outpacing decision ratification ({accepted_adrs}).",
                }
            )

        risk_counts = metrics["risk_counts"]
        if risk_counts["high"] > 2:
            insights.append(
                {
                    "type": "risk",
                    "severity": "high",
                    "description": "High concentration of critical governance findings requires immediate attention.",
                }
            )

        return insights

    def _load_project_trace_records(self) -> list[dict[str, Any]]:
        """Load valid project-scoped trace dicts from telemetry root."""
        trace_dir = get_telemetry_root()
        if not trace_dir.exists():
            return []
        if self.project:
            trace_files = sorted(
                glob.glob(str(trace_dir / f"trace-{self.project}-*.json"))
            )
        else:
            trace_files = sorted(glob.glob(str(trace_dir / "trace-*.json")))

        records: list[dict[str, Any]] = []
        for tf in trace_files:
            try:
                with open(tf, encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            trace_proj = data.get("project")
            if self.project and trace_proj and trace_proj != self.project:
                continue
            records.append(data)
        return records

    def _aggregate_trace_dicts(
        self, trace_records: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Aggregate economics and latency metrics across a list of trace dicts."""
        total_tokens = 0
        prompt_tokens = 0
        completion_tokens = 0
        total_cost = 0.0
        matched_trace_count = 0
        all_durations: list[float] = []
        model_stats: dict[tuple[str, str], dict[str, Any]] = {}
        step_stats: dict[str, dict[str, Any]] = {}

        for data in trace_records:
            matched_trace_count += 1
            for span in data.get("spans", []):
                if not isinstance(span, dict):
                    continue
                attrs = span.get("attributes") or {}
                p_tok = int(attrs.get("llm.prompt_tokens") or 0)
                c_tok = int(attrs.get("llm.completion_tokens") or 0)
                t_tok = int(attrs.get("llm.total_tokens") or (p_tok + c_tok))
                cost = float(attrs.get("llm.estimated_cost") or 0.0)
                model = str(attrs.get("llm.model") or "unknown")
                provider = str(attrs.get("llm.provider") or "unknown")
                step_name = str(
                    span.get("name") or attrs.get("cas.step_name") or "unknown"
                )

                start = span.get("start_time")
                end = span.get("end_time")
                duration = (
                    max(0.0, float(end) - float(start))
                    if start is not None and end is not None
                    else 0.0
                )
                if start is not None and end is not None:
                    all_durations.append(duration)

                total_tokens += t_tok
                prompt_tokens += p_tok
                completion_tokens += c_tok
                total_cost += cost

                m_key = (model, provider)
                if m_key not in model_stats:
                    model_stats[m_key] = {
                        "model": model,
                        "provider": provider,
                        "calls": 0,
                        "total_tokens": 0,
                        "prompt_tokens": 0,
                        "completion_tokens": 0,
                        "total_cost_usd": 0.0,
                    }
                ms = model_stats[m_key]
                ms["calls"] += 1
                ms["total_tokens"] += t_tok
                ms["prompt_tokens"] += p_tok
                ms["completion_tokens"] += c_tok
                ms["total_cost_usd"] += cost

                if step_name not in step_stats:
                    step_stats[step_name] = {
                        "name": step_name,
                        "count": 0,
                        "total_tokens": 0,
                        "total_cost_usd": 0.0,
                        "durations": [],
                        "error_count": 0,
                    }
                ss = step_stats[step_name]
                ss["count"] += 1
                ss["total_tokens"] += t_tok
                ss["total_cost_usd"] += cost
                if start is not None and end is not None:
                    ss["durations"].append(duration)
                if str(span.get("status") or "ok").lower() == "error":
                    ss["error_count"] += 1

        models_list = []
        for ms in model_stats.values():
            share = (
                (ms["total_cost_usd"] / total_cost * 100.0) if total_cost > 0 else 0.0
            )
            models_list.append(
                {
                    "model": ms["model"],
                    "provider": ms["provider"],
                    "calls": ms["calls"],
                    "total_tokens": ms["total_tokens"],
                    "prompt_tokens": ms["prompt_tokens"],
                    "completion_tokens": ms["completion_tokens"],
                    "total_cost_usd": round(ms["total_cost_usd"], 4),
                    "cost_share_pct": round(share, 1),
                }
            )
        models_list.sort(key=lambda x: x["total_cost_usd"], reverse=True)

        steps_list = []
        for ss in step_stats.values():
            cnt = ss["count"]
            durs = ss["durations"]
            avg_lat = sum(durs) / len(durs) if durs else 0.0
            p90_lat = _compute_percentile(durs, 90.0) if durs else 0.0
            max_lat = max(durs) if durs else 0.0
            share = (
                (ss["total_cost_usd"] / total_cost * 100.0) if total_cost > 0 else 0.0
            )
            steps_list.append(
                {
                    "name": ss["name"],
                    "count": cnt,
                    "total_tokens": ss["total_tokens"],
                    "total_cost_usd": round(ss["total_cost_usd"], 4),
                    "avg_cost_usd": round(ss["total_cost_usd"] / cnt, 4)
                    if cnt > 0
                    else 0.0,
                    "cost_share_pct": round(share, 1),
                    "avg_latency_s": round(avg_lat, 2),
                    "p90_latency_s": round(p90_lat, 2),
                    "max_latency_s": round(max_lat, 2),
                    "error_count": ss["error_count"],
                }
            )
        steps_list.sort(key=lambda x: x["total_cost_usd"], reverse=True)

        return {
            "project": self.project or "all",
            "trace_count": matched_trace_count,
            "total_cost_usd": round(total_cost, 4),
            "total_tokens": total_tokens,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "avg_cost_per_trace": round(total_cost / matched_trace_count, 4)
            if matched_trace_count > 0
            else 0.0,
            "models": models_list,
            "step_breakdown": steps_list,
            "all_durations": all_durations,
        }

    def _collect_telemetry_aggregates(self) -> dict[str, Any]:
        """Ingest project-scoped trace-*.json files with TTL caching and zero-trace resilience."""
        trace_dir = get_telemetry_root()
        cache_key = f"{self.project or '*'}:{trace_dir}"
        now = time.monotonic()
        if (
            self._telemetry_cache is not None
            and self._telemetry_cache[1] == cache_key
            and (now - self._telemetry_cache[0]) < self._cache_ttl
        ):
            return self._telemetry_cache[2]

        records = self._load_project_trace_records()
        result = self._aggregate_trace_dicts(records)
        self._telemetry_cache = (now, cache_key, result)
        return result

    @staticmethod
    def _build_economics_payload(agg: dict[str, Any]) -> dict[str, Any]:
        return {
            "status": "ok",
            "project": agg["project"],
            "currency": "USD",
            "summary": {
                "total_cost_usd": agg["total_cost_usd"],
                "total_tokens": agg["total_tokens"],
                "prompt_tokens": agg["prompt_tokens"],
                "completion_tokens": agg["completion_tokens"],
                "trace_count": agg["trace_count"],
                "avg_cost_per_trace": agg["avg_cost_per_trace"],
            },
            "models": agg["models"],
            "step_breakdown": agg["step_breakdown"],
        }

    @staticmethod
    def _build_performance_payload(
        agg: dict[str, Any], bottleneck_threshold_s: float = 8.0
    ) -> dict[str, Any]:
        durs = agg["all_durations"]
        avg_overall = round(sum(durs) / len(durs), 2) if durs else 0.0
        p90_overall = round(_compute_percentile(durs, 90.0), 2) if durs else 0.0
        max_overall = round(max(durs), 2) if durs else 0.0

        steps_ranked = sorted(
            [
                {
                    "name": s["name"],
                    "count": s["count"],
                    "avg_latency_s": s["avg_latency_s"],
                    "p90_latency_s": s["p90_latency_s"],
                    "max_latency_s": s["max_latency_s"],
                    "is_bottleneck": s["p90_latency_s"] > bottleneck_threshold_s,
                }
                for s in agg["step_breakdown"]
            ],
            key=lambda x: x["avg_latency_s"],
            reverse=True,
        )
        return {
            "status": "ok",
            "project": agg["project"],
            "bottleneck_threshold_s": bottleneck_threshold_s,
            "overall": {
                "avg_latency_s": avg_overall,
                "p90_latency_s": p90_overall,
                "max_latency_s": max_overall,
                "total_steps": sum(s["count"] for s in agg["step_breakdown"]),
            },
            "steps": steps_ranked,
        }

    def get_reasoning_economics(self) -> dict[str, Any]:
        """Return project-scoped USD spend, token burn, model breakdown, and step economics."""
        agg = self._collect_telemetry_aggregates()
        return self._build_economics_payload(agg)

    def get_performance_metrics(
        self, bottleneck_threshold_s: float = 8.0
    ) -> dict[str, Any]:
        """Return project-scoped latency percentiles and bottleneck step rankings."""
        agg = self._collect_telemetry_aggregates()
        return self._build_performance_payload(agg, bottleneck_threshold_s)

    def get_feature_sdlc_metrics(
        self,
        branch: str | None = None,
        feature_dir: str | None = None,
        since: str | None = None,
        bottleneck_threshold_s: float = 8.0,
        agent_collector: Any | None = None,
        include_agents: bool = True,
    ) -> dict[str, Any]:
        """Return active-feature-scoped economics & performance ('how much' and 'with what')."""
        from cas_runner.dashboard.agent_telemetry import CodingAgentTelemetryCollector

        proj_agg = self._collect_telemetry_aggregates()
        records = self._load_project_trace_records()

        feature_name = Path(feature_dir).name if feature_dir else None
        branch_tagged: list[dict[str, Any]] = []
        if branch or feature_name:
            for rec in records:
                rec_tags = {
                    str(rec.get("branch") or ""),
                    str(rec.get("feature") or ""),
                }
                for span in rec.get("spans", []):
                    if isinstance(span, dict):
                        attrs = span.get("attributes") or {}
                        rec_tags.add(str(attrs.get("git.branch") or ""))
                        rec_tags.add(str(attrs.get("cas.branch") or ""))
                        rec_tags.add(str(attrs.get("cas.feature") or ""))
                rec_tags.discard("")
                if (branch and branch in rec_tags) or (
                    feature_name and feature_name in rec_tags
                ):
                    branch_tagged.append(rec)

        if branch_tagged:
            filtered = branch_tagged
            filter_mode = "branch_tag"
        elif since:
            since_prefix = str(since).replace("Z", "").split("+")[0]
            filtered = [
                rec
                for rec in records
                if str(rec.get("timestamp") or "").replace("Z", "").split("+")[0]
                >= since_prefix
            ]
            filter_mode = "time_window"
        else:
            filtered = records
            filter_mode = "project_all"

        cas_agg = self._aggregate_trace_dicts(filtered)
        agent_records: list[dict[str, Any]] = []
        agents_map: dict[str, Any] = {}
        if include_agents:
            collector = agent_collector or CodingAgentTelemetryCollector()
            collected = collector.collect_trace_records(self.target_dir, since=since)
            agent_records = collected.get("trace_records", [])
            agents_map = collected.get("agents", {})

        feat_agg = self._aggregate_trace_dicts(filtered + agent_records)
        return {
            "status": "ok",
            "project": feat_agg["project"],
            "scope": {
                "branch": branch,
                "feature_dir": feature_dir,
                "since": since,
                "filter_mode": filter_mode,
            },
            "sources": {
                "cas_flows": {
                    "trace_count": cas_agg["trace_count"],
                    "total_cost_usd": cas_agg["total_cost_usd"],
                    "total_tokens": cas_agg["total_tokens"],
                },
                "coding_agents": {
                    "trace_count": len(agent_records),
                    "total_cost_usd": round(
                        sum(
                            float(a.get("cost_usd") or 0.0) for a in agents_map.values()
                        ),
                        4,
                    ),
                    "total_tokens": sum(
                        int(a.get("total_tokens") or 0) for a in agents_map.values()
                    ),
                    "agents": agents_map,
                },
            },
            "economics": self._build_economics_payload(feat_agg),
            "performance": self._build_performance_payload(
                feat_agg, bottleneck_threshold_s
            ),
            "project_totals": {
                "trace_count": proj_agg["trace_count"],
                "total_cost_usd": proj_agg["total_cost_usd"],
                "total_tokens": proj_agg["total_tokens"],
            },
        }

    def get_quality_metrics(self) -> dict[str, Any]:
        """Return skill evaluation pass rates (.cas/runtime/eval-report.json or Tier-1 fallback) and trace evals."""
        now = time.monotonic()
        if (
            self._quality_cache is not None
            and (now - self._quality_cache[0]) < self._cache_ttl
        ):
            return self._quality_cache[1]

        report_path = self.target_dir / ".cas" / "runtime" / "eval-report.json"
        source = "tier1_fallback"
        evaluations: dict[str, Any] = {
            "total_evals": 0,
            "passed": 0,
            "failed": 0,
            "pass_rate_pct": 100.0,
            "skills": [],
        }

        if report_path.is_file():
            try:
                raw = json.loads(report_path.read_text(encoding="utf-8"))
                if isinstance(raw, dict) and "total_evals" in raw:
                    source = "persisted"
                    total_e = int(raw.get("total_evals", 0))
                    passed_e = int(raw.get("passed", 0))
                    failed_e = int(raw.get("failed", max(0, total_e - passed_e)))
                    rate = float(
                        raw.get(
                            "pass_rate_pct",
                            round((passed_e / total_e * 100.0), 1)
                            if total_e > 0
                            else 100.0,
                        )
                    )
                    evaluations = {
                        "total_evals": total_e,
                        "passed": passed_e,
                        "failed": failed_e,
                        "pass_rate_pct": round(rate, 1),
                        "skills": raw.get("skills", []),
                    }
            except Exception:
                source = "tier1_fallback"

        if source == "tier1_fallback":
            try:
                from cas_runner.skills.evaluator import SkillEvaluator
                from cas_runner.skills.models import EvalStatus

                skills_root = self.target_dir / ".cas"
                if not skills_root.is_dir():
                    skills_root = self.target_dir / "src" / "cas_skills"
                evaluator = SkillEvaluator(root_dir=skills_root, provider=None)
                report = evaluator.evaluate()
                total_e = report.total
                passed_e = report.passed
                failed_e = report.failed
                rate = round((passed_e / total_e * 100.0), 1) if total_e > 0 else 100.0
                skill_map: dict[str, dict[str, Any]] = {}
                for res in report.results:
                    entry = skill_map.setdefault(
                        res.skill_name,
                        {
                            "skill": res.skill_name,
                            "eval_count": 0,
                            "passed": 0,
                            "failed": 0,
                            "durations": [],
                        },
                    )
                    entry["eval_count"] += 1
                    if res.status == EvalStatus.PASS:
                        entry["passed"] += 1
                    else:
                        entry["failed"] += 1
                    entry["durations"].append(float(res.duration_ms) / 1000.0)
                skills_out = [
                    {
                        "skill": s["skill"],
                        "eval_count": s["eval_count"],
                        "passed": s["passed"],
                        "failed": s["failed"],
                        "pass_rate_pct": round(s["passed"] / s["eval_count"] * 100.0, 1)
                        if s["eval_count"] > 0
                        else 100.0,
                        "avg_duration_s": round(
                            sum(s["durations"]) / len(s["durations"]), 2
                        )
                        if s["durations"]
                        else 0.0,
                    }
                    for s in skill_map.values()
                ]
                evaluations = {
                    "total_evals": total_e,
                    "passed": passed_e,
                    "failed": failed_e,
                    "pass_rate_pct": rate,
                    "skills": skills_out,
                }
            except Exception as exc:
                import logging

                logging.getLogger(__name__).warning(
                    "Tier-1 SkillEvaluator fallback failed: %s", exc
                )

        # Project-scoped trace-level evaluations from knowledge/runtime/evaluations/
        local_eval_dir = self.target_dir / "knowledge" / "runtime" / "evaluations"
        if local_eval_dir.is_dir():
            eval_dirs = [local_eval_dir]
        elif hasattr(self.provider, "base"):
            eval_dirs = [Path(self.provider.base) / "runtime" / "evaluations"]
        else:
            eval_dirs = []

        trace_eval_scores: list[float] = []
        seen_eval_names: set[str] = set()
        for ed in eval_dirs:
            if not ed.is_dir():
                continue
            pattern = f"eval-{self.project}-*.json" if self.project else "eval-*.json"
            for ef in sorted(ed.glob(pattern)):
                if ef.name in seen_eval_names:
                    continue
                seen_eval_names.add(ef.name)
                try:
                    edata = json.loads(ef.read_text(encoding="utf-8"))
                    if not isinstance(edata, dict):
                        continue
                    if (
                        self.project
                        and edata.get("project")
                        and edata.get("project") != self.project
                    ):
                        continue
                    score = edata.get("overall_score")
                    if score is not None:
                        trace_eval_scores.append(float(score))
                except Exception:
                    continue

        result = {
            "status": "ok",
            "project": self.project or "all",
            "source": source,
            "evaluations": evaluations,
            "trace_evaluations": {
                "count": len(trace_eval_scores),
                "avg_overall_score": round(
                    sum(trace_eval_scores) / len(trace_eval_scores), 3
                )
                if trace_eval_scores
                else 0.0,
            },
        }
        self._quality_cache = (now, result)
        return result
