"""Shared context-scoping and deduplication helpers for pattern lifecycle steps."""

from typing import Any

_KNOWN_PREFIXES = (
    "reference-architecture-",
    "promotion-decision-",
    "recommendation-",
    "proposal-",
    "adr-",
)

_HEAVY_STATE_KEYS = frozenset({"flows", "evidence", "diagnostics"})


def normalize_pattern_id(raw_id: Any) -> str | None:
    """Strip known artifact prefixes to yield a canonical pattern identifier."""
    if not isinstance(raw_id, str) or not raw_id:
        return None
    cleaned = raw_id
    for prefix in _KNOWN_PREFIXES:
        if cleaned.startswith(prefix):
            cleaned = cleaned.removeprefix(prefix)
            break
    return cleaned or None


def _item_pattern_id(item: Any) -> str | None:
    if not isinstance(item, dict):
        return None
    return normalize_pattern_id(item.get("pattern_id") or item.get("id"))


def extract_pattern_ids(items: list[Any]) -> set[str]:
    """Collect normalized pattern IDs from a list of decision, ADR, or pattern dicts."""
    ids: set[str] = set()
    for item in items or []:
        pid = _item_pattern_id(item)
        if pid:
            ids.add(pid)
    return ids


def extract_classified_pattern_ids(classification: Any) -> set[str]:
    """Collect normalized pattern IDs from a pattern_scope_classification payload."""
    if not isinstance(classification, dict):
        return set()
    ids: set[str] = set()
    for bucket in (
        "global_pattern_candidates",
        "project_pattern_candidates",
        "candidate_patterns_requiring_review",
        "duplicate_overlapping_patterns",
    ):
        entries = classification.get(bucket)
        if isinstance(entries, list):
            ids.update(extract_pattern_ids(entries))
    return ids


def filter_items_by_pattern_ids(items: list[Any], pattern_ids: set[str]) -> list[Any]:
    """Return only dict items whose normalized pattern ID is in ``pattern_ids``."""
    if not pattern_ids:
        return []
    return [item for item in (items or []) if _item_pattern_id(item) in pattern_ids]


def filter_proposals_by_pattern_ids(
    proposals: list[Any], pattern_ids: set[str]
) -> list[Any]:
    """Return only proposals whose normalized pattern ID is in ``pattern_ids``."""
    return filter_items_by_pattern_ids(proposals, pattern_ids)


def filter_recommendations_by_pattern_ids(recs_data: Any, pattern_ids: set[str]) -> Any:
    """Filter recommendation lists or dicts to items matching ``pattern_ids``."""
    if not recs_data:
        return [] if isinstance(recs_data, list) else ({} if isinstance(recs_data, dict) else recs_data)

    if isinstance(recs_data, list):
        return filter_items_by_pattern_ids(recs_data, pattern_ids)

    if isinstance(recs_data, dict):
        filtered = dict(recs_data)
        for key in ("recommendations", "promotion_candidates"):
            if isinstance(recs_data.get(key), list):
                filtered[key] = filter_items_by_pattern_ids(recs_data[key], pattern_ids)
        return filtered

    return recs_data


def deduplicate_proposals(
    proposals: list[Any], exclude_ids: set[str] | None = None
) -> list[Any]:
    """Deduplicate proposals by normalized pattern ID and drop excluded IDs."""
    seen: set[str] = set(exclude_ids or ())
    result: list[Any] = []
    for p in proposals or []:
        pid = _item_pattern_id(p)
        if pid:
            if pid in seen:
                continue
            seen.add(pid)
        result.append(p)
    return result


def summarize_architectural_state(state: Any) -> Any:
    """Return a compact architectural state excluding heavy trace/evidence arrays."""
    if not isinstance(state, dict):
        return state
    return {k: v for k, v in state.items() if k not in _HEAVY_STATE_KEYS}
