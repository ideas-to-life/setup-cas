"""CAS Runner - Continuous Architecture System Harness."""

__version__ = "0.2.1"

__all__ = ["__version__"]
