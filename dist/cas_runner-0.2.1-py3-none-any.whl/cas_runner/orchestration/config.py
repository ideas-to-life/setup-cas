from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from cas_runner.config import CASConfig


class ExecutionProfile(BaseModel):
    """Configuration for a single LLM execution."""

    provider: str = "mock"
    model: str = "mock-model"
    temperature: float = 0.0
    max_tokens: int | None = None
    api_base: str | None = None
    extra_params: dict[str, Any] = Field(default_factory=dict)


class ProjectConfiguration(BaseModel):
    """Project-level configuration model."""

    provider: str | None = None
    model: str | None = None
    temperature: float | None = None
    evaluation_enabled: bool = True
    extra_params: dict[str, Any] = Field(default_factory=dict)


class RuntimeConfig(BaseModel):
    """Global configuration state for the CAS runner session."""

    project: str
    default_profile: ExecutionProfile
    environment: str = "development"
    evaluation_enabled: bool = True


class ConfigLoader:
    """Service responsible for resolving runtime execution config via the CASConfig SSOT."""

    def resolve_config(
        self,
        project: str,
        cli_overrides: dict[str, Any] | None = None,
        target_dir: str | Path = ".",
    ) -> ExecutionProfile:
        """Resolve LLM execution profile using CASConfig's 5-tier cascade (.cas/config.yaml SSOT)."""
        effective = CASConfig.resolve(
            target_dir=target_dir, cli_overrides=cli_overrides
        )
        llm = effective.config.llm

        api_base = (cli_overrides or {}).get("api_base") or os.getenv("CAS_API_BASE")
        max_tokens_raw = (cli_overrides or {}).get("max_tokens") or os.getenv(
            "CAS_MAX_TOKENS"
        )
        max_tokens: int | None = None
        if max_tokens_raw is not None:
            try:
                max_tokens = int(max_tokens_raw)
            except ValueError:
                print(
                    f"[CAS][WARN] Invalid max_tokens value '{max_tokens_raw}'. Ignoring."
                )

        return ExecutionProfile(
            provider=llm.default_provider,
            model=llm.default_model,
            temperature=llm.temperature,
            max_tokens=max_tokens,
            api_base=api_base,
        )

    def _load_project_config(self, project: str) -> dict[str, Any]:
        """Loads project-specific configuration from the knowledge layer."""
        from cas_runner.io import load_project_config

        return load_project_config(project)

    def resolve_project_config(
        self, project: str, target_dir: str | Path = "."
    ) -> ProjectConfiguration:
        """Resolve project configuration including evaluation_enabled setting."""
        raw_config = self._load_project_config(project)
        eval_enabled = True
        if isinstance(raw_config, dict):
            cas_cfg = raw_config.get("cas", {})
            if isinstance(cas_cfg, dict):
                eval_cfg = cas_cfg.get("evaluation", {})
                if isinstance(eval_cfg, dict) and "enabled" in eval_cfg:
                    eval_enabled = bool(eval_cfg["enabled"])
            if "evaluation_enabled" in raw_config:
                eval_enabled = bool(raw_config["evaluation_enabled"])

        env_eval = os.getenv("CAS_EVALUATION_ENABLED")
        if env_eval is not None:
            eval_enabled = env_eval.lower() not in ("false", "0", "no")

        effective = CASConfig.resolve(target_dir=target_dir).config
        return ProjectConfiguration(
            provider=effective.llm.default_provider,
            model=effective.llm.default_model,
            temperature=effective.llm.temperature,
            evaluation_enabled=eval_enabled,
        )

    def is_evaluation_enabled(
        self, project: str, cli_overrides: dict[str, Any] | None = None
    ) -> bool:
        """Check whether evaluation should run, factoring in CLI overrides, ENV, and project YAML."""
        if cli_overrides and cli_overrides.get("skip_evaluation"):
            return False

        env_eval = os.getenv("CAS_EVALUATION_ENABLED")
        if env_eval is not None:
            return env_eval.lower() not in ("false", "0", "no")

        if (
            cli_overrides
            and "config" in cli_overrides
            and isinstance(cli_overrides["config"], dict)
        ):
            raw_config = cli_overrides["config"]
            cas_cfg = raw_config.get("cas", {})
            if isinstance(cas_cfg, dict):
                eval_cfg = cas_cfg.get("evaluation", {})
                if isinstance(eval_cfg, dict) and "enabled" in eval_cfg:
                    return bool(eval_cfg["enabled"])
            if "evaluation_enabled" in raw_config:
                return bool(raw_config["evaluation_enabled"])

        proj_cfg = self.resolve_project_config(project)
        return proj_cfg.evaluation_enabled
