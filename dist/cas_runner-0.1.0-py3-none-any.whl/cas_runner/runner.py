from datetime import datetime

from .io import (
    TargetProjectContext,
    get_telemetry_root,
    load_adrs,
    load_architecture_state,
    load_architecture_work,
    load_baseline_assessment,
    load_conversation,
    load_decision_records,
    load_latest_aem,
    load_latest_aid,
    load_latest_alignment,
    load_pattern_promotion_recommendations,
    load_pattern_proposals,
    load_pattern_scope_classification,
    load_project_config,
    load_project_vision,
    load_promotion_decisions,
    persist_outputs,
    resolve_target_project_context,
)
from .llm import get_llm_client
from .orchestration import PromptRepository, ReasoningExecutionContract
from .orchestration.config import ConfigLoader
from .orchestration.evaluation import EvaluationHarness
from .orchestration.hud import (
    RunHUDPublisher,
    calculate_step_cost,
    format_milestone_log,
)
from .orchestration.telemetry import LocalTelemetryProvider, NoOpTelemetryProvider
from .steps import get_flow_steps, load_step


class FlowRunner:
    def __init__(
        self,
        project: str,
        provider: str,
        dry_run: bool = False,
        project_context: TargetProjectContext | None = None,
        **kwargs,
    ):
        self.project = project
        self.dry_run = dry_run
        target_dir = kwargs.get("target_dir")
        workspace_root = kwargs.get("workspace_root")
        self.project_context = project_context or resolve_target_project_context(
            project=project, target_dir=target_dir, workspace_root=workspace_root
        )

        # Initialize Observability Layer
        if self.dry_run:
            self.telemetry = NoOpTelemetryProvider()
        else:
            self.telemetry = LocalTelemetryProvider(project=project)

        # Initialize Evaluation Harness
        self.evaluation_harness = None

        # Initialize Configuration Loader
        self.config_loader = ConfigLoader()

        # Resolve configuration with precedence
        cli_overrides = kwargs.copy()
        if provider:
            cli_overrides["provider"] = provider

        self.execution_profile = self.config_loader.resolve_config(
            project=project, cli_overrides=cli_overrides
        )

        self.provider = get_llm_client(profile=self.execution_profile)
        self.config = load_project_config(project)

        # Merge CLI overrides into config for context injection
        for k, v in cli_overrides.items():
            if k not in ["provider", "model", "temperature"]:
                self.config[k] = v

        self.context = {
            "project": project,
            "project_root": str(self.project_context.project_root),
            "evidence_root": str(self.project_context.evidence_root),
            "workspace_root": str(self.project_context.knowledge_base_path),
            "project_context": self.project_context,
            "rule_context": [],
            "architecture_work": [],
            "aid": {},
            "vision": {},
            "patterns": [],
            "baseline_assessment": {},
            "ingestion": [],
            "config": self.config,
            "execution_profile": self.execution_profile.model_dump(),
            "observability": self.telemetry,
            "dry_run": self.dry_run,
            "skip_evaluation": kwargs.get("skip_evaluation", False),
            "publish_root": kwargs.get("publish_root", False),
            "target_dir": kwargs.get("target_dir")
            or str(self.project_context.project_root),
            "target_pattern": kwargs.get("target_pattern"),
        }

        # Initialize Reasoning Engine
        prompt_base_path = self.config.get("prompt_base_path", "src/prompts")
        self.prompt_repo = PromptRepository(base_path=prompt_base_path)
        self.reasoning_engine = ReasoningExecutionContract(
            provider=self.provider, prompt_repo=self.prompt_repo, context=self.context
        )

    def run(self, flow_name: str, target_pattern: str | None = None):
        steps = get_flow_steps(flow_name)
        self.context["flow_name"] = flow_name
        if target_pattern:
            self.context["target_pattern"] = target_pattern

        if self.dry_run:
            print(f"[CAS][DEBUG] FlowRunner initialized for project: {self.project}")

        print(f"[CAS] Running flow: {flow_name}")

        architectural_state = load_architecture_state(self.project)
        self.context["architectural_state"] = architectural_state

        ingestion = load_conversation(self.project)
        self.context["ingestion"] = ingestion

        aw = load_architecture_work(self.project)
        self.context["architecture_work"] = aw

        aid = load_latest_aid(self.project)
        self.context["aid"] = aid

        vision = load_project_vision(self.project)
        self.context["vision"] = vision

        aem = load_latest_aem(self.project)
        self.context["aem"] = aem

        alignment = load_latest_alignment(self.project)
        self.context["alignment_report"] = alignment

        baseline = load_baseline_assessment(self.project)
        self.context["baseline_assessment"] = baseline

        pattern_proposals = load_pattern_proposals(self.project)
        self.context["pattern_proposals"] = pattern_proposals

        scope_classification = load_pattern_scope_classification(self.project)
        self.context["pattern_scope_classification"] = scope_classification

        promotion_recs = load_pattern_promotion_recommendations(self.project)
        self.context["pattern_promotion_recommendations"] = promotion_recs

        promotion_decisions = load_promotion_decisions(self.project)
        self.context["promotion_decisions"] = promotion_decisions

        adrs = load_adrs(self.project)
        self.context["adrs"] = adrs

        decision_records = load_decision_records()
        self.context["decision_records"] = decision_records

        # Persist execution profile for reproducibility
        if not self.dry_run:
            persist_outputs(
                {"execution_profile": self.execution_profile.model_dump()}, self.project
            )

        # Initialize Run HUD publisher
        model_name = getattr(self.execution_profile, "model", "gemini-1.5-flash")
        hud_publisher = RunHUDPublisher(
            flow_name=flow_name,
            project=self.project,
            steps=steps,
            model=model_name,
        )
        if not self.dry_run:
            hud_publisher.start_run()

        try:
            for idx, step_name in enumerate(steps, start=1):
                if not self.dry_run:
                    hud_publisher.start_step(step_name)

                step = load_step(step_name)
                self.context["step_name"] = step_name

                inputs = step.prepare_inputs(self.context)
                # Pass reasoning_engine instead of raw provider
                output = step.execute(inputs, self.reasoning_engine)

                step.validate(output)

                if not self.dry_run:
                    persist_outputs(output, self.project)

                self._update_context(output)

                # Check tokens from telemetry if available
                tokens_in = 0
                tokens_out = 0
                step_cost = 0.0
                if hasattr(self.telemetry, "spans") and self.telemetry.spans:
                    last_span = self.telemetry.spans[-1]
                    tokens_in = (
                        last_span.attributes.get("gen_ai.usage.input_tokens")
                        or last_span.attributes.get("llm.prompt_tokens")
                        or 0
                    )
                    tokens_out = (
                        last_span.attributes.get("gen_ai.usage.output_tokens")
                        or last_span.attributes.get("llm.completion_tokens")
                        or 0
                    )
                    estimated_cost = last_span.attributes.get("llm.estimated_cost")
                    if estimated_cost is not None and estimated_cost > 0:
                        step_cost = float(estimated_cost)
                    else:
                        step_cost = calculate_step_cost(model_name, tokens_in, tokens_out)
                else:
                    step_cost = calculate_step_cost(model_name, tokens_in, tokens_out)

                if not self.dry_run:
                    hud_publisher.finish_step(
                        step_name,
                        tokens_in=tokens_in,
                        tokens_out=tokens_out,
                        cost_usd=step_cost,
                    )

                next_step = steps[idx] if idx < len(steps) else None
                milestone = format_milestone_log(
                    step_name=step_name,
                    step_index=idx,
                    total_steps=len(steps),
                    tokens=tokens_in + tokens_out,
                    cost_usd=step_cost,
                    next_step=next_step,
                )
                print(milestone)

            if not self.dry_run:
                hud_publisher.finish_run(status="completed")
        except Exception as e:
            if not self.dry_run:
                hud_publisher.record_failure(str(e))
            raise

        if not self.dry_run:
            # Telemetry should be persisted to the runtime/traces substrate
            traces_dir = get_telemetry_root()
            self.telemetry.persist(output_dir=str(traces_dir))
            self._execute_evaluation()

        self.print_telemetry_summary()
        print("[CAS] Done.")

    def print_telemetry_summary(self):
        """Prints a structured summary table of telemetry spans, tokens, latency, and costs."""
        spans = getattr(self.telemetry, "spans", [])
        if not spans:
            return

        total_tokens_in = 0
        total_tokens_out = 0
        total_cost = 0.0
        total_duration_ms = 0.0
        successful_steps = 0
        failed_steps = 0

        rows = []
        for span in spans:
            step_name = span.attributes.get("cas.step_name") or span.name.replace("reasoning.", "")
            status = span.status.upper() if span.status else "OK"
            if span.status == "ok":
                successful_steps += 1
            elif span.status == "error":
                failed_steps += 1

            tin = (
                span.attributes.get("gen_ai.usage.input_tokens")
                or span.attributes.get("llm.prompt_tokens")
                or 0
            )
            tout = (
                span.attributes.get("gen_ai.usage.output_tokens")
                or span.attributes.get("llm.completion_tokens")
                or 0
            )
            tokens = tin + tout
            cost = float(span.attributes.get("llm.estimated_cost") or 0.0)
            duration_s = (span.duration_ms or 0.0) / 1000.0

            total_tokens_in += tin
            total_tokens_out += tout
            total_cost += cost
            total_duration_ms += (span.duration_ms or 0.0)

            rows.append((step_name, status, tokens, cost, duration_s))

        total_tokens = total_tokens_in + total_tokens_out
        total_duration_s = total_duration_ms / 1000.0

        print("\n" + "=" * 76)
        print(" [CAS] Telemetry Summary")
        print("=" * 76)
        trace_id = getattr(self.telemetry, "trace_id", "unknown")
        print(f" Trace ID:       {trace_id}")
        print(f" Total Steps:    {len(rows)} (Successful: {successful_steps}, Failed: {failed_steps})")
        print(f" Total Tokens:   {total_tokens:,} (In: {total_tokens_in:,} | Out: {total_tokens_out:,})")
        print(f" Estimated Cost: ${total_cost:.4f} USD")
        print(f" Total Latency:  {total_duration_s:.2f}s")
        print("-" * 76)
        print(f" {'Step':<36} {'Status':<8} {'Tokens':>10} {'Cost (USD)':>12} {'Duration':>8}")
        print("-" * 76)
        for step_name, status, tokens, cost, duration_s in rows:
            tokens_str = f"{tokens:,}" if tokens > 0 else "-"
            cost_str = f"${cost:.4f}" if cost > 0 else "$0.0000"
            duration_str = f"{duration_s:.2f}s"
            print(f" {step_name:<36} {status:<8} {tokens_str:>10} {cost_str:>12} {duration_str:>8}")
        print("=" * 76 + "\n")


    def _execute_evaluation(self):
        """Executes evaluation of the current trace."""
        if self.dry_run:
            return

        if self.context.get("skip_evaluation"):
            print("[CAS][INFO] Telemetry evaluation skipped (--skip-evaluation).")
            return

        if not self.config_loader.is_evaluation_enabled(self.project, self.context):
            print("[CAS][INFO] Telemetry evaluation disabled by configuration.")
            return

        try:
            # Initialize harness with the same provider if not already done
            if not self.evaluation_harness:
                self.evaluation_harness = EvaluationHarness(
                    project=self.project,
                    provider=self.provider,
                    prompt_repo=self.prompt_repo,
                )

            # Capture the current trace data
            trace_data = {
                "trace_id": self.telemetry.trace_id,
                "project": self.project,
                "timestamp": datetime.now().isoformat(),
                "spans": [span.model_dump() for span in self.telemetry.spans],
            }

            print(
                f"[CAS][INFO] Evaluating orchestration quality for trace {self.telemetry.trace_id[:8]}..."
            )
            record = self.evaluation_harness.evaluate(trace_data)

            from .io import persist_evaluation

            persist_evaluation(record.model_dump(), self.project)
            print(
                f"[CAS][INFO] Evaluation completed. Overall score: {record.overall_score}"
            )
        except Exception as e:
            print(f"[CAS][WARN] Evaluation failed: {e}")

    def _update_context(self, output: dict):
        for k, v in output.items():
            if isinstance(v, list):
                self.context.setdefault(k, []).extend(v)
            else:
                self.context[k] = v

        # In-memory proposal aggregation for pattern lifecycle flows
        if (
            "agentic_pattern_proposals" in output
            or "structural_pattern_proposals" in output
        ):
            existing = self.context.setdefault("pattern_proposals", [])
            existing_ids = {
                p.get("pattern_id") or p.get("id")
                for p in existing
                if isinstance(p, dict)
            }
            for key in ("agentic_pattern_proposals", "structural_pattern_proposals"):
                props_dict = output.get(key)
                if isinstance(props_dict, dict):
                    new_props = props_dict.get("pattern_proposals", [])
                    for p in new_props:
                        pid = p.get("pattern_id") or p.get("id")
                        if pid and pid not in existing_ids:
                            existing.append(p)
                            existing_ids.add(pid)
