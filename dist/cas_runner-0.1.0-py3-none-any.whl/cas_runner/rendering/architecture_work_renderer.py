from src.cas_runner.rendering.base_renderer import BaseRenderer


class ArchitectureWorkRenderer(BaseRenderer):
    """Renderer for Architecture Work structured data."""

    def render(self, data: dict) -> str:
        """Render architecture work data to markdown.

        Args:
            data: The architecture work structured data (dict)
                conforming to the architecture work schema.

        Returns:
            A markdown string representing the architecture work.
        """
        if not isinstance(data, dict):
            raise ValueError("Input data must be a dictionary")

        frontmatter = data.get('frontmatter', {})
        if not isinstance(frontmatter, dict):
            raise ValueError("'frontmatter' must be a dictionary if present")

        sections = data.get('sections', {})
        if not isinstance(sections, dict):
            raise ValueError("'sections' must be a dictionary if present")

        # Build the YAML frontmatter block
        markdown = BaseRenderer._render_frontmatter(frontmatter)

        # Output the section values in the order they appear in the sections dict
        for section_name, section_content in sections.items():
            if isinstance(section_content, str):
                markdown += f"{section_content}\n\n"
            elif isinstance(section_content, list):
                # For lists, we output each item on a new line with a bullet?
                # But the example doesn't do that.
                # We'll output the list as a YAML block?
                # But the example doesn't have lists in the content.
                # We'll output the list as a string representation
                # for now.
                markdown += f"{section_content}\n\n"
            else:
                markdown += f"{section_content}\n\n"

        # Remove trailing whitespace and extra newlines?
        # We'll return the markdown as built.
        return markdown.strip()
