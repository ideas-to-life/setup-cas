import re

import yaml
from yaml.representer import SafeRepresenter

from src.cas_runner.rendering.base_renderer import BaseRenderer


class QuotedString(str):
    pass


def quoted_string_presenter(dumper, data):
    return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='\"')


# Add the representer to the SafeRepresenter
SafeRepresenter.add_representer(QuotedString, quoted_string_presenter)


def quote_string_values(data):
    if isinstance(data, dict):
        return {k: quote_string_values(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [quote_string_values(i) for i in data]
    elif isinstance(data, str):
        return QuotedString(data)
    else:
        return data


class AlignmentReportRenderer(BaseRenderer):
    """Renderer for Alignment Report structured data."""

    def render(self, data: dict) -> str:
        """Render alignment report data to markdown.

        Args:
            data: The alignment report structured data (dict)
                conforming to the alignment report schema.

        Returns:
            A markdown string representing the alignment report.
        """
        if not isinstance(data, dict):
            raise ValueError("Input data must be a dictionary")

        frontmatter = data.get('frontmatter', {})
        if not isinstance(frontmatter, dict):
            raise ValueError("'frontmatter' must be a dictionary if present")

        sections = data.get('sections', {})
        if not isinstance(sections, dict):
            raise ValueError("'sections' must be a dictionary if present")

        # Define the schema fields for the YAML frontmatter block
        schema_fields = ['id', 'knowledgeType', 'project', 'date']
        # Build the YAML frontmatter block with only schema fields
        yaml_lines = []
        for key in schema_fields:
            if key in frontmatter:
                BaseRenderer._render_yaml_lines_for_key_value(
                    yaml_lines, key, frontmatter[key]
                )

        markdown = ""
        if yaml_lines:
            markdown += "---\n"
            markdown += "\n".join(yaml_lines)
            markdown += "\n---\n\n"

        # Title
        project = frontmatter.get('project', 'Unknown Project')
        markdown += f"# Alignment Report: {project}\n\n"

        # Extra lines after the title
        date = frontmatter.get('date', 'Unknown Date')
        aem_source = frontmatter.get('aem_source', 'Unknown AEM Source')
        aid_source = frontmatter.get('aid_source', 'Unknown AID Source')
        rules_applied = frontmatter.get(
            'rules_applied', 'Unknown Rules Applied'
        )

        markdown += f"**Generated:** {date}\n"
        markdown += f"**AEM Source:** {aem_source}\n"
        markdown += f"**AID Source:** {aid_source}\n"
        markdown += f"**Rules Applied:** {rules_applied}\n\n"
        markdown += "---\n\n"

        # Render each section
        for section_name, section_content in sections.items():
            markdown += f"## {section_name}\n\n"
            # Depending on the section, we might want to format the
            # content differently.
            # For simplicity, we'll treat the section content as a dict
            # and convert to YAML if it's a dict or list.
            # But note: in the example, some sections are YAML blocks,
            # some are markdown tables, and some are plain text.
            # We'll follow the example:
            #   - Alignment Summary: YAML block
            #   - Alignment Findings (Persistable): YAML block (list of objects)
            #   - Findings (Readable Summary): markdown table
            #   - Architecture Work (Derived): YAML block (list of objects)
            #   - Traceability Matrix: markdown table
            #   - Rules Applied Detail: YAML block (object)

            # We'll check the section name to decide the format.
            if section_name in [
                "Alignment Summary",
                "Alignment Findings (Persistable)",
                "Architecture Work (Derived)",
                "Rules Applied Detail",
            ]:
                # Format as YAML block with a top-level key
                # Remove text in parentheses
                yaml_key = re.sub(r'\s*\([^)]*\)', '', section_name)
                # Replace spaces with underscores and convert to lowercase
                yaml_key = yaml_key.replace(' ', '_').lower()

                # Apply the conversion to the section_content
                quoted_data = quote_string_values(section_content)

                # Dump the YAML with the custom representer
                yaml_content = yaml.dump(
                    {yaml_key: quoted_data},
                    default_flow_style=False,
                    Dumper=yaml.SafeDumper,
                )
                markdown += "```yaml\n"
                markdown += yaml_content
                markdown += "```\n\n"
            elif section_name in [
                "Findings (Readable Summary)",
                "Traceability Matrix",
            ]:
                # Format as markdown table
                # We'll assume the content is a list of dicts
                # for findings_readable_summary and traceability_matrix.
                if (isinstance(section_content, list)
                        and len(section_content) > 0):
                    # Get the headers from the keys of the first dict
                    headers = list(section_content[0].keys())
                    markdown += "| " + " | ".join(headers) + " |\n"
                    markdown += "| " + " | ".join(["---"] * len(headers)) + " |\n"
                    for row in section_content:
                        markdown += "| " + " | ".join(
                            str(row.get(h, "")) for h in headers
                        ) + " |\n"
                    markdown += "\n"
                else:
                    # If it's not a list or empty, just output as string?
                    markdown += str(section_content) + "\n\n"
            else:
                # Default: treat as string
                markdown += str(section_content) + "\n\n"
            markdown += "---\n\n"

        # Add the generator note at the end
        markdown += "*Generated by Alignment Engine*\n"

        # Remove trailing whitespace and extra newlines?
        # We'll return the markdown as built.
        return markdown.strip()
