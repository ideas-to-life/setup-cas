from src.cas_runner.rendering.base_renderer import BaseRenderer


class AIDRenderer(BaseRenderer):
    """Renderer for Architecture Intent Document (AID) structured data."""

    def render(self, data: dict) -> str:
        """Render AID data to markdown.

        Args:
            data: The AID structured data (dict) conforming to the AID schema.

        Returns:
            A markdown string representing the AID.
        """
        if not isinstance(data, dict):
            raise ValueError("Input data must be a dictionary")

        frontmatter = data.get('frontmatter', {})
        if not isinstance(frontmatter, dict):
            raise ValueError("'frontmatter' must be a dictionary if present")

        sections = data.get('sections', {})
        if not isinstance(sections, dict):
            raise ValueError("'sections' must be a dictionary if present")

        # Render the YAML frontmatter (the --- block at the top)
        markdown = BaseRenderer._render_frontmatter(frontmatter)

        # Title
        project = frontmatter.get('project', 'Unknown Project')
        markdown += f"# Architecture Intent Document: {project}\n\n"

        # Render each section
        for section_name, section_content in sections.items():
            markdown += f"## {section_name}\n\n"
            if isinstance(section_content, dict):
                content = section_content.get('content', '')
            else:
                # If it's not a dict, we convert to string for the content.
                content = str(section_content)
            markdown += f"{content}\n\n"

        # Remove trailing whitespace and extra newlines?
        # We'll return the markdown as built.
        return markdown.strip()
