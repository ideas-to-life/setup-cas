from abc import ABC, abstractmethod
from typing import Any


class BaseRenderer(ABC):
    """Abstract base class for rendering structured data to markdown."""

    @abstractmethod
    def render(self, data: Any) -> str:
        """Render structured data to markdown string.

        Args:
            data: The structured data to render.

        Returns:
            A markdown string representation of the data.
        """
        pass

    @staticmethod
    def _render_yaml_lines_for_key_value(
        yaml_lines: list,
        key: str,
        value: Any,
    ) -> None:
        """Append YAML lines for a key-value pair to the given list.

        Args:
            yaml_lines: The list to append lines to.
            key: The key.
            value: The value (can be any type, but we handle dict and non-dict).
        """
        if isinstance(value, dict):
            yaml_lines.append(f"{key}:")
            for sub_key, sub_value in value.items():
                if isinstance(sub_value, dict):
                    yaml_lines.append(f"  {sub_key}:")
                    for sub_sub_key, sub_sub_value in sub_value.items():
                        yaml_lines.append(f"    {sub_sub_key}: {sub_sub_value}")
                else:
                    yaml_lines.append(f"  {sub_key}: {sub_value}")
        else:
            yaml_lines.append(f"{key}: {value}")

    @staticmethod
    def _render_frontmatter(frontmatter: dict) -> str:
        """Render a frontmatter dict to YAML string wrapped in --- lines.

        Args:
            frontmatter: The frontmatter dictionary.

        Returns:
            A string of the form:
            ---
            key: value
            ...
            ---

            If the frontmatter is empty, returns an empty string.
        """
        yaml_lines = []
        for key, value in frontmatter.items():
            BaseRenderer._render_yaml_lines_for_key_value(
                yaml_lines, key, value
            )

        if not yaml_lines:
            return ""
        return "---\n" + "\n".join(yaml_lines) + "\n---\n\n"
