import json
import logging
from typing import Any

from pydantic import BaseModel

from .errors import StructuredOutputError

logger = logging.getLogger(__name__)

import re

def extract_json(text: str) -> str:
    """
    Robustly extract the largest JSON-like block from text.
    Handles markdown code blocks and leading/trailing prose without corrupting
    nested/embedded markdown code fences inside JSON string values.
    Supports both JSON objects ({...}) and JSON arrays ([...]).
    """
    stripped = text.strip()

    # 1. If text is already valid JSON directly, return it immediately
    try:
        json.loads(stripped)
        return stripped
    except Exception:
        pass

    # 2. Check if the entire response (or a major block) is wrapped in outer markdown code fences
    # We match only an outer fence (e.g. starting with ```json or ``` at beginning of string/line)
    fence_pattern = re.search(r"^\s*```(?:json)?\s*\n(.*?)\n\s*```\s*$", stripped, re.DOTALL)
    if fence_pattern:
        candidate = fence_pattern.group(1).strip()
        try:
            json.loads(candidate)
            return candidate
        except Exception:
            pass

    # 3. Locate outer braces/brackets
    first_brace = text.find("{")
    last_brace = text.rfind("}")
    first_bracket = text.find("[")
    last_bracket = text.rfind("]")

    candidate_spans = []
    if first_brace != -1 and last_brace > first_brace:
        candidate_spans.append((first_brace, last_brace + 1))
    if first_bracket != -1 and last_bracket > first_bracket:
        candidate_spans.append((first_bracket, last_bracket + 1))

    # Test candidate spans for valid JSON
    for start, end in sorted(candidate_spans, key=lambda s: s[0]):
        chunk = text[start:end]
        try:
            json.loads(chunk)
            return chunk
        except Exception:
            pass

    # Fallback to widest brace/bracket span
    if candidate_spans:
        min_start = min(s[0] for s in candidate_spans)
        max_end = max(s[1] for s in candidate_spans)
        return text[min_start:max_end]

    return stripped

def validate_structured_output(
    text: str, provider: str, model: str, prompt_id: str
) -> dict[str, Any] | list[Any] | BaseModel:
    """
    Parses and validates the LLM output against a schema.
    Raises StructuredOutputError on failure.
    """
    clean_text = extract_json(text)

    try:
        return json.loads(clean_text)
    except json.JSONDecodeError as e:
        logger.error(f"JSON Parse Failure. Raw text extracted: {clean_text}")
        raise StructuredOutputError(
            provider=provider,
            model=model,
            prompt_id=prompt_id,
            raw_output=text,
            reason="JSON Parse Failure",
            details=str(e),
        )

def get_json_instruction(schema: dict[str, Any],current_instruction: str | None = None) -> str:
    """
    Returns a concise but strict JSON instruction, preserving existing instructions.
    Injects the JSON schema for model guidance.
    """
    json_requirements = (
        "Return ONLY valid JSON. No prose, no preamble. "
        "Must conform exactly to this schema. No extra keys."
    )
    schema_json = json.dumps(schema)

    base = f"{current_instruction}\n\n" if current_instruction else ""
    return f"{base}{json_requirements}\nSchema: {schema_json}"
