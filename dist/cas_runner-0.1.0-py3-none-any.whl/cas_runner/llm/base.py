from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from pydantic import BaseModel, Field


@dataclass
class LLMCapabilities:
    """Describes the capabilities of an LLM model."""
    supports_text_in: bool = True
    supports_text_out: bool = True
    supports_structured_json: bool = True
    supports_tools: bool = False
    supports_vision: bool = False

@dataclass
class LLMUsage:
    """Captured token and cost telemetry for an LLM invocation."""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    estimated_cost: float | None = None
    currency: str = "USD"
    cost_estimation_source: str | None = None

@dataclass
class LLMResponse:
    """Wrapped LLM response containing content and usage metadata."""
    content: str | dict[str, Any] | BaseModel
    usage: LLMUsage = Field(default_factory=LLMUsage)

class LLMClient(ABC):
    """
    Abstract base class for LLM clients in CAS.
    Decouples orchestration from specific providers.
    """

    @property
    @abstractmethod
    def capabilities(self) -> LLMCapabilities:
        """Return the capabilities of this LLM client."""
        pass

    @abstractmethod
    def generate(
        self,
        prompt: str,
        *,
        instruction: str | None = None,
        schema: dict[str, Any] | None = None,
        temperature: float | None = None,
        metadata: dict[str, Any] | None = None,
        name: str | None = None,
    ) -> LLMResponse:
        """Generate a response for a single prompt."""
        pass

    @abstractmethod
    def chat(
        self,
        messages: list[dict[str, str]],
        *,
        instruction: str | None = None,
        schema: dict[str, Any] | None = None,
        temperature: float | None = None,
        metadata: dict[str, Any] | None = None,
        name: str | None = None,
    ) -> LLMResponse:
        """Conduct a multi-turn conversation."""
        pass
