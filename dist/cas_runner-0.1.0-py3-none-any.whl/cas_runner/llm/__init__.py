from typing import Optional

# We import inside to avoid potential circular dependencies if needed,
# but currently it should be fine.
from cas_runner.orchestration.config import ExecutionProfile

from .base import LLMCapabilities, LLMClient, LLMResponse, LLMUsage
from .errors import StructuredOutputError
from .litellm_client import LiteLLMClient
from .mock_client import MockLLMClient


def get_llm_client(profile: ExecutionProfile) -> LLMClient:
    """
    Factory function to get the appropriate LLM client using an ExecutionProfile.
    """
    if profile.provider.lower() in ["mock", "stub"]:
        return MockLLMClient(**profile.extra_params)

    return LiteLLMClient(
        model_name=profile.model,
        provider=profile.provider,
        temperature=profile.temperature,
        max_tokens=profile.max_tokens,
        api_base=profile.api_base,
        **profile.extra_params
    )
