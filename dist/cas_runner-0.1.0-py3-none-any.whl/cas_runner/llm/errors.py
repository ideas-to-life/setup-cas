from typing import Any


class StructuredOutputError(Exception):
    """Exception raised when an LLM fails to produce valid structured output."""

    def __init__(
        self,
        provider: str,
        model: str,
        prompt_id: str,
        raw_output: str,
        reason: str,
        details: Any | None = None,
    ):
        self.provider = provider
        self.model = model
        self.prompt_id = prompt_id
        self.raw_output = raw_output
        self.reason = reason
        self.details = details

        message = (
            f"Structured output failure for {provider}/{model} (Prompt: {prompt_id}). "
            f"Reason: {reason}. Output snippet: {raw_output[:100]}..."
        )
        super().__init__(message)
