from typing import Any, Union

from pydantic import BaseModel

from .base import LLMCapabilities, LLMClient, LLMResponse, LLMUsage


class MockLLMClient(LLMClient):
    """
    Mock LLMClient for testing and stubs.
    """

    @property
    def capabilities(self) -> LLMCapabilities:
        return LLMCapabilities()

    def __init__(self, response: str | dict[str, Any] | BaseModel = None, **kwargs):
        self.response = response or {"_mock": True, "result": "Mocked LLM output"}
        self.last_prompt = None
        self.last_schema = None
        self.call_count = 0

    def generate(
        self,
        prompt: str,
        *,
        instruction: str | None = None,
        schema: type[BaseModel] | None = None,
        temperature: float | None = None,
        metadata: dict[str, Any] | None = None,
        name: str | None = None,
    ) -> LLMResponse:
        self.last_prompt = prompt
        self.last_instruction = instruction
        self.last_schema = schema
        self.call_count += 1

        usage = LLMUsage(
            prompt_tokens=10,
            completion_tokens=20,
            total_tokens=30,
            estimated_cost=0.001,
            currency="USD",
            cost_estimation_source="mock"
        )

        content = self.response

        # If we have a schema and the response is the default mock, try to generate dummy data
        # to pass validation in dry-run scenarios.
        if schema and self.response == {"_mock": True, "result": "Mocked LLM output"}:
            if not isinstance(schema, dict):
                # Pydantic model: generate dummy data
                try:
                    dummy_data = self._generate_dummy_data(schema)
                    content = schema.model_validate(dummy_data)
                except Exception as e:
                    print(f"[LLM][WARN] Failed to generate dummy data for Pydantic model {schema}: {e}")
            else:
                # JSON schema dict: generate dummy data
                try:
                    content = self._generate_dummy_from_jsonschema(schema)
                except Exception as e:
                    print(f"[LLM][WARN] Failed to generate dummy data for JSON schema: {e}")

        elif schema and not isinstance(schema, dict) and isinstance(self.response, dict):
            content = schema.model_validate(self.response)

        elif schema and not isinstance(schema, dict) and isinstance(self.response, str):
            import json
            try:
                data = json.loads(self.response)
                content = schema.model_validate(data)
            except:
                content = self.response

        return LLMResponse(content=content, usage=usage)

    def _generate_dummy_from_jsonschema(self, schema: dict[str, Any]) -> Any:
        """Generates dummy data that satisfies a JSON schema."""
        if not isinstance(schema, dict):
            return {}

        # Handle 'const' or 'enum' immediately as they are the most specific
        if "const" in schema:
            return schema["const"]
        if schema.get("enum"):
            return schema["enum"][0]

        # Handle anyOf, allOf, oneOf by taking the first option
        for key in ["anyOf", "allOf", "oneOf"]:
            if schema.get(key):
                return self._generate_dummy_from_jsonschema(schema[key][0])

        if "type" not in schema:
            # If no type but has properties, assume object
            if "properties" in schema:
                stype = "object"
            else:
                return {}
        else:
            stype = schema["type"]

        if stype == "object":
            obj = {}
            properties = schema.get("properties", {})
            for prop_name, prop_schema in properties.items():
                obj[prop_name] = self._generate_dummy_from_jsonschema(prop_schema)
            return obj
        elif stype == "array":
            items_schema = schema.get("items", {})
            return [self._generate_dummy_from_jsonschema(items_schema)]
        elif stype == "string":
            if "format" in schema and schema["format"] == "date":
                return "2026-05-25"
            if "format" in schema and schema["format"] == "date-time":
                return "2026-05-25T10:00:00Z"
            if "pattern" in schema and "^[a-z0-9-]+$" in schema["pattern"]:
                return "mock-kebab-pattern"
            # Special case for synthesis schema to avoid 'dummy_string' in markdown
            if "complete Markdown block" in schema.get("description", ""):
                return "## Mocked Markdown\n\nThis is a mocked synthesis response."
            return "dummy_string"
        elif stype == "integer":
            return 1
        elif stype == "number":
            return 1.0
        elif stype == "boolean":
            return True
        return None

    def _generate_dummy_data(self, model: type[BaseModel]) -> dict[str, Any]:
        """Generates dummy data that satisfies a Pydantic model's requirements."""
        data = {}
        for name, field in model.model_fields.items():
            # Basic type generation
            field_type = field.annotation

            # Handle Optional/Union
            if hasattr(field_type, "__origin__") and field_type.__origin__ is Union:
                field_type = field_type.__args__[0]

            if field_type is str:
                data[name] = f"dummy_{name}"
            elif field_type is int:
                data[name] = 1
            elif field_type is float:
                data[name] = 1.0
            elif field_type is bool:
                data[name] = True
            elif field_type is list or (hasattr(field_type, "__origin__") and field_type.__origin__ is list):
                # Try to get the inner type of the list
                item_type = str
                if hasattr(field_type, "__args__"):
                    item_type = field_type.__args__[0]

                if isinstance(item_type, type) and issubclass(item_type, BaseModel):
                    data[name] = [self._generate_dummy_data(item_type)]
                else:
                    data[name] = []
            elif field_type is dict or (hasattr(field_type, "__origin__") and field_type.__origin__ is dict):
                data[name] = {}
            elif isinstance(field_type, type) and issubclass(field_type, BaseModel):
                data[name] = self._generate_dummy_data(field_type)
            else:
                # Default for unknown types
                data[name] = None
        return data

    def chat(
        self,
        messages: list[dict[str, str]],
        *,
        instruction: str | None = None,
        schema: type[BaseModel] | None = None,
        temperature: float | None = None,
        metadata: dict[str, Any] | None = None,
        name: str | None = None,
    ) -> LLMResponse:
        prompt = messages[-1]["content"] if messages else ""
        return self.generate(
            prompt,
            instruction=instruction,
            schema=schema,
            temperature=temperature,
            metadata=metadata,
            name=name,
        )
