"""
Portal Preprocessor Entrypoint & Orchestration.
Integrates workspace discovery, context switching, evidence processing, and navigation generation.
"""
from pathlib import Path
from typing import Dict, Any

from cas_runner.tasks.portal.models import PortalWorkspaceContext
from cas_runner.tasks.portal.workspace_discovery import scan_workspace_projects
from cas_runner.tasks.portal.project_context import ProjectContextResolver, render_missing_artefact_notice
from cas_runner.tasks.portal.navigation_builder import build_portal_navigation
from cas_runner.tasks.portal.validator import validate_portal_workspace_context


class PortalPreprocessor:
    """Preprocesses CAS Knowledge Workspace artifacts for multi-project Portal presentation."""

    def __init__(self, knowledge_root: Path, portal_docs_root: Path):
        self.knowledge_root = Path(knowledge_root)
        self.portal_docs_root = Path(portal_docs_root)
        self.context: PortalWorkspaceContext = PortalWorkspaceContext(workspace_id="cas-knowledge-workspace")

    def run_discovery(self) -> PortalWorkspaceContext:
        """Discovers onboarded projects and builds PortalWorkspaceContext."""
        projects = scan_workspace_projects(self.knowledge_root)
        self.context.projects = projects
        
        # Discover Product Discovery evidence
        from cas_runner.tasks.portal.evidence_processor import parse_product_discovery_evidence
        self.context.product_discovery.evidence_nodes = parse_product_discovery_evidence()

        # Aggregate cross-project insights
        from cas_runner.tasks.portal.workspace_discovery import aggregate_cross_project_insights
        self.context.cross_project_insights = aggregate_cross_project_insights(projects)

        # Validate schema contract
        validate_portal_workspace_context(self.context.to_dict())
        return self.context

    def generate_projects_hub(self) -> str:
        """Generates Projects Hub index markdown content."""
        hub_content = "# CAS Projects Hub\n\n"
        hub_content += "Discover and switch between onboarded projects in the CAS Knowledge Workspace.\n\n"
        hub_content += "| Project Identity | Status | Context Link |\n"
        hub_content += "|-------------------|--------|--------------|\n"

        for proj in self.context.projects:
            hub_content += f"| **{proj.display_name}** (`{proj.project_id}`) | `{proj.status}` | [Enter Project Context]({proj.project_id}/index.md) |\n"


        return hub_content
