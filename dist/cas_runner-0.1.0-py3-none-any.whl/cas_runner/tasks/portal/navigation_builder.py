"""
Scope-Oriented Navigation Builder.
Generates structured nav trees distinguishing workspace scope (/), project scope (/projects/<id>/), and product/platform background (/about/).
"""
from typing import Any, Dict, List
from cas_runner.tasks.portal.models import PortalWorkspaceContext


def build_scoped_navigation_tree(context: PortalWorkspaceContext) -> List[Dict[str, Any]]:
    """Builds explicit Workspace Scope vs Active Project Scope vs About navigation tree for MkDocs."""
    workspace_nav = [
        {"Home": "index.md"},
        {"Governance Lifecycle": "governance/index.md"},
        {"Governance Intelligence": "global/governance/index.md"},
        {"Architecture & State": "global/maps/index.md"},
        {"Operations & Audit": "runtime/traces/index.md"},
        {"Cross-Project Insights": "global/insights/index.md"},
    ]

    project_nav = []
    for proj in context.projects:
        pid = proj.project_id
        project_pages = [
            {"Overview & Health": f"projects/{pid}/index.md"},
            {"Architecture State": f"projects/{pid}/state/index.md"},
            {"Intent Documents": f"projects/{pid}/intent/index.md"},
            {"Architecture Work": f"projects/{pid}/work/index.md"},
            {"Alignment Reports": f"projects/{pid}/alignment/index.md"},
            {"Architecture Decisions": f"projects/{pid}/adrs/index.md"},
            {"Execution Traces": f"projects/{pid}/traces/index.md"},
            {"Product Discovery Evidence": f"projects/{pid}/evidence/index.md"},
        ]
        project_nav.append({proj.display_name: project_pages})

    about_nav = [
        {"What is CAS?": "about/index.md"},
        {"Why CAS?": "about/why-cas.md"},
        {"How CAS Works": "about/how-cas-works.md"},
        {"Operating Model": "about/operating-model.md"},
        {"Platform Documentation": "about/platform-docs/index.md"},
    ]

    return [
        {"Workspace Scope": workspace_nav},
        {"Active Project Scope": project_nav if project_nav else [{"No Projects Onboarded": "projects/index.md"}]},
        {"About Scope": about_nav}
    ]


def build_portal_navigation(context: PortalWorkspaceContext) -> List[Dict[str, Any]]:
    """Builds 7 top-level domain navigation data structure for MkDocs."""
    navigation = []

    # 1. Home
    navigation.append({"Home": "index.md"})

    # 2. Governance Lifecycle
    navigation.append({
        "Governance Lifecycle": [
            {"1. Pattern Proposals": "governance/proposals/index.md"},
            {"2. Promotion Recommendations": "governance/recommendations/index.md"},
            {"3. Promotion Decisions": "governance/decisions/index.md"},
            {"4. ADR Review Queue": "governance/adrs/index.md"},
            {"5. Institutional Patterns": "governance/patterns/index.md"},
        ]
    })

    # 3. Governance Intelligence
    navigation.append({
        "Governance Intelligence": [
            {"Governance Health": "global/governance/health/index.md"},
            {"Governance Compliance": "global/governance/compliance/index.md"},
            {"Decisions Inbox": "global/governance/decisions/index.md"},
        ]
    })

    # 4. Architecture & State
    navigation.append({
        "Architecture & State": [
            {"Evolution Maps (AEM)": "global/maps/index.md"},
            {"Institutional Patterns": "global/patterns/index.md"},
            {"Governance Rules": "global/rules/index.md"},
        ]
    })

    # 5. Operations & Audit
    navigation.append({
        "Operations & Audit": [
            {"Rules & Constraints": "global/rules/index.md"},
            {"Evaluations": "runtime/evaluations/index.md"},
            {"Traces": "runtime/traces/index.md"},
        ]
    })

    # 6. Projects
    projects_items = [{"Projects Hub": "projects/index.md"}]
    for proj in context.projects:
        pid = proj.project_id
        project_pages = [
            {"Overview & Health": f"projects/{pid}/index.md"},
            {"Architecture State": f"projects/{pid}/state/index.md"},
            {"Intent Documents": f"projects/{pid}/intent/index.md"},
            {"Architecture Work": f"projects/{pid}/work/index.md"},
            {"Alignment Reports": f"projects/{pid}/alignment/index.md"},
            {"Architecture Decisions": f"projects/{pid}/adrs/index.md"},
            {"Execution Traces": f"projects/{pid}/traces/index.md"},
            {"Product Discovery Evidence": f"projects/{pid}/evidence/index.md"},
        ]
        projects_items.append({proj.display_name: project_pages})

    navigation.append({"Projects": projects_items})

    # 7. About
    about_items = [
        {"What is CAS?": "about/index.md"},
        {"Why CAS?": "about/why-cas.md"},
        {"How CAS Works": "about/how-cas-works.md"},
        {"Operating Model": "about/operating-model.md"},
        {
            "Platform Documentation": [
                {"Continuous Architecture System": "about/platform-docs/cas.md"},
                {"CAS Orchestration Flows": "about/platform-docs/cas-flows-overview.md"},
                {"Agent Collaboration": "about/platform-docs/cas-coding-agent-collaboration.md"},
                {"Governance Foundation": "about/platform-docs/cas-governance-foundation.md"},
                {"Governance Compliance": "about/platform-docs/cas-governance-compliance.md"},
            ]
        },
    ]
    navigation.append({"About": about_items})

    return navigation


def generate_consolidated_architecture_state_matrix(context: PortalWorkspaceContext) -> str:
    """Renders a Consolidated Architecture State Matrix table for workspace-level Architecture & State view."""
    content = "# Consolidated Architecture State Matrix\n\n"
    content += "Architecture state overview across all onboarded projects in the CAS Knowledge Workspace.\n\n"

    if not context.projects:
        content += "*No onboarded projects found in workspace.*\n"
        return content

    content += "| Project Identity | Status | Latest State | Active AWs | Architecture Link |\n"
    content += "|-------------------|--------|--------------|------------|-------------------|\n"

    for proj in context.projects:
        pid = proj.project_id
        disp = proj.display_name
        st = proj.status
        aem_slot = proj.artefacts.get("aem") if hasattr(proj, "artefacts") else None
        state_date = "Available" if aem_slot and aem_slot.is_present else "N/A"
        aw_slot = proj.artefacts.get("work") if hasattr(proj, "artefacts") else None
        aw_count = "Active" if aw_slot and aw_slot.is_present else "0"
        link = f"projects/{pid}/state/index.md"
        content += f"| **{disp}** (`{pid}`) | `{st}` | {state_date} | {aw_count} | [View Architecture State]({link}) |\n"

    content += "\n---\n\n"
    content += "!!! info \"Single-Project Topology Diagrams\"\n"
    content += "    Single-project architecture topology diagrams and AEM graphs are scoped strictly to project views. Select a project above to inspect its detailed architecture state.\n"

    return content
