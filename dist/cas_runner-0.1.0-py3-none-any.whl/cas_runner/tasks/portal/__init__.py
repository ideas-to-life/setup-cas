"""
CAS Portal Tasks Package.
Provides workspace discovery, project context resolution, navigation scoping,
evidence processing, and layout generation for the CAS Portal.
"""
