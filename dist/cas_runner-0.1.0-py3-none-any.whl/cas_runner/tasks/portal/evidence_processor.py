"""
Product Discovery Evidence & Epistemic Status Processor.
Parses candidate metrics, renders 5-tier status badges, builds 5-stage evidence chains, and formats evidence domain views.
"""
from typing import List, Optional
from cas_runner.tasks.portal.models import (
    EvidenceNode,
    EpistemicStatus,
    MeasurementReadiness,
    DomainType,
    MetricDefinition,
    EvidenceChainStage,
    SourceLocation,
    WorkspaceMetricAggregate,
    ProjectMetricContext,
    GovernancePath,
)


STATUS_BADGES = {
    EpistemicStatus.CANDIDATE_HYPOTHESISED: "🟡 **Candidate / Hypothesised**",
    EpistemicStatus.OBSERVED: "🔵 **Observed**",
    EpistemicStatus.DEMONSTRATED: "🟣 **Demonstrated**",
    EpistemicStatus.VALIDATED: "🟢 **Validated**",
    EpistemicStatus.MEASURED_OUTCOME: "🏆 **Measured Outcome**",
}

READINESS_BADGES = {
    MeasurementReadiness.NOT_MEASURABLE: "⚠️ **Not Measurable**",
    MeasurementReadiness.EVIDENCE_GAP: "❌ **Evidence Gap**",
    MeasurementReadiness.INSTRUMENTABLE: "📡 **Instrumentable**",
    MeasurementReadiness.DERIVABLE: "⚡ **Derivable**",
    MeasurementReadiness.OBSERVED: "👁️ **Observed**",
    MeasurementReadiness.MEASURED: "📊 **Measured**",
    MeasurementReadiness.VALIDATED: "✅ **Validated**",
}


def render_epistemic_status_badge(status: EpistemicStatus) -> str:
    """Renders a visual badge markdown string for a given 5-tier epistemic status."""
    return STATUS_BADGES.get(status, f"⚪ **{status.value}**")


def render_measurement_readiness_badge(readiness: MeasurementReadiness) -> str:
    """Renders a visual badge markdown string for a given measurement readiness state."""
    return READINESS_BADGES.get(readiness, f"⚪ **{readiness.value}**")


def build_evidence_chain_for_metric(metric: MetricDefinition) -> List[EvidenceChainStage]:
    """Builds a 5-stage evidence chain (Rule/Pattern -> Applicability -> Guidance -> Implementation -> Governance Outcome) for a metric."""
    has_loc = metric.primary_source_location is not None
    is_measured = metric.measurement_readiness in [MeasurementReadiness.MEASURED, MeasurementReadiness.VALIDATED]

    stage1 = EvidenceChainStage(
        stage_name="Rule / Pattern",
        is_complete=True,
        description=f"Governed rule or pattern defined for metric '{metric.name}'",
        source_location=metric.primary_source_location if has_loc else None,
    )
    stage2 = EvidenceChainStage(
        stage_name="Applicability",
        is_complete=True,
        description=f"Applicability condition identified for category scope {metric.category}",
        source_location=metric.primary_source_location if has_loc else None,
    )
    stage3 = EvidenceChainStage(
        stage_name="Guidance",
        is_complete=True,
        description=f"Active guidance emitted via CAS Skills and prompts",
        source_location=metric.primary_source_location if has_loc else None,
    )
    stage4 = EvidenceChainStage(
        stage_name="Implementation",
        is_complete=is_measured,
        description="Implementation verified in project source code" if is_measured else "Implementation evidence pending telemetry",
        gap_reason=None if is_measured else "Telemetry numerator or denominator missing in project context",
        source_location=metric.primary_source_location if (has_loc and is_measured) else None,
    )
    stage5 = EvidenceChainStage(
        stage_name="Governance Outcome",
        is_complete=is_measured,
        description=f"Outcome computed: {metric.calculated_value}" if is_measured else "Governance outcome calculation incomplete",
        gap_reason=None if is_measured else "Required evidence telemetry missing",
        source_location=metric.primary_source_location if (has_loc and is_measured) else None,
    )

    return [stage1, stage2, stage3, stage4, stage5]


def render_metric_detail_view(metric: MetricDefinition, evidence_chain: List[EvidenceChainStage], scope_target: Optional[str] = None) -> str:
    """Renders inspectable metric detail view with explicit scope, 5-tier EpistemicStatus, MeasurementReadiness, and 5-stage chain."""
    ep_badge = render_epistemic_status_badge(metric.epistemic_status)
    mr_badge = render_measurement_readiness_badge(metric.measurement_readiness)
    gov_path = metric.governance_path.value if metric.governance_path else "Standard Path"

    scope_str = f"**Scope**: `{scope_target}`" if scope_target else "**Scope**: `Workspace Aggregate`"

    view = f"# Metric Detail: {metric.name}\n\n"
    view += f"{scope_str} | **Category Scope**: `{metric.category}` | **Dimension**: `{metric.value_dimension.value}`\n\n"
    view += f"**Epistemic Status (Hypothesis Maturity)**: {ep_badge}\n"
    view += f"**Measurement Readiness (Telemetry Data)**: {mr_badge}\n"
    view += f"**Governance Path**: `{gov_path}`\n\n"

    view += "## Definition & Formula\n\n"
    view += f"> {metric.definition}\n\n"
    if metric.formula:
        view += f"**Formula**: `{metric.formula}`\n\n"

    if metric.calculated_value:
        view += f"### Current Calculated Value: **{metric.calculated_value}**\n\n"

    view += "## 5-Stage Evidence Chain\n\n"
    view += "| Stage # | Stage Name | Status | Description | Source Locator |\n"
    view += "|---------|------------|--------|-------------|----------------|\n"

    for idx, stage in enumerate(evidence_chain, 1):
        st_icon = "✅ Complete" if stage.is_complete else f"❌ Gap ({stage.gap_reason or 'Incomplete'})"
        loc_str = "N/A"
        if stage.source_location:
            loc = stage.source_location
            if loc.is_item_level:
                sub = f"#{loc.section_heading}" if loc.section_heading else ""
                lines = f" ({loc.line_range})" if loc.line_range else ""
                loc_str = f"[`{loc.file_path}{sub}{lines}`]({loc.file_path})"
            else:
                loc_str = f"*(Limitation: {loc.traceability_limitation or 'Collection link'})*"
        view += f"| `{idx}` | **{stage.stage_name}** | {st_icon} | {stage.description} | {loc_str} |\n"

    return view


def render_workspace_governance_dashboard_table(aggregates: List[WorkspaceMetricAggregate]) -> str:
    """Renders workspace-level Home Governance Health Dashboard metric summary table with project attribution."""
    table = "| Metric Name | Workspace Aggregate Value | Evidence Coverage Ratio | Contributing Projects | Uninstrumented Projects |\n"
    table += "|-------------|---------------------------|-------------------------|-----------------------|-------------------------|\n"

    for agg in aggregates:
        val_str = agg.aggregated_value if agg.aggregated_value else "*No Telemetry (Evidence Gap)*"
        contrib = ", ".join([f"`{p}`" for p in agg.contributing_projects]) if agg.contributing_projects else "*None*"
        uninst = ", ".join([f"`{p}`" for p in agg.uninstrumented_projects]) if agg.uninstrumented_projects else "*None*"
        # Home page metric links direct to the CAS Projects Hub page (projects/index.md)
        name_str = f"[**{agg.name}**](projects/index.md)"
        table += f"| {name_str} | {val_str} | `{agg.evidence_coverage_ratio}` | {contrib} | {uninst} |\n"

    return table


def render_project_evidence_matrix_table(context: ProjectMetricContext, is_project_landing: bool = False) -> str:
    """Renders active project context evidence matrix table with project-scoped metric detail links."""
    table = "| Metric Name | Category Scope | Epistemic Status | Measurement Readiness | Calculated Value | Primary Source Location |\n"
    table += "|-------------|----------------|------------------|-----------------------|------------------|-------------------------|\n"

    prefix = "evidence/metrics/" if is_project_landing else "metrics/"
    metric_links = {
        "prevent-guidance-adoption": f"{prefix}prevent-guidance-adoption.md",
        "prevent-pattern-reuse": f"{prefix}prevent-pattern-reuse.md",
    }

    for m in context.metrics:
        ep_badge = render_epistemic_status_badge(m.epistemic_status)
        mr_badge = render_measurement_readiness_badge(m.measurement_readiness)
        val_str = m.calculated_value if m.calculated_value else "*Evidence Gap*"
        loc_str = "N/A"
        if m.primary_source_location:
            loc = m.primary_source_location
            if loc.is_item_level:
                sub = f"#{loc.section_heading}" if loc.section_heading else ""
                lines = f" ({loc.line_range})" if loc.line_range else ""
                loc_str = f"[`{loc.file_path}{sub}{lines}`]({loc.file_path})"
            else:
                loc_str = f"*(Limitation: {loc.traceability_limitation or 'Collection link'})*"

        link_target = metric_links.get(m.metric_id, f"{prefix}{m.metric_id}.md")
        name_str = f"[**{m.name}**]({link_target})"

        table += f"| {name_str} | `{m.category}` | {ep_badge} | {mr_badge} | **{val_str}** | {loc_str} |\n"

    return table


def parse_product_discovery_evidence() -> List[EvidenceNode]:
    """Provides canonical candidate metrics for CAS Product Discovery."""
    metrics = [
        # Prevent
        ("ev-prevent-1", "Percentage of changes receiving applicable guidance", "Prevent", "global/rules/index.md"),
        ("ev-prevent-2", "Pattern reuse rate", "Prevent", "global/patterns/index.md"),
        ("ev-prevent-3", "Percentage of changes covered by existing Rules", "Prevent", "global/rules/index.md"),
        ("ev-prevent-4", "Number of preventable deviations", "Prevent", "global/signals/index.md"),
        ("ev-prevent-5", "Number of new architectural decisions", "Prevent", "global/decisions/index.md"),
        # Governance
        ("ev-gov-1", "Percentage of changes automatically governed", "Governance", "global/governance/health/index.md"),
        ("ev-gov-2", "ADR creation rate", "Governance", "global/decisions/index.md"),
        ("ev-gov-3", "ADR cycle time", "Governance", "global/decisions/index.md"),
        # Detect & Correct
        ("ev-detect-1", "Number of findings", "Detect & Correct", "global/signals/index.md"),
        ("ev-detect-2", "Time to detection", "Detect & Correct", "global/signals/index.md"),
        ("ev-detect-3", "Time to correction", "Detect & Correct", "global/signals/index.md"),
    ]

    nodes = []
    for ev_id, title, cat, src in metrics:
        nodes.append(
            EvidenceNode(
                evidence_id=ev_id,
                title=title,
                domain_type=DomainType.PRODUCT_DISCOVERY,
                epistemic_status=EpistemicStatus.CANDIDATE_HYPOTHESISED,
                source_link=src,
                description=f"Product Discovery candidate metric under category: {cat}",
            )
        )
    return nodes


def render_evidence_table(nodes: List[EvidenceNode]) -> str:
    """Renders a markdown table of evidence nodes with epistemic status badges, project badges, and source links."""
    table = "| ID | Metric / Evidence | Domain Scope | Attributed Project | Epistemic Status | Traceability Source |\n"
    table += "|----|-------------------|--------------|--------------------|------------------|---------------------|\n"

    ev_detail_links = {
        "ev-prevent-1": "metrics/prevent-guidance-adoption.md",
        "ev-prevent-2": "metrics/prevent-pattern-reuse.md",
    }

    for n in nodes:
        badge = render_epistemic_status_badge(n.epistemic_status)
        clean_link = n.source_link.replace("knowledge/", "").replace("README.md", "index.md")
        if not clean_link.startswith("../") and not clean_link.startswith("http") and not clean_link.startswith("mailto"):
            clean_link = f"../{clean_link}"
        link = f"[Source Artifact]({clean_link})"

        if n.evidence_id in ev_detail_links:
            title_str = f"[**{n.title}**]({ev_detail_links[n.evidence_id]})"
        else:
            title_str = f"**{n.title}**"

        proj_badge = f"`{n.originating_project_id}`" if getattr(n, "originating_project_id", None) else "*Workspace*"

        table += f"| `{n.evidence_id}` | {title_str} | `{n.domain_type.value}` | {proj_badge} | {badge} | {link} |\n"
    return table


def format_evidence_domain_view(nodes: List[EvidenceNode]) -> str:
    """Formats evidence nodes grouped into Product Discovery vs Project-Generated evidence domains."""
    pd_nodes = [n for n in nodes if n.domain_type == DomainType.PRODUCT_DISCOVERY]
    proj_nodes = [n for n in nodes if n.domain_type == DomainType.PROJECT_GENERATED]
    cp_nodes = [n for n in nodes if n.domain_type == DomainType.CROSS_PROJECT]

    view = "# Product Discovery Evidence Hub\n\n"
    view += "This view surfaces CAS Product Discovery hypotheses alongside project-generated empirical evidence.\n\n"

    if pd_nodes:
        view += "## CAS Product Discovery Evidence\n\n"
        view += "*Hypotheses and candidate metrics for CAS as a governed architecture platform.*\n\n"
        view += render_evidence_table(pd_nodes)
        view += "\n"

    if proj_nodes:
        view += "## Project-Generated Evidence\n\n"
        view += "*Empirical evidence generated through CAS usage on onboarded projects.*\n\n"
        view += render_evidence_table(proj_nodes)
        view += "\n"

    if cp_nodes:
        view += "## Cross-Project Aggregated Evidence\n\n"
        view += render_evidence_table(cp_nodes)
        view += "\n"

    return view

