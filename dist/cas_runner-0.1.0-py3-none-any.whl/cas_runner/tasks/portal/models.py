"""
Domain models for CAS Portal Workspace Context & Product Discovery Evidence Traceability.
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


class EpistemicStatus(str, Enum):
    CANDIDATE_HYPOTHESISED = "candidate_hypothesised"
    OBSERVED = "observed"
    DEMONSTRATED = "demonstrated"
    VALIDATED = "validated"
    MEASURED_OUTCOME = "measured_outcome"


class MeasurementReadiness(str, Enum):
    NOT_MEASURABLE = "not_measurable"
    EVIDENCE_GAP = "evidence_gap"
    INSTRUMENTABLE = "instrumentable"
    DERIVABLE = "derivable"
    OBSERVED = "observed"
    MEASURED = "measured"
    VALIDATED = "validated"


class PreventValueDimension(str, Enum):
    GUIDANCE_ADOPTION = "guidance_adoption"
    ARCHITECTURAL_REUSE = "architectural_reuse"
    DEVIATION_PREVENTION = "deviation_prevention"
    GOVERNANCE_AUTOMATION = "governance_automation"


class GovernancePath(str, Enum):
    GOVERNED_REUSE = "governed_reuse"
    ARCHITECTURAL_NOVELTY = "architectural_novelty"
    GOVERNED_EXCEPTION = "governed_exception"


class DomainType(str, Enum):
    PRODUCT_DISCOVERY = "product_discovery"
    PROJECT_GENERATED = "project_generated"
    CROSS_PROJECT = "cross_project"


class FallbackAction(str, Enum):
    RENDER_CONTENT = "render_content"
    RENDER_MISSING_NOTICE = "render_missing_notice"


@dataclass
class SourceLocation:
    file_path: str
    section_heading: Optional[str] = None
    line_range: Optional[str] = None
    item_id: Optional[str] = None
    is_item_level: bool = True
    traceability_limitation: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "file_path": self.file_path,
            "section_heading": self.section_heading,
            "line_range": self.line_range,
            "item_id": self.item_id,
            "is_item_level": self.is_item_level,
            "traceability_limitation": self.traceability_limitation,
        }


@dataclass
class EvidenceChainStage:
    stage_name: str
    is_complete: bool
    description: str
    gap_reason: Optional[str] = None
    source_location: Optional[SourceLocation] = None

    def to_dict(self) -> dict:
        return {
            "stage_name": self.stage_name,
            "is_complete": self.is_complete,
            "description": self.description,
            "gap_reason": self.gap_reason,
            "source_location": self.source_location.to_dict() if self.source_location else None,
        }


@dataclass
class MetricDefinition:
    metric_id: str
    name: str
    value_dimension: PreventValueDimension
    category: str  # Prevent, Governance, Detect & Correct
    definition: str
    formula: Optional[str] = None
    epistemic_status: EpistemicStatus = EpistemicStatus.CANDIDATE_HYPOTHESISED
    measurement_readiness: MeasurementReadiness = MeasurementReadiness.EVIDENCE_GAP
    evidence_maturity: str = "Level 1 — Instrumented"
    governance_path: Optional[GovernancePath] = None
    numerator_label: Optional[str] = None
    numerator_value: Optional[float] = None
    denominator_label: Optional[str] = None
    denominator_value: Optional[float] = None
    calculated_value: Optional[str] = None
    evidence_chain: List[EvidenceChainStage] = field(default_factory=list)
    primary_source_location: Optional[SourceLocation] = None
    evidence_gaps: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "metric_id": self.metric_id,
            "name": self.name,
            "value_dimension": self.value_dimension.value if isinstance(self.value_dimension, PreventValueDimension) else self.value_dimension,
            "category": self.category,
            "definition": self.definition,
            "formula": self.formula,
            "epistemic_status": self.epistemic_status.value if isinstance(self.epistemic_status, EpistemicStatus) else self.epistemic_status,
            "measurement_readiness": self.measurement_readiness.value if isinstance(self.measurement_readiness, MeasurementReadiness) else self.measurement_readiness,
            "evidence_maturity": self.evidence_maturity,
            "governance_path": self.governance_path.value if isinstance(self.governance_path, GovernancePath) else self.governance_path,
            "numerator_label": self.numerator_label,
            "numerator_value": self.numerator_value,
            "denominator_label": self.denominator_label,
            "denominator_value": self.denominator_value,
            "calculated_value": self.calculated_value,
            "evidence_chain": [s.to_dict() for s in self.evidence_chain],
            "primary_source_location": self.primary_source_location.to_dict() if self.primary_source_location else None,
            "evidence_gaps": self.evidence_gaps,
        }


@dataclass
class ProjectMetricContext:
    project_id: str
    metrics: List[MetricDefinition] = field(default_factory=list)
    is_project_isolated: bool = True

    def to_dict(self) -> dict:
        return {
            "project_id": self.project_id,
            "is_project_isolated": self.is_project_isolated,
            "metrics": [m.to_dict() for m in self.metrics],
        }


@dataclass
class WorkspaceMetricAggregate:
    workspace_id: str
    metric_id: str
    name: str
    aggregated_value: Optional[str] = None
    contributing_projects: List[str] = field(default_factory=list)
    uninstrumented_projects: List[str] = field(default_factory=list)
    evidence_coverage_ratio: str = "0/0"

    def to_dict(self) -> dict:
        return {
            "workspace_id": self.workspace_id,
            "metric_id": self.metric_id,
            "name": self.name,
            "aggregated_value": self.aggregated_value,
            "contributing_projects": self.contributing_projects,
            "uninstrumented_projects": self.uninstrumented_projects,
            "evidence_coverage_ratio": self.evidence_coverage_ratio,
        }


@dataclass
class ProjectArtefactSlot:
    artefact_type: str
    is_present: bool
    source_path: Optional[str] = None
    fallback_action: FallbackAction = FallbackAction.RENDER_MISSING_NOTICE

    def to_dict(self) -> dict:
        return {
            "artefact_type": self.artefact_type,
            "is_present": self.is_present,
            "source_path": self.source_path,
            "fallback_action": self.fallback_action.value
            if isinstance(self.fallback_action, FallbackAction)
            else self.fallback_action,
        }


@dataclass
class OnboardedProject:
    project_id: str
    display_name: str
    status: str
    base_path: str
    artefacts: Dict[str, ProjectArtefactSlot] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "project_id": self.project_id,
            "display_name": self.display_name,
            "status": self.status,
            "base_path": self.base_path,
            "artefacts": {k: v.to_dict() for k, v in self.artefacts.items()},
        }


@dataclass
class EvidenceNode:
    evidence_id: str
    title: str
    domain_type: DomainType
    epistemic_status: EpistemicStatus
    source_link: str
    description: str = ""
    originating_project_id: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "evidence_id": self.evidence_id,
            "title": self.title,
            "domain_type": self.domain_type.value
            if isinstance(self.domain_type, DomainType)
            else self.domain_type,
            "epistemic_status": self.epistemic_status.value
            if isinstance(self.epistemic_status, EpistemicStatus)
            else self.epistemic_status,
            "source_link": self.source_link,
            "description": self.description,
            "originating_project_id": self.originating_project_id,
        }


@dataclass
class ConsolidatedArchitectureStateRow:
    project_id: str
    display_name: str
    status: str
    latest_aem_date: str = "N/A"
    active_aw_count: int = 0
    project_state_link: str = ""

    def to_dict(self) -> dict:
        return {
            "project_id": self.project_id,
            "display_name": self.display_name,
            "status": self.status,
            "latest_aem_date": self.latest_aem_date,
            "active_aw_count": self.active_aw_count,
            "project_state_link": self.project_state_link,
        }


@dataclass
class ProductDiscoveryDomain:
    domain_id: str = "cas-product-discovery"
    evidence_nodes: List[EvidenceNode] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "domain_id": self.domain_id,
            "evidence_nodes": [e.to_dict() for e in self.evidence_nodes],
        }


@dataclass
class CrossProjectInsight:
    insight_id: str
    title: str
    attributed_project_ids: List[str]
    metric_value: str = ""

    def to_dict(self) -> dict:
        return {
            "insight_id": self.insight_id,
            "title": self.title,
            "attributed_project_ids": self.attributed_project_ids,
            "metric_value": self.metric_value,
        }


@dataclass
class WorkspaceConsolidatedContext:
    workspace_id: str
    projects: List[OnboardedProject] = field(default_factory=list)
    workspace_metrics: List[WorkspaceMetricAggregate] = field(default_factory=list)
    cross_project_insights: List[CrossProjectInsight] = field(default_factory=list)
    consolidated_evidence_nodes: List[EvidenceNode] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "workspace_id": self.workspace_id,
            "projects": [p.to_dict() for p in self.projects],
            "workspace_metrics": [m.to_dict() for m in self.workspace_metrics],
            "cross_project_insights": [c.to_dict() for c in self.cross_project_insights],
            "consolidated_evidence_nodes": [e.to_dict() for e in self.consolidated_evidence_nodes],
        }



class PortalScopeType(str, Enum):
    WORKSPACE = "WORKSPACE"
    PROJECT = "PROJECT"


@dataclass
class PortalScopeContext:
    workspace_id: str
    scope_type: PortalScopeType = PortalScopeType.WORKSPACE
    active_project_id: Optional[str] = None
    navigation_workspace_areas: List[str] = field(default_factory=lambda: ["home", "evidence", "insights", "projects_hub"])
    navigation_project_areas: List[str] = field(default_factory=lambda: ["overview", "architecture_state", "intent", "alignment", "work", "signals", "operations_audit"])
    host_fallback_prohibited: bool = True

    def to_dict(self) -> dict:
        return {
            "workspace_id": self.workspace_id,
            "scope_type": self.scope_type.value if isinstance(self.scope_type, PortalScopeType) else self.scope_type,
            "active_project_id": self.active_project_id,
            "navigation_scopes": {
                "workspace_areas": self.navigation_workspace_areas,
                "project_areas": self.navigation_project_areas,
            },
            "host_fallback_prohibited": self.host_fallback_prohibited,
        }


@dataclass
class PortalWorkspaceContext:
    workspace_id: str
    projects: List[OnboardedProject] = field(default_factory=list)
    product_discovery: ProductDiscoveryDomain = field(
        default_factory=ProductDiscoveryDomain
    )
    cross_project_insights: List[CrossProjectInsight] = field(default_factory=list)
    workspace_metrics: List[WorkspaceMetricAggregate] = field(default_factory=list)
    active_project_id: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "workspace_id": self.workspace_id,
            "active_project_id": self.active_project_id,
            "projects": [p.to_dict() for p in self.projects],
            "product_discovery": self.product_discovery.to_dict(),
            "cross_project_insights": [c.to_dict() for c in self.cross_project_insights],
            "workspace_metrics": [m.to_dict() for m in self.workspace_metrics],
        }
