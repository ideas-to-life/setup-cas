"""
JSON schema validator helper for PortalWorkspaceContext.
"""
import json
from pathlib import Path
import jsonschema

SCHEMA_PATH = Path(__file__).parent.parent.parent / "schemas" / "portal_workspace_context.json"


def load_portal_schema() -> dict:
    if not SCHEMA_PATH.exists():
        raise FileNotFoundError(f"Portal workspace context schema not found at {SCHEMA_PATH}")
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def validate_portal_workspace_context(data: dict) -> None:
    """Validates a dict representation of PortalWorkspaceContext against schema."""
    schema = load_portal_schema()
    jsonschema.validate(instance=data, schema=schema)


SCOPE_SCHEMA_PATH = Path(__file__).parent.parent.parent / "schemas" / "portal_scope_context.json"

def validate_portal_scope_context(data: dict) -> None:
    """Validates a dict representation of PortalScopeContext against scope schema."""
    if not SCOPE_SCHEMA_PATH.exists():
        raise FileNotFoundError(f"Portal scope context schema not found at {SCOPE_SCHEMA_PATH}")
    with open(SCOPE_SCHEMA_PATH, "r", encoding="utf-8") as f:
        schema = json.load(f)
    jsonschema.validate(instance=data, schema=schema)


CONTRACT_SCHEMA_PATH = Path(__file__).parent.parent.parent.parent.parent / "specs" / "073-portal-workspace-consolidation" / "contracts" / "portal-workspace-contract.json"

def validate_portal_workspace_contract(data: dict) -> None:
    """Validates data against portal workspace consolidation contract schema."""
    if CONTRACT_SCHEMA_PATH.exists():
        with open(CONTRACT_SCHEMA_PATH, "r", encoding="utf-8") as f:
            schema = json.load(f)
        jsonschema.validate(instance=data, schema=schema)
