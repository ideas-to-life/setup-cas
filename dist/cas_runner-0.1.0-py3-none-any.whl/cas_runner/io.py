import glob
import json
import os
import shutil
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Any, Protocol

import yaml


def safe_mkdir(path: Path, parents: bool = True, exist_ok: bool = True):
    """
    Robust version of Path.mkdir that handles broken symlinks.
    If a part of the path is a broken symlink, it will be unlinked and created as a directory.
    """
    if exist_ok and path.exists() and path.is_dir():
        return

    # If it's a broken symlink itself
    if path.is_symlink() and not path.exists():
        path.unlink()
        path.mkdir(parents=parents, exist_ok=exist_ok)
        return

    try:
        path.mkdir(parents=parents, exist_ok=exist_ok)
    except FileExistsError:
        # One of the parents might be a broken symlink or a file
        if not parents:
            raise

        parts = path.parts
        current = Path(parts[0]) if path.is_absolute() else Path(parts[0])
        start_idx = 1

        # Handle Windows drive letters or root
        if path.is_absolute() and len(parts) > 1 and ":" in parts[0]:
            current = Path(parts[0] + os.sep)
            start_idx = 1
        elif path.is_absolute():
            current = Path(os.sep)
            start_idx = 1
        else:
            # Relative path, first part is already in current
            pass

        for i in range(start_idx, len(parts)):
            current = current / parts[i]
            if current.is_symlink() and not current.exists():
                print(f"[IO][INFO] Fixing broken symlink at {current}")
                current.unlink()
                current.mkdir()
            elif current.exists() and not current.is_dir():
                if i == len(parts) - 1 and exist_ok:
                    raise FileExistsError(f"{current} exists and is not a directory")
                raise FileExistsError(f"Parent {current} exists and is not a directory")
            elif not current.exists():
                current.mkdir()

def get_default_base() -> Path:
    """Returns the default base path for the knowledge layer.
    Priority: CAS_KNOWLEDGE_WORKSPACE env var > <project_root>/knowledge > <project_root>/cas-knowledge.
    """
    env_root = os.getenv("CAS_KNOWLEDGE_WORKSPACE")
    if env_root is not None and env_root.strip():
        # Strip potential quotes and whitespace
        env_root = env_root.strip().strip('"').strip("'")
        return Path(env_root).expanduser().resolve()

    cwd = Path.cwd()
    if (cwd / "knowledge").exists():
        return (cwd / "knowledge").resolve()
    if (cwd / "cas-knowledge").exists():
        return (cwd / "cas-knowledge").resolve()
    return (cwd / "knowledge").resolve()


def get_workspace_name() -> str:
    """Returns the canonical workspace name (basename of the workspace root).
    Used in telemetry/logs to avoid leaking full filesystem paths.
    """
    return get_workspace_root().name

from dataclasses import dataclass


@dataclass
class TargetProjectContext:
    project_id: str
    project_root: Path
    evidence_root: Path
    knowledge_base_path: Path
    config_path: Path | None = None

    def __post_init__(self):
        self.project_root = Path(self.project_root).expanduser().resolve()
        self.evidence_root = Path(self.evidence_root).expanduser().resolve()
        self.knowledge_base_path = Path(self.knowledge_base_path).expanduser().resolve()
        if self.config_path:
            self.config_path = Path(self.config_path).expanduser().resolve()


def resolve_target_project_context(
    project: str | None = None,
    target_dir: str | Path | None = None,
    workspace_root: str | Path | None = None
) -> TargetProjectContext:
    """Resolves authoritative TargetProjectContext including project_id, project_root, and evidence_root."""
    proj_dir = Path(target_dir).expanduser().resolve() if target_dir else Path.cwd()
    config_file = proj_dir / "cas-config.yaml"
    if not target_dir and not config_file.exists() and (Path.cwd() / "cas-config.yaml").exists():
        config_file = Path.cwd() / "cas-config.yaml"

    config_data = {}
    if config_file.exists():
        try:
            with open(config_file) as fh:
                config_data = yaml.safe_load(fh) or {}
        except Exception:
            pass

    resolved_project = project or config_data.get("project") or os.getenv("CAS_PROJECT") or "ideas-to-life-cas"

    env_k_workspace = os.getenv("CAS_KNOWLEDGE_WORKSPACE")
    if workspace_root:
        k_base = Path(workspace_root).expanduser().resolve()
    elif env_k_workspace:
        k_base = Path(env_k_workspace).expanduser().resolve()
    else:
        raw_w_root = config_data.get("knowledge_provider", {}).get("workspace_root") or config_data.get("knowledge_provider", {}).get("path")
        if raw_w_root:
            k_base = (proj_dir / raw_w_root).expanduser().resolve()
        else:
            k_base = get_default_base()

    # Harden target_dir resolution: if project is explicitly provided and not target_dir,
    # avoid implicitly assuming host repo cwd is the project root if project dir exists in knowledge/projects/
    # Only reassign if proj_dir is the CAS implementation repository root
    is_cas_host_repo = (proj_dir / "pyproject.toml").exists() and (proj_dir / "src" / "cas_runner").exists()
    if project and not target_dir and is_cas_host_repo:
        project_k_dir = k_base / "projects" / resolved_project
        if project_k_dir.exists() and resolved_project != "ideas-to-life-cas":
            proj_dir = project_k_dir


    raw_ev_root = config_data.get("knowledge_provider", {}).get("evidence_root") or config_data.get("evidence_root")
    if raw_ev_root:
        evidence_root = (proj_dir / raw_ev_root).expanduser().resolve()
    else:
        evidence_root = proj_dir

    return TargetProjectContext(
        project_id=resolved_project,
        project_root=proj_dir,
        evidence_root=evidence_root,
        knowledge_base_path=k_base,
        config_path=config_file if config_file.exists() else None
    )



class KnowledgeProvider(Protocol):
    """
    Architectural abstraction for governance knowledge persistence and retrieval.
    """
    base: Path
    def load_architecture_state(self, project: str) -> dict[str, Any] | None: ...
    def load_conversation(self, project: str) -> list[dict[str, str]]: ...
    def load_foundational_assets(self, project: Any) -> list[dict[str, Any]]: ...
    def load_project_vision(self, project: str) -> dict[str, Any] | None: ...
    def load_baseline_assessment(self, project: str) -> dict[str, Any] | None: ...
    def load_architecture_work(self, project: str) -> list[dict[str, Any]]: ...
    def load_latest_aem(self, project: str) -> dict[str, Any] | None: ...
    def load_latest_alignment(self, project: str) -> dict[str, Any] | None: ...
    def load_latest_aid(self, project: str) -> dict[str, Any] | None: ...
    def load_rules(self, project: str | None = None) -> list[dict[str, Any]]: ...
    def load_capability_lineage(self, project: str) -> dict[str, Any]: ...
    def load_project_config(self, project: str) -> dict[str, Any]: ...
    def load_pattern_proposals(self, project: str) -> list[dict[str, Any]]: ...
    def load_agentic_patterns_catalogue(self, project: str) -> dict[str, Any] | None: ...
    def load_structural_patterns_catalogue(self, project: str) -> dict[str, Any] | None: ...
    def load_pattern_scope_classification(self, project: str) -> dict[str, Any] | None: ...
    def load_pattern_promotion_recommendations(self, project: str) -> dict[str, Any] | None: ...
    def load_promotion_decisions(self, project: str) -> list[dict[str, Any]]: ...
    def load_adrs(self, project: str) -> list[dict[str, Any]]: ...
    def load_decision_records(self, project: str | None = None) -> list[dict[str, Any]]: ...
    def persist_outputs(self, output: dict[str, Any], project: str): ...
    def persist_capability_lineage(self, lineage: dict[str, Any], project: str): ...
    def persist_evaluation(self, evaluation: dict[str, Any], project: str): ...
    def load_capability_inventory(self, project: str) -> dict[str, Any]: ...
    def persist_capability_inventory(self, inventory: dict[str, Any], project: str): ...
    def archive_conversations(self, project: str, file_paths: list[str]) -> list[Path]: ...

class LocalKnowledgeProvider:
    """
    Local filesystem implementation of the KnowledgeProvider.
    """
    def __init__(self, base_path: str | Path | None = None, project_context: TargetProjectContext | None = None):
        if project_context:
            self.context = project_context
            self.base = project_context.knowledge_base_path
        elif base_path:
            self.context = None
            self.base = Path(base_path).expanduser().resolve()
        else:
            self.context = None
            self.base = get_default_base()

    def load_architecture_state(self, project: str) -> dict[str, Any] | None:
        pattern = self.base / "projects" / project / "state" / "*.md"
        files = sorted(glob.glob(str(pattern)), reverse=True)
        if not files: return None
        return self._parse_markdown_with_frontmatter(files[0])

    def load_conversation(self, project: str) -> list[dict[str, str]]:
        ingestion_dir = self.base / "projects" / project / "ingestion"
        if not ingestion_dir.exists():
            return []
        contents = []
        for p in sorted(ingestion_dir.glob("*.md")):
            if not p.is_file():
                continue
            try:
                size = p.stat().st_size
                if size > 500 * 1024:
                    print(f"[IO][WARN] Skipping oversized conversation file {p} ({size / 1024:.1f} KB > 500 KB limit)")
                    continue
                with open(p, encoding="utf-8") as fh:
                    contents.append({"path": str(p), "content": fh.read()})
            except Exception as e:
                print(f"[IO][WARN] Failed to read conversation file {p}: {e}")
        return contents

    def archive_conversations(self, project: str, file_paths: list[str]) -> list[Path]:
        archived = []
        if not file_paths:
            return archived
        archive_dir = self.base / "projects" / project / "ingestion" / "archive"
        archive_dir.mkdir(parents=True, exist_ok=True)
        for fp in file_paths:
            p = Path(fp)
            if not p.exists() or not p.is_file():
                continue
            target = archive_dir / p.name
            if target.exists():
                ts = datetime.now().strftime("%Y%m%d%H%M%S")
                target = archive_dir / f"{p.stem}-{ts}{p.suffix}"
            try:
                shutil.move(str(p), str(target))
                archived.append(target)
                print(f"[IO][INFO] Archived ingested conversation: {p.name} -> {target}")
            except Exception as e:
                print(f"[IO][WARN] Failed to archive conversation {p}: {e}")
        return archived

    def load_foundational_assets(self, project: Any) -> list[dict[str, Any]]:
        assets = []
        if isinstance(project, TargetProjectContext):
            context = project
        elif hasattr(self, "context") and self.context:
            context = self.context
        else:
            context = resolve_target_project_context(project=str(project) if project else None)

        project_id = context.project_id
        evidence_root = context.evidence_root
        kb_base = getattr(context, "knowledge_base_path", None) or self.base

        # 1. Load project knowledge directory recursive (Foundational)
        knowledge_pattern = f"{kb_base}/projects/{project_id}/**/*.md"
        knowledge_files = glob.glob(knowledge_pattern, recursive=True)
        for f in knowledge_files:
            with open(f) as fh:
                assets.append({
                    "path": f,
                    "content": fh.read(),
                    "category": "foundational",
                    "type": "knowledge"
                })

        # 2. Load codebase docs strictly from within target project evidence_root (Foundational)
        docs_pattern = str(evidence_root / "src" / "**" / "*.md")
        docs_files = glob.glob(docs_pattern, recursive=True)
        for f in docs_files:
            with open(f) as fh:
                assets.append({
                    "path": f,
                    "content": fh.read(),
                    "category": "foundational",
                    "type": "codebase"
                })

        # 3. Load project root specific files strictly from within target project evidence_root (Foundational)
        root_files = ["README.md", "VISION.md", "vision.md", "RUNBOOK.md", "AGENT.md", "GEMINI.md", "CLAUDE.md"]
        for f in root_files:
            p = evidence_root / f
            if p.exists():
                with open(p) as fh:
                    assets.append({
                        "path": str(p),
                        "content": fh.read(),
                        "category": "foundational",
                        "type": "core_doc"
                    })

        # 4. Load Governance Evidence (Decisions)
        project_adrs_pattern = kb_base / "projects" / project_id / "adrs" / "*.md"
        decision_files = sorted(glob.glob(str(project_adrs_pattern)))
        if not decision_files:
            global_decisions_pattern = kb_base / "global" / "decisions" / "*.md"
            decision_files = sorted(glob.glob(str(global_decisions_pattern)))

        for f in decision_files:
            with open(f) as fh:
                assets.append({
                    "path": f,
                    "content": fh.read(),
                    "category": "governance_evidence",
                    "type": "adr"
                })
        return assets

    def load_project_vision(self, project: str) -> dict[str, Any] | None:
        pattern = self.base / "projects" / project / "vision" / "*.md"
        files = sorted(glob.glob(str(pattern)), reverse=True)
        if not files: return None
        return self._parse_markdown_with_frontmatter(files[0])

    def load_baseline_assessment(self, project: str) -> dict[str, Any] | None:
        pattern = self.base / "projects" / project / "baseline" / "*.md"
        files = sorted(glob.glob(str(pattern)), reverse=True)
        if not files: return None
        return self._parse_markdown_with_frontmatter(files[0])

    def load_architecture_work(self, project: str) -> list[dict[str, Any]]:
        pattern = self.base / "projects" / project / "work" / "*.md"
        files = sorted(glob.glob(str(pattern)))
        return [self._parse_markdown_with_frontmatter(f) for f in files]

    def load_latest_aem(self, project: str) -> dict[str, Any] | None:
        # Search project-scoped maps first
        proj_pattern = self.base / "projects" / project / "maps" / "aem-*.md"
        proj_files = sorted(glob.glob(str(proj_pattern)), reverse=True)
        if proj_files:
            return self._parse_markdown_with_frontmatter(proj_files[0])

        # Global fallback ONLY for CAS platform itself
        if project in ["ideas-to-life-cas", "global"]:
            global_pattern = self.base / "global" / "maps" / "aem-*.md"
            global_files = sorted(glob.glob(str(global_pattern)), reverse=True)
            if global_files:
                return self._parse_markdown_with_frontmatter(global_files[0])

        return None

    def load_latest_alignment(self, project: str) -> dict[str, Any] | None:
        pattern = self.base / "projects" / project / "alignment" / "alignment-*.md"
        files = sorted(glob.glob(str(pattern)), reverse=True)
        if not files: return None
        return self._parse_markdown_with_frontmatter(files[0])

    def load_latest_aid(self, project: str) -> dict[str, Any] | None:
        pattern = self.base / "projects" / project / "intent" / "*.md"
        files = sorted(glob.glob(str(pattern)), reverse=True)
        if not files: return None
        return self._parse_markdown_with_frontmatter(files[0])

    def load_rules(self, project: str | None = None) -> list[dict[str, Any]]:
        rules = []

        # 1. Load Global Rules
        global_pattern = self.base / "global" / "rules" / "**" / "*.md"
        global_files = sorted(glob.glob(str(global_pattern), recursive=True))
        for f in global_files:
            rules.append({
                "id": Path(f).stem,
                "title": Path(f).stem.replace("-", " ").title(),
                "content": Path(f).read_text(),
                "scope": "global",
                "status": "active"
            })

        # 2. Load Project Rules
        if project:
            project_pattern = self.base / "projects" / project / "rules" / "**" / "*.md"
            project_files = sorted(glob.glob(str(project_pattern), recursive=True))
            for f in project_files:
                rules.append({
                    "id": Path(f).stem,
                    "title": Path(f).stem.replace("-", " ").title(),
                    "content": Path(f).read_text(),
                    "scope": "project",
                    "status": "active"
                })
        return rules

    def load_capability_lineage(self, project: str) -> dict[str, Any]:
        path = self.base / "projects" / project / "capabilities" / "lineage.yaml"
        if path.exists():
            with open(path) as fh:
                return yaml.safe_load(fh) or {}
        return {"capabilities": {}}

    def load_capability_inventory(self, project: str) -> dict[str, Any]:
        path = self.base / "projects" / project / "capabilities" / "inventory.yaml"
        if path.exists():
            with open(path) as fh:
                return yaml.safe_load(fh) or {}
        return {
            "version": "1.0.0",
            "project": project,
            "last_updated": "",
            "capabilities": {}
        }

    def load_project_config(self, project: str) -> dict[str, Any]:
        path = self.base / "projects" / project / "config.yaml"
        if path.exists():
            with open(path) as fh:
                return yaml.safe_load(fh) or {}
        return {}

    def load_pattern_proposals(self, project: str) -> list[dict[str, Any]]:
        directory = self.base / "projects" / project / "proposed-patterns"
        if not directory.exists():
            return []

        proposals = []

        # 1. Load YAML files
        yaml_files = sorted(glob.glob(str(directory / "*.yaml")))
        for path in yaml_files:
            try:
                with open(path) as fh:
                    for doc in yaml.safe_load_all(fh):
                        if not doc:
                            continue
                        if isinstance(doc, dict):
                            items = doc.get("pattern_proposals") or doc.get("patterns") or []
                        else:
                            items = doc
                        if isinstance(items, list):
                            for item in items:
                                if isinstance(item, dict):
                                    if "pattern_id" not in item and "id" in item:
                                        item["pattern_id"] = item["id"]
                            proposals.extend(items)
            except Exception as e:
                print(f"[IO][WARN] Failed to load pattern proposals from {path}: {e}")

        # 2. Load JSON files
        json_files = sorted(glob.glob(str(directory / "*.json")))
        for path in json_files:
            try:
                with open(path) as fh:
                    data = json.load(fh) or {}
                    if isinstance(data, dict):
                        # Skip raw extraction catalogues
                        if "catalogue_metadata" in data:
                            continue
                        items = data.get("pattern_proposals") or data.get("patterns") or []
                    else:
                        items = data
                    if isinstance(items, list):
                        for item in items:
                            if isinstance(item, dict):
                                if "pattern_id" not in item and "id" in item:
                                    item["pattern_id"] = item["id"]
                        proposals.extend(items)
            except Exception as e:
                print(f"[IO][WARN] Failed to load pattern proposals from {path}: {e}")

        return proposals

    def load_agentic_patterns_catalogue(self, project: str) -> dict[str, Any] | None:
        directory = self.base / "projects" / project / "proposed-patterns"
        candidate_paths = [
            directory / f"{project}-agentic-patterns.json",
            directory / "cas_agentic_ai_patterns.json",
            directory / "agentic-patterns.json",
        ]
        for path in candidate_paths:
            if path.exists():
                try:
                    with open(path, "r", encoding="utf-8") as fh:
                        return json.load(fh)
                except Exception as e:
                    print(f"[IO][WARN] Failed to load agentic patterns catalogue from {path}: {e}")
        return None

    def load_structural_patterns_catalogue(self, project: str) -> dict[str, Any] | None:
        directory = self.base / "projects" / project / "proposed-patterns"
        candidate_paths = [
            directory / f"{project}-structural-patterns.json",
            directory / "cas_structural_architecture_patterns.json",
            directory / "structural-patterns.json",
        ]
        for path in candidate_paths:
            if path.exists():
                try:
                    with open(path, "r", encoding="utf-8") as fh:
                        return json.load(fh)
                except Exception as e:
                    print(f"[IO][WARN] Failed to load structural patterns catalogue from {path}: {e}")
        return None

    def load_pattern_scope_classification(self, project: str) -> dict[str, Any] | None:
        path = self.base / "projects" / project / "governance" / "pattern-scope-classification.yaml"
        if path.exists():
            try:
                with open(path) as fh:
                    return yaml.safe_load(fh)
            except Exception as e:
                print(f"[IO][WARN] Failed to load pattern scope classification from {path}: {e}")
        return None

    def load_pattern_promotion_recommendations(self, project: str) -> dict[str, Any] | None:
        path = self.base / "projects" / project / "governance" / "pattern-promotion-recommendations.yaml"
        if path.exists():
            try:
                with open(path) as fh:
                    return yaml.safe_load(fh)
            except Exception as e:
                print(f"[IO][WARN] Failed to load pattern promotion recommendations from {path}: {e}")
        return None

    def load_promotion_decisions(self, project: str) -> list[dict[str, Any]]:
        directory = self.base / "projects" / project / "governance" / "promotion-decisions"
        if not directory.exists():
            return []

        decisions = []
        yaml_files = sorted(glob.glob(str(directory / "*.yaml")))
        for path in yaml_files:
            try:
                with open(path) as fh:
                    data = yaml.safe_load(fh) or {}
                    if data.get("decision", {}).get("status") == "accepted":
                        decisions.append(data)
            except Exception as e:
                print(f"[IO][WARN] Failed to load promotion decision from {path}: {e}")
        return decisions

    def load_adrs(self, project: str) -> list[dict[str, Any]]:
        directory = self.base / "projects" / project / "adrs"
        if not directory.exists():
            return []

        adrs = []
        md_files = sorted(glob.glob(str(directory / "*.md")))
        for path in md_files:
            try:
                data = self._parse_markdown_with_frontmatter(path)
                if data.get("knowledgeType") == "architecture_decision_record":
                    # Only include forum-approved ADRs for this specific workflow context
                    if data.get("governance", {}).get("forum_status") in ("accepted", "conditional"):
                        adrs.append(data)
            except Exception as e:
                print(f"[IO][WARN] Failed to load ADR from {path}: {e}")
        return adrs

    def load_decision_records(self, project: str | None = None) -> list[dict[str, Any]]:
        """
        Load decision records (ADRs). If project is provided and exists under projects/{project}/adrs,
        load project-specific decision records; otherwise load global decision records.
        """
        if project:
            directory = self.base / "projects" / project / "adrs"
            if not directory.exists() or not glob.glob(str(directory / "*.md")):
                directory = self.base / "global" / "decisions"
        else:
            directory = self.base / "global" / "decisions"

        if not directory.exists():
            return []

        adrs = []
        md_files = sorted(glob.glob(str(directory / "*.md")))
        for path in md_files:
            try:
                data = self._parse_markdown_with_frontmatter(path)
                adrs.append(data)
            except Exception as e:
                print(f"[IO][WARN] Failed to load decision record from {path}: {e}")
        return adrs

    def persist_outputs(self, output: dict[str, Any], project: str):
        try:
            for key, value in output.items():
                if key == "architecture_work":
                    self._persist_collection(value, self.base / "projects" / project / "work", _format_aw_markdown)
                elif key == "archived_conversations":
                    self.archive_conversations(project, value)
                elif key == "rule_context":
                    self._persist_json_as_yaml(value, self.base / "runtime" / "rule-context.json")
                elif key == "execution_profile":
                    self._persist_yaml(value, self.base / "runtime" / "execution-profile.yaml")
                elif key == "capabilities":
                    self._persist_file(
                        _format_capability_markdown(value),
                        self.base / "projects" / project / "capabilities" / f"capabilities-{date.today().isoformat()}.md"
                    )
                elif key == "capability_lineage":
                    self.persist_capability_lineage(value, project)
                elif key == "aem":
                    date_str = value.get("frontmatter", {}).get("date") or date.today().isoformat()
                    self._persist_file(_format_aem_markdown(value), self.base / "global" / "maps" / f"aem-{date_str}.md")
                elif key == "alignment_report":
                    date_str = value.get("frontmatter", {}).get("date") or date.today().isoformat()
                    self._persist_file(_format_alignment_markdown(value), self.base / "projects" / project / "alignment" / f"alignment-{date_str}.md")
                elif key == "aid":
                    date_str = value.get("frontmatter", {}).get("date") or date.today().isoformat()
                    self._persist_file(_format_aid_markdown(value), self.base / "projects" / project / "intent" / f"aid-{date_str}.md")
                elif key == "baseline_assessment":
                    date_str = value.get("frontmatter", {}).get("date") or date.today().isoformat()
                    self._persist_file(_format_baseline_assessment_markdown(value), self.base / "projects" / project / "baseline" / f"baseline-assessment-{date_str}.md")
                elif key == "current_architecture_state":
                    date_str = value.get("frontmatter", {}).get("date") or date.today().isoformat()
                    self._persist_file(_format_current_architecture_state_markdown(value), self.base / "projects" / project / "state" / "current-architecture-state.md")
                elif key == "agentic_patterns_catalogue":
                    self._persist_file(json.dumps(value, indent=2), self.base / "projects" / project / "proposed-patterns" / f"{project}-agentic-patterns.json")
                elif key == "structural_patterns_catalogue":
                    self._persist_file(json.dumps(value, indent=2), self.base / "projects" / project / "proposed-patterns" / f"{project}-structural-patterns.json")
                elif key == "agentic_pattern_proposals":
                    self._persist_upsert_proposals(value, self.base / "projects" / project / "proposed-patterns" / "agentic-pattern-proposals.yaml")
                elif key == "structural_pattern_proposals":
                    self._persist_upsert_proposals(value, self.base / "projects" / project / "proposed-patterns" / "structural-pattern-proposals.yaml")
                elif key == "pattern_proposals":
                    self._persist_file(_format_pattern_proposals_yaml(value), self.base / "projects" / project / "proposed-patterns" / "pattern-proposals.yaml")
                elif key == "pattern_scope_classification":
                    self._persist_file(_format_pattern_scope_classification_yaml(value), self.base / "projects" / project / "governance" / "pattern-scope-classification.yaml")
                elif key == "pattern_promotion_recommendations":
                    self._persist_file(_format_pattern_promotion_recommendations_yaml(value), self.base / "projects" / project / "governance" / "pattern-promotion-recommendations.yaml")
                elif key == "promotion_decision":
                    pattern_id = value.get("pattern_id", "unknown")
                    self._persist_file(_format_promotion_decision_yaml(value), self.base / "projects" / project / "governance" / "promotion-decisions" / f"promotion-decision-{pattern_id}.yaml")
                elif key == "adrs":
                    self._persist_collection(value, self.base / "projects" / project / "adrs", _format_adr_markdown)
                elif key == "patterns":
                    for item in (value if isinstance(value, list) else [value]):
                        item_id = item.get("frontmatter", {}).get("id") or item.get("id")
                        if not item_id:
                            print(f"[IO][WARN] Pattern item missing ID, skipping persistence: {item}")
                            continue
                        clean_id = item_id.removeprefix("pattern-")
                        classification = item.get("frontmatter", {}).get("classification") or item.get("classification")
                        scope_raw = item.get("frontmatter", {}).get("scope") or item.get("scope")
                        scope_type = scope_raw.get("type") if isinstance(scope_raw, dict) else scope_raw
                        scope_class = (
                            item.get("frontmatter", {}).get("source_traceability", {}).get("scope_classification")
                            or item.get("source_traceability", {}).get("scope_classification")
                        )

                        is_global = (
                            classification in ["core", "supporting", "global"]
                            or scope_type in ["core", "supporting", "global"]
                            or scope_class == "global"
                        )
                        if is_global:
                            global_dir = self.base / "global" / "patterns"
                            self._persist_file(_format_pattern_markdown(item), global_dir / f"{clean_id}.md")
                        else:
                            project_dir = self.base / "projects" / project / "patterns"
                            self._persist_file(_format_pattern_markdown(item), project_dir / f"{item_id}.md")

                elif key == "reference_architectures":
                    repo_root = getattr(self.context, "project_root", None) if hasattr(self, "context") and self.context else Path.cwd()
                    for item in value if isinstance(value, list) else [value]:
                        pid = item.get("pattern_id")
                        content = item.get("markdown_content") or item.get("content")
                        if pid and content:
                            persist_reference_architecture(
                                project=project,
                                pattern_id=pid,
                                content=content,
                                base_path=self.base,
                                repo_root=repo_root,
                            )
        except Exception as e:
            print(f"[IO][ERROR] persist_outputs failed: {e}")

    def persist_capability_lineage(self, lineage: dict[str, Any], project: str):
        cap_dir = self.base / "projects" / project / "capabilities"
        safe_mkdir(cap_dir, parents=True, exist_ok=True)
        (cap_dir / "lineage.yaml").write_text(yaml.dump(lineage, sort_keys=False))

    def persist_capability_inventory(self, inventory: dict[str, Any], project: str):
        import jsonschema
        schema_path = Path(__file__).parent / "schemas" / "inventory_schema.json"
        if schema_path.exists():
            with open(schema_path) as sf:
                schema = json.load(sf)
            jsonschema.validate(instance=inventory, schema=schema)
        
        cap_dir = self.base / "projects" / project / "capabilities"
        safe_mkdir(cap_dir, parents=True, exist_ok=True)
        (cap_dir / "inventory.yaml").write_text(yaml.dump(inventory, sort_keys=False))

    def persist_evaluation(self, evaluation: dict[str, Any], project: str):
        eval_dir = self.base / "runtime" / "evaluations"
        safe_mkdir(eval_dir, parents=True, exist_ok=True)
        trace_id = evaluation.get("trace_id", "unknown")
        timestamp = evaluation.get("timestamp", date.today().isoformat()).replace(":", "-")
        if "T" in timestamp:
            timestamp = timestamp.split(".")[0].replace("-", "").replace(":", "").replace("T", "-")
        path = eval_dir / f"eval-{project}-{timestamp}-{trace_id[:8]}.json"
        path.write_text(json.dumps(evaluation, indent=2))

    # --- Internal Helpers ---

    def _parse_markdown_with_frontmatter(self, file_path: str) -> dict[str, Any]:
        try:
            content = Path(file_path).read_text()
            if content.startswith("---"):
                parts = content.split("---", 2)
                if len(parts) >= 3:
                    _, yaml_block, body = parts
                    data = yaml.safe_load(yaml_block) or {}
                    data["details"] = body.strip()
                    # Basic section parsing
                    sections = {}
                    current_section = None
                    for line in body.split("\n"):
                        if line.startswith("## ") or line.startswith("# "):
                            level = 3 if line.startswith("## ") else 2
                            current_section = line[level:].lower().replace(" ", "_").strip()
                            sections[current_section] = ""
                        elif current_section:
                            sections[current_section] += line + "\n"
                    data["sections"] = {k: v.strip() for k, v in sections.items()}
                    return data
            return {"details": content.strip(), "sections": {}}
        except Exception as e:
            print(f"[IO][WARN] Failed to parse {file_path}: {e}")
            return {"details": "", "sections": {}}

    def _persist_collection(self, items: list[dict[str, Any]], dir_path: Path, formatter):
        safe_mkdir(dir_path, parents=True, exist_ok=True)
        for item in items:
            # Handle new structure where id is in frontmatter
            item_id = item.get("frontmatter", {}).get("id") or item.get("id")
            if not item_id:
                print(f"[IO][WARN] Item missing ID, skipping persistence: {item}")
                continue
            self._persist_file(formatter(item), dir_path / f"{item_id}.md")

    def _persist_file(self, content: str, path: Path):
        safe_mkdir(path.parent, parents=True, exist_ok=True)
        if path.exists() and path.read_text() == content:
            return
        path.write_text(content)
        print(f"[IO] Persisted {path}")

    def _persist_yaml(self, data: Any, path: Path):
        self._persist_file(yaml.dump(data, sort_keys=False), path)

    def _persist_upsert_proposals(self, new_data: dict[str, Any], path: Path):
        """Persists pattern proposals by performing an upsert merge keyed by pattern_id."""
        existing_items = []
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    for loaded in yaml.safe_load_all(fh):
                        if not loaded:
                            continue
                        if isinstance(loaded, dict):
                            items = loaded.get("pattern_proposals") or loaded.get("patterns") or []
                        elif isinstance(loaded, list):
                            items = loaded
                        else:
                            items = []
                        existing_items.extend(items)
            except Exception as e:
                print(f"[IO][WARN] Could not read existing proposals from {path} for upsert: {e}")

        # Index existing items by pattern_id
        merged_by_id: dict[str, dict[str, Any]] = {}
        for item in existing_items:
            if isinstance(item, dict):
                pid = item.get("pattern_id") or item.get("id")
                if pid:
                    merged_by_id[pid] = item

        # Upsert new proposals
        new_items = []
        if isinstance(new_data, dict):
            new_items = new_data.get("pattern_proposals") or new_data.get("patterns") or []
        elif isinstance(new_data, list):
            new_items = new_data

        for item in new_items:
            if isinstance(item, dict):
                pid = item.get("pattern_id") or item.get("id")
                if pid:
                    if pid in merged_by_id:
                        # Update existing entry with refreshed fields
                        merged_by_id[pid].update(item)
                    else:
                        merged_by_id[pid] = item

        # Write merged list
        merged_output = {"pattern_proposals": list(merged_by_id.values())}
        self._persist_file(yaml.dump(merged_output, sort_keys=False), path)

    def _persist_json_as_yaml(self, data: Any, path: Path):
        # Despite the filename extension in some old logic, we might be writing YAML
        self._persist_file(yaml.dump(data), path)

# --- Global Provider Resolution ---

_active_provider: KnowledgeProvider | None = None

def get_provider() -> KnowledgeProvider | LocalKnowledgeProvider:
    """Returns the active knowledge provider based on configuration."""
    global _active_provider
    if _active_provider is None:
        # 1. Try to load config from current directory
        config_path = Path("cas-config.yaml")
        config = {}
        if config_path.exists():
            try:
                with open(config_path) as f:
                    config = yaml.safe_load(f) or {}
            except Exception as e:
                print(f"[IO][WARN] Failed to load cas-config.yaml: {e}")

        provider_config = config.get("knowledge_provider", {})
        provider_type = provider_config.get("type", "local")

        if provider_type == "local":
            # Priority: 1. Environment Variable, 2. Config File, 3. Default (get_default_base())
            env_root = os.getenv("CAS_KNOWLEDGE_WORKSPACE")
            if env_root is not None and env_root.strip():
                # Strip potential quotes and whitespace
                env_root = env_root.strip().strip('"').strip("'")
                base_path = Path(env_root).expanduser().resolve()
            else:
                raw_path = provider_config.get("workspace_root") or provider_config.get("path")
                if raw_path:
                    candidate = Path(raw_path).expanduser().resolve()
                    try:
                        if candidate.exists() or candidate.parent.exists():
                            base_path = candidate
                        else:
                            print(f"[IO][WARN] Configured workspace_root '{raw_path}' does not exist on disk. Falling back to default base.")
                            base_path = get_default_base()
                    except Exception as e:
                        print(f"[IO][WARN] Failed checking configured workspace_root '{raw_path}': {e}. Falling back to default base.")
                        base_path = get_default_base()
                else:
                    base_path = get_default_base()
                    # Low-verbosity fallback warning
                    if os.getenv("CAS_VERBOSE", "false").lower() == "true":
                        print(f"[IO][INFO] No workspace root configured. Falling back to project root: {base_path}")

            _active_provider = LocalKnowledgeProvider(base_path=str(base_path))
        else:
            _active_provider = LocalKnowledgeProvider(base_path=str(get_default_base()))
            print(f"[IO][WARN] Unknown provider type '{provider_type}'. Defaulting to 'local' {_active_provider}.")

    return _active_provider

def get_workspace_root() -> Path:
    """Returns the base path of the active knowledge provider."""
    provider = get_provider()
    if hasattr(provider, "base"):
        return provider.base
    return get_default_base()

def get_telemetry_root() -> Path:
    """
    Returns the root directory for telemetry traces.
    Priority: KNOWLEDGE_TELEMETRY_OUTPUT_DIR env var > cas-config.yaml telemetry.output_dir > workspace_root/runtime/traces
    """
    # 1. Environment Variable
    env_dir = os.getenv("KNOWLEDGE_TELEMETRY_OUTPUT_DIR")
    if env_dir is not None and env_dir.strip():
        # Strip potential quotes and whitespace
        env_dir = env_dir.strip().strip('"').strip("'")
        return Path(env_dir).expanduser().resolve()

    # 2. Config File
    config_path = Path("cas-config.yaml")
    if config_path.exists():
        try:
            with open(config_path) as f:
                config = yaml.safe_load(f) or {}
                telemetry_dir = config.get("telemetry", {}).get("output_dir")
                if telemetry_dir:
                    return Path(telemetry_dir).expanduser().resolve()
        except Exception:
            pass

    # 3. Default
    return get_workspace_root() / "runtime" / "traces"

# --- Legacy Functional API (Delegates to Provider) ---
# These are kept for backward compatibility with existing flows.
def load_architecture_state(project: str):
    return get_provider().load_architecture_state(project)

def load_baseline_assessment(project: str):
    return get_provider().load_baseline_assessment(project)

def load_conversation(project: str):
    return get_provider().load_conversation(project)

def load_foundational_assets(project: Any):
    return get_provider().load_foundational_assets(project)

def load_project_vision(project: str):
    return get_provider().load_project_vision(project)

def load_architecture_work(project: str):
    return get_provider().load_architecture_work(project)

def load_latest_aem(project: str):
    return get_provider().load_latest_aem(project)

def load_latest_alignment(project: str):
    return get_provider().load_latest_alignment(project)

def load_latest_aid(project: str):
    return get_provider().load_latest_aid(project)

def load_capability_lineage(project: str):
    return get_provider().load_capability_lineage(project)

def load_project_config(project: str):
    return get_provider().load_project_config(project)

def load_pattern_proposals(project: str):
    return get_provider().load_pattern_proposals(project)

def load_pattern_scope_classification(project: str):
    return get_provider().load_pattern_scope_classification(project)

def load_pattern_promotion_recommendations(project: str):
    return get_provider().load_pattern_promotion_recommendations(project)

def load_promotion_decisions(project: str):
    return get_provider().load_promotion_decisions(project)

def load_adrs(project: str):
    return get_provider().load_adrs(project)

def load_decision_records(project: str | None = None):
    return get_provider().load_decision_records(project=project)

def persist_outputs(output: dict, project: str):
    return get_provider().persist_outputs(output, project)

def persist_capability_lineage(lineage: dict, project: str):
    return get_provider().persist_capability_lineage(lineage, project)

def load_capability_inventory(project: str):
    return get_provider().load_capability_inventory(project)

def persist_capability_inventory(inventory: dict, project: str):
    return get_provider().persist_capability_inventory(inventory, project)

def persist_evaluation(evaluation: dict, project: str):
    return get_provider().persist_evaluation(evaluation, project)

def archive_conversations(project: str, file_paths: list[str]) -> list[Path]:
    return get_provider().archive_conversations(project, file_paths)

# --- Formatters ---

def _format_aw_markdown(aw: dict) -> str:
    # Handle new structure vs legacy structure
    if "frontmatter" in aw and "sections" in aw:
        frontmatter_data = aw["frontmatter"]
        sections_data = aw["sections"]

        # Extract summary and details from sections
        summary = sections_data.get("summary", "N/A")
        details = sections_data.get("details", "N/A")

        # Build YAML block
        yaml_block = yaml.dump(frontmatter_data, sort_keys=False)

        # Build other sections
        sections_content = ""
        for key, value in sections_data.items():
            if key in ["summary", "details"]:
                continue
            if value:
                label = key.replace("_", " ").title()
                sections_content += f"\n## {label}\n\n{value}\n"
    else:
        # Legacy structure
        frontmatter = {
            "id": aw["id"],
            "knowledgeType": aw.get("knowledgeType", "architecture_work"),
            "status": aw["status"],
            "source": aw["source"],
            "date": aw["date"],
        }
        yaml_block = yaml.dump(frontmatter, sort_keys=False)
        summary = aw.get("summary", "N/A")
        details = aw.get("details", "N/A")
        sections_content = ""

    return f"""---
{yaml_block}---

# Summary

{summary}

# Details

{details}
{sections_content}"""

def _format_markdown_table(rows: list[dict]) -> str:
    if not rows:
        return ""

    headers = list(rows[0].keys())
    header_line = "| " + " | ".join([h.replace("_", " ").title() for h in headers]) + " |"
    separator_line = "| " + " | ".join(["---" for _ in headers]) + " |"

    row_lines = []
    for row in rows:
        cells = []
        for key in headers:
            value = row.get(key, "")
            if isinstance(value, dict):
                value = json.dumps(value, ensure_ascii=False)
            else:
                value = str(value)
            cells.append(value.replace("\n", " ").replace("|", "\\|"))
        row_lines.append("| " + " | ".join(cells) + " |")

    return "\n".join([header_line, separator_line] + row_lines)

def _format_aem_markdown(aem: dict) -> str:
    frontmatter_data = aem.get("frontmatter", {})
    sections_data = aem.get("sections", {})

    summary = sections_data.get("execution_summary", {})
    tag_legend = sections_data.get("execution_tag_legend", {})
    evolution_map = sections_data.get("evolution_map", [])
    actions = sections_data.get("todays_actions", [])
    decisions = sections_data.get("key_architectural_decisions", [])
    system_evolution = sections_data.get("system_evolution", "")
    intent_direction = sections_data.get("intent_direction", "")
    patterns = sections_data.get("pattern_evolution", {})
    health = sections_data.get("knowledge_system_health", {})

    yaml_block = yaml.dump(frontmatter_data, sort_keys=False)

    items_text = _format_markdown_table(evolution_map) if isinstance(evolution_map, list) else ""
    decisions_text = _format_markdown_table(decisions) if isinstance(decisions, list) else ""

    patterns_text = ""
    if isinstance(patterns, dict):
        for status, plist in patterns.items():
            if plist:
                patterns_text += f"\n### {status.title()} Patterns\n"
                for p in plist:
                    patterns_text += f"- {p}\n"

    return f"""---
{yaml_block}---

# Architecture Evolution Map

## AEM Summary
{yaml.dump(summary, sort_keys=False)}

## Execution Tag Legend
{yaml.dump(tag_legend, sort_keys=False)}

## Today's Actions
{"".join([f"- {a}\n" for a in actions])}

## Evolution Map
{items_text}

## Key Architectural Decisions
{decisions_text}

## System Evolution
{system_evolution}

## Intent & Direction
{intent_direction}

## Pattern Evolution
{patterns_text}

## Knowledge System Health
{yaml.dump(health, sort_keys=False)}
"""

def _format_alignment_markdown(report: dict) -> str:
    frontmatter_data = report.get("frontmatter", {})
    sections_data = report.get("sections", {})

    summary = sections_data.get("alignment_summary", {})
    findings = sections_data.get("alignment_findings", [])
    derived_aw = sections_data.get("architecture_work_derived", [])

    yaml_block = yaml.dump(frontmatter_data, sort_keys=False)

    findings_text = ""
    for f in findings:
        severity = f.get('severity', 'medium')
        description = f.get('description', 'N/A')
        findings_text += f"- [{severity.upper()}] {description}\n"
        if 'recommendation' in f:
            findings_text += f"  - Recommendation: {f['recommendation']}\n"

    aw_text = "".join([f"- [{aw.get('priority', 'medium').upper()}] {aw.get('description', 'N/A')}\n" for aw in derived_aw])

    return f"""---
{yaml_block}---

# Alignment Summary
{yaml.dump(summary, sort_keys=False)}

# Alignment Findings
{findings_text if findings_text else "No issues detected."}

# Architecture Work Derived
{aw_text}
"""

def _format_aid_markdown(aid: dict) -> str:
    frontmatter_data = aid.get("frontmatter", {})
    sections_data = aid.get("sections", {})

    vision = sections_data.get("vision", {})
    context = sections_data.get("scope_project_context", {})
    current_state = sections_data.get("current_state", {})
    roadmap = sections_data.get("roadmap", [])
    risks = sections_data.get("gaps_tensions", [])
    principles = sections_data.get("principles", [])
    heuristics = sections_data.get("emergent_heuristics", {})

    yaml_block = yaml.dump(frontmatter_data, sort_keys=False)
    return f"""---
{yaml_block}---

# Architecture Intent

## Strategic Vision
- **What we are building:** {vision.get('what_we_are_building', 'N/A')}
- **Why it exists:** {vision.get('why_it_exists', 'N/A')}

## Project Context
{yaml.dump(context, sort_keys=False)}

## Current State Alignment
{current_state.get('alignment_notes', 'N/A')}

## Focus Areas / Roadmap
{"".join([f"- {f}\n" for f in roadmap])}

## Gaps & Tensions (Risks)
{"".join([f"- {r}\n" for r in risks])}

## Principles
{"".join([f"- {p}\n" for p in principles])}

## Emergent Heuristics
{yaml.dump(heuristics, sort_keys=False)}
"""

def _format_baseline_assessment_markdown(assessment: dict) -> str:
    frontmatter_data = assessment.get("frontmatter", {})
    sections_data = assessment.get("sections", {})

    yaml_block = yaml.dump(frontmatter_data, sort_keys=False)

    inventory = sections_data.get("discovery_inventory", [])
    evidence = sections_data.get("evidence_conclusions", [])
    maturity = sections_data.get("governance_maturity", "Unknown")
    gaps = sections_data.get("gaps_opportunities", [])
    candidates = sections_data.get("architecture_work_candidates", [])

    relationships = frontmatter_data.get("relationships", {})

    inventory_table = _format_markdown_table(inventory)
    candidates_table = _format_markdown_table(candidates)

    rel_section = "\n"
    for rel_type, targets in relationships.items():
        if targets:
            label = rel_type.replace("_", " ").title()
            rel_section += f"- **{label}**: " + ", ".join([f"[[{t}]]" for t in targets]) + "\n"

    return f"""---
{yaml_block}---

# Baseline Architectural Assessment

## Discovery Inventory
{inventory_table}

## Evidence & Conclusions
{"".join([f"- {e}\n" for e in evidence])}

## Governance Maturity
{maturity}

## Identified Gaps & Opportunities
{"".join([f"- {g}\n" for g in gaps])}

## Initial Architecture Work Candidates
{candidates_table}

## Relationships
{rel_section}
"""

def _format_capability_markdown(capabilities: list[dict]) -> str:
    frontmatter = {
        "date": date.today().isoformat(),
        "knowledgeType": "capability_set",
        "count": len(capabilities),
    }
    yaml_block = yaml.dump(frontmatter, sort_keys=False)
    table = _format_markdown_table(capabilities)
    return f"""---
{yaml_block}---

# Capability Set

{table}
"""

def _format_current_architecture_state_markdown(cas_state: dict) -> str:
    frontmatter_data = cas_state.get("frontmatter", {})
    sections_data = cas_state.get("sections", {})

    yaml_block = yaml.dump(frontmatter_data, sort_keys=False)

    # Define the order of sections based on spec/data-model
    section_order = [
        ("Executive Summary", "executive_summary"),
        ("Architecture Evolution Summary", "evolution_summary"),
        ("Architecture Evolution", "architecture_evolution"),
        ("Capability Landscape", "capability_landscape"),
        ("Capability Dependencies", "capability_dependencies"),
        ("Initiative Landscape", "initiative_landscape"),
        ("Governance State", "governance_state"),
        ("Architecture State", "architecture_state"),
        ("Intelligence State", "intelligence_state"),
        ("Operational State", "operational_state"),
        ("Architecture State Metrics", "metrics"),
        ("Strategic Gaps", "strategic_gaps"),
        ("Observed State", "observed_state"),
        ("Interpreted State", "interpreted_state"),
        ("Hypothesised State", "hypothesised_state"),
        ("Confidence Assessment", "confidence_assessment"),
        ("Evidence Sources", "evidence_sources")
    ]

    sections_content = ""
    for title, key in section_order:
        content = sections_data.get(key)
        if content:
            sections_content += f"\n## {title}\n\n{content}\n"

    # Major Findings
    major_findings = sections_data.get("major_findings", [])
    if major_findings:
        sections_content += "\n## Major Findings\n\n"
        for finding in major_findings:
            title = finding.get("title", "Untitled Finding")
            conf = finding.get("confidence", "low").upper()
            evidence = finding.get("evidence", "")
            rationale = finding.get("rationale", "")

            sections_content += f"### {title}\n"
            sections_content += f"- **Confidence**: {conf}\n"
            sections_content += f"- **Evidence**: {evidence}\n"
            sections_content += f"- **Rationale**: {rationale}\n\n"

    return f"""---
{yaml_block}---

# Current Architecture State
{sections_content}"""

def _format_pattern_proposals_yaml(proposals: dict) -> str:
    return yaml.dump(proposals, sort_keys=False)

def _format_pattern_scope_classification_yaml(classification: dict) -> str:
    return yaml.dump(classification, sort_keys=False)

def _format_pattern_promotion_recommendations_yaml(recommendations: dict) -> str:
    return yaml.dump(recommendations, sort_keys=False)

def _format_promotion_decision_yaml(decision: dict) -> str:
    return yaml.dump(decision, sort_keys=False)

def _format_adr_markdown(adr: dict) -> str:
    """Format ADR as markdown with YAML frontmatter and structured sections."""
    frontmatter = {}
    sections = {}

    # Handle new structure vs flattened
    if "frontmatter" in adr and "sections" in adr:
        frontmatter = adr["frontmatter"]
        sections = adr["sections"]
    else:
        # Extract metadata for frontmatter
        fm_keys = [
            "id", "knowledgeType", "project", "date", "version", "pattern_id",
            "decision_scope", "decision_target", "decision", "classification",
            "promotion_evidence", "promotion_criteria_met", "governance_risks",
            "source_decision", "source_traceability", "governance", "related",
            "scope_classification", "promotion_recommendation"
        ]
        for k in fm_keys:
            if k in adr:
                frontmatter[k] = adr[k]
        sections = adr.get("sections", {})

    yaml_block = yaml.dump(frontmatter, sort_keys=False)

    # Build markdown content from sections
    content = f"---\n{yaml_block}---\n"

    # ADR Title
    title = frontmatter.get("id", "Architecture Decision Record")
    content += f"\n# {title}\n"

    # Ordered sections based on ADR standard
    section_order = [
        ("Decision", "decision"),
        ("Context", "context"),
        ("Scope", "scope"),
        ("Consequences", "consequences"),
        ("Evidence Summary", "evidence_summary"),
        ("Traceability", "traceability"),
        ("Next Step", "next_step")
    ]

    for title, key in section_order:
        section_data = sections.get(key)
        if section_data:
            content += f"\n## {title}\n\n"
            if isinstance(section_data, dict):
                # Format specific structured sub-sections
                if key == "decision":
                    content += section_data.get("summary", "N/A") + "\n"
                elif key == "context":
                    content += f"- **Source**: {section_data.get('source', 'N/A')}\n"
                    content += f"- **Pattern**: {section_data.get('pattern', 'N/A')}\n"

                    recommendation = section_data.get('promotion_recommendation')
                    if recommendation:
                        content += f"- **Promotion Recommendation**: {recommendation}\n"

                    # Improved scope_classification rendering
                    scope_classification = section_data.get('scope_classification')
                    if scope_classification:
                        if isinstance(scope_classification, dict):
                            classification_value = scope_classification.get('classification')
                            artifact_id = scope_classification.get('artifact_id')

                            if classification_value:
                                content += f"- **Scope Classification**: {classification_value}\n"

                            if artifact_id:
                                content += f"- **Scope Classification Artifact**: {artifact_id}\n"
                        else:
                            content += f"- **Scope Classification**: {scope_classification}\n"

                    content += "\n"
                    content += section_data.get("summary", "") + "\n"
                elif key == "scope":
                    applicability = section_data.get("applicability")
                    if applicability:
                        content += f"**Applicability:** {applicability}\n\n"

                    content += section_data.get("summary", "") + "\n"
                elif key == "consequences":
                    governance = section_data.get("governance")
                    execution = section_data.get("execution")
                    system_behaviour = section_data.get("system_behaviour")

                    if governance:
                        content += f"### Governance\n\n{governance}\n\n"

                    if execution:
                        content += f"### Execution\n\n{execution}\n\n"

                    if system_behaviour:
                        content += f"### System Behaviour\n\n{system_behaviour}\n\n"
                elif key == "evidence_summary":
                    promotion_evidence = section_data.get("promotion_evidence")
                    promotion_criteria = section_data.get("promotion_criteria")
                    governance_risks = section_data.get("governance_risks")

                    if promotion_evidence:
                        content += f"### Promotion Evidence\n\n{promotion_evidence}\n\n"

                    if promotion_criteria:
                        content += f"### Promotion Criteria\n\n{promotion_criteria}\n\n"

                    if governance_risks:
                        content += f"### Governance Risks\n\n{governance_risks}\n\n"
                elif key == "traceability":
                    pattern_proposal = section_data.get("pattern_proposal")
                    scope_classification = section_data.get("scope_classification")
                    promotion_recommendation = section_data.get("promotion_recommendation")
                    promotion_decision = section_data.get("promotion_decision")

                    if pattern_proposal:
                        content += f"### Pattern Proposal\n\n{pattern_proposal}\n\n"

                    # Improved scope_classification rendering
                    if scope_classification:
                        content += "### Scope Classification\n\n"

                        if isinstance(scope_classification, dict):
                            artifact_id = scope_classification.get("artifact_id")
                            classification_value = scope_classification.get("classification")

                            if artifact_id:
                                content += f"Artifact: {artifact_id}\n\n"

                            if classification_value:
                                content += f"Classification: {classification_value}\n\n"
                        else:
                            content += f"{scope_classification}\n\n"

                    if promotion_recommendation:
                        content += f"### Promotion Recommendation\n\n{promotion_recommendation}\n\n"

                    if promotion_decision:
                        content += f"### Promotion Decision\n\n{promotion_decision}\n\n"
                elif key == "next_step":
                    actions = section_data.get("actions", [])
                    # Add lifecycle-aware fallback actions if actions is empty
                    if not actions:
                        actions = [
                            "Submit ADR to Architecture Forum (accept / reject / defer)",
                            "Upon forum acceptance create or update the promoted pattern artifact",
                            "Update Pattern Registry and Governance Views",
                            "Validate compliance through alignment checks"
                        ]
                    for action in actions:
                        content += f"- {action}\n"
                else:
                    # Fallback: generic key/value rendering for future compatibility
                    for k, v in section_data.items():
                        content += f"### {k.replace('_', ' ').title()}\n{v}\n\n"
            else:
                content += str(section_data) + "\n"

    return content

def _format_pattern_markdown(pattern: dict) -> str:
    """Format Pattern as markdown with YAML frontmatter and structured sections."""
    frontmatter = {}
    sections = {}

    # Handle new structure vs flattened
    if "frontmatter" in pattern and "sections" in pattern:
        frontmatter = pattern["frontmatter"]
        sections = pattern["sections"]
    else:
        # Extract metadata for frontmatter
        fm_keys = [
            "id", "knowledgeType", "title", "summary", "date", "tags",
            "maturity", "confidence", "decision", "domain",
            "relatedExperiments", "relatedLearnings", "sources", "diagram",
            "knowledgeId", "scope", "origin", "governance", "source",
            "source_traceability", "signals", "applies_to",
            "automation_ready", "promotion", "forum_review", "related"
        ]
        for k in fm_keys:
            if k in pattern:
                frontmatter[k] = pattern[k]
        sections = pattern.get("sections", {})

    yaml_block = yaml.dump(frontmatter, sort_keys=False)

    # Build markdown content from sections
    content = f"---\n{yaml_block}---\n"

    # Pattern Title
    title = frontmatter.get("title", frontmatter.get("id", "Architecture Pattern"))
    content += f"\n# {title}\n"

    # Pattern Sections from mapping
    section_order = [
        ("Intent", "intent"),
        ("Context", "context"),
        ("Agentic Profile", "agentic_profile"),
        ("Forces", "forces"),
        ("Solution", "solution"),
        ("Operationalisation", "operationalisation"),
        ("Implementation Signals", "implementation_signals"),
        ("Evidence", "evidence"),
        ("Consequences", "consequences"),
        ("Reuse Notes", "reuse_notes"),
        ("Confidence", "confidence")
    ]

    for title, key in section_order:
        section_data = sections.get(key)
        if not section_data:
            continue

        content += f"\n## {title}\n\n"

        if not isinstance(section_data, dict):
            content += f"{section_data}\n"
            continue

        summary = section_data.get("summary")
        if summary:
            content += f"{summary}\n\n"

        if key == "forces":
            drivers = section_data.get("drivers", [])
            constraints = section_data.get("constraints", [])
            tradeoffs = section_data.get("tradeoffs", [])

            if drivers:
                content += "### Drivers\n\n"
                for item in drivers:
                    content += f"- {item}\n"
                content += "\n"

            if constraints:
                content += "### Constraints\n\n"
                for item in constraints:
                    content += f"- {item}\n"
                content += "\n"

            if tradeoffs:
                content += "### Tradeoffs\n\n"
                for item in tradeoffs:
                    content += f"- {item}\n"
                content += "\n"

        elif key == "operationalisation":
            workflow_implications = section_data.get("workflow_implications", [])
            automation_opportunities = section_data.get("automation_opportunities", [])

            if workflow_implications:
                content += "### Workflow Implications\n\n"
                for item in workflow_implications:
                    content += f"- {item}\n"
                content += "\n"

            if automation_opportunities:
                content += "### Automation Opportunities\n\n"
                for item in automation_opportunities:
                    content += f"- {item}\n"
                content += "\n"

        elif key == "evidence":
            signals = section_data.get("signals", [])
            architecture_work = section_data.get("architecture_work", [])
            confidence_basis = section_data.get("confidence_basis")

            if signals:
                content += "### Signals\n\n"
                for item in signals:
                    content += f"- {item}\n"
                content += "\n"

            if architecture_work:
                content += "### Supporting Evidence\n\n"
                for item in architecture_work:
                    content += f"- {item}\n"
                content += "\n"

            if confidence_basis:
                content += f"### Confidence Basis\n\n{confidence_basis}\n\n"

        elif key == "consequences":
            benefits = section_data.get("benefits", [])
            risks = section_data.get("risks", [])
            governance_implications = section_data.get("governance_implications", [])

            if benefits:
                content += "### Benefits\n\n"
                for item in benefits:
                    content += f"- {item}\n"
                content += "\n"

            if risks:
                content += "### Risks\n\n"
                for item in risks:
                    content += f"- {item}\n"
                content += "\n"

            if governance_implications:
                content += "### Governance Implications\n\n"
                for item in governance_implications:
                    content += f"- {item}\n"
                content += "\n"

        elif key == "confidence":
            level = section_data.get("level")
            rationale = section_data.get("rationale")

            if level:
                content += f"**Level:** {level}\n\n"

            if rationale:
                content += f"### Rationale\n\n{rationale}\n\n"

        else:
            rendered_keys = {"summary"}
            for field_name, value in section_data.items():
                if field_name in rendered_keys:
                    continue

                heading = field_name.replace("_", " ").title()

                if isinstance(value, list):
                    if value:
                        content += f"### {heading}\n\n"
                        for item in value:
                            content += f"- {item}\n"
                        content += "\n"
                elif value not in [None, ""]:
                    content += f"### {heading}\n\n{value}\n\n"

    return content


def save_architecture_state_pack(
    project: str | TargetProjectContext,
    state_data: dict,
    views: dict[str, str] | None = None,
    diagrams: dict[str, str] | None = None,
    diagnostics: dict[str, str] | None = None,
    architecture_md: str | None = None,
    base_path: Path | None = None,
) -> Path:
    """Saves the complete architecture state pack under knowledge/projects/<project>/architecture-state/."""
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    state_dir = base / "projects" / project_id / "architecture-state"
    model_dir = state_dir / "model"
    views_dir = state_dir / "views"
    diagrams_dir = state_dir / "diagrams"
    diagnostic_dir = state_dir / "diagnostic"

    for d in (model_dir, views_dir, diagrams_dir, diagnostic_dir):
        safe_mkdir(d)

    # 1. Save root architecture-state.yaml
    with open(model_dir / "architecture-state.yaml", "w", encoding="utf-8") as f:
        yaml.safe_dump(state_data, f, sort_keys=False)

    # 2. Save partitioned entity files
    partitions = {
        "systems.yaml": state_data.get("system_boundary"),
        "containers.yaml": state_data.get("containers", []),
        "components.yaml": state_data.get("components", []),
        "dependencies.yaml": state_data.get("dependencies", []),
        "flows.yaml": state_data.get("flows", []),
        "controls.yaml": state_data.get("controls", []),
        "evidence.yaml": state_data.get("evidence", []),
    }
    for filename, part_data in partitions.items():
        with open(model_dir / filename, "w", encoding="utf-8") as f:
            yaml.safe_dump(part_data, f, sort_keys=False)

    # 3. Save views
    if views:
        for view_name, content in views.items():
            slug = view_name.lower().replace(" ", "-")
            if not slug.endswith(".md"):
                slug += ".md"
            with open(views_dir / slug, "w", encoding="utf-8") as f:
                f.write(content)

    # 4. Save diagrams
    if diagrams:
        for diag_name, markup in diagrams.items():
            slug = diag_name.lower().replace(" ", "-")
            if not slug.endswith(".mmd"):
                slug += ".mmd"
            with open(diagrams_dir / slug, "w", encoding="utf-8") as f:
                f.write(markup)

    # 5. Save diagnostics
    if diagnostics:
        for diag_name, report in diagnostics.items():
            slug = diag_name.lower().replace(" ", "-")
            if not slug.endswith(".md"):
                slug += ".md"
            with open(diagnostic_dir / slug, "w", encoding="utf-8") as f:
                f.write(report)

    # 6. Save consolidated ARCHITECTURE.md
    if architecture_md:
        with open(state_dir / "ARCHITECTURE.md", "w", encoding="utf-8") as f:
            f.write(architecture_md)

    return state_dir


def load_architecture_state(
    project: str | TargetProjectContext,
    base_path: Path | None = None,
) -> dict | None:
    """Loads the architecture-state.yaml from knowledge/projects/<project>/architecture-state/model/."""
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    state_file = base / "projects" / project_id / "architecture-state" / "model" / "architecture-state.yaml"
    if not state_file.exists():
        return None

    with open(state_file, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def promote_architecture_state_baseline(
    project: str | TargetProjectContext,
    notes: str | None = None,
    base_path: Path | None = None,
) -> Path:
    """Promotes discovered architecture state to validated-baseline and archives a snapshot under baseline/."""
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    state = load_architecture_state(project, base_path=base)
    if not state:
        raise FileNotFoundError(f"No architecture state found for project '{project_id}'")

    state["status"] = "validated-baseline"
    today_str = date.today().isoformat()
    state["promoted_at"] = today_str
    if notes:
        state["promotion_notes"] = notes

    # Resave active state pack
    model_dir = base / "projects" / project_id / "architecture-state" / "model"
    with open(model_dir / "architecture-state.yaml", "w", encoding="utf-8") as f:
        yaml.safe_dump(state, f, sort_keys=False)

    # Archive to baseline directory
    baseline_dir = base / "projects" / project_id / "baseline"
    safe_mkdir(baseline_dir)
    snapshot_file = baseline_dir / f"architecture-state-{today_str}.yaml"
    with open(snapshot_file, "w", encoding="utf-8") as f:
        yaml.safe_dump(state, f, sort_keys=False)
    with open(baseline_dir / "architecture-state.yaml", "w", encoding="utf-8") as f:
        yaml.safe_dump(state, f, sort_keys=False)

    return snapshot_file


def load_flows(
    project: str | TargetProjectContext,
    base_path: Path | None = None,
) -> list[dict] | None:
    """Loads flows from knowledge/projects/<project>/architecture-state/model/flows.yaml."""
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    flows_file = base / "projects" / project_id / "architecture-state" / "model" / "flows.yaml"
    if not flows_file.exists():
        # Fallback to checking root architecture-state.yaml
        state = load_architecture_state(project, base_path=base)
        if state and "flows" in state:
            return state.get("flows", [])
        return None

    with open(flows_file, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
        if isinstance(data, list):
            return data
        if isinstance(data, dict) and "flows" in data:
            return data.get("flows", [])
        return []


def save_flows(
    project: str | TargetProjectContext,
    flows: list[dict],
    candidates: list[dict] | None = None,
    base_path: Path | None = None,
) -> Path:
    """Saves flows to model/flows.yaml and updates architecture-state.yaml and unknowns.yaml."""
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    state_dir = base / "projects" / project_id / "architecture-state"
    model_dir = state_dir / "model"
    diag_dir = state_dir / "diagnostic"
    safe_mkdir(model_dir)
    safe_mkdir(diag_dir)

    flows_file = model_dir / "flows.yaml"
    with open(flows_file, "w", encoding="utf-8") as f:
        yaml.safe_dump(flows, f, sort_keys=False)

    # Update root architecture-state.yaml if present
    state_file = model_dir / "architecture-state.yaml"
    if state_file.exists():
        with open(state_file, "r", encoding="utf-8") as f:
            state = yaml.safe_load(f) or {}
        state["flows"] = flows
        with open(state_file, "w", encoding="utf-8") as f:
            yaml.safe_dump(state, f, sort_keys=False)

    # Save candidates if provided
    if candidates:
        cand_file = diag_dir / "unknowns.yaml"
        with open(cand_file, "w", encoding="utf-8") as f:
            yaml.safe_dump(candidates, f, sort_keys=False)

    return flows_file


def load_agentic_patterns_catalogue(
    project: str | TargetProjectContext,
    base_path: Path | None = None,
) -> dict[str, Any] | None:
    """Loads agentic patterns catalogue from proposed-patterns directory."""
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    provider = LocalKnowledgeProvider(base_path=base)
    return provider.load_agentic_patterns_catalogue(project_id)


def load_structural_patterns_catalogue(
    project: str | TargetProjectContext,
    base_path: Path | None = None,
) -> dict[str, Any] | None:
    """Loads structural patterns catalogue from proposed-patterns directory."""
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    provider = LocalKnowledgeProvider(base_path=base)
    return provider.load_structural_patterns_catalogue(project_id)


def persist_reference_architecture(
    project: str | TargetProjectContext,
    pattern_id: str,
    content: str,
    base_path: Path | None = None,
    repo_root: Path | None = None,
) -> dict[str, Path]:
    """Persists a reference architecture markdown file to both knowledge and docs directories.

    Locations:
    1. knowledge/projects/<project>/reference-architectures/reference-architecture-<pattern_id>.md
    2. docs/architecture/reference-architectures/reference-architecture-<pattern_id>.md
    """
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
        root = repo_root or project.project_root
    else:
        project_id = str(project)
        base = base_path or get_default_base()
        root = repo_root or Path.cwd()

    # 1. Knowledge destination
    knowledge_dir = base / "projects" / project_id / "reference-architectures"
    safe_mkdir(knowledge_dir)
    filename = f"reference-architecture-{pattern_id}.md"
    knowledge_path = knowledge_dir / filename
    knowledge_path.write_text(content, encoding="utf-8")

    # 2. Docs destination
    docs_dir = root / "docs" / "architecture" / "reference-architectures"
    safe_mkdir(docs_dir)
    docs_path = docs_dir / filename
    docs_path.write_text(content, encoding="utf-8")

    # 3. Initialize/update archgov-sync manifest record
    recommendation_id = None
    status = "draft"
    if content.startswith("---\n"):
        parts = content.split("---\n", 2)
        if len(parts) >= 3:
            try:
                fm = yaml.safe_load(parts[1]) or {}
                recommendation_id = fm.get("recommendation_id")
                status = fm.get("status", "draft")
            except Exception:
                pass

    rel_knowledge_path = f"knowledge/projects/{project_id}/reference-architectures/{filename}"
    sync_record_data = {
        "pattern_id": pattern_id,
        "recommendation_id": recommendation_id,
        "artifact_path": rel_knowledge_path,
        "status": status,
    }
    save_archgov_sync_record(project, pattern_id, sync_record_data, base_path=base)

    return {
        "knowledge_path": knowledge_path,
        "docs_path": docs_path,
    }


def load_reference_architecture(
    project: str | TargetProjectContext,
    pattern_id: str,
    base_path: Path | None = None,
) -> str | None:
    """Loads a reference architecture markdown file from knowledge directory."""
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    filename = f"reference-architecture-{pattern_id}.md"
    target = base / "projects" / project_id / "reference-architectures" / filename
    if target.exists():
        return target.read_text(encoding="utf-8")
    return None


def list_reference_architectures(
    project: str | TargetProjectContext,
    base_path: Path | None = None,
) -> list[str]:
    """Lists existing reference architecture pattern IDs for a project."""
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    ref_dir = base / "projects" / project_id / "reference-architectures"
    if not ref_dir.exists():
        return []

    pattern_ids = []
    for file in sorted(ref_dir.glob("reference-architecture-*.md")):
        name = file.stem  # reference-architecture-<pattern_id>
        if name.startswith("reference-architecture-"):
            pattern_ids.append(name[len("reference-architecture-"):])
    return pattern_ids


def resolve_pattern_details(
    project: str | TargetProjectContext,
    pattern_id: str,
    base_path: Path | None = None,
) -> dict[str, Any] | None:
    """Finds detailed pattern definition across agentic catalogues, structural catalogues, and pattern proposals."""
    # 1. Check agentic patterns catalogue
    agentic_cat = load_agentic_patterns_catalogue(project, base_path=base_path)
    if agentic_cat and isinstance(agentic_cat, dict):
        patterns = agentic_cat.get("patterns", [])
        for p in patterns:
            if isinstance(p, dict) and p.get("id") == pattern_id:
                details = dict(p)
                details["catalogue_type"] = "agentic"
                return details

    # 2. Check structural patterns catalogue
    structural_cat = load_structural_patterns_catalogue(project, base_path=base_path)
    if structural_cat and isinstance(structural_cat, dict):
        patterns = structural_cat.get("patterns", [])
        for p in patterns:
            if isinstance(p, dict) and p.get("id") == pattern_id:
                details = dict(p)
                details["catalogue_type"] = "structural"
                return details

    # 3. Check pattern proposals (e.g. signal-derived proposals or projected proposals)
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    provider = LocalKnowledgeProvider(base_path=base)
    proposals = provider.load_pattern_proposals(project_id)
    for prop in proposals:
        if isinstance(prop, dict):
            pid = prop.get("pattern_id") or prop.get("id")
            if pid == pattern_id:
                details = dict(prop)
                details["catalogue_type"] = "proposal"
                return details

    return None


def load_archgov_sync_manifest(
    project: str | TargetProjectContext,
    base_path: Path | None = None,
) -> dict[str, Any]:
    """Loads the ArchGov synchronization manifest for a project."""
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    manifest_file = base / "projects" / project_id / "governance" / "archgov-sync.yaml"
    default_manifest = {
        "schema_version": "1.0.0",
        "project_id": project_id,
        "last_synced_at": None,
        "records": {},
    }

    if not manifest_file.exists():
        return default_manifest

    try:
        content = yaml.safe_load(manifest_file.read_text(encoding="utf-8")) or {}
        if not isinstance(content, dict):
            return default_manifest
        if "records" not in content:
            content["records"] = {}
        if "project_id" not in content:
            content["project_id"] = project_id
        return content
    except Exception as e:
        print(f"[CAS][WARN] Failed reading {manifest_file}: {e}")
        return default_manifest


def save_archgov_sync_record(
    project: str | TargetProjectContext,
    pattern_id: str,
    record_data: dict[str, Any],
    base_path: Path | None = None,
) -> dict[str, Any]:
    """Saves or updates a synchronization record in the project's archgov-sync.yaml."""
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    manifest = load_archgov_sync_manifest(project, base_path=base)
    now_iso = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

    if "records" not in manifest or not isinstance(manifest["records"], dict):
        manifest["records"] = {}

    existing_record = manifest["records"].get(pattern_id, {})
    merged_record = {**existing_record, **record_data}
    extracted_pattern_id = record_data.get("pattern_id") or existing_record.get("pattern_id")
    if not extracted_pattern_id:
        if pattern_id.startswith("adr-"):
            extracted_pattern_id = pattern_id.removeprefix("adr-")
        elif pattern_id.startswith("reference-architecture-"):
            extracted_pattern_id = pattern_id.removeprefix("reference-architecture-")
        else:
            extracted_pattern_id = pattern_id
    merged_record["pattern_id"] = extracted_pattern_id
    if "artifact_id" not in merged_record:
        merged_record["artifact_id"] = pattern_id
    if "artifact_type" not in merged_record:
        if pattern_id.startswith("adr-"):
            merged_record["artifact_type"] = "adr"
        else:
            merged_record["artifact_type"] = "reference_arch"
    if "last_synced_at" not in merged_record or not merged_record["last_synced_at"]:
        merged_record["last_synced_at"] = now_iso

    manifest["records"][pattern_id] = merged_record
    manifest["last_synced_at"] = now_iso

    gov_dir = base / "projects" / project_id / "governance"
    safe_mkdir(gov_dir)
    manifest_file = gov_dir / "archgov-sync.yaml"
    manifest_file.write_text(yaml.dump(manifest, default_flow_style=False, sort_keys=False), encoding="utf-8")

    return manifest


def update_reference_architecture_frontmatter(
    file_path: Path | str,
    metadata: dict[str, Any],
    repo_root: Path | None = None,
) -> str:
    """Injects or updates YAML frontmatter in a reference architecture markdown file,

    mirroring changes to docs/ if present.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Reference architecture file not found: {path}")

    content = path.read_text(encoding="utf-8")
    body = content
    existing_data: dict[str, Any] = {}

    if content.startswith("---\n"):
        parts = content.split("---\n", 2)
        if len(parts) >= 3:
            try:
                existing_data = yaml.safe_load(parts[1]) or {}
            except Exception:
                existing_data = {}
            body = parts[2]

    # Deep merge metadata
    merged_data = {**existing_data, **metadata}
    if "governance" in existing_data and "governance" in metadata:
        merged_data["governance"] = {**existing_data["governance"], **metadata["governance"]}

    new_yaml = yaml.dump(merged_data, default_flow_style=False, sort_keys=False)
    new_content = f"---\n{new_yaml}---\n{body.lstrip()}"
    path.write_text(new_content, encoding="utf-8")

    # Mirror to docs/architecture/reference-architectures/ if found
    try:
        root = repo_root or get_workspace_root()
        docs_mirror = root / "docs" / "architecture" / "reference-architectures" / path.name
        if docs_mirror.exists():
            docs_mirror.write_text(new_content, encoding="utf-8")
    except Exception:
        pass

    return new_content


def is_reference_architecture_approved(
    project: str | TargetProjectContext,
    pattern_id: str,
    base_path: Path | None = None,
) -> bool:
    """Checks whether a reference architecture has achieved approved status."""
    manifest = load_archgov_sync_manifest(project, base_path=base_path)
    record = manifest.get("records", {}).get(pattern_id)
    if record and isinstance(record, dict):
        if record.get("status") == "approved":
            return True

    # Fallback: check file frontmatter
    ref_content = load_reference_architecture(project, pattern_id, base_path=base_path)
    if ref_content and ref_content.startswith("---\n"):
        parts = ref_content.split("---\n", 2)
        if len(parts) >= 3:
            try:
                fm = yaml.safe_load(parts[1]) or {}
                return fm.get("status") == "approved"
            except Exception:
                pass

    return False


def update_adr_frontmatter(
    file_path: Path | str,
    metadata: dict[str, Any],
    repo_root: Path | None = None,
) -> str:
    """Injects or updates YAML frontmatter in an ADR markdown file,

    mirroring changes to docs/architecture/decisions/ if present.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"ADR file not found: {path}")

    content = path.read_text(encoding="utf-8")
    body = content
    existing_data: dict[str, Any] = {}

    if content.startswith("---\n"):
        parts = content.split("---\n", 2)
        if len(parts) >= 3:
            try:
                existing_data = yaml.safe_load(parts[1]) or {}
            except Exception:
                existing_data = {}
            body = parts[2]

    # Deep merge metadata
    merged_data = {**existing_data, **metadata}
    if "governance" in existing_data and "governance" in metadata:
        merged_data["governance"] = {**existing_data["governance"], **metadata["governance"]}
    if "decision" in existing_data and "decision" in metadata:
        merged_data["decision"] = {**existing_data["decision"], **metadata["decision"]}

    new_yaml = yaml.dump(merged_data, default_flow_style=False, sort_keys=False)
    new_content = f"---\n{new_yaml}---\n{body.lstrip()}"
    path.write_text(new_content, encoding="utf-8")

    # Mirror to docs/architecture/decisions/ if found
    try:
        root = repo_root or get_workspace_root()
        docs_mirror = root / "docs" / "architecture" / "decisions" / path.name
        if docs_mirror.exists():
            docs_mirror.write_text(new_content, encoding="utf-8")
    except Exception:
        pass

    return new_content


def is_adr_approved(
    project: str | TargetProjectContext,
    adr_id: str,
    base_path: Path | None = None,
) -> bool:
    """Checks whether an ADR has achieved accepted/approved status in archgov-sync.yaml or frontmatter."""
    manifest = load_archgov_sync_manifest(project, base_path=base_path)
    candidates = [adr_id]
    if not adr_id.startswith("adr-"):
        candidates.append(f"adr-{adr_id}")
    else:
        candidates.append(adr_id.removeprefix("adr-"))

    for key in candidates:
        record = manifest.get("records", {}).get(key)
        if record and isinstance(record, dict):
            status = str(record.get("status", "")).lower()
            if status in ("accepted", "approved", "conditional"):
                return True

    # Fallback: check file frontmatter under knowledge/projects/<project>/adrs/
    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    adr_dir = base / "projects" / project_id / "adrs"
    possible_names = [
        f"{adr_id}.md",
        f"adr-{adr_id}.md" if not adr_id.startswith("adr-") else f"{adr_id}.md",
        f"{adr_id.removeprefix('adr-')}.md" if adr_id.startswith("adr-") else f"{adr_id}.md",
    ]
    for name in possible_names:
        target = adr_dir / name
        if target.exists():
            content = target.read_text(encoding="utf-8")
            if content.startswith("---\n"):
                parts = content.split("---\n", 2)
                if len(parts) >= 3:
                    try:
                        fm = yaml.safe_load(parts[1]) or {}
                        gov = fm.get("governance", {})
                        if isinstance(gov, dict):
                            forum_status = str(gov.get("forum_status", "")).lower()
                            if forum_status in ("accepted", "approved", "conditional"):
                                return True
                        dec = fm.get("decision", {})
                        if isinstance(dec, dict):
                            dec_status = str(dec.get("status", "")).lower()
                            if dec_status in ("accepted", "approved", "conditional"):
                                return True
                        top_status = str(fm.get("status", "")).lower()
                        if top_status in ("accepted", "approved", "conditional"):
                            return True

                    except Exception:
                        pass
    return False
