from __future__ import annotations

import time
from datetime import datetime

from rich.console import Group, RenderableType
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .sdlc_state import SDLCState


def get_status_badge(status: str) -> Text:
    status_upper = status.upper()
    if "PATH_A" in status_upper or status_upper in ("PASSED", "APPROVED"):
        badge_text = "● PATH A" if "PATH_A" in status_upper else "● PASSED"
        return Text(badge_text, style="bold green")
    elif "PATH_B" in status_upper or status_upper in ("WARNING", "NOVELTY"):
        return Text("▲ PATH B", style="bold yellow")
    elif "PATH_C" in status_upper or status_upper in ("EXCEPTION",):
        return Text("◆ PATH C", style="bold cyan")
    elif status_upper in ("RUNNING", "IN_PROGRESS"):
        return Text("⟳ RUNNING", style="bold yellow")
    elif status_upper in ("FAILED", "REJECTED", "BLOCKED"):
        return Text("✖ FAILED", style="bold red")
    else:
        return Text("○ PENDING", style="dim")


def render_sdlc_header(state: SDLCState) -> Table:
    header_table = Table.grid(expand=True)
    header_table.add_column(justify="left", ratio=3)
    header_table.add_column(justify="right", ratio=1)

    elapsed = time.time() - state.start_time
    elapsed_str = (
        f"{elapsed:.1f}s"
        if elapsed < 60
        else f"{int(elapsed // 60)}m {int(elapsed % 60)}s"
    )

    header_table.add_row(
        Text.assemble(
            ("CAS SDLC MONITOR", "bold magenta"),
            (" | ", "dim"),
            (state.project, "bold white"),
            (" (", "dim"),
            (f"branch: {state.branch}", "yellow"),
            (" | ", "dim"),
            (f"profile: {state.sdlc_profile}", "cyan"),
            (")", "dim"),
        ),
        Text.assemble(
            ("Elapsed: ", "dim"),
            (elapsed_str, "bold white"),
        ),
    )
    return header_table


def render_stage_progress(state: SDLCState) -> Panel:
    total_stages = 6
    percent = state.progress_percent

    bar_width = 30
    filled_len = int(bar_width * (state.stage / float(total_stages)))
    unfilled_len = bar_width - filled_len

    bar_str = "█" * filled_len + "░" * unfilled_len

    content = Text.assemble(
        (f"Stage {state.stage}/{total_stages}: ", "bold white"),
        (f"{state.stage_name} ", "bold cyan"),
        (" [", "dim"),
        (bar_str, "green"),
        (f"] {percent}%", "bold yellow"),
    )
    return Panel(content, title="Active SDLC Lifecycle Progress", border_style="cyan")


def render_gate_scorecard(state: SDLCState) -> Table:
    table = Table(
        title="Governance Gates & Policy Scorecard",
        expand=True,
        box=None,
        padding=(0, 1),
    )
    table.add_column("Stage / Gate", style="bold white", ratio=2)
    table.add_column("Status", ratio=1)
    table.add_column("Details", style="dim", ratio=3)

    gate_definitions = [
        (
            "Stage 1: Intent Triage",
            "intent",
            "verify-intent ([A] anchors, [P] presumptions, [Q] questions)",
        ),
        (
            "Stage 2: Two-Key Artifacts",
            "two_key",
            "spec.md and plan.md co-evolution (SDD-001, SPEC-002)",
        ),
        (
            "Stage 3: Plan Routing",
            "route_plan",
            "route-plan (Path A reuse / Path B novelty / Path C exception)",
        ),
        (
            "Stage 4: TDD & Build",
            "tdd",
            "Unit tests and regression test suite execution",
        ),
        (
            "Stage 5: Architecture Linter",
            "lint",
            "lint (ARCH-LINT-001..004 anti-pattern gates)",
        ),
        (
            "Stage 6: 3-Pass Diff Verification",
            "verify_diff",
            "verify-diff (SDD alignment, security, pattern invariants)",
        ),
    ]

    for label, gate_key, default_details in gate_definitions:
        record = state.gates.get(gate_key)
        if record:
            badge = get_status_badge(record.status)
            details = record.details or default_details
        elif (
            gate_key == "two_key"
            and state.checklist.get("spec_md")
            and state.checklist.get("plan_md")
        ):
            badge = get_status_badge("PASSED")
            details = "spec.md and plan.md active and co-evolved"
        elif gate_key == "tdd" and state.checklist.get("tests") and state.stage >= 4:
            badge = get_status_badge("PASSED")
            details = "Unit and regression tests implemented"
        else:
            badge = get_status_badge("PENDING")
            details = default_details
        table.add_row(label, badge, details)

    return table


def render_artifact_checklist(state: SDLCState) -> Table:
    table = Table(
        title="Two-Key SDLC Artifact Checklist", expand=True, box=None, padding=(0, 2)
    )
    table.add_column("Artifact", style="bold cyan")
    table.add_column("State", style="white")

    items = [
        ("Specification (`spec.md`)", state.checklist.get("spec_md", False)),
        ("Implementation Plan (`plan.md`)", state.checklist.get("plan_md", False)),
        ("Tasks Breakdown (`tasks.md`)", state.checklist.get("tasks_md", False)),
        ("Unit Tests (`tests/`)", state.checklist.get("tests", False)),
        ("Production Code (`src/`)", state.checklist.get("src", False)),
    ]

    for label, is_present in items:
        badge = (
            Text("✓ Aligned", style="bold green")
            if is_present
            else Text("○ Pending", style="dim")
        )
        table.add_row(label, badge)

    return table


def render_sdlc_hud(state: SDLCState) -> RenderableType:
    header = render_sdlc_header(state)
    progress = render_stage_progress(state)
    scorecard = render_gate_scorecard(state)
    checklist = render_artifact_checklist(state)

    events_table = Table(
        title="Recent Lifecycle Events", expand=True, box=None, padding=(0, 1)
    )
    events_table.add_column("Time", style="dim", ratio=1)
    events_table.add_column("Gate", style="bold cyan", ratio=1)
    events_table.add_column("Status", ratio=1)
    events_table.add_column("Details", style="white", ratio=3)

    if not state.events:
        events_table.add_row("-", "-", "○ PENDING", "No events recorded yet")
    else:
        for ev in reversed(state.events[-5:]):
            t_str = datetime.fromtimestamp(ev.get("timestamp", time.time())).strftime(
                "%H:%M:%S"
            )
            events_table.add_row(
                t_str,
                ev.get("gate", ""),
                get_status_badge(ev.get("status", "")),
                ev.get("details", ""),
            )

    return Group(
        header,
        Text(""),
        progress,
        Text(""),
        scorecard,
        Text(""),
        checklist,
        Text(""),
        events_table,
    )
