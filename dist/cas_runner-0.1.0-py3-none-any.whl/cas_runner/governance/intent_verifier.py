"""Stage 1 Zero-Hallucination Intent Triage Verifier.

Validates that committed intent and specification artifacts anchor structural claims
in verified code evidence ([A]), track heuristic presumptions ([P]), and resolve all
open questions ([Q]) prior to acceptance.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

from cas_runner.governance.models import (
    CodeAnchorCitation,
    HeuristicPresumption,
    IntentProvenanceReport,
    OpenQuestion,
)
from cas_runner.governance.sdlc_profile import SDLCProfileResolver


class IntentVerifier:
    """Verifies intent and specification provenance against real code evidence."""

    ANCHOR_PATTERN = re.compile(r"(?<!`)\[A\]\s+([^\s:\(\)`\[\]]+)(?::(\d+))?(?!`)")
    PRESUMPTION_PATTERN = re.compile(r"(?<!`)\[P\]\s+([^`\n]+)(?!`)")
    QUESTION_PATTERN = re.compile(r"(?<!`)\[Q\]\s+([^`\n]+)(?!`)")
    STATUS_PATTERN = re.compile(r"(?i)\bstatus:\s*([a-z_]+)")

    def __init__(self, target_dir: Path | str = Path(".")) -> None:
        self.target_dir = Path(target_dir).resolve()
        self.resolver = SDLCProfileResolver(target_dir=self.target_dir)

    def resolve_target_file(self) -> Path | None:
        """Locates the active intent or spec artifact via SDLCProfileResolver."""
        try:
            artifacts = self.resolver.resolve()
            for rel in artifacts.intent_files:
                p = self.target_dir / rel
                if p.is_file():
                    return p
            for rel in artifacts.spec_files:
                p = self.target_dir / rel
                if p.is_file():
                    return p
        except Exception:
            pass

        # Fallback search
        for candidate in ["intent.md", "spec.md"]:
            candidate_path = self.target_dir / candidate
            if candidate_path.is_file():
                return candidate_path

        return None

    def verify_artifact(self, artifact_path: Path) -> IntentProvenanceReport:
        """Parses and validates an intent or specification markdown file."""
        if not artifact_path.is_file():
            return IntentProvenanceReport(
                artifact_path=str(artifact_path),
                artifact_status="unknown",
                is_valid=False,
                errors=[f"Artifact file not found: {artifact_path}"],
            )

        content = artifact_path.read_text(encoding="utf-8")
        status = self._extract_status(content)

        report = IntentProvenanceReport(
            artifact_path=str(artifact_path),
            artifact_status=status,
            is_valid=True,
        )

        # Filter out fenced code blocks and inline code backticks to avoid parsing syntax examples
        active_lines: list[str] = []
        in_code_block = False
        for line in content.splitlines():
            if line.strip().startswith("```"):
                in_code_block = not in_code_block
                continue
            if not in_code_block:
                cleaned_line = re.sub(r"`[^`]*`", "", line)
                active_lines.append(cleaned_line)

        # 1. Parse and validate [A] anchors
        for line in active_lines:
            for match in self.ANCHOR_PATTERN.finditer(line):
                raw = match.group(0)
                file_rel = match.group(1).strip("`\"'[](),;:")
                line_no = int(match.group(2)) if match.group(2) else None

                citation = self._verify_code_anchor(file_rel, line_no, raw)
                report.anchors.append(citation)
                if not citation.is_valid:
                    report.is_valid = False
                    if citation.error_message:
                        report.errors.append(citation.error_message)

        # 2. Parse [P] presumptions
        for line in active_lines:
            match = self.PRESUMPTION_PATTERN.search(line)
            if match:
                raw = match.group(0)
                stmt = match.group(1).strip()
                report.presumptions.append(
                    HeuristicPresumption(raw_text=raw, statement=stmt)
                )

        # 3. Parse [Q] open questions
        for line in active_lines:
            match = self.QUESTION_PATTERN.search(line)
            if match:
                raw = match.group(0)
                q_text = match.group(1).strip()
                is_blocking = status == "accepted"
                question = OpenQuestion(
                    raw_text=raw, question=q_text, is_blocking=is_blocking
                )
                report.open_questions.append(question)
                if is_blocking:
                    report.is_valid = False
                    report.errors.append(
                        f"Status: accepted is blocked while open questions [Q] remain: '{q_text}'"
                    )

        return report

    def _extract_status(self, content: str) -> str:
        """Extracts the status field from frontmatter or top lines."""
        for line in content.splitlines()[:30]:
            match = self.STATUS_PATTERN.search(line)
            if match:
                return match.group(1).strip().lower()
        return "draft"

    def _verify_code_anchor(
        self, file_rel: str, line_no: int | None, raw_citation: str
    ) -> CodeAnchorCitation:
        """Verifies that a referenced file exists and line matches code AST bounds."""
        target_file = self.target_dir / file_rel
        if not target_file.is_file():
            # Try relative to parent if file_rel was relative to subfolder
            if not target_file.exists():
                return CodeAnchorCitation(
                    raw_citation=raw_citation,
                    file_path=file_rel,
                    line_number=line_no,
                    is_valid=False,
                    error_message=f"File not found on disk: '{file_rel}'",
                )

        if line_no is None:
            return CodeAnchorCitation(
                raw_citation=raw_citation,
                file_path=file_rel,
                line_number=None,
                is_valid=True,
            )

        try:
            content = target_file.read_text(encoding="utf-8")
        except Exception as exc:
            return CodeAnchorCitation(
                raw_citation=raw_citation,
                file_path=file_rel,
                line_number=line_no,
                is_valid=False,
                error_message=f"Cannot read file '{file_rel}': {exc}",
            )

        lines = content.splitlines()
        total_lines = len(lines)
        if line_no < 1 or line_no > total_lines:
            return CodeAnchorCitation(
                raw_citation=raw_citation,
                file_path=file_rel,
                line_number=line_no,
                is_valid=False,
                error_message=(
                    f"Line number {line_no} exceeds total line count ({total_lines}) "
                    f"in '{file_rel}'"
                ),
            )

        # For Python files, verify AST node bounds
        ast_node_type: str | None = None
        if target_file.suffix.lower() == ".py":
            try:
                tree = ast.parse(content, filename=str(target_file))
                node_match = self._find_ast_statement(tree, line_no)
                if not node_match:
                    return CodeAnchorCitation(
                        raw_citation=raw_citation,
                        file_path=file_rel,
                        line_number=line_no,
                        is_valid=False,
                        error_message=(
                            f"Line {line_no} in '{file_rel}' does not fall within a valid "
                            f"Python AST statement or symbol definition."
                        ),
                    )
                ast_node_type = type(node_match).__name__
            except SyntaxError:
                # If target file has syntax errors, fall back to line bounds
                pass

        return CodeAnchorCitation(
            raw_citation=raw_citation,
            file_path=file_rel,
            line_number=line_no,
            is_valid=True,
            ast_node_type=ast_node_type,
        )

    def _find_ast_statement(self, tree: ast.AST, target_line: int) -> ast.AST | None:
        """Finds whether target_line lies within any AST statement or definition."""
        found: ast.AST | None = None
        for node in ast.walk(tree):
            if hasattr(node, "lineno") and hasattr(node, "end_lineno"):
                if node.lineno <= target_line <= node.end_lineno:
                    # Prefer statement-level nodes over expressions
                    if isinstance(
                        node,
                        (
                            ast.stmt,
                            ast.FunctionDef,
                            ast.AsyncFunctionDef,
                            ast.ClassDef,
                            ast.Import,
                            ast.ImportFrom,
                            ast.Assign,
                            ast.AnnAssign,
                            ast.Expr,
                            ast.Return,
                        ),
                    ):
                        found = node
        return found

    def verify(self) -> IntentProvenanceReport:
        """Executes intent verification against the active repository."""
        target_file = self.resolve_target_file()
        if not target_file:
            report = IntentProvenanceReport(
                artifact_path="<none>",
                artifact_status="none",
                is_valid=True,
                warnings=[
                    "No intent.md or spec.md artifact resolved for verification."
                ],
            )
        else:
            report = self.verify_artifact(target_file)

        try:
            from .sdlc_state import SDLCStatePublisher

            status = "PASSED" if report.is_valid else "FAILED"
            details = f"{report.valid_anchors_count} [A] verified, {report.open_questions_count} [Q] open"
            publisher = SDLCStatePublisher(target_dir=self.target_dir)
            publisher.record_gate(
                gate_name="intent",
                status=status,
                details=details,
                stage=1,
                checklist_updates={"spec_md": bool(target_file)},
            )
        except Exception:
            pass

        return report
