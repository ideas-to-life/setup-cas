from __future__ import annotations

import json
import os
import re
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from .sdlc_profile import SDLCProfileResolver

STAGE_NAMES = {
    0: "Initializing",
    1: "Stage 1: Intent Triage",
    2: "Stage 2: Specification & Planning",
    3: "Stage 3: Plan Governance Routing",
    4: "Stage 4: TDD & Build",
    5: "Stage 5: Architecture Linter",
    6: "Stage 6: 3-Pass Diff Verification",
}


class GateRecord(BaseModel):
    name: str
    status: str = "PENDING"  # PENDING, RUNNING, PASSED, FAILED, PATH_A, PATH_B, PATH_C
    details: str = ""
    timestamp: float = Field(default_factory=time.time)


class SDLCState(BaseModel):
    project: str = "ideas-to-life-cas"
    branch: str = "main"
    feature_dir: str = ""
    sdlc_profile: str = "speckit"
    stage: int = 0
    stage_name: str = "Initializing"
    start_time: float = Field(default_factory=time.time)
    updated_at: float = Field(default_factory=time.time)
    gates: dict[str, GateRecord] = Field(default_factory=dict)
    checklist: dict[str, bool] = Field(
        default_factory=lambda: {
            "spec_md": False,
            "plan_md": False,
            "tasks_md": False,
            "tests": False,
            "src": False,
        }
    )
    events: list[dict[str, Any]] = Field(default_factory=list)

    @property
    def progress_percent(self) -> int:
        return min(100, int((self.stage / 6.0) * 100))


def get_default_sdlc_state_path(target_dir: Path | str = ".") -> Path:
    return Path(target_dir) / ".cas" / "runtime" / "sdlc-state.json"


def detect_current_branch(target_dir: Path | str = ".") -> str:
    try:
        res = subprocess.run(
            ["git", "-C", str(target_dir), "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            check=False,
            timeout=2.0,
        )
        if res.returncode == 0:
            branch = res.stdout.strip()
            if branch:
                return branch
    except Exception:
        pass
    return "unknown"


class SDLCStatePublisher:
    """Publishes atomic state updates to the shared .cas/runtime/sdlc-state.json file."""

    def __init__(
        self,
        project: str = "ideas-to-life-cas",
        target_dir: Path | str = ".",
        state_file: Path | str | None = None,
    ):
        self.project = project
        self.target_dir = Path(target_dir).resolve()
        self.state_file = (
            Path(state_file)
            if state_file
            else get_default_sdlc_state_path(self.target_dir)
        )

    def _branch_state_file(self, branch: str) -> Path:
        sanitized = re.sub(r"[^a-zA-Z0-9_.-]", "_", branch)
        return self.state_file.parent / f"sdlc-state-{sanitized}.json"

    def _create_initial_state(self, branch: str) -> SDLCState:
        profile_name = "speckit"
        feature_dir = ""
        try:
            resolver = SDLCProfileResolver(self.target_dir)
            resolved = resolver.resolve(
                branch_name=branch if branch != "unknown" else None
            )
            profile_name = resolved.profile_name
            feature_dir = resolved.feature_dir or ""
        except Exception:
            pass

        return SDLCState(
            project=self.project,
            branch=branch,
            feature_dir=feature_dir,
            sdlc_profile=profile_name,
            stage=0,
            stage_name=STAGE_NAMES.get(0, "Initializing"),
        )

    def _save_to_file(self, state: SDLCState, target_path: Path) -> None:
        state.updated_at = time.time()
        target_path.parent.mkdir(parents=True, exist_ok=True)
        dir_path = target_path.parent
        temp_name = None
        try:
            with tempfile.NamedTemporaryFile(
                "w", dir=dir_path, delete=False, encoding="utf-8"
            ) as tf:
                tf.write(state.model_dump_json(indent=2))
                temp_name = tf.name
            os.replace(temp_name, target_path)
        except Exception:
            if temp_name and os.path.exists(temp_name):
                try:
                    os.unlink(temp_name)
                except OSError:
                    pass
            raise

    def save(self, state: SDLCState) -> None:
        self._save_to_file(state, self.state_file)
        if state.branch and state.branch != "unknown":
            self._save_to_file(state, self._branch_state_file(state.branch))

    def load_or_create(self) -> SDLCState:
        current_branch = detect_current_branch(self.target_dir)

        if self.state_file.exists():
            try:
                with open(self.state_file, encoding="utf-8") as f:
                    data = json.load(f)
                loaded_state = SDLCState(**data)

                # Reconcile if git branch has changed
                if (
                    current_branch != "unknown"
                    and loaded_state.branch != current_branch
                ):
                    # Archive state for old branch if valid
                    if loaded_state.branch and loaded_state.branch != "unknown":
                        old_branch_file = self._branch_state_file(loaded_state.branch)
                        self._save_to_file(loaded_state, old_branch_file)

                    # Restore or create state for current branch
                    new_branch_file = self._branch_state_file(current_branch)
                    if new_branch_file.exists():
                        try:
                            with open(new_branch_file, encoding="utf-8") as bf:
                                branch_data = json.load(bf)
                            active_state = SDLCState(**branch_data)
                        except Exception:
                            active_state = self._create_initial_state(current_branch)
                    else:
                        active_state = self._create_initial_state(current_branch)

                    self.save(active_state)
                    return active_state

                return loaded_state
            except Exception:
                pass

        # Check if branch-specific archive exists before initializing blank state
        if current_branch and current_branch != "unknown":
            branch_file = self._branch_state_file(current_branch)
            if branch_file.exists():
                try:
                    with open(branch_file, encoding="utf-8") as bf:
                        branch_data = json.load(bf)
                    state = SDLCState(**branch_data)
                    self.save(state)
                    return state
                except Exception:
                    pass

        # Create default
        branch = current_branch
        state = self._create_initial_state(branch)
        self.save(state)
        return state

    def record_gate(
        self,
        gate_name: str,
        status: str,
        details: str = "",
        stage: int | None = None,
        checklist_updates: dict[str, bool] | None = None,
    ) -> SDLCState:
        state = self.load_or_create()
        record = GateRecord(
            name=gate_name,
            status=status,
            details=details,
            timestamp=time.time(),
        )
        state.gates[gate_name] = record

        if stage is not None and stage > state.stage:
            state.stage = stage
            state.stage_name = STAGE_NAMES.get(stage, f"Stage {stage}")

        if checklist_updates:
            state.checklist.update(checklist_updates)

        state.events.append(
            {
                "timestamp": record.timestamp,
                "gate": gate_name,
                "status": status,
                "details": details,
            }
        )
        # Keep only the last 20 events
        if len(state.events) > 20:
            state.events = state.events[-20:]

        self.save(state)
        return state
