from dataclasses import asdict, dataclass, field
from enum import StrEnum
from typing import Any


@dataclass
class ResolutionResult:
    workspace_path: str
    portal_url: str


@dataclass
class TraceableMetric:
    count: int
    workspace_path: str | None = None
    portal_url: str | None = None


@dataclass
class GovernanceInventory:
    proposals: TraceableMetric
    recommendations: TraceableMetric
    decisions: TraceableMetric
    adrs: TraceableMetric
    patterns: TraceableMetric


@dataclass
class GovernanceHealth:
    schemas: str
    traceability: str
    lifecycle: str
    governance_state: str


@dataclass
class GovernanceThroughput:
    recommendations_created: TraceableMetric
    decisions_made: TraceableMetric
    adrs_generated: TraceableMetric
    patterns_institutionalised: TraceableMetric


@dataclass
class GovernanceRisks:
    pending_reviews: TraceableMetric
    deferred_decisions: TraceableMetric
    conditional_adrs: TraceableMetric


@dataclass
class ComplianceFinding:
    rule_id: str
    severity: str
    validation_type: str
    artifact_id: str
    category: str
    description: str
    recommendation: str
    portal_url: str | None = None


@dataclass
class ComplianceMetrics:
    compliant: TraceableMetric
    warnings: TraceableMetric
    violations: TraceableMetric
    exceptions: TraceableMetric


@dataclass
class GovernanceException:
    id: str
    rule_id: str
    artifact_id: str
    rationale: str
    approved_by: str
    approval_date: str
    expiry_date: str
    status: str


@dataclass
class GovernanceAction:
    action_id: str
    action_type: str
    target_artifact_id: str
    target_artifact_type: str
    executed_by: str
    execution_date: str
    previous_state: str
    new_state: str
    rationale: str | None = None


@dataclass
class GovernanceActionMetrics:
    pending: TraceableMetric
    approved: TraceableMetric
    rejected: TraceableMetric
    deferred: TraceableMetric


@dataclass
class GovernanceMetrics:
    inventory: GovernanceInventory
    health: GovernanceHealth
    throughput: GovernanceThroughput
    risks: GovernanceRisks
    compliance: ComplianceMetrics | None = None
    actions: GovernanceActionMetrics | None = None


@dataclass
class ArtifactReference:
    artifact_id: str
    portal_url: str
    title: str | None = None


class GovernancePath(StrEnum):
    PATH_A = "Path A (Governed Reuse)"
    PATH_B = "Path B (Architectural Novelty)"
    PATH_C = "Path C (Architectural Exception)"


@dataclass
class CodeAnchorCitation:
    """Represents a code anchor citation [A] path/to/file[:line]."""

    raw_citation: str
    file_path: str
    line_number: int | None = None
    is_valid: bool = False
    error_message: str | None = None
    ast_node_type: str | None = None


@dataclass
class HeuristicPresumption:
    """Represents a presumption tagged with [P]."""

    raw_text: str
    statement: str


@dataclass
class OpenQuestion:
    """Represents an open question tagged with [Q]."""

    raw_text: str
    question: str
    is_blocking: bool = False


@dataclass
class IntentProvenanceReport:
    """Report detailing the outcome of intent triage."""

    artifact_path: str
    artifact_status: str
    anchors: list[CodeAnchorCitation] = field(default_factory=list)
    presumptions: list[HeuristicPresumption] = field(default_factory=list)
    open_questions: list[OpenQuestion] = field(default_factory=list)
    is_valid: bool = True
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def valid_anchors_count(self) -> int:
        return sum(1 for a in self.anchors if a.is_valid)

    @property
    def open_questions_count(self) -> int:
        return len(self.open_questions)

    @property
    def blocking_questions_count(self) -> int:
        return sum(1 for q in self.open_questions if q.is_blocking)


@dataclass
class PlanRoutingDecision:
    """Decision outcome of plan routing."""

    plan_path: str
    path: GovernancePath
    status: str  # "approved" | "escalated" | "blocked" | "exception_validated"
    matched_patterns: list[str] = field(default_factory=list)
    unmapped_dependencies: list[str] = field(default_factory=list)
    violated_invariants: list[str] = field(default_factory=list)
    detected_anti_patterns: list[str] = field(default_factory=list)
    candidate_adr_path: str | None = None
    exception_record_path: str | None = None
    reasons: list[str] = field(default_factory=list)


@dataclass
class PackageCouplingMetrics:
    """Robert C. Martin coupling and main-sequence distance metrics for a Python package."""

    package: str
    path: str
    ca: int = 0
    ce: int = 0
    instability: float = 0.0
    abstractness: float = 0.0
    distance: float = 0.0
    abstract_classes: int = 0
    total_classes: int = 0
    afferent_packages: list[str] = field(default_factory=list)
    efferent_packages: list[str] = field(default_factory=list)
    anchor_file: str = ""
    anchor_line: int = 1

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ControlBandTier:
    """Threshold and action specification for a single Western Electric band (1sigma/2sigma/3sigma)."""

    threshold: float
    action: str  # "log" | "diagnose" | "propose"
    tools: str | None = None
    routes: list[str] = field(default_factory=list)


@dataclass
class ControlBandSpec:
    """Declarative specification for a single architectural metric in .cas/bands.yaml."""

    metric: str
    description: str = ""
    baseline: str = "rolling_30d"
    rules: str = "western_electric"
    mean: float | None = None
    std_dev: float | None = None
    tiers: dict[str, ControlBandTier] = field(default_factory=dict)

    def get_threshold(self, band: str) -> float:
        multiplier = {"1sigma": 1.0, "2sigma": 2.0, "3sigma": 3.0}.get(band, 1.0)
        tier = self.tiers.get(band)
        if tier is not None and tier.threshold >= 0:
            return float(tier.threshold)
        if self.mean is not None and self.std_dev is not None:
            return round(float(self.mean) + multiplier * float(self.std_dev), 4)
        return 0.0


@dataclass
class BandEvaluationResult:
    """Evaluation outcome of a single metric against its Western Electric control bands."""

    metric: str
    observed_value: float
    band: str  # "ok" | "1sigma" | "2sigma" | "3sigma"
    action: str  # "none" | "log" | "diagnose" | "propose"
    threshold_1sigma: float = 0.0
    threshold_2sigma: float = 0.0
    threshold_3sigma: float = 0.0
    diagnostics: list[str] = field(default_factory=list)
    code_anchors: list[str] = field(default_factory=list)
    drafted_intent_path: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ControlBandsReport:
    """Aggregated evaluation report returned by cas governance check-bands."""

    target_dir: str
    config_path: str
    highest_band: str = "ok"
    has_3sigma_breach: bool = False
    drafted_intent_path: str | None = None
    results: list[BandEvaluationResult] = field(default_factory=list)
    package_metrics: list[PackageCouplingMetrics] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "target_dir": self.target_dir,
            "config_path": self.config_path,
            "highest_band": self.highest_band,
            "has_3sigma_breach": self.has_3sigma_breach,
            "drafted_intent_path": self.drafted_intent_path,
            "results": [r.to_dict() for r in self.results],
            "package_metrics": [p.to_dict() for p in self.package_metrics],
        }
