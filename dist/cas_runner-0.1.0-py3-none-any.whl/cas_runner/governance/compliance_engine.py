import json
from pathlib import Path
from typing import Any

import yaml

from ..io import get_workspace_root
from .models import (
    ComplianceFinding,
    ComplianceMetrics,
    GovernanceException,
    TraceableMetric,
)


class ComplianceEngine:
    """
    Evaluates governance artifacts against compliance-enabled rules.
    """
    def __init__(self, project: str, rules_dir: Path | None = None):
        self.project = project
        self.workspace_root = get_workspace_root()
        self.rules_dir = rules_dir or (self.workspace_root / "global" / "rules")
        self.exceptions_dir = self.workspace_root / "global" / "governance" / "exceptions"
        self.findings: list[ComplianceFinding] = []
        self.exceptions: list[GovernanceException] = []

    def load_rules(self) -> list[dict[str, Any]]:
        """Loads rules from the knowledge layer and filters for compliance-enabled ones."""
        compliance_rules = []
        if not self.rules_dir.exists():
            return []

        for rule_file in self.rules_dir.glob("*.md"):
            try:
                content = rule_file.read_text()
                if content.startswith("---"):
                    parts = content.split("---", 2)
                    if len(parts) >= 3:
                        data = yaml.safe_load(parts[1]) or {}
                        if data.get("compliance", {}).get("enabled") is True:
                            compliance_rules.append(data)
            except Exception as e:
                print(f"[CAS][ERROR] Failed to load rule {rule_file}: {e}")

        return compliance_rules

    def load_exceptions(self) -> list[GovernanceException]:
        """Loads and validates compliance exceptions."""
        self.exceptions = []
        if not self.exceptions_dir.exists():
            return []

        for exc_file in self.exceptions_dir.glob("*.yaml"):
            try:
                data = yaml.safe_load(exc_file.read_text()) or {}
                # In a real scenario, we would validate against schema here
                # For now, we assume valid or handle missing fields gracefully
                self.exceptions.append(GovernanceException(**data))
            except Exception as e:
                print(f"[CAS][ERROR] Failed to load exception {exc_file}: {e}")

        return self.exceptions

    def evaluate(self, artifacts: dict[str, list[dict[str, Any]]]) -> tuple[list[ComplianceFinding], ComplianceMetrics]:
        """Evaluates artifacts against compliance-enabled rules."""
        self.findings = []
        rules = self.load_rules()
        self.exceptions = self.load_exceptions()

        compliant_count = 0
        warning_count = 0
        violation_count = 0
        exception_count = 0

        for rule in rules:
            comp_config = rule.get("compliance", {})
            val_type = comp_config.get("validation_type")
            target_category = comp_config.get("target")

            if not val_type or not target_category:
                continue

            target_artifacts = artifacts.get(target_category, [])
            rule_compliant = True

            for art in target_artifacts:
                art_id = art.get("id") or art.get("pattern_id", "unknown")

                # Perform validation based on type
                is_valid = self._validate_artifact(art, comp_config)

                if not is_valid:
                    rule_compliant = False
                    severity = comp_config.get("severity", "warning")

                    # Check for exception
                    is_excepted = self._is_excepted(rule["id"], art_id)

                    if is_excepted:
                        severity = "info" # Demote severity if excepted
                        exception_count += 1
                    else:
                        if severity == "error":
                            violation_count += 1
                        else:
                            warning_count += 1

                    finding = ComplianceFinding(
                        rule_id=rule["id"],
                        severity=severity,
                        validation_type=val_type,
                        artifact_id=art_id,
                        category=rule.get("category", "General"),
                        description=f"Violation of {rule['id']} for {art_id}",
                        recommendation=comp_config.get("recommendation", "Review rule constraints"),
                        portal_url=art.get("portal_url")
                    )
                    self.findings.append(finding)

            if rule_compliant and target_artifacts:
                compliant_count += 1

        metrics = ComplianceMetrics(
            compliant=TraceableMetric(compliant_count),
            warnings=TraceableMetric(warning_count),
            violations=TraceableMetric(violation_count),
            exceptions=TraceableMetric(exception_count)
        )

        return self.findings, metrics

    def _validate_artifact(self, art: dict[str, Any], config: dict[str, Any]) -> bool:
        val_type = config.get("validation_type")

        if val_type == "status_check":
            field_path = config.get("field", "")
            expected = config.get("expected")

            actual = art
            for key in field_path.split("."):
                if isinstance(actual, dict):
                    actual = actual.get(key)
                else:
                    actual = None
                    break

            return actual == expected

        # Add more validation types as needed (e.g. required_fields, traceability_check)
        return True

    def _is_excepted(self, rule_id: str, artifact_id: str) -> bool:
        for exc in self.exceptions:
            if exc.rule_id == rule_id and exc.artifact_id == artifact_id and exc.status == "active":
                # Check expiry if format is correct
                return True
        return False

    def generate_report(self, metrics: ComplianceMetrics) -> dict[str, Any]:
        """Generates a serialized compliance report."""
        from dataclasses import asdict
        return {
            "project": self.project,
            "metrics": asdict(metrics),
            "findings": [asdict(f) for f in self.findings],
            "exceptions": [asdict(e) for e in self.exceptions]
        }

    def render_markdown(self, metrics: ComplianceMetrics) -> str:
        """Renders the compliance state into Markdown."""
        from .markdown_renderer import _status_icon

        status = "PASS"
        if metrics.violations.count > 0:
            status = "FAIL"
        elif metrics.warnings.count > 0:
            status = "WARNING"

        md = [
            "# Governance Compliance Report",
            "",
            f"**Overall Compliance Status**: {_status_icon(status)}",
            "",
            "## Compliance Status",
            "",
            "| Metric | Count |",
            "|---|---|",
            f"| Compliant Rules | {metrics.compliant.count} |",
            f"| Warnings | {metrics.warnings.count} |",
            f"| Violations | {metrics.violations.count} |",
            f"| Active Exceptions | {metrics.exceptions.count} |",
            "",
            "## Findings",
            "",
            "| Severity | Category | Description | Artifact | Recommendation |",
            "|---|---|---|---|---|"
        ]

        for f in self.findings:
            sev_icon = "🔴 Error" if f.severity == "error" else "🟡 Warning" if f.severity == "warning" else "🔵 Info"
            artifact_link = f"[{f.artifact_id}]({f.portal_url})" if f.portal_url else f.artifact_id
            md.append(f"| {sev_icon} | {f.category} | {f.description} | {artifact_link} | {f.recommendation} |")

        md.append("")
        return "\n".join(md)

    def save_report(self, metrics: ComplianceMetrics):
        """Saves both JSON and Markdown compliance reports."""
        report_dir = self.workspace_root / "global" / "governance" / "compliance"
        report_dir.mkdir(parents=True, exist_ok=True)

        # Save JSON
        report_data = self.generate_report(metrics)
        json_path = report_dir / "report.json"
        with open(json_path, "w") as f:
            json.dump(report_data, f, indent=2)

        # Save Markdown
        md_content = self.render_markdown(metrics)
        md_path = report_dir / "index.md"
        with open(md_path, "w") as f:
            f.write(md_content)

        print(f"[CAS][GOVERNANCE] Compliance reports saved to {report_dir}")
