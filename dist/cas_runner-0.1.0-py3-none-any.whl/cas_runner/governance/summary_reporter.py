"""Summary reporter for CAS governance artifacts.

Provides deterministic, pure functional formatting of IntentProvenanceReport and
associated Stage 1 intent provenance metrics into clean Markdown tables.
"""

from __future__ import annotations

from collections.abc import Sequence

from cas_runner.governance.models import (
    CodeAnchorCitation,
    HeuristicPresumption,
    IntentProvenanceReport,
    OpenQuestion,
)


def format_intent_provenance_table(report: IntentProvenanceReport) -> str:
    """Formats an IntentProvenanceReport into a clean Markdown summary table.

    Operates as a pure, deterministic function conforming to the
    pure-functional-health-evaluation pattern.
    """
    outcome_str = "PASS" if report.is_valid else "FAIL"
    outcome_icon = "✅ PASS" if report.is_valid else "❌ FAIL"

    anchors_total = len(report.anchors)
    anchors_valid = report.valid_anchors_count
    if anchors_total == 0:
        anchors_status = "✅ PASS" if report.is_valid else "None"
    else:
        anchors_status = "✅ PASS" if anchors_valid == anchors_total else "❌ FAIL"

    presumptions_count = len(report.presumptions)
    questions_count = len(report.open_questions)
    blocking_count = report.blocking_questions_count
    questions_status = "✅ PASS" if blocking_count == 0 else "❌ FAIL"

    rows: list[tuple[str, str, str]] = [
        ("Target Artifact", f"`{report.artifact_path}`", f"`{report.artifact_status}`"),
        ("Verification Result", outcome_str, outcome_icon),
        (
            "Code Anchors ([A])",
            f"{anchors_valid} / {anchors_total} valid",
            anchors_status,
        ),
        (
            "Heuristic Presumptions ([P])",
            f"{presumptions_count} tracked",
            "Tracked" if presumptions_count > 0 else "None",
        ),
        (
            "Open Questions ([Q])",
            f"{questions_count} active ({blocking_count} blocking)",
            "✅ None" if questions_count == 0 else questions_status,
        ),
    ]

    if report.errors:
        rows.append(("Errors", f"{len(report.errors)} error(s)", "❌ FAIL"))

    if report.warnings:
        rows.append(("Warnings", f"{len(report.warnings)} warning(s)", "⚠️ Warning"))

    lines = [
        "| Metric | Value | Status |",
        "|---|---|---|",
    ]
    for metric, val, status in rows:
        lines.append(f"| {metric} | {val} | {status} |")

    return "\n".join(lines)


def format_anchors_table(anchors: Sequence[CodeAnchorCitation]) -> str:
    """Formats a list of CodeAnchorCitation records into a clean Markdown table."""
    if not anchors:
        return "_No code anchors recorded._"

    lines = [
        "| Citation | Target File | Line | AST Node | Status | Details |",
        "|---|---|---|---|---|---|",
    ]
    for a in anchors:
        line_str = str(a.line_number) if a.line_number is not None else "-"
        ast_str = f"`{a.ast_node_type}`" if a.ast_node_type else "-"
        status = "✅ Valid" if a.is_valid else "❌ Invalid"
        details = a.error_message if not a.is_valid and a.error_message else "Valid"
        lines.append(
            f"| `{a.raw_citation}` | `{a.file_path}` | {line_str} | {ast_str} | {status} | {details} |"
        )
    return "\n".join(lines)


def format_presumptions_table(
    presumptions: Sequence[HeuristicPresumption],
) -> str:
    """Formats a list of HeuristicPresumption records into a clean Markdown table."""
    if not presumptions:
        return "_No heuristic presumptions recorded._"

    lines = [
        "| # | Presumption |",
        "|---|---|",
    ]
    for idx, p in enumerate(presumptions, start=1):
        lines.append(f"| {idx} | {p.statement} |")
    return "\n".join(lines)


def format_questions_table(questions: Sequence[OpenQuestion]) -> str:
    """Formats a list of OpenQuestion records into a clean Markdown table."""
    if not questions:
        return "_No open questions recorded._"

    lines = [
        "| # | Question | Blocking | Status |",
        "|---|---|---|---|",
    ]
    for idx, q in enumerate(questions, start=1):
        blocking_str = "🔴 Yes" if q.is_blocking else "⚪ No"
        status_str = "❌ Blocking" if q.is_blocking else "Open"
        lines.append(f"| {idx} | {q.question} | {blocking_str} | {status_str} |")
    return "\n".join(lines)


def format_intent_provenance_report(report: IntentProvenanceReport) -> str:
    """Renders a complete Markdown report for an IntentProvenanceReport."""
    sections = [
        "## Intent Provenance Summary",
        "",
        format_intent_provenance_table(report),
        "",
        "### Code Anchors ([A])",
        "",
        format_anchors_table(report.anchors),
        "",
        "### Heuristic Presumptions ([P])",
        "",
        format_presumptions_table(report.presumptions),
        "",
        "### Open Questions ([Q])",
        "",
        format_questions_table(report.open_questions),
    ]

    if report.errors:
        sections.extend(
            [
                "",
                "### Verification Errors",
                "",
                *[f"- ❌ {err}" for err in report.errors],
            ]
        )

    if report.warnings:
        sections.extend(
            [
                "",
                "### Verification Warnings",
                "",
                *[f"- ⚠️ {warn}" for warn in report.warnings],
            ]
        )

    return "\n".join(sections)
