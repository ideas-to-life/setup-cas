from cas_runner.io import resolve_target_project_context
from .models import ResolutionResult


def _get_project_context(artifact_id: str) -> str:
    ctx = resolve_target_project_context()
    return ctx.project_id

def resolve_artifact_reference(artifact_id: str) -> ResolutionResult:
    """
    Resolves a governance artifact ID into both its internal knowledge layer path
    and its external MkDocs portal route.
    """
    if not artifact_id:
        return ResolutionResult("#", "#")

    project = _get_project_context(artifact_id)

    from cas_runner import io
    workspace_root = io.get_workspace_root()

    # Simple mapping based on prefixes
    if artifact_id.startswith("adr-"):
        k_path = str(workspace_root / f"projects/{project}/adrs/{artifact_id}.md")
        p_url = f"../../../projects/{project}/adrs/{artifact_id}/"
        return ResolutionResult(k_path, p_url)

    elif artifact_id.startswith("pattern-") and "proposal" not in artifact_id:
        k_path = str(workspace_root / f"projects/{project}/patterns/{artifact_id}.md")
        p_url = f"../../../projects/{project}/patterns/{artifact_id}/"
        return ResolutionResult(k_path, p_url)

    elif artifact_id.startswith("promotion-decision-"):
        k_path = str(workspace_root / f"projects/{project}/governance/promotion-decisions/{artifact_id}.yaml")
        clean_id = artifact_id.replace("promotion-decision-", "decision-")
        p_url = f"../../../governance/decisions/{clean_id}/"
        return ResolutionResult(k_path, p_url)

    elif artifact_id.startswith("recommendation-"):
        k_path = str(workspace_root / f"projects/{project}/governance/pattern-promotion-recommendations.yaml")
        p_url = f"../../../governance/recommendations/{artifact_id}/"
        return ResolutionResult(k_path, p_url)

    elif artifact_id.startswith("proposal-") or "-proposal-" in artifact_id:
        k_path = str(workspace_root / f"projects/{project}/governance/pattern-proposals.yaml")
        clean_id = artifact_id if artifact_id.startswith("proposal-") else f"proposal-{artifact_id}"
        p_url = f"../../../governance/proposals/{clean_id}/"
        return ResolutionResult(k_path, p_url)

    return ResolutionResult(f"#{artifact_id}", f"#{artifact_id}")

def resolve_collection_reference(category: str, is_global: bool = False) -> ResolutionResult:
    """
    Resolves a governance category to its internal index path and its MkDocs collection route.
    """
    project = _get_project_context("")
    from cas_runner import io
    workspace_root = io.get_workspace_root()

    if category == "adrs":
        k_path = str(workspace_root / "global/decisions/index.md") if is_global else str(workspace_root / f"projects/{project}/adrs/index.md")
        p_url = "../../../decisions/" if is_global else f"../../../projects/{project}/adrs/"
        return ResolutionResult(k_path, p_url)

    elif category == "patterns":
        k_path = str(workspace_root / "global/patterns/index.md") if is_global else str(workspace_root / f"projects/{project}/patterns/index.md")
        p_url = "../../../patterns/" if is_global else f"../../../projects/{project}/patterns/"
        return ResolutionResult(k_path, p_url)

    elif category == "decisions":
        k_path = str(workspace_root / "global/decisions/index.md") if is_global else str(workspace_root / f"projects/{project}/governance/promotion-decisions/")
        p_url = "../../../governance/decisions/"
        return ResolutionResult(k_path, p_url)

    elif category == "recommendations":
        k_path = str(workspace_root / f"projects/{project}/governance/pattern-promotion-recommendations.yaml")
        p_url = "../../../governance/recommendations/"
        return ResolutionResult(k_path, p_url)

    elif category == "proposals":
        k_path = str(workspace_root / f"projects/{project}/governance/pattern-proposals.yaml")
        p_url = "../../../governance/proposals/"
        return ResolutionResult(k_path, p_url)

    return ResolutionResult("#", "#")
