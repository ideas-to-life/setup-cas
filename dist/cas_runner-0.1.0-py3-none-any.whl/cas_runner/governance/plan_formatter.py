"""Plan formatter for CAS proportionate governance routing decisions.

Provides deterministic, pure functional formatting of PlanRoutingDecision into
an executive Markdown summary callout conforming to the pure-functional-health-evaluation pattern.
"""

from __future__ import annotations

import re
from pathlib import Path

from cas_runner.governance.models import GovernancePath, PlanRoutingDecision


def extract_candidate_adr_id(decision: PlanRoutingDecision) -> str:
    """Extracts candidate ADR ID from decision candidate_adr_path, unmapped dependencies, or reasons.

    Operates as a pure functional helper without filesystem I/O.
    """
    if decision.candidate_adr_path:
        return Path(decision.candidate_adr_path).stem

    for dep in decision.unmapped_dependencies:
        if dep:
            clean = re.sub(r"[^a-zA-Z0-9_-]", "-", dep.lower()).strip("-")
            if clean:
                return f"adr-candidate-{clean}"

    for reason in decision.reasons:
        match = re.search(r"\b(adr-[a-zA-Z0-9_-]+)\b", reason, re.IGNORECASE)
        if match:
            return match.group(1)

    return "adr-candidate-pending"


def extract_exception_record_id(decision: PlanRoutingDecision) -> str | None:
    """Extracts architectural exception record ID from exception_record_path or reasons.

    Operates as a pure functional helper without filesystem I/O.
    """
    if decision.exception_record_path:
        return Path(decision.exception_record_path).stem

    for reason in decision.reasons:
        match = re.search(r"\b(exc-[a-zA-Z0-9_-]+)\b", reason, re.IGNORECASE)
        if match:
            return match.group(1)
        match_quoted = re.search(
            r"(?:exception|exc)\s+['\"]?([a-zA-Z0-9_-]+)['\"]?", reason, re.IGNORECASE
        )
        if match_quoted:
            val = match_quoted.group(1)
            return val if val.startswith("exc-") else f"exc-{val}"

    return None


def format_plan_routing_callout(decision: PlanRoutingDecision) -> str:
    """Formats a PlanRoutingDecision into an executive Markdown summary callout.

    Operates as a pure, deterministic function conforming to the
    pure-functional-health-evaluation pattern:
    - Side-effect-free, strictly operates over immutable input attributes.
    - Performs zero filesystem, network, or LLM I/O.
    - Produces reproducible Markdown callouts with appropriate alert classifications.
    """
    path_val = str(decision.path)
    is_path_b = (
        decision.path == GovernancePath.PATH_B
        or "Path B" in path_val
        or "Architectural Novelty" in path_val
    )
    is_path_c = (
        decision.path == GovernancePath.PATH_C
        or "Path C" in path_val
        or "Architectural Exception" in path_val
    )

    if is_path_b:
        path_display = GovernancePath.PATH_B.value
        alert_type = "WARNING"
    elif is_path_c:
        path_display = GovernancePath.PATH_C.value
        alert_type = "CAUTION" if decision.status.lower() == "blocked" else "IMPORTANT"
    else:
        path_display = GovernancePath.PATH_A.value
        alert_type = "NOTE"

    lines: list[str] = [
        f"> [!{alert_type}]",
        f"> ### Governance Path: {path_display}",
        ">",
        f"> - **Governance Path**: {path_display}",
        f"> - **Status**: {decision.status.upper()}",
        f"> - **Plan**: `{decision.plan_path}`",
    ]

    if is_path_b:
        adr_id = extract_candidate_adr_id(decision) or "adr-candidate-pending"
        lines.append(f"> - **Candidate ADR ID**: `{adr_id}`")
        if decision.candidate_adr_path:
            lines.append(f"> - **Candidate ADR Path**: `{decision.candidate_adr_path}`")
        if decision.unmapped_dependencies:
            novel_str = ", ".join(f"`{dep}`" for dep in decision.unmapped_dependencies)
            lines.append(f"> - **Unmapped Dependencies / Novel Patterns**: {novel_str}")
        lines.append("> - **Outcome**: Autonomous build halted.")
        lines.append(
            "> - **Action Required**: Auto-mode paused. Submit candidate ADR for ARB review via `uv run cas governance publish`."
        )
    elif is_path_c:
        exc_id = extract_exception_record_id(decision) or "Unknown Exception"
        lines.append(f"> - **Exception Record ID**: `{exc_id}`")
        if decision.exception_record_path:
            lines.append(
                f"> - **Exception Record Path**: `{decision.exception_record_path}`"
            )
        if decision.status.lower() == "blocked":
            lines.append(
                "> - **Outcome**: Autonomous build blocked (exception invalid or expired)."
            )
        else:
            lines.append(
                "> - **Outcome**: Autonomous build unlocked (active architectural exception)."
            )
    else:
        # Path A
        lines.append(
            "> - **Outcome**: Autonomous build unlocked (governed standard reuse)."
        )
        if decision.matched_patterns:
            patterns_str = ", ".join(f"`{p}`" for p in decision.matched_patterns)
            lines.append(f"> - **Matched Patterns**: {patterns_str}")

    if decision.violated_invariants:
        lines.append("> - **Violated Invariants**:")
        for inv in decision.violated_invariants:
            lines.append(f">   - ⚠️ {inv}")

    if decision.detected_anti_patterns:
        lines.append("> - **Detected Anti-Patterns**:")
        for ap in decision.detected_anti_patterns:
            lines.append(f">   - ❌ {ap}")

    if decision.reasons:
        lines.append("> - **Governance Details**:")
        for reason in decision.reasons:
            lines.append(f">   - {reason}")

    return "\n".join(lines)


# Aliases for flexible call sites
format_plan_routing_decision = format_plan_routing_callout
format_plan_routing_summary = format_plan_routing_callout
