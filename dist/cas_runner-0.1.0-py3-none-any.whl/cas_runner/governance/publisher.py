import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

import yaml

from ..io import TargetProjectContext, get_default_base

SUPPORTED_ARTIFACT_TYPES = ["reference_arch", "adr", "principle", "hld", "lld"]
SUPPORTED_REVIEW_TYPES = ["design_authority", "adr", "arb", "infosec", "cab"]


def resolve_review_type_default(artifact_type: str) -> str:
    """Returns sensible default review type based on artifact type."""
    if artifact_type == "adr":
        return "arb"
    elif artifact_type == "reference_arch":
        return "design_authority"
    elif artifact_type == "principle":
        return "design_authority"
    return "design_authority"


@dataclass(frozen=True)
class ArchGovEndpoints:
    artifacts: str
    artifact_detail: str
    reviews: str
    review_detail: str

    def format_artifacts(self) -> str:
        return self.artifacts

    def format_artifact_detail(self, artifact_id: int) -> str:
        return self.artifact_detail.format(artifact_id=artifact_id, id=artifact_id)

    def format_reviews(self, artifact_id: int) -> str:
        return self.reviews.format(artifact_id=artifact_id, id=artifact_id)

    def format_review_detail(self, artifact_id: int, review_id: int) -> str:
        return self.review_detail.format(
            artifact_id=artifact_id, id=artifact_id, review_id=review_id
        )


DEFAULT_CANONICAL_ENDPOINTS = ArchGovEndpoints(
    artifacts="/artifacts",
    artifact_detail="/artifacts/{artifact_id}",
    reviews="/artifacts/{artifact_id}/reviews",
    review_detail="/artifacts/{artifact_id}/reviews/{review_id}",
)


@dataclass
class ArchGovConfig:
    base_url: str | None = None
    default_owner: str | None = None
    domain_id: int | None = None
    initiative_id: int | None = None
    review_type: str | None = None
    arb_reviewer: str | None = None
    dry_run: bool = False
    endpoints: ArchGovEndpoints | None = None


def load_archgov_config(
    project: str | TargetProjectContext,
    base_path: Path | None = None,
    cli_overrides: dict[str, Any] | None = None,
) -> ArchGovConfig:
    """Resolves ArchGov configuration using 3-tier hierarchy:

    1. CLI overrides
    2. Environment variables (ARCHGOV_*)
    3. Project config.yaml (under governance_integrations.archgov)

    Endpoints MUST be explicitly defined under governance_integrations.archgov.endpoints
    in config.yaml; omitting any route triggers a ValueError (no hardcoded fallbacks).
    """
    cli_overrides = cli_overrides or {}

    if isinstance(project, TargetProjectContext):
        project_id = project.project_id
        base = base_path or project.knowledge_base_path
    else:
        project_id = str(project)
        base = base_path or get_default_base()

    # Tier 3: Load config.yaml
    cfg_file = base / "projects" / project_id / "config.yaml"
    file_cfg: dict[str, Any] = {}
    if cfg_file.exists():
        try:
            raw = yaml.safe_load(cfg_file.read_text(encoding="utf-8")) or {}
            file_cfg = raw.get("governance_integrations", {}).get("archgov", {})
        except Exception as e:
            print(f"[PUBLISHER][WARN] Failed reading project config at {cfg_file}: {e}")

    # Validate mandatory endpoints block from project config
    endpoints_cfg = file_cfg.get("endpoints")
    if not endpoints_cfg or not isinstance(endpoints_cfg, dict):
        raise ValueError(
            f"Missing required 'governance_integrations.archgov.endpoints' configuration in {cfg_file}. "
            "All routes ('artifacts', 'artifact_detail', 'reviews', 'review_detail') must be explicitly configured."
        )

    required_routes = ["artifacts", "artifact_detail", "reviews", "review_detail"]
    missing = [r for r in required_routes if not endpoints_cfg.get(r)]
    if missing:
        raise ValueError(
            f"Missing required ArchGov endpoint route(s) in {cfg_file}: {', '.join(missing)}. "
            "Every endpoint must be explicitly configured without hard-coded fallbacks."
        )

    endpoints = ArchGovEndpoints(
        artifacts=endpoints_cfg["artifacts"],
        artifact_detail=endpoints_cfg["artifact_detail"],
        reviews=endpoints_cfg["reviews"],
        review_detail=endpoints_cfg["review_detail"],
    )

    # Tier 2: Env vars
    env_base_url = os.getenv("ARCHGOV_BASE_URL")
    env_owner = os.getenv("ARCHGOV_OWNER_EMAIL")
    env_arb_reviewer = os.getenv("ARCHGOV_ARB_REVIEWER")
    env_domain = os.getenv("ARCHGOV_DOMAIN_ID")
    env_init = os.getenv("ARCHGOV_INITIATIVE_ID")

    # Tier 1: CLI overrides > Env > File > Default
    base_url = (
        cli_overrides.get("base_url")
        or env_base_url
        or file_cfg.get("base_url")
        or "http://archgov.pbo-tech.net"
    ).rstrip("/")

    owner = cli_overrides.get("owner") or env_owner or file_cfg.get("default_owner")
    arb_reviewer = (
        cli_overrides.get("arb_reviewer")
        or env_arb_reviewer
        or file_cfg.get("arb_reviewer")
        or owner
    )

    domain_raw = (
        cli_overrides.get("domain_id") or env_domain or file_cfg.get("domain_id")
    )
    domain_id = (
        int(domain_raw)
        if domain_raw is not None and str(domain_raw).isdigit()
        else None
    )

    init_raw = (
        cli_overrides.get("initiative_id") or env_init or file_cfg.get("initiative_id")
    )
    initiative_id = (
        int(init_raw) if init_raw is not None and str(init_raw).isdigit() else None
    )

    dry_run = bool(cli_overrides.get("dry_run", False))

    return ArchGovConfig(
        base_url=base_url,
        default_owner=owner,
        arb_reviewer=arb_reviewer,
        domain_id=domain_id,
        initiative_id=initiative_id,
        dry_run=dry_run,
        endpoints=endpoints,
    )


@runtime_checkable
class ExternalGovernancePublisherProtocol(Protocol):
    def publish_artifact(
        self,
        title: str,
        artifact_type: str,
        content: str,
        owner: str | None = None,
        created_by: str | None = None,
        domain_id: int | None = None,
        initiative_id: int | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]: ...

    def request_review(
        self,
        artifact_id: int,
        review_type: str,
        reviewer: str,
        comment: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]: ...

    def get_artifact(
        self, artifact_id: int, dry_run: bool = False
    ) -> dict[str, Any]: ...

    def get_reviews(
        self, artifact_id: int, dry_run: bool = False
    ) -> list[dict[str, Any]]: ...

    def update_review_status(
        self,
        artifact_id: int,
        review_id: int,
        status: str,
        rationale: str | None = None,
        comment: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]: ...


class ArchGovPublisher:
    """Publisher adapter communicating with the ArchGov REST API."""

    def __init__(
        self,
        base_url: str = "http://archgov.pbo-tech.net",
        endpoints: ArchGovEndpoints | None = None,
        max_retries: int = 3,
        backoff_factor: float = 1.0,
    ):
        self.base_url = base_url.rstrip("/")
        self.endpoints = endpoints or DEFAULT_CANONICAL_ENDPOINTS
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor

    def _resolve_url(self, path: str) -> str:
        """Joins base_url with relative endpoint path cleanly."""
        clean_path = path if path.startswith("/") else f"/{path}"
        return f"{self.base_url}{clean_path}"

    def publish_artifact(
        self,
        title: str,
        artifact_type: str,
        content: str,
        owner: str | None = None,
        created_by: str | None = None,
        domain_id: int | None = None,
        initiative_id: int | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Creates an artifact on ArchGov via configured artifacts endpoint."""
        payload: dict[str, Any] = {
            "title": title,
            "type": artifact_type,
            "content": content,
            "requires_formal_review": False,
        }
        if owner:
            payload["owner"] = owner
        if created_by or owner:
            payload["created_by"] = created_by or owner
        if domain_id is not None:
            payload["domain_id"] = domain_id
        if initiative_id is not None:
            payload["initiative_id"] = initiative_id

        url = self._resolve_url(self.endpoints.format_artifacts())

        if dry_run:
            print(f"[PUBLISHER][DRY-RUN] Staging artifact creation to {url}:")
            print(json.dumps(payload, indent=2))
            return {
                "id": 0,
                "title": title,
                "type": artifact_type,
                "status": "staged",
                "dry_run": True,
            }

        return self._post_with_retry(url, payload)

    def request_review(
        self,
        artifact_id: int,
        review_type: str,
        reviewer: str,
        comment: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Submits an artifact for review via configured reviews endpoint."""
        payload: dict[str, Any] = {
            "review_type": review_type,
            "reviewer": reviewer,
        }
        if comment:
            payload["comment"] = comment

        url = self._resolve_url(self.endpoints.format_reviews(artifact_id))

        if dry_run:
            print(f"[PUBLISHER][DRY-RUN] Staging review request to {url}:")
            print(json.dumps(payload, indent=2))
            return {
                "id": 0,
                "artifact_id": artifact_id,
                "review_type": review_type,
                "reviewer": reviewer,
                "status": "staged",
                "dry_run": True,
            }

        return self._post_with_retry(url, payload)

    def get_artifact(self, artifact_id: int, dry_run: bool = False) -> dict[str, Any]:
        """Fetches artifact details from ArchGov via configured artifact_detail endpoint."""
        url = self._resolve_url(self.endpoints.format_artifact_detail(artifact_id))
        if dry_run:
            print(
                f"[PUBLISHER][DRY-RUN] Staging get_artifact for ID {artifact_id} at {url}"
            )
            return {"id": artifact_id, "status": "draft", "dry_run": True}
        res = self._request_with_retry(url, method="GET")
        return res if isinstance(res, dict) else {"status": "success", "data": res}

    def get_reviews(
        self, artifact_id: int, dry_run: bool = False
    ) -> list[dict[str, Any]]:
        """Fetches reviews for an artifact from ArchGov via configured reviews endpoint."""
        url = self._resolve_url(self.endpoints.format_reviews(artifact_id))
        if dry_run:
            print(
                f"[PUBLISHER][DRY-RUN] Staging get_reviews for ID {artifact_id} at {url}"
            )
            return [
                {
                    "id": 1,
                    "artifact_id": artifact_id,
                    "status": "pending_review",
                    "dry_run": True,
                }
            ]
        res = self._request_with_retry(url, method="GET")
        if isinstance(res, list):
            return res
        if isinstance(res, dict) and "reviews" in res:
            return res["reviews"]
        if isinstance(res, dict) and "error" in res:
            return [res]
        return []

    def update_review_status(
        self,
        artifact_id: int,
        review_id: int,
        status: str,
        rationale: str | None = None,
        comment: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Updates review status on ArchGov via configured review_detail endpoint."""
        notes = rationale or comment
        payload: dict[str, Any] = {"status": status}
        if notes:
            payload["decision_notes"] = notes

        url = self._resolve_url(
            self.endpoints.format_review_detail(artifact_id, review_id)
        )

        if dry_run:
            print(f"[PUBLISHER][DRY-RUN] Staging review status update to {url}:")
            print(json.dumps(payload, indent=2))
            return {
                "id": review_id,
                "artifact_id": artifact_id,
                "status": status,
                "dry_run": True,
            }

        res = self._request_with_retry(url, payload=payload, method="PATCH")
        return res if isinstance(res, dict) else {"status": "success", "data": res}

    def _post_with_retry(self, url: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Executes HTTP POST request with JSON payload and exponential backoff retry."""
        res = self._request_with_retry(url, payload=payload, method="POST")
        return res if isinstance(res, dict) else {"status": "success", "data": res}

    def _request_with_retry(
        self,
        url: str,
        payload: dict[str, Any] | None = None,
        method: str = "POST",
    ) -> Any:
        """Executes HTTP request with exponential backoff retry."""
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        headers = {"Accept": "application/json"}
        if data is not None:
            headers["Content-Type"] = "application/json"

        req = urllib.request.Request(
            url=url,
            data=data,
            headers=headers,
            method=method,
        )

        attempts = 0
        last_error = ""

        for attempt in range(1, self.max_retries + 1):
            attempts = attempt
            try:
                with urllib.request.urlopen(req, timeout=30) as response:
                    res_bytes = response.read()
                    if res_bytes:
                        try:
                            return json.loads(res_bytes.decode("utf-8"))
                        except json.JSONDecodeError:
                            return {
                                "status": "success",
                                "raw": res_bytes.decode("utf-8"),
                            }
                    return {"status": "success", "http_status": response.status}
            except urllib.error.HTTPError as e:
                body = ""
                try:
                    body = e.read().decode("utf-8")
                except Exception:
                    pass
                last_error = f"HTTP {e.code} {e.reason}: {body}"
                # Retry on 5xx server errors
                if e.code >= 500 and attempt < self.max_retries:
                    wait_time = self.backoff_factor * (2 ** (attempt - 1))
                    print(
                        f"[PUBLISHER][WARN] Attempt {attempt} failed ({last_error}). Retrying in {wait_time:.1f}s..."
                    )
                    time.sleep(wait_time)
                    continue
                # For 4xx errors, fail immediately
                if e.code < 500:
                    print(
                        f"[PUBLISHER][ERROR] Request failed with client error: {last_error}"
                    )
                    return {"error": last_error, "code": e.code, "attempts": attempts}
            except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
                last_error = str(e)
                if attempt < self.max_retries:
                    wait_time = self.backoff_factor * (2 ** (attempt - 1))
                    print(
                        f"[PUBLISHER][WARN] Connection attempt {attempt} failed ({last_error}). Retrying in {wait_time:.1f}s..."
                    )
                    time.sleep(wait_time)
                    continue

        print(
            f"[PUBLISHER][ERROR] Request to {url} failed after {attempts} attempts: {last_error}"
        )
        return {"error": last_error, "attempts": attempts}
