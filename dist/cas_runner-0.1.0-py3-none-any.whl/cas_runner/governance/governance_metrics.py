from typing import Any

from .models import (
    GovernanceActionMetrics,
    GovernanceHealth,
    GovernanceInventory,
    GovernanceMetrics,
    GovernanceRisks,
    GovernanceThroughput,
    TraceableMetric,
)
from .reference_resolver import resolve_artifact_reference, resolve_collection_reference


class GovernanceMetricsEngine:
    """
    Calculates governance metrics based on discovered artifacts and validation findings.
    """
    def __init__(self, project: str, artifacts: dict[str, list[dict[str, Any]]], validation_report: dict[str, Any]):
        self.project = project
        self.artifacts = artifacts
        self.report = validation_report

    def _create_metric(self, count: int, category: str, singular_artifacts: list[dict[str, Any]] = None) -> TraceableMetric:
        """Helper to create a TraceableMetric. Resolves to specific artifact if count==1, else collection."""
        if count == 1 and singular_artifacts and len(singular_artifacts) == 1:
            art = singular_artifacts[0]
            art_id = art.get("id") or art.get("pattern_id")
            if art_id:
                # If we have a single item, point directly to it
                if category == "adrs" and not art_id.startswith("adr-"):
                    art_id = f"adr-{art_id}"
                res = resolve_artifact_reference(art_id)
                return TraceableMetric(count=1, workspace_path=res.workspace_path, portal_url=res.portal_url)

        # Fallback to collection link if count is 0 or > 1, or we couldn't resolve single item
        res = resolve_collection_reference(category)
        return TraceableMetric(count=count, workspace_path=res.workspace_path, portal_url=res.portal_url)

    def calculate(self) -> GovernanceMetrics:
        from .governance_action_service import GovernanceActionService
        action_service = GovernanceActionService(self.project)
        pending_actions = action_service.get_pending_actions(self.artifacts)

        # Calculate other action metrics if needed (e.g., from reading action files directly)
        # For MVP, we'll populate pending and leave others as 0
        action_metrics = GovernanceActionMetrics(
            pending=TraceableMetric(count=len(pending_actions), portal_url="../../governance/decisions/"), # Using generic inbox route
            approved=TraceableMetric(0, portal_url="../../governance/decisions/"),
            rejected=TraceableMetric(0, portal_url="../../governance/decisions/"),
            deferred=TraceableMetric(0, portal_url="../../governance/decisions/")
        )

        return GovernanceMetrics(
            inventory=self._calculate_inventory(),
            health=self._calculate_health(),
            throughput=self._calculate_throughput(),
            risks=self._calculate_risks(),
            actions=action_metrics
        )

    def _calculate_inventory(self) -> GovernanceInventory:
        # Count recommendations
        recs_count = 0
        for r in self.artifacts.get("recommendations", []):
            recs_count += len(r.get("promotion_candidates", []))

        return GovernanceInventory(
            proposals=self._create_metric(len(self.artifacts.get("proposals", [])), "proposals", self.artifacts.get("proposals")),
            recommendations=self._create_metric(recs_count, "recommendations"),
            decisions=self._create_metric(len(self.artifacts.get("decisions", [])), "decisions", self.artifacts.get("decisions")),
            adrs=self._create_metric(len(self.artifacts.get("adrs", [])), "adrs", self.artifacts.get("adrs")),
            patterns=self._create_metric(len(self.artifacts.get("patterns", [])), "patterns", self.artifacts.get("patterns"))
        )

    def _calculate_health(self) -> GovernanceHealth:
        findings = self.report.get("findings", [])

        # A category fails if it has ANY finding of severity "error"
        schemas_fail = any(f["type"] == "schema_violation" and f["severity"] == "error" for f in findings)
        trace_fail = any(f["type"] == "broken_reference" and f["severity"] == "error" for f in findings)
        life_fail = any(f["type"] == "lifecycle_violation" and f["severity"] == "error" for f in findings)
        state_fail = any(f["type"] == "state_inconsistency" and f["severity"] == "error" for f in findings)

        return GovernanceHealth(
            schemas="FAIL" if schemas_fail else "PASS",
            traceability="FAIL" if trace_fail else "PASS",
            lifecycle="FAIL" if life_fail else "PASS",
            governance_state="FAIL" if state_fail else "PASS"
        )

    def _calculate_throughput(self) -> GovernanceThroughput:
        recs_count = 0
        for r in self.artifacts.get("recommendations", []):
            recs_count += len(r.get("promotion_candidates", []))

        institutionalised_patterns = [
            p for p in self.artifacts.get("patterns", [])
            if p.get("governance", {}).get("status") == "approved"
        ]

        return GovernanceThroughput(
            recommendations_created=self._create_metric(recs_count, "recommendations"),
            decisions_made=self._create_metric(len(self.artifacts.get("decisions", [])), "decisions", self.artifacts.get("decisions")),
            adrs_generated=self._create_metric(len(self.artifacts.get("adrs", [])), "adrs", self.artifacts.get("adrs")),
            patterns_institutionalised=self._create_metric(len(institutionalised_patterns), "patterns", institutionalised_patterns)
        )

    def _calculate_risks(self) -> GovernanceRisks:
        pending_adrs = [
            a for a in self.artifacts.get("adrs", [])
            if a.get("governance", {}).get("forum_status") == "pending"
        ]

        deferred_decisions = [
            d for d in self.artifacts.get("decisions", [])
            if d.get("decision", {}).get("status") == "deferred"
        ]

        deferred_count = len(deferred_decisions)

        # Add deferred recommendations to deferred decisions
        for r in self.artifacts.get("recommendations", []):
            deferred_count += len(r.get("deferred_candidates", []))

        conditional_adrs = [
            a for a in self.artifacts.get("adrs", [])
            if a.get("governance", {}).get("forum_status") == "conditional"
        ]

        return GovernanceRisks(
            pending_reviews=self._create_metric(len(pending_adrs), "adrs", pending_adrs),
            deferred_decisions=self._create_metric(deferred_count, "decisions", deferred_decisions),
            conditional_adrs=self._create_metric(len(conditional_adrs), "adrs", conditional_adrs)
        )
