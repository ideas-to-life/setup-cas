import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

import yaml

from ..io import (
    get_workspace_root,
    load_archgov_sync_manifest,
    save_archgov_sync_record,
    update_adr_frontmatter,
    update_reference_architecture_frontmatter,
)
from .governance_action_engine import GovernanceActionEngine
from .models import GovernanceAction


class GovernanceActionService:
    """
    Provides a stable internal interface for executing and querying governance actions.
    """

    def __init__(self, project: str, workspace_root: Path | None = None):
        self.project = project
        self.workspace_root = workspace_root or get_workspace_root()
        self.actions_dir = self.workspace_root / "global" / "governance" / "actions"
        self.engine = GovernanceActionEngine(project)

        self.actions_dir.mkdir(parents=True, exist_ok=True)

    def _get_user_identity(self) -> str:
        """Discovers the user identity via git config or system login."""
        try:
            result = subprocess.run(
                ["git", "config", "user.name"],
                capture_output=True,
                text=True,
                check=True,
            )
            name = result.stdout.strip()
            if name:
                return name
        except Exception:
            pass

        try:
            return os.getlogin()
        except Exception:
            return "unknown_user"

    def execute_action(
        self,
        artifact_id: str,
        artifact_type: str,
        current_state: str,
        action_type: str,
        rationale: str | None = None,
    ) -> GovernanceAction:
        """
        Executes a governance action, transitioning the state and recording an audit trail.
        Returns the created GovernanceAction record.
        """
        new_state = self.engine._apply_transition(
            artifact_type, current_state, action_type
        )

        # Update the target artifact file state on disk
        self.update_artifact_state(
            artifact_id, artifact_type, new_state, rationale=rationale
        )

        action = GovernanceAction(
            action_id=f"action-{uuid4().hex[:8]}",
            action_type=action_type,
            target_artifact_id=artifact_id,
            target_artifact_type=artifact_type,
            executed_by=self._get_user_identity(),
            execution_date=datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            previous_state=current_state,
            new_state=new_state,
            rationale=rationale,
        )

        self._persist_audit_record(action)
        return action

    def _persist_audit_record(self, action: GovernanceAction):
        """Saves the action as an immutable YAML record."""
        # E.g. action-adr-123-approve-20240101T120000Z.yaml
        safe_date = action.execution_date.replace(":", "").replace("-", "")
        filename = (
            f"action-{action.target_artifact_id}-{action.action_type}-{safe_date}.yaml"
        )
        file_path = self.actions_dir / filename

        from dataclasses import asdict

        record_data = asdict(action)

        with open(file_path, "w") as f:
            yaml.dump(record_data, f, default_flow_style=False, sort_keys=False)

        print(f"[CAS][GOVERNANCE] Action audit record saved to {file_path}")

    def get_pending_actions(
        self, artifacts: dict[str, list[dict[str, Any]]]
    ) -> list[dict[str, Any]]:
        """Scans artifacts to find items in pending or proposed status."""
        pending = []

        for adr in artifacts.get("adrs", []):
            status = adr.get("governance", {}).get("forum_status")
            if status in ["pending", "proposed"]:
                pending.append({"id": adr.get("id"), "type": "adr", "status": status})

        for decision in artifacts.get("decisions", []):
            status = decision.get("decision", {}).get("status")
            if status == "pending":
                # For decisions, ID might be stored as pattern_id in some projections
                art_id = decision.get("id") or decision.get("pattern_id")
                pending.append(
                    {"id": art_id, "type": "promotion_decision", "status": status}
                )

        # Add Proposals (All active proposals are pending action: Recommendation)
        for proposal in artifacts.get("proposals", []):
            art_id = proposal.get("id") or proposal.get("pattern_id")
            pending.append({"id": art_id, "type": "proposal", "status": "proposed"})

        # Add Recommendations (All active recommendations are pending action: Decision)
        for rec_doc in artifacts.get("recommendations", []):
            for cand in rec_doc.get("promotion_candidates", []):
                art_id = cand.get("id") or cand.get("pattern_id")
                pending.append(
                    {"id": art_id, "type": "recommendation", "status": "recommended"}
                )

        return pending

    def get_action_history(self, artifact_id: str) -> list[GovernanceAction]:
        """Retrieves chronological history of actions for a given artifact."""
        history = []
        # Find all action files for this artifact
        # Format: action-{target_artifact_id}-{action_type}-{timestamp}.yaml
        prefix = f"action-{artifact_id}-"

        for file_path in self.actions_dir.glob("*.yaml"):
            if file_path.name.startswith(prefix):
                try:
                    with open(file_path) as f:
                        data = yaml.safe_load(f)
                        history.append(GovernanceAction(**data))
                except Exception as e:
                    print(f"[CAS][ERROR] Failed to load audit record {file_path}: {e}")

        # Sort by execution_date descending
        history.sort(key=lambda a: a.execution_date, reverse=True)
        return history

    def is_pattern_or_recommendation(self, artifact_id: str) -> bool:
        """Checks if the artifact ID corresponds to an existing promotion decision or candidate recommendation."""
        # 1. Direct or prefixed file in promotion-decisions
        if self._find_artifact_path(artifact_id, "promotion_decision"):
            return True
        # 2. Candidate in pattern-promotion-recommendations.yaml
        return self._find_candidate_recommendation(artifact_id) is not None

    def _find_candidate_recommendation(self, artifact_id: str) -> dict[str, Any] | None:
        """Finds candidate recommendation by pattern ID from pattern-promotion-recommendations.yaml."""
        rec_path = (
            self.workspace_root
            / "projects"
            / self.project
            / "governance"
            / "pattern-promotion-recommendations.yaml"
        )
        if not rec_path.exists():
            return None
        try:
            with open(rec_path) as f:
                data = yaml.safe_load(f) or {}
            clean_id = artifact_id.removeprefix("promotion-decision-").removeprefix(
                "recommendation-"
            )
            for cand in data.get("promotion_candidates", []):
                p_id = cand.get("pattern_id") or cand.get("id")
                if p_id in [artifact_id, clean_id]:
                    return cand
        except Exception as e:
            print(
                f"[CAS][WARN] Failed to read recommendations for pattern resolution: {e}"
            )
        return None

    def _find_artifact_path(self, artifact_id: str, artifact_type: str) -> Path | None:
        """Locates the target artifact file on disk."""
        if artifact_type == "adr":
            # Search in projects/<project>/adrs and global/decisions
            clean_id = artifact_id.removeprefix("adr-")
            candidates = [
                f"{artifact_id}.md",
                f"adr-{clean_id}.md",
                f"{clean_id}.md",
            ]
            for c in candidates:
                project_path = (
                    self.workspace_root
                    / "projects"
                    / self.project
                    / "adrs"
                    / c
                )
                if project_path.exists():
                    return project_path
                global_path = (
                    self.workspace_root / "global" / "decisions" / c
                )
                if global_path.exists():
                    return global_path
        elif artifact_type == "promotion_decision":
            # Search in projects/<project>/governance/promotion-decisions/
            dec_dir = (
                self.workspace_root
                / "projects"
                / self.project
                / "governance"
                / "promotion-decisions"
            )
            path = dec_dir / f"{artifact_id}.yaml"
            if path.exists():
                return path
            prefixed = dec_dir / f"promotion-decision-{artifact_id}.yaml"
            if prefixed.exists():
                return prefixed
        elif artifact_type == "governance_exception":
            # Search in global/governance/exceptions/
            path = (
                self.workspace_root
                / "global"
                / "governance"
                / "exceptions"
                / f"{artifact_id}.yaml"
            )
            if path.exists():
                return path
        elif artifact_type == "architecture_work":
            # Search in projects/<project>/work/
            path = (
                self.workspace_root
                / "projects"
                / self.project
                / "work"
                / f"{artifact_id}.md"
            )
            if path.exists():
                return path
        elif artifact_type == "reference_arch":
            # Search in projects/<project>/reference-architectures/
            ref_dir = (
                self.workspace_root
                / "projects"
                / self.project
                / "reference-architectures"
            )
            path = ref_dir / f"{artifact_id}.md"
            if path.exists():
                return path
            if not artifact_id.startswith("reference-architecture-"):
                prefixed = ref_dir / f"reference-architecture-{artifact_id}.md"
                if prefixed.exists():
                    return prefixed
        return None

    def _pattern_exists(self, pattern_id: str) -> bool:
        """Checks if a global pattern file exists as either .yaml or .md."""
        clean_id = pattern_id.removeprefix("adr-")
        unprefixed = clean_id.removeprefix("pattern-")
        patterns_dir = self.workspace_root / "global" / "patterns"
        for name in {clean_id, unprefixed}:
            if (patterns_dir / f"{name}.yaml").exists() or (patterns_dir / f"{name}.md").exists():
                return True
        return False

    def get_artifact_state(self, artifact_id: str, artifact_type: str) -> str:
        """Loads the target artifact and extracts its current state."""
        path = self._find_artifact_path(artifact_id, artifact_type)
        if not path or not path.exists():
            if artifact_type == "promotion_decision":
                # Check if it exists as a candidate recommendation
                cand = self._find_candidate_recommendation(artifact_id)
                if cand:
                    return "pending"
            elif artifact_type == "reference_arch":
                # Check archgov-sync manifest first
                pattern_id = artifact_id.removeprefix("reference-architecture-")
                manifest = load_archgov_sync_manifest(
                    self.project, base_path=self.workspace_root
                )
                rec = manifest.get("records", {}).get(pattern_id)
                if rec and isinstance(rec, dict) and rec.get("status"):
                    return rec.get("status")
                return "draft"
            return "pending" if artifact_type != "governance_exception" else "active"

        if artifact_type == "adr":
            content = path.read_text()
            if content.startswith("---"):
                parts = content.split("---", 2)
                if len(parts) >= 3:
                    data = yaml.safe_load(parts[1]) or {}
                    return data.get("governance", {}).get("forum_status", "pending")
        elif artifact_type == "promotion_decision":
            with open(path) as f:
                data = yaml.safe_load(f) or {}
                return data.get("decision", {}).get("status", "pending")
        elif artifact_type == "governance_exception":
            with open(path) as f:
                data = yaml.safe_load(f) or {}
                return data.get("status", "active")
        elif artifact_type == "architecture_work":
            content = path.read_text()
            if content.startswith("---"):
                parts = content.split("---", 2)
                if len(parts) >= 3:
                    data = yaml.safe_load(parts[1]) or {}
                    return data.get("status", "proposed")
        elif artifact_type == "reference_arch":
            content = path.read_text(encoding="utf-8")
            if content.startswith("---"):
                parts = content.split("---", 2)
                if len(parts) >= 3:
                    try:
                        data = yaml.safe_load(parts[1]) or {}
                        if data.get("status"):
                            return data.get("status")
                    except Exception:
                        pass
            pattern_id = artifact_id.removeprefix("reference-architecture-")
            manifest = load_archgov_sync_manifest(
                self.project, base_path=self.workspace_root
            )
            rec = manifest.get("records", {}).get(pattern_id)
            if rec and isinstance(rec, dict) and rec.get("status"):
                return rec.get("status")
            return "draft"

        return (
            "pending"
            if artifact_type
            not in ["governance_exception", "architecture_work", "reference_arch"]
            else (
                "active"
                if artifact_type == "governance_exception"
                else ("proposed" if artifact_type == "architecture_work" else "draft")
            )
        )

    def _synthesize_promotion_decision(
        self, artifact_id: str, new_state: str, rationale: str | None = None
    ) -> Path | None:
        """Deterministically materializes a schema-compliant promotion decision artifact from recommendations."""
        cand = self._find_candidate_recommendation(artifact_id)
        if not cand:
            clean_id = (
                artifact_id.removeprefix("promotion-decision-")
                .removeprefix("reference-architecture-")
                .removeprefix("recommendation-")
            )
            cand = {
                "pattern_id": clean_id,
                "promotion_rationale": rationale
                or f"Promoted following Reference Architecture ratification for {clean_id}",
                "promotion_evidence": ["Ratified Reference Architecture in ArchGov"],
                "promotion_criteria_met": [
                    "governance maturity",
                    "ratified reference architecture",
                ],
                "governance_risks": [],
                "scope_alignment": "global",
            }

        pattern_id = (
            cand.get("pattern_id")
            or cand.get("id")
            or artifact_id.removeprefix("promotion-decision-")
        )
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        dec_dir = (
            self.workspace_root
            / "projects"
            / self.project
            / "governance"
            / "promotion-decisions"
        )
        dec_dir.mkdir(parents=True, exist_ok=True)
        decision_path = dec_dir / f"promotion-decision-{pattern_id}.yaml"

        summary = (
            rationale
            or cand.get("promotion_rationale")
            or f"Architect action applied: {new_state}"
        )

        decision_data = {
            "id": f"promotion-decision-{pattern_id}",
            "artifact_type": "promotion_decision",
            "pattern_id": pattern_id,
            "decision": {"status": new_state, "decision_date": today},
            "review": {"reviewed_by": self._get_user_identity()},
            "rationale": {"summary": summary},
            "knowledgeType": "promotion_decision",
            "project": self.project,
            "date": today,
            "version": "1.0",
            "relationships": {
                "derives_from": [f"recommendation-{pattern_id}"],
                "influences": [],
                "evaluates": [pattern_id],
                "related_to": [],
            },
            "promotion_evidence": cand.get("promotion_evidence", []),
            "promotion_criteria_met": cand.get("promotion_criteria_met", []),
            "promotion_criteria_missing": [],
            "governance_risks": cand.get("governance_risks", []),
            "source_traceability": {
                "pattern_proposal": {"id": pattern_id},
                "scope_classification": {
                    "artifact_id": "pattern-scope-classification",
                    "classification": cand.get("scope_alignment", "global"),
                },
                "promotion_recommendation": {"id": f"recommendation-{pattern_id}"},
            },
            "governance": {
                "next_step": "adr_generation"
                if new_state == "accepted"
                else ("additional_evidence" if new_state == "deferred" else "closed")
            },
        }

        with open(decision_path, "w") as f:
            yaml.dump(decision_data, f, default_flow_style=False, sort_keys=False)

        print(
            f"[CAS][GOVERNANCE] Materialized promotion decision {decision_path.name} with status {new_state}"
        )
        return decision_path

    def update_artifact_state(
        self,
        artifact_id: str,
        artifact_type: str,
        new_state: str,
        rationale: str | None = None,
    ) -> bool:
        """Updates the state and relevant dates in the target artifact file."""
        path = self._find_artifact_path(artifact_id, artifact_type)
        if not path or not path.exists():
            if artifact_type == "promotion_decision":
                # Synthesize on demand from candidate recommendation
                synthesized = self._synthesize_promotion_decision(
                    artifact_id, new_state, rationale=rationale
                )
                if synthesized:
                    return True
            print(
                f"[CAS][WARN] Artifact file not found for update: {artifact_id} ({artifact_type})"
            )
            return False

        today = datetime.now(UTC).strftime("%Y-%m-%d")

        if artifact_type == "adr":
            clean_id = artifact_id.removeprefix("adr-")
            sync_key = f"adr-{clean_id}"
            # 1. Update manifest
            save_archgov_sync_record(
                self.project,
                sync_key,
                {
                    "status": new_state,
                    "artifact_path": f"knowledge/projects/{self.project}/adrs/{path.name}",
                },
                base_path=self.workspace_root,
            )
            # 2. Update frontmatter
            gov_meta: dict[str, Any] = {
                "forum_status": new_state,
                "forum_decision_date": today,
            }
            dec_meta: dict[str, Any] = {
                "status": new_state,
                "date": today,
                "decided_by": self._get_user_identity(),
            }
            if rationale:
                gov_meta["rationale"] = rationale
                dec_meta["rationale"] = (
                    {"summary": rationale} if isinstance(rationale, str) else rationale
                )
            update_adr_frontmatter(
                path,
                {
                    "governance": gov_meta,
                    "decision": dec_meta,
                },
            )
            print(
                f"[CAS][GOVERNANCE] Updated ADR {artifact_id} status to {new_state} in {path} and archgov-sync.yaml"
            )
            return True
        elif artifact_type == "promotion_decision":
            with open(path) as f:
                data = yaml.safe_load(f) or {}
            if "decision" not in data:
                data["decision"] = {}
            data["decision"]["status"] = new_state
            data["decision"]["decision_date"] = today
            if rationale and "rationale" in data:
                data["rationale"]["summary"] = rationale

            with open(path, "w") as f:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False)
            print(
                f"[CAS][GOVERNANCE] Updated promotion decision {artifact_id} status to {new_state} in {path}"
            )
            return True
        elif artifact_type == "governance_exception":
            with open(path) as f:
                data = yaml.safe_load(f) or {}
            data["status"] = new_state
            data["approval_date"] = today

            with open(path, "w") as f:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False)
            print(
                f"[CAS][GOVERNANCE] Updated governance exception {artifact_id} status to {new_state} in {path}"
            )
            return True
        elif artifact_type == "architecture_work":
            content = path.read_text()
            if content.startswith("---"):
                parts = content.split("---", 2)
                if len(parts) >= 3:
                    data = yaml.safe_load(parts[1]) or {}
                    data["status"] = new_state
                    new_yaml = yaml.dump(
                        data, default_flow_style=False, sort_keys=False
                    )
                    new_content = f"---\n{new_yaml}---{parts[2]}"
                    path.write_text(new_content)
                    print(
                        f"[CAS][GOVERNANCE] Updated Architecture Work {artifact_id} status to {new_state} in {path}"
                    )
                    return True
        elif artifact_type == "reference_arch":
            pattern_id = artifact_id.removeprefix("reference-architecture-")
            # 1. Update manifest
            save_archgov_sync_record(
                self.project,
                pattern_id,
                {
                    "status": new_state,
                    "artifact_path": f"knowledge/projects/{self.project}/reference-architectures/{path.name}",
                },
                base_path=self.workspace_root,
            )
            # 2. Update frontmatter
            gov_meta: dict[str, Any] = {
                "decision_date": today,
                "decided_by": self._get_user_identity(),
            }
            if rationale:
                gov_meta["rationale"] = rationale
            update_reference_architecture_frontmatter(
                path,
                {
                    "status": new_state,
                    "governance": gov_meta,
                },
            )
            print(
                f"[CAS][GOVERNANCE] Updated Reference Architecture {artifact_id} status to {new_state} in {path} and archgov-sync.yaml"
            )
            return True

        return False

    def sync_project_reviews(
        self,
        publisher: Any = None,
        dry_run: bool = False,
        no_chain: bool = False,
        provider: str | None = "stub",
        artifact_type_filter: str | None = "all",
    ) -> dict[str, Any]:
        """Queries external ArchGov for review updates on tracked reference architectures and ADRs

        and reconciles them into the local repository.
        """
        if publisher is None:
            from .publisher import ArchGovPublisher, load_archgov_config

            cfg = load_archgov_config(self.project, base_path=self.workspace_root)
            publisher = ArchGovPublisher(base_url=cfg.base_url, endpoints=cfg.endpoints)

        manifest = load_archgov_sync_manifest(
            self.project, base_path=self.workspace_root
        )
        records = manifest.get("records", {})

        stats = {
            "total_records": len(records),
            "synced": 0,
            "approved": 0,
            "rejected": 0,
            "deferred": 0,
            "unchanged": 0,
            "errors": 0,
            "chained_adrs": [],
            "chained_patterns": [],
        }

        now_iso = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        print(
            f"[CAS][INFO] Querying ArchGov at {publisher.base_url} for project '{self.project}'..."
        )

        for record_key, record in records.items():
            rec_type = record.get("artifact_type")
            if not rec_type:
                if str(record_key).startswith("adr-"):
                    rec_type = "adr"
                else:
                    rec_type = "reference_arch"

            if artifact_type_filter and artifact_type_filter != "all":
                if artifact_type_filter != rec_type:
                    continue

            art_id = record.get("archgov_artifact_id")
            if not art_id:
                stats["unchanged"] += 1
                continue

            try:
                # 1. Fetch remote reviews
                reviews = publisher.get_reviews(int(art_id), dry_run=dry_run)
                if not reviews or not isinstance(reviews, list):
                    stats["unchanged"] += 1
                    continue

                # Filter out error dicts
                valid_reviews = [
                    r for r in reviews if isinstance(r, dict) and "error" not in r
                ]
                if not valid_reviews:
                    stats["unchanged"] += 1
                    continue

                # Pick latest or matching review
                target_review = None
                rev_id = record.get("archgov_review_id")
                if rev_id:
                    for r in valid_reviews:
                        if r.get("id") == int(rev_id):
                            target_review = r
                            break
                if not target_review:
                    target_review = valid_reviews[0]

                remote_status = target_review.get("decision") or target_review.get(
                    "status"
                )
                reviewer = target_review.get("reviewer") or record.get("reviewer")
                notes = (
                    target_review.get("decision_notes")
                    or target_review.get("comment")
                    or target_review.get("notes")
                )

                # Map remote status to canonical CAS status
                if (
                    remote_status in ["pending", "pending_review", "submitted"]
                    or remote_status is None
                ):
                    mapped_status = "in_review"
                elif rec_type == "adr":
                    if remote_status == "approved":
                        mapped_status = "accepted"
                    elif remote_status == "rejected":
                        mapped_status = "rejected"
                    elif remote_status in [
                        "deferred",
                        "conditional",
                        "approved_with_conditions",
                    ]:
                        mapped_status = "conditional"
                    else:
                        mapped_status = remote_status
                else:
                    if remote_status in [
                        "deferred",
                        "conditional",
                        "approved_with_conditions",
                    ]:
                        mapped_status = "deferred"
                    else:
                        mapped_status = remote_status

                local_status = record.get(
                    "status", "draft" if rec_type == "reference_arch" else "in_review"
                )
                target_valid_states = (
                    ["accepted", "rejected", "conditional"]
                    if rec_type == "adr"
                    else ["approved", "rejected", "deferred"]
                )

                if (
                    mapped_status
                    and mapped_status != local_status
                    and mapped_status in target_valid_states
                ):
                    print(
                        f"[CAS][SYNC] {rec_type.upper()} '{record_key}' (Artifact {art_id}): {local_status} -> {mapped_status} (by {reviewer})"
                    )
                    if dry_run:
                        stats["synced"] += 1
                        if mapped_status in ["approved", "accepted"]:
                            stats["approved"] += 1
                        elif mapped_status == "rejected":
                            stats["rejected"] += 1
                        elif mapped_status in ["deferred", "conditional"]:
                            stats["deferred"] += 1
                        continue

                    # Execute state transition
                    if rec_type == "adr":
                        clean_id = record_key.removeprefix("adr-")
                        artifact_id = f"adr-{clean_id}"
                    else:
                        clean_id = record_key.removeprefix("reference-architecture-")
                        artifact_id = f"reference-architecture-{clean_id}"

                    action_type = (
                        "approve"
                        if mapped_status in ["approved", "accepted"]
                        else ("reject" if mapped_status == "rejected" else "defer")
                    )
                    self.execute_action(
                        artifact_id=artifact_id,
                        artifact_type=rec_type,
                        current_state=local_status,
                        action_type=action_type,
                        rationale=notes
                        or f"Synchronized from ArchGov review (by {reviewer})",
                    )
                    stats["synced"] += 1
                    if mapped_status in ["approved", "accepted"]:
                        stats["approved"] += 1
                    elif mapped_status == "rejected":
                        stats["rejected"] += 1
                    elif mapped_status in ["deferred", "conditional"]:
                        stats["deferred"] += 1

                    # Update record with remote details
                    save_archgov_sync_record(
                        self.project,
                        record_key,
                        {
                            "remote_status": remote_status,
                            "reviewer": reviewer,
                            "last_synced_at": now_iso,
                        },
                        base_path=self.workspace_root,
                    )

                    # Auto-chain downstream
                    if mapped_status in ["approved", "accepted"] and not no_chain:
                        if rec_type == "reference_arch":
                            clean_id = record_key.removeprefix("reference-architecture-")
                            adr_file = (
                                self.workspace_root
                                / "projects"
                                / self.project
                                / "adrs"
                                / f"adr-{clean_id}.md"
                            )
                            if not (
                                record.get("downstream_chained", False)
                                and adr_file.exists()
                            ):
                                chained = self.trigger_downstream_adr_chaining(
                                    record_key,
                                    rationale=notes,
                                    provider=provider,
                                )
                                if chained:
                                    stats["chained_adrs"].append(f"adr-{clean_id}")
                        elif rec_type == "adr":
                            clean_id = record_key.removeprefix("adr-")
                            if not (
                                record.get("downstream_chained", False)
                                and self._pattern_exists(clean_id)
                            ):
                                chained = self.trigger_downstream_pattern_chaining(
                                    record_key,
                                    rationale=notes,
                                    provider=provider,
                                )
                                if chained:
                                    stats["chained_patterns"].append(clean_id)
                else:
                    if not dry_run:
                        save_archgov_sync_record(
                            self.project,
                            record_key,
                            {
                                "remote_status": remote_status,
                                "last_synced_at": now_iso,
                            },
                            base_path=self.workspace_root,
                        )
                        # Check for self-healing unchained
                        if mapped_status in ["approved", "accepted"] and not no_chain:
                            if rec_type == "reference_arch":
                                clean_id = record_key.removeprefix(
                                    "reference-architecture-"
                                )
                                adr_file = (
                                    self.workspace_root
                                    / "projects"
                                    / self.project
                                    / "adrs"
                                    / f"adr-{clean_id}.md"
                                )
                                if not (
                                    record.get("downstream_chained", False)
                                    and adr_file.exists()
                                ):
                                    chained = self.trigger_downstream_adr_chaining(
                                        record_key,
                                        rationale=notes
                                        or "Auto-reconciled on sync for approved reference architecture",
                                        provider=provider,
                                    )
                                    if chained:
                                        stats["chained_adrs"].append(f"adr-{clean_id}")
                            elif rec_type == "adr":
                                clean_id = record_key.removeprefix("adr-")
                                if not (
                                    record.get("downstream_chained", False)
                                    and self._pattern_exists(clean_id)
                                ):
                                    chained = self.trigger_downstream_pattern_chaining(
                                        record_key,
                                        rationale=notes
                                        or "Auto-reconciled on sync for accepted ADR",
                                        provider=provider,
                                    )
                                    if chained:
                                        stats["chained_patterns"].append(clean_id)
                    stats["unchanged"] += 1
            except Exception as e:
                print(f"[CAS][WARNING] Sync failed for record {record_key}: {e}")
                stats["errors"] += 1

        print(
            f"[CAS][SUMMARY] Sync complete: {stats['approved']} approved, {stats['rejected']} rejected, "
            f"{stats['deferred']} deferred, {stats['unchanged']} unchanged."
        )
        return stats

    def trigger_downstream_adr_chaining(
        self,
        pattern_id: str,
        rationale: str | None = None,
        provider: str | None = "stub",
    ) -> bool:
        """Executes downstream ADR generation for an approved pattern.

        Synthesizes the accepted promotion decision if missing, runs promotion-to-decision-records flow,
        and verifies the resulting ADR file exists on disk before updating the sync record.
        """
        clean_id = pattern_id.removeprefix("reference-architecture-")
        adr_id = f"adr-{clean_id}"
        expected_adr_path = (
            self.workspace_root / "projects" / self.project / "adrs" / f"{adr_id}.md"
        )

        print(
            f"[CAS][CHAIN] Automatically invoking downstream ADR generation for approved pattern '{clean_id}'..."
        )

        # 1. Ensure promotion decision exists and is accepted
        dec_path = (
            self.workspace_root
            / "projects"
            / self.project
            / "governance"
            / "promotion-decisions"
            / f"promotion-decision-{clean_id}.yaml"
        )
        if not dec_path.exists():
            self._synthesize_promotion_decision(
                f"promotion-decision-{clean_id}", "accepted", rationale=rationale
            )
        else:
            try:
                with open(dec_path) as f:
                    dec_data = yaml.safe_load(f) or {}
                if dec_data.get("decision", {}).get("status") != "accepted":
                    self.update_artifact_state(
                        f"promotion-decision-{clean_id}",
                        "promotion_decision",
                        "accepted",
                        rationale=rationale,
                    )
            except Exception as e:
                print(f"[CAS][WARN] Could not verify promotion decision state: {e}")

        # 2. Run the promotion-to-decision-records flow
        try:
            from ..runner import FlowRunner

            runner = FlowRunner(
                project=self.project,
                provider=provider,
                target_pattern=clean_id,
                workspace_root=self.workspace_root,
            )
            runner.run("promotion-to-decision-records")
        except Exception as ex:
            print(f"[CAS][WARNING] Downstream ADR chaining flow failed: {ex}")
            save_archgov_sync_record(
                self.project,
                clean_id,
                {"downstream_chained": False},
                base_path=self.workspace_root,
            )
            return False

        # 3. Verify on disk that ADR was persisted
        if expected_adr_path.exists():
            save_archgov_sync_record(
                self.project,
                clean_id,
                {
                    "downstream_chained": True,
                    "downstream_adr_id": adr_id,
                },
                base_path=self.workspace_root,
            )
            print(
                f"[CAS][SUCCESS] ADR synthesized: knowledge/projects/{self.project}/adrs/{adr_id}.md"
            )

            # Auto-publish newly synthesized ADR to ArchGov for ARB review
            try:
                print(
                    f"[CAS][PUBLISH] Auto-publishing synthesized ADR '{adr_id}' to ArchGov for ARB review..."
                )
                self.publish_governance_artifact(
                    artifact_path=expected_adr_path,
                    artifact_type="adr",
                    review_type="arb",
                )
            except Exception as e:
                print(
                    f"[CAS][WARN] Failed to auto-publish ADR '{adr_id}' to ArchGov: {e}"
                )

            return True
        else:
            save_archgov_sync_record(
                self.project,
                clean_id,
                {"downstream_chained": False},
                base_path=self.workspace_root,
            )
            return False

    def trigger_downstream_pattern_chaining(
        self,
        pattern_id: str,
        rationale: str | None = None,
        provider: str | None = "stub",
    ) -> bool:
        """Executes downstream pattern institutionalization (approved-adr-to-pattern) for an accepted ADR.

        Runs approved-adr-to-pattern flow, verifies the pattern file exists under
        knowledge/global/patterns/<clean_id>.yaml (or .md), and updates the archgov-sync.yaml record.
        """
        clean_id = pattern_id.removeprefix("adr-")
        unprefixed_id = clean_id.removeprefix("pattern-")
        sync_key = f"adr-{clean_id}" if not pattern_id.startswith("adr-") else pattern_id
        candidates = [
            self.workspace_root / "global" / "patterns" / f"{clean_id}.yaml",
            self.workspace_root / "global" / "patterns" / f"{clean_id}.md",
            self.workspace_root / "global" / "patterns" / f"{unprefixed_id}.yaml",
            self.workspace_root / "global" / "patterns" / f"{unprefixed_id}.md",
        ]

        print(
            f"[CAS][CHAIN] Automatically invoking downstream pattern generation for accepted ADR '{clean_id}'..."
        )

        try:
            from ..runner import FlowRunner

            runner = FlowRunner(
                project=self.project, provider=provider, target_pattern=clean_id
            )
            runner.run("approved-adr-to-pattern")
        except Exception as ex:
            print(f"[CAS][WARNING] Downstream pattern chaining flow failed: {ex}")
            save_archgov_sync_record(
                self.project,
                sync_key,
                {"downstream_chained": False},
                base_path=self.workspace_root,
            )
            return False

        matched_path = next((p for p in candidates if p.exists()), None)
        if matched_path:
            save_archgov_sync_record(
                self.project,
                sync_key,
                {
                    "downstream_chained": True,
                    "downstream_pattern_id": matched_path.stem,
                },
                base_path=self.workspace_root,
            )
            print(
                f"[CAS][SUCCESS] Global pattern institutionalized: {matched_path}"
            )
            return True
        else:
            print(
                f"[CAS][WARNING] Downstream pattern chaining completed but pattern file was not found: {candidates[0]}"
            )
            save_archgov_sync_record(
                self.project,
                sync_key,
                {"downstream_chained": False},
                base_path=self.workspace_root,
            )
            return False

    def publish_governance_artifact(
        self,
        artifact_path: Path,
        artifact_type: str,
        review_type: str | None = None,
        reviewer: str | None = None,
        publisher: Any = None,
        dry_run: bool = False,
        force: bool = False,
        cli_overrides: dict[str, Any] | None = None,
        comment: str | None = None,
    ) -> dict[str, Any]:
        """Publishes a local governance artifact (ADR or Reference Architecture) to ArchGov and requests review."""
        with open(artifact_path, encoding="utf-8") as f:
            content = f.read()

        # Check existing frontmatter and manifest status
        fm = {}
        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                try:
                    fm = yaml.safe_load(parts[1]) or {}
                except Exception:
                    fm = {}

        current_status = fm.get("status")
        if artifact_type == "adr" and not current_status:
            current_status = fm.get("governance", {}).get("forum_status")

        if current_status in ["approved", "accepted"]:
            raise ValueError(
                f"Cannot publish artifact {artifact_path.name}: artifact is already {current_status}"
            )

        # Check existing manifest record
        manifest = load_archgov_sync_manifest(self.project, base_path=self.workspace_root)
        records = manifest.get("records", {})
        if artifact_type == "adr":
            clean_id = artifact_path.stem.removeprefix("adr-")
            sync_key = f"adr-{clean_id}"
        else:
            clean_id = artifact_path.stem.removeprefix("reference-architecture-")
            sync_key = clean_id

        rec = records.get(sync_key, {})
        existing_art_id = rec.get("archgov_artifact_id") or fm.get("governance", {}).get("archgov_artifact_id")
        existing_rev_id = rec.get("archgov_review_id") or fm.get("governance", {}).get("archgov_review_id")

        if (current_status == "in_review" or rec.get("status") == "in_review") and existing_art_id and not force:
            print(
                f"[CAS][INFO] Artifact {artifact_path.name} is already in_review (Artifact ID {existing_art_id}, Review ID {existing_rev_id}); skipping duplicate publication."
            )
            return {
                "archgov_artifact_id": existing_art_id,
                "archgov_review_id": existing_rev_id,
                "status": "in_review",
            }

        if publisher is None:
            from .publisher import ArchGovPublisher, load_archgov_config

            cfg = load_archgov_config(
                self.project,
                base_path=self.workspace_root,
                cli_overrides=cli_overrides,
            )
            publisher = ArchGovPublisher(base_url=cfg.base_url, endpoints=cfg.endpoints)
        else:
            from .publisher import load_archgov_config

            try:
                cfg = load_archgov_config(
                    self.project,
                    base_path=self.workspace_root,
                    cli_overrides=cli_overrides,
                )
            except Exception:
                # If custom publisher passed in tests without full config file
                from .publisher import DEFAULT_CANONICAL_ENDPOINTS, ArchGovConfig
                cfg = ArchGovConfig(base_url="http://archgov.test.net", default_owner="test@example.com", endpoints=DEFAULT_CANONICAL_ENDPOINTS)

        title = artifact_path.stem
        for line in content.splitlines():
            if line.startswith("# "):
                title = line.lstrip("# ").strip()
                break

        if artifact_type == "adr":
            resolved_review_type = review_type or "arb"
            resolved_reviewer = (
                reviewer
                or cfg.arb_reviewer
                or cfg.default_owner
                or "alexandre.franco@mostelli.com"
            )
        elif artifact_type == "reference_arch":
            resolved_review_type = review_type or "design_authority"
            resolved_reviewer = (
                reviewer
                or cfg.default_owner
                or "alexandre.franco@mostelli.com"
            )
        else:
            resolved_review_type = review_type or "design_authority"
            resolved_reviewer = (
                reviewer
                or cfg.default_owner
                or "alexandre.franco@mostelli.com"
            )

        art_res = publisher.publish_artifact(
            title=title,
            artifact_type=artifact_type,
            content=content,
            owner=cfg.default_owner,
            created_by=cfg.default_owner,
            domain_id=cfg.domain_id,
            initiative_id=cfg.initiative_id,
            dry_run=dry_run or cfg.dry_run,
        )
        if "error" in art_res:
            raise RuntimeError(f"Failed to publish artifact: {art_res['error']}")

        art_id = art_res.get("id")

        rev_res = publisher.request_review(
            artifact_id=art_id,
            review_type=resolved_review_type,
            reviewer=resolved_reviewer,
            comment=comment or f"Submitted via CAS for project {self.project}",
            dry_run=dry_run or cfg.dry_run,
        )
        if "error" in rev_res:
            raise RuntimeError(f"Failed to request review: {rev_res['error']}")

        rev_id = rev_res.get("id")

        if not (dry_run or cfg.dry_run):
            if artifact_type == "adr":
                clean_id = artifact_path.stem.removeprefix("adr-")
                sync_key = f"adr-{clean_id}"
                rel_path = f"knowledge/projects/{self.project}/adrs/{artifact_path.name}"
                save_archgov_sync_record(
                    self.project,
                    sync_key,
                    {
                        "artifact_id": sync_key,
                        "artifact_type": "adr",
                        "pattern_id": clean_id,
                        "artifact_path": rel_path,
                        "archgov_artifact_id": art_id,
                        "archgov_review_id": rev_id,
                        "review_type": resolved_review_type,
                        "reviewer": resolved_reviewer,
                        "status": "in_review",
                        "remote_status": "in_review",
                    },
                    base_path=self.workspace_root,
                )
                try:
                    update_adr_frontmatter(
                        artifact_path,
                        {
                            "governance": {
                                "archgov_artifact_id": art_id,
                                "archgov_review_id": rev_id,
                                "review_type": resolved_review_type,
                                "reviewer": resolved_reviewer,
                                "forum_status": "in_review",
                            }
                        },
                    )
                except Exception:
                    pass
            elif artifact_type == "reference_arch":
                clean_id = artifact_path.stem.removeprefix("reference-architecture-")
                rel_path = f"knowledge/projects/{self.project}/reference-architectures/{artifact_path.name}"
                save_archgov_sync_record(
                    self.project,
                    clean_id,
                    {
                        "artifact_path": rel_path,
                        "archgov_artifact_id": art_id,
                        "archgov_review_id": rev_id,
                        "review_type": resolved_review_type,
                        "reviewer": resolved_reviewer,
                        "status": "in_review",
                        "remote_status": "in_review",
                    },
                    base_path=self.workspace_root,
                )
                try:
                    update_reference_architecture_frontmatter(
                        artifact_path,
                        {
                            "status": "in_review",
                            "governance": {
                                "archgov_artifact_id": art_id,
                                "archgov_review_id": rev_id,
                                "review_type": resolved_review_type,
                                "reviewer": resolved_reviewer,
                            },
                        },
                    )
                except Exception:
                    pass

        return {
            "archgov_artifact_id": art_id,
            "archgov_review_id": rev_id,
            "status": "in_review",
        }

    def publish_all_unpublished(
        self,
        artifact_type: str = "adr",
        review_type: str | None = None,
        reviewer: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Discovers and publishes all unpublished local governance artifacts of a given type."""
        manifest = load_archgov_sync_manifest(self.project, base_path=self.workspace_root)
        records = manifest.get("records", {})

        stats: dict[str, Any] = {
            "total_candidates": 0,
            "already_tracked": 0,
            "published": 0,
            "errors": [],
        }

        if artifact_type == "adr":
            target_dir = self.workspace_root / "projects" / self.project / "adrs"
            pattern_glob = "adr-*.md"
        elif artifact_type == "reference_arch":
            target_dir = (
                self.workspace_root
                / "projects"
                / self.project
                / "reference-architectures"
            )
            pattern_glob = "reference-architecture-*.md"
        else:
            raise ValueError(
                f"Unsupported artifact type for batch publish: {artifact_type}"
            )

        if not target_dir.exists():
            return stats

        candidate_files = sorted(target_dir.glob(pattern_glob))
        stats["total_candidates"] = len(candidate_files)

        for fpath in candidate_files:
            clean_id = fpath.stem
            if artifact_type == "adr":
                clean_id = clean_id.removeprefix("adr-")
                sync_key = f"adr-{clean_id}"
            else:
                clean_id = clean_id.removeprefix("reference-architecture-")
                sync_key = clean_id

            rec = records.get(sync_key)
            if rec and rec.get("archgov_artifact_id"):
                stats["already_tracked"] += 1
                continue

            try:
                res = self.publish_governance_artifact(
                    artifact_path=fpath,
                    artifact_type=artifact_type,
                    review_type=review_type,
                    reviewer=reviewer,
                    dry_run=dry_run,
                )
                stats["published"] += 1
                print(
                    f"[CAS][PUBLISH] Published {sync_key} (Artifact {res.get('archgov_artifact_id')})"
                )
            except Exception as e:
                print(f"[CAS][ERROR] Failed publishing {sync_key}: {e}")
                stats["errors"].append({"artifact": sync_key, "error": str(e)})

        return stats
