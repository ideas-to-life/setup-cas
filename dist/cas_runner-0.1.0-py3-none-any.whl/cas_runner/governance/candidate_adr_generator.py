"""Candidate ADR Generator for Path B Architectural Novelty.

Scaffolds a machine-readable Architecture Decision Record (ADR) conforming to the
authoritative CAS ADR schema (architecture_decision_record_schema.json) and template.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime
from pathlib import Path

import yaml


def generate_candidate_adr(
    target_dir: Path,
    project: str,
    novel_element: str,
    slug: str | None = None,
) -> Path:
    """Scaffolds a candidate ADR in knowledge/projects/<project>/adrs/."""
    today = datetime.now(UTC).strftime("%Y-%m-%d")
    clean_slug = re.sub(r"[^a-zA-Z0-9_-]", "-", (slug or novel_element).lower()).strip(
        "-"
    )
    adr_id = f"adr-{project}-{today}-{clean_slug}"

    adrs_dir = target_dir / "knowledge" / "projects" / project / "adrs"
    adrs_dir.mkdir(parents=True, exist_ok=True)
    target_file = adrs_dir / f"{adr_id}.md"

    frontmatter = {
        "id": adr_id,
        "knowledgeType": "architecture_decision_record",
        "project": project,
        "date": today,
        "version": 1,
        "decision_scope": "pattern",
        "decision_target": novel_element,
        "decision": {
            "type": "creation",
            "status": "proposed",
            "decided_by": "system",
            "date": today,
            "rationale": {
                "summary": f"Plan proposes introducing net-new pattern or unmapped dependency: {novel_element}."
            },
            "evidence": {"strength": "medium"},
            "confidence": "medium",
        },
        "classification": "project",
        "governance": {
            "forum_status": "pending",
            "forum_decision_date": None,
        },
        "related": {
            "patterns": [novel_element],
            "architecture_work": [],
            "findings": [],
            "promotion_decisions": [],
            "promotion_recommendations": [],
        },
        "sections": {
            "context_and_problem": f"Implementation plan proposes components not covered by ratified patterns in patterns-catalogue.yaml: {novel_element}.",
            "decision_drivers": [
                "Modifiability impact",
                "Dependency security and isolation",
            ],
            "considered_options": [
                f"Ratify '{novel_element}' into patterns-catalogue.yaml (Path B)",
                "Re-architect plan to reuse existing approved patterns (Path A)",
                "Grant temporary architectural exception with compensating controls (Path C)",
            ],
        },
    }

    yaml_str = yaml.safe_dump(frontmatter, sort_keys=False, default_flow_style=False)
    body = f"""---
{yaml_str}---

# Architecture Decision Record: {novel_element}

## Context & Problem Statement
The implementation plan proposes components or dependencies not covered by ratified patterns in `patterns-catalogue.yaml`: **{novel_element}**.

## Decision Drivers & ATAM Quality Attributes
- Modifiability impact
- Dependency security & licensing

## Considered Options
1. Ratify novel pattern and institutionalize into `patterns-catalogue.yaml`.
2. Re-architect plan to reuse existing approved patterns (Path A).
3. Grant temporary architectural exception (Path C).
"""
    target_file.write_text(body, encoding="utf-8")
    return target_file
