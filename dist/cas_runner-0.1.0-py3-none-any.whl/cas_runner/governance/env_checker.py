"""Pre-flight Environment & Onboarding Configuration Diagnostics (`cas governance check-env`).

Inspects local developer and CI runner environments against the standardized CAS
onboarded project configuration matrix (`CAS-REQ-SPEC-UNIVERSAL-DISTRIBUTION-001`),
reporting [OK], [WARN], and [MISSING] badges and remediation links without ever
exposing or logging raw secret values (NFR-SEC-001).
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml


def resolve_github_repo_slug(target_dir: Path | str = ".") -> str:
    """Resolves '<owner>/<repo>' from GITHUB_REPOSITORY env var or git remote origin."""
    env_repo = os.getenv("GITHUB_REPOSITORY", "").strip()
    if env_repo and "/" in env_repo:
        return env_repo

    target_path = Path(target_dir).resolve()
    try:
        res = subprocess.run(
            ["git", "config", "--get", "remote.origin.url"],
            cwd=target_path,
            capture_output=True,
            text=True,
            check=False,
        )
        if res.returncode == 0 and res.stdout.strip():
            url = res.stdout.strip()
            # Match https://github.com/owner/repo(.git) or git@github.com:owner/repo(.git)
            match = re.search(r"github\.com[:/]([^/]+/[^/\s]+?)(?:\.git)?$", url)
            if match:
                return match.group(1)
    except Exception:
        pass

    return f"<owner>/{target_path.name}"


@dataclass
class EnvCheckItem:
    """Represents a single environment variable or secret diagnostic check."""

    category: str  # identity | knowledge | llm | telemetry | security
    kind: str  # variable | secret
    name: str
    status: str  # OK | WARN | MISSING
    required: bool
    detail: str
    remediation: str = ""


@dataclass
class EnvCheckReport:
    """Structured pre-flight environment diagnostic report."""

    target_dir: str
    project_id: str
    github_repo: str
    secrets_settings_url: str
    variables_settings_url: str
    ready_for_deterministic_governance: bool
    ready_for_continuous_loop: bool
    items: list[EnvCheckItem] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

    def to_text(self) -> str:
        lines: list[str] = [
            "=== CAS Pre-Flight Environment Diagnostics (check-env) ===",
            f"Target Directory : {self.target_dir}",
            f"Resolved Project : {self.project_id}",
            f"GitHub Repository: {self.github_repo}",
            "",
        ]

        categories = [
            ("identity", "1. Project Identity & Knowledge Target"),
            ("knowledge", "2. Central Knowledge Persistence (cas-brain/knowledge)"),
            ("llm", "3. LLM Provider & Reasoning Configuration"),
            ("telemetry", "4. OpenTelemetry & Observability Configuration"),
            ("security", "5. Security & Portal Token Boundary (INV-SEC-001)"),
        ]

        for cat_key, cat_title in categories:
            cat_items = [i for i in self.items if i.category == cat_key]
            if not cat_items:
                continue
            lines.append(cat_title)
            for item in cat_items:
                badge = f"[{item.status}]"
                lines.append(
                    f"  {badge:<9} {item.name:<28} ({item.kind}) -> {item.detail}"
                )
                if item.remediation and item.status in ("MISSING", "WARN"):
                    lines.append(f"            Remediation: {item.remediation}")
            lines.append("")

        det_badge = "[OK]" if self.ready_for_deterministic_governance else "[WARN]"
        loop_badge = "[OK]" if self.ready_for_continuous_loop else "[WARN]"
        lines.append("Summary Readiness:")
        lines.append(
            f"  {det_badge} Deterministic Governance (lint, verify-diff, check-bands, skills eval): READY"
        )
        if self.ready_for_continuous_loop:
            lines.append(
                f"  {loop_badge} Continuous Architecture Loop & Knowledge Sync: READY"
            )
        else:
            lines.append(
                f"  {loop_badge} Continuous Architecture Loop & Knowledge Sync: DEGRADED (Advisory/Local-Only Mode)"
            )
            lines.append(f"       Configure secrets at  : {self.secrets_settings_url}")
            lines.append(
                f"       Configure variables at: {self.variables_settings_url}"
            )

        return "\n".join(lines)


class EnvironmentChecker:
    """Inspects local and CI environment variables/secrets without leaking secret values."""

    def __init__(self, target_dir: Path | str = ".") -> None:
        self.target_path = Path(target_dir).resolve()

    def _load_cas_config_project(self) -> str | None:
        cfg_file = self.target_path / "cas-config.yaml"
        if cfg_file.is_file():
            try:
                data = yaml.safe_load(cfg_file.read_text(encoding="utf-8"))
                if isinstance(data, dict) and data.get("project"):
                    return str(data["project"])
            except Exception:
                pass
        return None

    def check(self) -> EnvCheckReport:
        github_repo = resolve_github_repo_slug(self.target_path)
        secrets_url = f"https://github.com/{github_repo}/settings/secrets/actions"
        variables_url = f"https://github.com/{github_repo}/settings/variables/actions"

        env_project = os.getenv("CAS_PROJECT", "").strip()
        cfg_project = self._load_cas_config_project()
        resolved_project = env_project or cfg_project or self.target_path.name

        items: list[EnvCheckItem] = []

        # 1. Project Identity & Knowledge Target Variables
        if env_project:
            items.append(
                EnvCheckItem(
                    category="identity",
                    kind="variable",
                    name="CAS_PROJECT",
                    status="OK",
                    required=False,
                    detail=f"Configured via environment ('{env_project}')",
                )
            )
        elif cfg_project:
            items.append(
                EnvCheckItem(
                    category="identity",
                    kind="variable",
                    name="CAS_PROJECT",
                    status="OK",
                    required=False,
                    detail=f"Resolved from cas-config.yaml ('{cfg_project}')",
                )
            )
        else:
            items.append(
                EnvCheckItem(
                    category="identity",
                    kind="variable",
                    name="CAS_PROJECT",
                    status="WARN",
                    required=False,
                    detail=f"Not explicitly set; defaulting to repository name ('{resolved_project}')",
                    remediation=f"Set repository variable CAS_PROJECT at {variables_url}",
                )
            )

        knowledge_repo = os.getenv("KNOWLEDGE_REPO_NAME", "").strip()
        if knowledge_repo:
            items.append(
                EnvCheckItem(
                    category="identity",
                    kind="variable",
                    name="KNOWLEDGE_REPO_NAME",
                    status="OK",
                    required=False,
                    detail=f"Configured ('{knowledge_repo}')",
                )
            )
        else:
            items.append(
                EnvCheckItem(
                    category="identity",
                    kind="variable",
                    name="KNOWLEDGE_REPO_NAME",
                    status="OK",
                    required=False,
                    detail="Using default ('cas-brain/knowledge')",
                )
            )

        # 2. Knowledge Repository Authentication (INV-COMPAT-001: CAS_KNOWLEDGE_BRAIN || CAS_KNOWLEDGE_TOKEN)
        has_brain_token = bool(os.getenv("CAS_KNOWLEDGE_BRAIN", "").strip())
        has_legacy_token = bool(os.getenv("CAS_KNOWLEDGE_TOKEN", "").strip())
        local_knowledge_dir = (
            (self.target_path / "knowledge").exists()
            or (self.target_path / "cas-knowledge").exists()
            or bool(os.getenv("CAS_KNOWLEDGE_WORKSPACE", "").strip())
        )

        if has_brain_token:
            items.append(
                EnvCheckItem(
                    category="knowledge",
                    kind="secret",
                    name="CAS_KNOWLEDGE_BRAIN",
                    status="OK",
                    required=True,
                    detail="Present (masked, read/write access to cas-brain/knowledge)",
                )
            )
        elif has_legacy_token:
            items.append(
                EnvCheckItem(
                    category="knowledge",
                    kind="secret",
                    name="CAS_KNOWLEDGE_BRAIN",
                    status="WARN",
                    required=True,
                    detail="Using legacy fallback secret CAS_KNOWLEDGE_TOKEN (INV-COMPAT-001)",
                    remediation=f"Migrate secret name from CAS_KNOWLEDGE_TOKEN to CAS_KNOWLEDGE_BRAIN at {secrets_url}",
                )
            )
        else:
            items.append(
                EnvCheckItem(
                    category="knowledge",
                    kind="secret",
                    name="CAS_KNOWLEDGE_BRAIN",
                    status="MISSING",
                    required=True,
                    detail=(
                        "Not configured (local knowledge directory detected)"
                        if local_knowledge_dir
                        else "Not configured; remote cas-brain/knowledge sync disabled"
                    ),
                    remediation=f"Add fine-grained PAT secret CAS_KNOWLEDGE_BRAIN with write access to cas-brain/knowledge at {secrets_url}",
                )
            )

        # 3. LLM Provider Configuration & Secrets
        provider = os.getenv("CAS_DEFAULT_PROVIDER", "").strip() or "openai"
        model = os.getenv("CAS_DEFAULT_MODEL", "").strip() or "gpt-6.1-sol"
        max_tokens = os.getenv("CAS_MAX_TOKENS", "").strip() or "10000"
        temperature = os.getenv("CAS_TEMPERATURE", "").strip() or "1.0"

        items.append(
            EnvCheckItem(
                category="llm",
                kind="variable",
                name="CAS_DEFAULT_PROVIDER",
                status="OK",
                required=False,
                detail=f"Active provider: '{provider}' (model: '{model}', max_tokens: {max_tokens}, temp: {temperature})",
            )
        )

        has_openai = bool(os.getenv("OPENAI_API_KEY", "").strip())
        has_gemini = bool(os.getenv("GEMINI_API_KEY", "").strip())
        has_hf = bool(os.getenv("HF_TOKEN", "").strip())

        if has_openai:
            items.append(
                EnvCheckItem(
                    category="llm",
                    kind="secret",
                    name="OPENAI_API_KEY",
                    status="OK",
                    required=(provider == "openai"),
                    detail="Present (masked)",
                )
            )
        else:
            items.append(
                EnvCheckItem(
                    category="llm",
                    kind="secret",
                    name="OPENAI_API_KEY",
                    status="MISSING"
                    if provider == "openai" and not (has_gemini or has_hf)
                    else "WARN",
                    required=(provider == "openai"),
                    detail="Not configured",
                    remediation=f"Add secret OPENAI_API_KEY at {secrets_url} if using OpenAI models",
                )
            )

        if has_gemini:
            items.append(
                EnvCheckItem(
                    category="llm",
                    kind="secret",
                    name="GEMINI_API_KEY",
                    status="OK",
                    required=(provider == "gemini"),
                    detail="Present (masked)",
                )
            )
        else:
            items.append(
                EnvCheckItem(
                    category="llm",
                    kind="secret",
                    name="GEMINI_API_KEY",
                    status="MISSING" if provider == "gemini" else "WARN",
                    required=(provider == "gemini"),
                    detail="Not configured (optional unless provider is gemini)",
                    remediation=f"Add secret GEMINI_API_KEY at {secrets_url} if using Gemini models",
                )
            )

        if has_hf:
            items.append(
                EnvCheckItem(
                    category="llm",
                    kind="secret",
                    name="HF_TOKEN",
                    status="OK",
                    required=False,
                    detail="Present (masked)",
                )
            )
        else:
            items.append(
                EnvCheckItem(
                    category="llm",
                    kind="secret",
                    name="HF_TOKEN",
                    status="WARN",
                    required=False,
                    detail="Not configured (optional for Hugging Face embeddings/models)",
                    remediation=f"Add secret HF_TOKEN at {secrets_url} for Hugging Face Hub access",
                )
            )

        # 4. Telemetry Configuration
        otel_enabled = os.getenv("COPILOT_OTEL_ENABLED", "").strip().lower() == "true"
        otel_endpoint = os.getenv("COPILOT_OTEL_ENDPOINT", "").strip()
        has_otel_headers = bool(os.getenv("OTEL_EXPORTER_OTLP_HEADERS", "").strip())

        if otel_enabled:
            otel_status = "OK" if otel_endpoint else "WARN"
            items.append(
                EnvCheckItem(
                    category="telemetry",
                    kind="variable",
                    name="COPILOT_OTEL_ENABLED",
                    status=otel_status,
                    required=False,
                    detail=(
                        f"Enabled (endpoint: {otel_endpoint}, headers: {'present' if has_otel_headers else 'not set'})"
                        if otel_endpoint
                        else "Enabled, but COPILOT_OTEL_ENDPOINT is not set"
                    ),
                    remediation=(
                        ""
                        if otel_endpoint
                        else f"Configure COPILOT_OTEL_ENDPOINT variable at {variables_url}"
                    ),
                )
            )
        else:
            items.append(
                EnvCheckItem(
                    category="telemetry",
                    kind="variable",
                    name="COPILOT_OTEL_ENABLED",
                    status="OK",
                    required=False,
                    detail="Disabled (optional)",
                )
            )

        # 5. Security Boundary Check (INV-SEC-001: Zero Deployment Token Proliferation)
        is_engine_repo = (self.target_path / "pyproject.toml").exists() and (
            self.target_path / "src" / "cas_runner"
        ).exists()
        has_portal_token = bool(os.getenv("CAS_PORTAL_TOKEN", "").strip())
        if has_portal_token and not is_engine_repo:
            items.append(
                EnvCheckItem(
                    category="security",
                    kind="secret",
                    name="CAS_PORTAL_TOKEN",
                    status="WARN",
                    required=False,
                    detail="INV-SEC-001 violation: Client repositories must not store CAS_PORTAL_TOKEN",
                    remediation=(
                        f"Remove CAS_PORTAL_TOKEN from {secrets_url}; portal deployment is handled centrally via cas-brain/knowledge."
                    ),
                )
            )
        else:
            items.append(
                EnvCheckItem(
                    category="security",
                    kind="secret",
                    name="CAS_PORTAL_TOKEN",
                    status="OK",
                    required=False,
                    detail="Compliant with INV-SEC-001 (centralized portal publishing)",
                )
            )

        has_any_llm_key = has_openai or has_gemini or has_hf or provider == "stub"
        ready_for_loop = (has_brain_token or has_legacy_token) and has_any_llm_key

        return EnvCheckReport(
            target_dir=str(self.target_path),
            project_id=resolved_project,
            github_repo=github_repo,
            secrets_settings_url=secrets_url,
            variables_settings_url=variables_url,
            ready_for_deterministic_governance=True,
            ready_for_continuous_loop=ready_for_loop,
            items=items,
        )
