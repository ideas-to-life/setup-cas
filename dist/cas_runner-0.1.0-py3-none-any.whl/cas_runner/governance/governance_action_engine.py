from ..io import get_workspace_root


class TransitionRegistry:
    """
    Declarative registry of valid state transitions for governance artifacts.
    Structure: { artifact_type: { current_state: { action_type: new_state } } }
    """
    def __init__(self):
        self.transitions = {
            "promotion_decision": {
                "pending": {
                    "approve": "accepted",
                    "reject": "rejected",
                    "defer": "deferred"
                },
                "deferred": {
                    "reopen": "pending"
                }
            },
            "adr": {
                "pending": {
                    "approve": "accepted",
                    "reject": "rejected",
                    "defer": "conditional",
                },
                "in_review": {
                    "approve": "accepted",
                    "reject": "rejected",
                    "defer": "conditional",
                },
                "proposed": {
                    "approve": "accepted",
                    "reject": "rejected",
                    "defer": "conditional",
                },
                "draft": {
                    "approve": "accepted",
                    "reject": "rejected",
                    "defer": "conditional",
                },
                "conditional": {
                    "reopen": "in_review",
                },
                "deferred": {
                    "reopen": "in_review",
                },
            },
            "governance_exception": {
                "active": {
                    "expire": "expired",
                    "reject": "revoked"
                }
            },
            "architecture_work": {
                "proposed": {
                    "approve": "active",
                    "reject": "retired",
                    "defer": "deferred"
                },
                "accepted": {
                    "approve": "active",
                    "reject": "retired"
                },
                "active": {
                    "approve": "done",
                    "reject": "retired",
                    "defer": "deferred"
                },
                "done": {
                    "reopen": "active"
                },
                "deferred": {
                    "reopen": "proposed"
                }
            },
            "reference_arch": {
                "draft": {
                    "approve": "approved",
                    "reject": "rejected",
                    "defer": "deferred",
                },
                "in_review": {
                    "approve": "approved",
                    "reject": "rejected",
                    "defer": "deferred",
                },
                "submitted": {
                    "approve": "approved",
                    "reject": "rejected",
                    "defer": "deferred",
                },
                "deferred": {
                    "reopen": "draft",
                },
            },
        }

    def get_new_state(self, artifact_type: str, current_state: str, action_type: str) -> str | None:
        """Returns the new state if the transition is valid, else None."""
        return self.transitions.get(artifact_type, {}).get(current_state, {}).get(action_type)


class GovernanceActionEngine:
    """
    Handles governance state transitions and audit trails.
    """
    def __init__(self, project: str):
        self.project = project
        self.workspace_root = get_workspace_root()
        self.registry = TransitionRegistry()

    def _apply_transition(self, artifact_type: str, current_state: str, action_type: str) -> str:
        """Determines the next state based on the registry."""
        new_state = self.registry.get_new_state(artifact_type, current_state, action_type)
        if not new_state:
            raise ValueError(f"Invalid transition for {artifact_type}: {current_state} --({action_type})--> ?")
        return new_state
