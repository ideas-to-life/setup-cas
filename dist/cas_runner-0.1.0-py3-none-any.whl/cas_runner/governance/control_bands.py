"""Statistical Control Bands (Stage 6: Maintain -> Closed-Loop Feedback).

Evaluates architecture & delivery telemetry (`martin_distance_d`, `lint_violations`,
`rework_rate`) against Western Electric control bands (`.cas/bands.yaml`):
- 1sigma -> log
- 2sigma -> diagnose
- 3sigma -> propose (auto-drafts a provenance-anchored Stage 1 `intent.md`)
"""

from __future__ import annotations

import ast
import json
import re
import subprocess
from pathlib import Path
from typing import Any

import jsonschema
import yaml

from cas_runner.governance.architecture_linter import ArchitectureLinter
from cas_runner.governance.intent_verifier import IntentVerifier
from cas_runner.governance.models import (
    BandEvaluationResult,
    ControlBandSpec,
    ControlBandsReport,
    ControlBandTier,
    PackageCouplingMetrics,
)
from cas_runner.governance.sdlc_profile import SDLCProfileResolver

BAND_SEVERITY_ORDER: dict[str, int] = {
    "ok": 0,
    "1sigma": 1,
    "2sigma": 2,
    "3sigma": 3,
}

DEFAULT_BANDS_CONFIG: dict[str, Any] = {
    "version": "1.0",
    "baseline": "rolling_30d",
    "rules": "western_electric",
    "metrics": {
        "martin_distance_d": {
            "description": "Maximum Normalized Distance from Main Sequence D = |A + I - 1| across coupled packages",
            "baseline": "rolling_30d",
            "rules": "western_electric",
            "tiers": {
                "1sigma": {"threshold": 0.50, "action": "log"},
                "2sigma": {
                    "threshold": 0.70,
                    "action": "diagnose",
                    "tools": "Read,Grep,Glob",
                },
                "3sigma": {
                    "threshold": 0.85,
                    "action": "propose",
                    "routes": ["intent.md", "pull_request"],
                },
            },
        },
        "lint_violations": {
            "description": "Deterministic architecture and anti-pattern linter violations (ARCH-LINT-001..004)",
            "baseline": "rolling_30d",
            "rules": "western_electric",
            "tiers": {
                "1sigma": {"threshold": 1, "action": "log"},
                "2sigma": {
                    "threshold": 3,
                    "action": "diagnose",
                    "tools": "Read,Grep,Bash(uv run cas governance lint)",
                },
                "3sigma": {
                    "threshold": 5,
                    "action": "propose",
                    "routes": ["intent.md", "pull_request"],
                },
            },
        },
        "rework_rate": {
            "description": "Post-implementation architectural rework rate percentage across recent commits",
            "baseline": "rolling_30d",
            "rules": "western_electric",
            "tiers": {
                "1sigma": {"threshold": 5.0, "action": "log"},
                "2sigma": {
                    "threshold": 10.0,
                    "action": "diagnose",
                    "tools": "Read,Grep,Bash(git log -n 50 --oneline)",
                },
                "3sigma": {
                    "threshold": 15.0,
                    "action": "propose",
                    "routes": ["intent.md", "pull_request"],
                },
            },
        },
    },
}


def render_bands_yaml() -> str:
    """Return the default `.cas/bands.yaml` substrate content."""
    substrate_path = (
        Path(__file__).resolve().parents[1]
        / "templates"
        / "onboarding"
        / "substrate"
        / ".cas"
        / "bands.yaml"
    )
    if substrate_path.is_file():
        return substrate_path.read_text(encoding="utf-8")
    return yaml.safe_dump(DEFAULT_BANDS_CONFIG, sort_keys=False)


def load_bands_schema() -> dict[str, Any]:
    """Load the JSON Schema for `.cas/bands.yaml`."""
    schema_path = (
        Path(__file__).resolve().parents[1] / "schemas" / "control-bands.schema.json"
    )
    return json.loads(schema_path.read_text(encoding="utf-8"))


def _slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or "architecture-control-bands"


def _first_valid_statement_line(py_file: Path) -> int:
    """Return the 1-based line number of the first AST statement in `py_file`."""
    try:
        tree = ast.parse(py_file.read_text(encoding="utf-8"))
        for node in tree.body:
            if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                return node.lineno
        if tree.body:
            return tree.body[0].lineno
    except Exception:
        pass
    return 1


def _resolve_tier_spec(
    tiers_cfg: dict[str, Any],
    metric_name: str,
    tier_key: str,
    sigma_mult: int,
    default_action: str,
    mean: float | None,
    std_dev: float | None,
) -> ControlBandTier:
    t_raw = tiers_cfg.get(tier_key, {})
    if "threshold" in t_raw and t_raw["threshold"] is not None:
        thresh_val = float(t_raw["threshold"])
    elif mean is not None and std_dev is not None:
        thresh_val = round(mean + sigma_mult * std_dev, 4)
    else:
        default_metric = DEFAULT_BANDS_CONFIG["metrics"].get(metric_name, {})
        thresh_val = float(
            default_metric.get("tiers", {})
            .get(tier_key, {})
            .get("threshold", float(sigma_mult))
        )
    action = str(t_raw.get("action", default_action))
    return ControlBandTier(
        threshold=thresh_val,
        action=action,
        tools=t_raw.get("tools"),
        routes=list(t_raw.get("routes", [])),
    )


class ControlBandsEngine:
    """Evaluates repository telemetry against `.cas/bands.yaml` statistical control bands."""

    def __init__(
        self,
        target_dir: Path,
        sdlc_profile: str | None = None,
        metric_overrides: dict[str, float] | None = None,
    ) -> None:
        self.target_dir = target_dir.resolve()
        self.sdlc_profile = sdlc_profile
        self.metric_overrides = dict(metric_overrides or {})

    def load_config(self) -> tuple[dict[str, ControlBandSpec], str]:
        """Load and validate `.cas/bands.yaml` (or default config if absent)."""
        bands_path = self.target_dir / ".cas" / "bands.yaml"
        if bands_path.is_file():
            raw = yaml.safe_load(bands_path.read_text(encoding="utf-8")) or {}
            config_rel = ".cas/bands.yaml"
        else:
            raw = DEFAULT_BANDS_CONFIG
            config_rel = ".cas/bands.yaml (default)"

        schema = load_bands_schema()
        jsonschema.validate(instance=raw, schema=schema)

        specs: dict[str, ControlBandSpec] = {}
        for metric_name, m_cfg in raw.get("metrics", {}).items():
            mean = (
                float(m_cfg["mean"])
                if "mean" in m_cfg and m_cfg["mean"] is not None
                else None
            )
            std_dev = (
                float(m_cfg["std_dev"])
                if "std_dev" in m_cfg and m_cfg["std_dev"] is not None
                else None
            )
            tiers_cfg = m_cfg.get("tiers", {})

            specs[metric_name] = ControlBandSpec(
                metric=metric_name,
                description=str(m_cfg.get("description", "")),
                baseline=str(m_cfg.get("baseline", raw.get("baseline", "rolling_30d"))),
                rules=str(m_cfg.get("rules", raw.get("rules", "western_electric"))),
                mean=mean,
                std_dev=std_dev,
                tiers={
                    "1sigma": _resolve_tier_spec(
                        tiers_cfg, metric_name, "1sigma", 1, "log", mean, std_dev
                    ),
                    "2sigma": _resolve_tier_spec(
                        tiers_cfg, metric_name, "2sigma", 2, "diagnose", mean, std_dev
                    ),
                    "3sigma": _resolve_tier_spec(
                        tiers_cfg, metric_name, "3sigma", 3, "propose", mean, std_dev
                    ),
                },
            )

        return specs, config_rel

    def _collect_package_metrics(self) -> list[PackageCouplingMetrics]:
        from cas_runner.steps.forensic.extractor import compute_package_coupling_metrics

        raw_list = compute_package_coupling_metrics(self.target_dir)
        return [
            PackageCouplingMetrics(
                package=str(item["package"]),
                path=str(item.get("directory", item.get("path", ""))),
                ca=int(item["ca"]),
                ce=int(item["ce"]),
                instability=float(item["instability"]),
                abstract_classes=int(item["abstract_classes"]),
                total_classes=int(item["total_classes"]),
                abstractness=float(item["abstractness"]),
                distance=float(item["distance"]),
                afferent_packages=list(item.get("afferent_packages", [])),
                efferent_packages=list(item.get("efferent_packages", [])),
                anchor_file=str(item.get("anchor_file") or ""),
                anchor_line=int(item.get("anchor_line") or 1),
            )
            for item in raw_list
        ]

    def _collect_rework_rate(self) -> float:
        """Compute percentage of recent git commits that represent rework/fixups."""
        try:
            proc = subprocess.run(
                [
                    "git",
                    "-C",
                    str(self.target_dir),
                    "log",
                    "-n",
                    "20",
                    "--pretty=format:%s",
                ],
                capture_output=True,
                text=True,
                check=False,
                timeout=5,
            )
            if proc.returncode != 0 or not proc.stdout.strip():
                return 0.0
            subjects = [
                line.strip() for line in proc.stdout.splitlines() if line.strip()
            ]
            if not subjects:
                return 0.0
            rework_pattern = re.compile(
                r"\b(revert|fixup!|squash!|hotfix)\b", re.IGNORECASE
            )
            rework_count = sum(1 for s in subjects if rework_pattern.search(s))
            return round((rework_count / len(subjects)) * 100.0, 2)
        except Exception:
            return 0.0

    def _fallback_code_anchor(
        self, pkg_metrics: list[PackageCouplingMetrics]
    ) -> tuple[str, int]:
        """Find a guaranteed-valid Python statement anchor `[A] path:line` in `target_dir`."""
        for pm in pkg_metrics:
            if pm.anchor_file:
                candidate = self.target_dir / pm.anchor_file
                if candidate.is_file():
                    line = pm.anchor_line or _first_valid_statement_line(candidate)
                    return pm.anchor_file, line

        search_root = (
            self.target_dir / "src"
            if (self.target_dir / "src").is_dir()
            else self.target_dir
        )
        for py_file in sorted(search_root.rglob("*.py")):
            rel = py_file.relative_to(self.target_dir).as_posix()
            if any(
                part.startswith(".") or part in ("venv", ".venv", "tests")
                for part in py_file.parts
            ):
                continue
            return rel, _first_valid_statement_line(py_file)

        return ".cas/bands.yaml", 1

    def evaluate(self) -> ControlBandsReport:
        """Evaluate all configured metrics against control bands and auto-draft Stage 1 intent on 3sigma."""
        specs, config_rel = self.load_config()
        pkg_metrics = self._collect_package_metrics()
        lint_report = ArchitectureLinter(target_dir=self.target_dir).lint()

        coupled_pkgs = [p for p in pkg_metrics if (p.ca + p.ce) > 0]
        worst_pkg = (
            max(coupled_pkgs, key=lambda p: p.distance) if coupled_pkgs else None
        )

        observed_values: dict[str, float] = {
            "martin_distance_d": worst_pkg.distance if worst_pkg is not None else 0.0,
            "lint_violations": float(len(lint_report.findings)),
            "rework_rate": self._collect_rework_rate(),
        }
        for k, v in self.metric_overrides.items():
            observed_values[k] = float(v)

        results: list[BandEvaluationResult] = []
        highest_band = "ok"

        for metric_name, spec in specs.items():
            val = round(float(observed_values.get(metric_name, 0.0)), 4)
            t1 = spec.get_threshold("1sigma")
            t2 = spec.get_threshold("2sigma")
            t3 = spec.get_threshold("3sigma")

            if val >= t3:
                band = "3sigma"
                action = spec.tiers["3sigma"].action
            elif val >= t2:
                band = "2sigma"
                action = spec.tiers["2sigma"].action
            elif val >= t1:
                band = "1sigma"
                action = spec.tiers["1sigma"].action
            else:
                band = "ok"
                action = "none"

            if BAND_SEVERITY_ORDER[band] > BAND_SEVERITY_ORDER[highest_band]:
                highest_band = band

            diagnostics: list[str] = []
            code_anchors: list[str] = []
            if band != "ok":
                if metric_name == "martin_distance_d":
                    threshold_used = (
                        t3 if band == "3sigma" else t2 if band == "2sigma" else t1
                    )
                    offending = [
                        p for p in coupled_pkgs if p.distance >= threshold_used
                    ] or ([worst_pkg] if worst_pkg else [])
                    for p in offending:
                        if p is None:
                            continue
                        if p.anchor_file:
                            code_anchors.append(f"{p.anchor_file}:{p.anchor_line}")
                        zone = (
                            "Zone of Pain (high stability, low abstractness)"
                            if p.instability < 0.5 and p.abstractness < 0.5
                            else "Zone of Uselessness (high abstractness, low stability)"
                            if p.instability >= 0.5 and p.abstractness >= 0.5
                            else "Main Sequence deviation"
                        )
                        diagnostics.append(
                            f"Package '{p.package}' has D={p.distance:.4f} "
                            f"(Ca={p.ca}, Ce={p.ce}, I={p.instability:.4f}, A={p.abstractness:.4f}) — {zone}."
                        )
                    if not diagnostics:
                        diagnostics.append(
                            f"Metric 'martin_distance_d' observed={val:.4f} breached {band} threshold."
                        )
                elif metric_name == "lint_violations":
                    for f in lint_report.findings[:5]:
                        f_path = getattr(f, "file", getattr(f, "file_path", ""))
                        if f_path:
                            code_anchors.append(f"{f_path}:{f.line}")
                        diagnostics.append(
                            f"{f.rule_id} at {f_path}:{f.line}: {f.message}"
                        )
                    if not diagnostics:
                        diagnostics.append(
                            f"Metric 'lint_violations' observed={val:.0f} breached {band} threshold."
                        )
                else:
                    diagnostics.append(
                        f"Metric '{metric_name}' observed={val} breached {band} threshold "
                        f"(1sigma={t1}, 2sigma={t2}, 3sigma={t3})."
                    )

            results.append(
                BandEvaluationResult(
                    metric=metric_name,
                    observed_value=val,
                    band=band,
                    action=action,
                    threshold_1sigma=t1,
                    threshold_2sigma=t2,
                    threshold_3sigma=t3,
                    diagnostics=diagnostics,
                    code_anchors=code_anchors,
                )
            )

        drafted_intent_path: str | None = None
        breaches_3sigma = [
            e for e in results if e.band == "3sigma" or e.action == "propose"
        ]
        if breaches_3sigma:
            drafted_intent_path = self._draft_stage1_intent(
                breaches=breaches_3sigma,
                pkg_metrics=pkg_metrics,
                worst_pkg=worst_pkg,
                lint_findings=lint_report.findings,
            )
            for b in breaches_3sigma:
                b.drafted_intent_path = drafted_intent_path

        return ControlBandsReport(
            target_dir=str(self.target_dir),
            config_path=config_rel,
            highest_band=highest_band,
            has_3sigma_breach=bool(breaches_3sigma),
            drafted_intent_path=drafted_intent_path,
            results=results,
            package_metrics=pkg_metrics,
        )

    def _resolve_intent_target_path(self, slug: str) -> Path:
        """Resolve the profile-aware Stage 1 intent.md path with idempotent speckit directory reuse."""
        resolver = SDLCProfileResolver(
            target_dir=self.target_dir, profile_override=self.sdlc_profile
        )
        resolved = resolver.resolve()
        profile_name = resolved.profile_name

        if profile_name == "speckit":
            specs_dir = self.target_dir / "specs"
            specs_dir.mkdir(parents=True, exist_ok=True)
            existing = sorted(specs_dir.glob(f"*-refactor-{slug}/intent.md"))
            if existing:
                return existing[0]
            existing_any = sorted(specs_dir.glob("*-refactor-*/intent.md"))
            if existing_any:
                return existing_any[0]
            max_num = 0
            for child in specs_dir.iterdir():
                if child.is_dir():
                    m = re.match(r"^(\d{3})-", child.name)
                    if m:
                        max_num = max(max_num, int(m.group(1)))
            next_num = f"{max_num + 1:03d}"
            return specs_dir / f"{next_num}-refactor-{slug}" / "intent.md"

        if profile_name == "anthropic-native":
            return self.target_dir / "intent.md"

        if profile_name == "superpowers":
            return self.target_dir / "docs" / "plans" / f"refactor-{slug}-design.md"

        if profile_name == "agent-skills":
            return self.target_dir / "docs" / "specs" / f"refactor-{slug}-intent.md"

        return self.target_dir / "intent.md"

    def _draft_stage1_intent(
        self,
        breaches: list[BandEvaluationResult],
        pkg_metrics: list[PackageCouplingMetrics],
        worst_pkg: PackageCouplingMetrics | None,
        lint_findings: list[Any],
    ) -> str:
        slug = _slugify(
            worst_pkg.package if worst_pkg is not None else "architecture-control-bands"
        )
        target_path = self._resolve_intent_target_path(slug)
        rel_target = target_path.relative_to(self.target_dir).as_posix()

        # Respect lifecycle status: never overwrite 'proposed' or 'accepted'
        if target_path.is_file():
            existing_text = target_path.read_text(encoding="utf-8")
            head = "\n".join(existing_text.splitlines()[:30])
            statuses = [
                m.group(1).lower() for m in IntentVerifier.STATUS_PATTERN.finditer(head)
            ]
            if any(s in ("proposed", "accepted") for s in statuses):
                return rel_target

        # Collect verified [A] path:line anchors
        anchors: list[str] = []
        seen_anchors: set[str] = set()

        for pm in sorted(pkg_metrics, key=lambda p: p.distance, reverse=True):
            if pm.anchor_file:
                candidate = self.target_dir / pm.anchor_file
                if candidate.is_file():
                    line = pm.anchor_line or _first_valid_statement_line(candidate)
                    key = f"{pm.anchor_file}:{line}"
                    if key not in seen_anchors:
                        seen_anchors.add(key)
                        anchors.append(
                            f"- [A] {pm.anchor_file}:{line} — Package `{pm.package}` coupling telemetry "
                            f"(Ca={pm.ca}, Ce={pm.ce}, I={pm.instability:.2f}, A={pm.abstractness:.2f}, D={pm.distance:.2f})"
                        )

        for lf in lint_findings[:5]:
            f_path = getattr(lf, "file", getattr(lf, "file_path", ""))
            key = f"{f_path}:{lf.line}"
            if (
                f_path
                and key not in seen_anchors
                and (self.target_dir / f_path).is_file()
            ):
                seen_anchors.add(key)
                anchors.append(f"- [A] {f_path}:{lf.line} — {lf.rule_id}: {lf.message}")

        if not anchors:
            fb_file, fb_line = self._fallback_code_anchor(pkg_metrics)
            anchors.append(
                f"- [A] {fb_file}:{fb_line} — Primary architectural module anchor for 3sigma control band remediation"
            )

        breach_rows = "\n".join(
            f"| `{b.metric}` | `{b.observed_value}` | `{b.threshold_3sigma}` | `{b.band}` (`{b.action}`) |"
            for b in breaches
        )
        diagnosis_bullets = "\n".join(
            f"- **{b.metric}**: {diag}"
            for b in breaches
            for diag in (
                b.diagnostics
                or [f"Observed {b.observed_value} >= {b.threshold_3sigma}"]
            )
        )
        anchors_block = "\n".join(anchors)

        content = f"""---
status: draft
generated_by: cas governance check-bands
trigger: 3sigma_anomaly
---

# Intent: Architectural Refactoring for 3-Sigma Control Band Remediation

Author: cas governance check-bands
Status: draft
Timestamp: 2026-01-01T00:00:00Z

## Problem

The Continuous Architecture System (`cas governance check-bands`) detected a **3sigma (`propose`)** statistical control band anomaly requiring an architectural refactoring evaluation:

| Metric | Observed Value | 3sigma Threshold | Classification |
| :--- | :--- | :--- | :--- |
{breach_rows}

### Diagnostic Telemetry

{diagnosis_bullets}

## Proposed Outcome

Decouple high-afferent concrete modules and resolve control band breaches so all repository telemetry returns below the `2sigma` threshold while preserving existing runtime behavior.

## Affected Users and Systems

{anchors_block}

## Constraints

- [P] Extract `typing.Protocol` or `abc.ABC` interfaces (`arch-pattern-protocol-first-provider-boundary`) to decouple stable core modules in the Zone of Pain ($I \\approx 0, A \\approx 0, D \\to 1$) and restore Normalized Distance from the Main Sequence below the `2sigma` threshold.
- [P] Preserve all existing public entrypoints and regression tests while introducing dependency inversion boundaries.

## Open Questions

- [Q] Should the high-afferent concrete abstractions identified above be extracted into a dedicated `protocols.py` / `contracts.py` module or split into separate domain subpackages before promoting this `intent.md` from `Status: draft` to `Status: accepted`?
"""
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_text(content, encoding="utf-8")
        return rel_target


def format_control_bands_text(report: ControlBandsReport) -> str:
    """Format a human-readable control bands evaluation report."""
    lines = [
        f"Control Bands Evaluation ({report.config_path}) — Highest Band: {report.highest_band.upper()}",
    ]
    for ev in report.results:
        lines.append(
            f"  - {ev.metric}: observed={ev.observed_value} "
            f"[1sigma={ev.threshold_1sigma}, 2sigma={ev.threshold_2sigma}, 3sigma={ev.threshold_3sigma}] -> band={ev.band} (action={ev.action})"
        )
        for diag in ev.diagnostics:
            lines.append(f"      * {diag}")
    if report.drafted_intent_path:
        lines.append(
            f"  => Auto-drafted Stage 1 intent artifact: {report.drafted_intent_path}"
        )
    return "\n".join(lines)
