from __future__ import annotations

import json
import re
import subprocess
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from cas_runner.governance.architecture_linter import ArchitectureLinter
from cas_runner.governance.sdlc_profile import SDLCProfileResolver
from cas_runner.llm import get_llm_client
from cas_runner.orchestration.config import ConfigLoader

SEVERITY_LEVELS = ("Critical", "High", "Medium", "Low")

# Known slopsquatting / hallucinated package names from the v0.1 spec
SLOPSQUATTING_PACKAGES = {
    "reqwests",
    "lodahs",
    "urllib4",
    "pyyaml-safe",
    "python-dotenv-cli",
    "fastapi-core-utils",
}

SECRET_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("Live Stripe/API Secret Key (sk_live_)", re.compile(r"sk_live_[0-9a-zA-Z]{8,}")),
    ("GitHub Personal Access Token (ghp_)", re.compile(r"ghp_[0-9a-zA-Z]{16,}")),
    ("AWS Access Key ID (AKIA)", re.compile(r"AKIA[0-9A-Z]{16}")),
    (
        "PEM Private Key Header",
        re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    ),
]


@dataclass
class VerificationFinding:
    """Represents a single finding from Pass 1, Pass 2, or Pass 3 verification."""

    pass_number: int
    rule_id: str
    severity: str
    file: str
    line: int
    message: str
    remediation: str


@dataclass
class VerificationReport:
    """Structured 3-pass verification report for verify-diff and review-pr."""

    target_dir: str
    mode: str
    enforcement: str
    fail_on: str
    resolved_profile: str
    passed: bool
    exit_code: int
    counts: dict[str, int] = field(default_factory=dict)
    findings: list[VerificationFinding] = field(default_factory=list)
    summary_line: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

    def to_markdown(self) -> str:
        lines: list[str] = [
            f"# CAS 3-Pass Verification Report (`{self.mode}`)",
            "",
            f"- **Target Directory**: `{self.target_dir}`",
            f"- **Resolved SDLC Profile**: `{self.resolved_profile}`",
            f"- **Enforcement Mode**: `{self.enforcement}` (fail-on: `{self.fail_on}`)",
            f"- **Status**: `{'PASSED' if self.passed else 'FAILED'}` (exit code: `{self.exit_code}`)",
            "",
        ]

        pass_titles = {
            1: "## Pass 1: Logic, SDD/TDD & Implementation Plan Alignment",
            2: "## Pass 2: Security, Secrets, Slopsquatting & Runtime Integrity",
            3: "## Pass 3: CAS Pattern Invariants, Anti-Patterns & Architecture Linter",
        }

        for pnum in (1, 2, 3):
            lines.append(pass_titles[pnum])
            pass_findings = [f for f in self.findings if f.pass_number == pnum]
            if not pass_findings:
                lines.append("- No issues detected.")
            else:
                for f in pass_findings:
                    lines.append(
                        f"- **[{f.severity}] `{f.rule_id}`** (`{f.file}:{f.line}`): {f.message} *(Remediation: {f.remediation})*"
                    )
            lines.append("")

        lines.append(self.summary_line)
        return "\n".join(lines)


class DiffVerifier:
    """
    Executes the 3-pass CAS verification contract (verify-diff / review-pr).
    Deterministic by default (<2s, zero LLM/network calls), with optional --provider semantic LLM critique.
    """

    def __init__(
        self,
        target_dir: str | Path = ".",
        mode: str = "verify-diff",
        base_ref: str | None = None,
        sdlc_profile: str | None = None,
        fail_on: str = "high",
        advisory: bool = False,
        provider: str | None = None,
        model: str | None = None,
    ):
        self.target_path = Path(target_dir).resolve()
        self.mode = mode
        self.base_ref = base_ref
        self.resolver = SDLCProfileResolver(
            target_dir=self.target_path, profile_override=sdlc_profile
        )
        self.provider = provider
        self.model = model

        # Determine enforcement and fail_on threshold
        cfg_enforcement = self.resolver.config.enforcement
        if advisory or fail_on.lower() == "none" or cfg_enforcement == "advisory":
            self.enforcement = "advisory"
            self.fail_on = "none"
        else:
            self.enforcement = "strict"
            self.fail_on = (
                fail_on.lower()
                if fail_on.lower() in ("critical", "high", "medium", "low")
                else "high"
            )

    def verify(
        self,
        changed_files: list[str] | None = None,
        commit_message: str | None = None,
    ) -> VerificationReport:
        diff_files = (
            [self.resolver._normalize_rel(f) for f in changed_files]
            if changed_files is not None
            else self.resolver.get_git_changed_files(base_ref=self.base_ref)
        )
        branch = self.resolver.get_git_branch() or ""
        commit_msg = (
            commit_message
            if commit_message is not None
            else self._get_last_commit_message()
        )

        resolved = self.resolver.resolve(changed_files=diff_files, branch_name=branch)
        findings: list[VerificationFinding] = []

        # Pass 1: Logic, SDD/TDD & Implementation Plan Alignment
        findings.extend(
            self._run_pass1_sdd_tdd_plan(diff_files, resolved, branch, commit_msg)
        )

        # Pass 2: Security, Secrets, Slopsquatting & Bugfix Test-Tampering
        findings.extend(
            self._run_pass2_security_and_integrity(diff_files, branch, commit_msg)
        )

        # Pass 3: CAS Pattern Invariants & Deterministic Architecture Linter
        findings.extend(self._run_pass3_architecture_linter(resolved))

        # Optional LLM Critic Pass when --provider is supplied
        if self.provider:
            findings.extend(self._run_optional_llm_critic(diff_files, resolved))

        counts = dict.fromkeys(SEVERITY_LEVELS, 0)
        for f in findings:
            sev = f.severity.capitalize()
            if sev not in counts:
                sev = "Medium"
                f.severity = sev
            counts[sev] += 1

        summary_line = (
            f"Critical: {counts['Critical']} | High: {counts['High']} | "
            f"Medium: {counts['Medium']} | Low: {counts['Low']}"
        )

        threshold_failed = self._exceeds_threshold(counts)
        passed = not threshold_failed
        exit_code = 0 if (self.enforcement == "advisory" or passed) else 1

        report = VerificationReport(
            target_dir=str(self.target_path),
            mode=self.mode,
            enforcement=self.enforcement,
            fail_on=self.fail_on,
            resolved_profile=resolved.profile_name,
            passed=passed,
            exit_code=exit_code,
            counts=counts,
            findings=findings,
            summary_line=summary_line,
        )

        try:
            from .sdlc_state import SDLCStatePublisher

            publisher = SDLCStatePublisher(target_dir=self.target_path)
            status = "PASSED" if report.passed else "FAILED"
            gate_key = "review_pr" if self.mode == "review-pr" else "verify_diff"
            checklist_updates = {
                "spec_md": bool(resolved.spec_files),
                "plan_md": bool(resolved.plan_files),
                "tasks_md": bool(resolved.tasks_files),
                "tests": bool(resolved.test_files),
                "src": any(f.startswith("src/") for f in diff_files),
            }
            publisher.record_gate(
                gate_name=gate_key,
                status=status,
                details=report.summary_line,
                stage=6,
                checklist_updates=checklist_updates,
            )
        except Exception:
            pass

        return report

    def _run_pass1_sdd_tdd_plan(
        self,
        diff_files: list[str],
        resolved: Any,
        branch: str,
        commit_msg: str,
    ) -> list[VerificationFinding]:
        findings: list[VerificationFinding] = []
        is_exempt = (
            "[skip-governance]" in commit_msg
            or "[bugfix]" in commit_msg
            or branch.startswith("fix/")
            or branch.startswith("bugfix/")
        )

        has_src_changes = any(
            f.startswith("src/") and f.endswith(".py") for f in diff_files
        )
        if not has_src_changes or is_exempt:
            return findings

        # 1. SDD specification/plan presence check (Two-Key Invariance)
        if not resolved.spec_files or not resolved.plan_files:
            missing_types: list[str] = []
            if not resolved.spec_files:
                missing_types.append("specification ('spec.md')")
            if not resolved.plan_files:
                missing_types.append("implementation plan ('plan.md')")
            findings.append(
                VerificationFinding(
                    pass_number=1,
                    rule_id="SDD-001",
                    severity="High",
                    file="(diff)",
                    line=1,
                    message=(
                        f"Production code changes detected in 'src/' without resolved {' and '.join(missing_types)} "
                        f"for profile '{resolved.profile_name}'."
                    ),
                    remediation=(
                        "Ensure both a feature specification and implementation plan matching "
                        ".cas/sdlc-profile.yaml exist and are maintained before modifying 'src/'."
                    ),
                )
            )

        # 2. Plan required sections check
        if resolved.missing_plan_sections and resolved.plan_files:
            findings.append(
                VerificationFinding(
                    pass_number=1,
                    rule_id="PLAN-001",
                    severity="Medium",
                    file=resolved.plan_files[0],
                    line=1,
                    message=(
                        f"Implementation plan '{resolved.plan_files[0]}' is missing required section(s): "
                        f"{', '.join(resolved.missing_plan_sections)}."
                    ),
                    remediation=(
                        "Ensure the plan includes sections covering files that change, order of work, "
                        "risks, and proof/verification."
                    ),
                )
            )

        # 2b. Plan scope check (PLAN-002: Plan Scope Invariance)
        if resolved.plan_files:
            primary_plan = self.target_path / resolved.plan_files[0]
            if primary_plan.is_file():
                profile_spec = self.resolver.config.profiles.get(
                    resolved.profile_name, self.resolver.config.profiles.get("speckit")
                )
                section_text = self.resolver.get_plan_files_section_text(
                    primary_plan, profile_spec
                )
                if section_text:
                    for src_f in diff_files:
                        if src_f.startswith("src/") and src_f.endswith(".py"):
                            basename = Path(src_f).name
                            if (
                                src_f not in section_text
                                and basename not in section_text
                            ):
                                findings.append(
                                    VerificationFinding(
                                        pass_number=1,
                                        rule_id="PLAN-002",
                                        severity="High",
                                        file=src_f,
                                        line=1,
                                        message=(
                                            f"Production code file '{src_f}' modified in git diff is not declared "
                                            f"in active plan '{resolved.plan_files[0]}' under 'Files that change'."
                                        ),
                                        remediation=(
                                            f"Update '{resolved.plan_files[0]}' to declare '{src_f}' in the "
                                            f"'Files that change' section before modifying code."
                                        ),
                                    )
                                )

        # 2c. Specification scope co-evolution check (SPEC-002: Specification Scope Invariance)
        if resolved.spec_files:
            primary_spec = self.target_path / resolved.spec_files[0]
            spec_rel = self.resolver._normalize_rel(resolved.spec_files[0])
            spec_updated_in_diff = spec_rel in diff_files
            if primary_spec.is_file() and not spec_updated_in_diff:
                try:
                    spec_text = primary_spec.read_text(encoding="utf-8")
                except Exception:
                    spec_text = ""
                for src_f in diff_files:
                    if src_f.startswith("src/") and src_f.endswith(".py"):
                        basename = Path(src_f).name
                        stem = Path(src_f).stem
                        if (
                            src_f not in spec_text
                            and basename not in spec_text
                            and stem not in spec_text
                        ):
                            findings.append(
                                VerificationFinding(
                                    pass_number=1,
                                    rule_id="SPEC-002",
                                    severity="High",
                                    file=src_f,
                                    line=1,
                                    message=(
                                        f"Production code file '{src_f}' modified in diff is not specified in active "
                                        f"specification '{resolved.spec_files[0]}' and the specification was not updated in this diff."
                                    ),
                                    remediation=(
                                        f"Update '{resolved.spec_files[0]}' with requirements, scenarios, or [A] code anchors "
                                        f"for '{src_f}' to maintain spec-to-code traceability."
                                    ),
                                )
                            )

        # 3. TDD test presence check
        has_test_changes = any(f.startswith("tests/") for f in diff_files)
        if not has_test_changes:
            findings.append(
                VerificationFinding(
                    pass_number=1,
                    rule_id="TDD-001",
                    severity="High",
                    file="(diff)",
                    line=1,
                    message="Production code changes detected in 'src/' without corresponding test updates in 'tests/'.",
                    remediation="Write or update unit tests under 'tests/' following Red-Green-Refactor TDD discipline.",
                )
            )

        # 4. Intent provenance & zero-hallucination verification (INTENT-001)
        intent_target: Path | None = None
        target_candidates = getattr(resolved, "spec_files", []) + getattr(
            resolved, "intent_files", []
        )
        for cand in target_candidates:
            p = self.target_path / cand
            if p.is_file():
                intent_target = p
                break
        if intent_target:
            from .intent_verifier import IntentVerifier

            intent_verifier = IntentVerifier(target_dir=self.target_path)
            intent_report = intent_verifier.verify_artifact(intent_target)
            if not intent_report.is_valid:
                for err in intent_report.errors:
                    findings.append(
                        VerificationFinding(
                            pass_number=1,
                            rule_id="INTENT-001",
                            severity="High",
                            file=str(intent_target.relative_to(self.target_path)),
                            line=1,
                            message=f"Intent provenance verification failed: {err}",
                            remediation="Ensure all [A] code citations exist on disk and match AST bounds, and resolve all [Q] open questions before marking status accepted.",
                        )
                    )

        return findings

    def _run_pass2_security_and_integrity(
        self,
        diff_files: list[str],
        branch: str,
        commit_msg: str,
    ) -> list[VerificationFinding]:
        findings: list[VerificationFinding] = []

        # Scan changed files (or all src/ and dependency files if diff_files is empty)
        files_to_scan = list(diff_files)
        if not files_to_scan:
            for p in ("requirements.txt", "pyproject.toml"):
                if (self.target_path / p).exists():
                    files_to_scan.append(p)

        for rel in files_to_scan:
            # Skip scanning the verifier/hook rules themselves for regex literals
            if (
                rel
                in (
                    "src/cas_runner/governance/verifier.py",
                    ".cas/hooks/production-gate.sh",
                    "src/cas_runner/templates/onboarding/substrate/.cas/hooks/production-gate.sh",
                )
                or rel.startswith("tests/")
                or rel.startswith("docs/")
                or rel.startswith("specs/")
                or rel.startswith(".specify/")
                or rel == "REVIEW.md"
                or rel.endswith("/REVIEW.md")
            ):
                continue

            fpath = self.target_path / rel
            if not fpath.is_file():
                continue

            text = fpath.read_text(encoding="utf-8", errors="ignore")
            for idx, line in enumerate(text.splitlines(), start=1):
                for label, pattern in SECRET_PATTERNS:
                    if pattern.search(line):
                        findings.append(
                            VerificationFinding(
                                pass_number=2,
                                rule_id="SEC-001",
                                severity="Critical",
                                file=rel,
                                line=idx,
                                message=f"Hardcoded secret pattern detected: {label}.",
                                remediation="Remove the secret immediately, rotate the credential, and load from environment variables.",
                            )
                        )

            # Check dependency files for slopsquatting
            if fpath.name in ("requirements.txt", "pyproject.toml"):
                for idx, line in enumerate(text.splitlines(), start=1):
                    stripped = line.split("#", 1)[0].strip().strip("\"',")
                    if not stripped:
                        continue
                    pkg = (
                        re.split(r"[<>=!~\[\s;]", stripped, maxsplit=1)[0]
                        .strip()
                        .lower()
                    )
                    if pkg in SLOPSQUATTING_PACKAGES:
                        findings.append(
                            VerificationFinding(
                                pass_number=2,
                                rule_id="SEC-002",
                                severity="Critical",
                                file=rel,
                                line=idx,
                                message=f"Suspected slopsquatting / hallucinated dependency '{pkg}' in {rel}.",
                                remediation="Verify the exact upstream package name on PyPI before adding dependencies.",
                            )
                        )

        # Check bugfix test-tampering (TDD-002) when on fix/*, bugfix/*, or [bugfix] commit
        is_bugfix = (
            "[bugfix]" in commit_msg
            or branch.startswith("fix/")
            or branch.startswith("bugfix/")
        )
        if is_bugfix:
            for rel in diff_files:
                if not (rel.startswith("tests/") and rel.endswith(".py")):
                    continue
                fpath = self.target_path / rel
                if not fpath.is_file():
                    continue
                t_text = fpath.read_text(encoding="utf-8", errors="ignore")
                tampered = False
                tamper_line = 1
                for idx, line in enumerate(t_text.splitlines(), start=1):
                    if "@pytest.mark.skip" in line or "pytest.skip(" in line:
                        tampered = True
                        tamper_line = idx
                        break
                if not tampered and "def test_" in t_text and "assert " not in t_text:
                    tampered = True
                if not tampered:
                    try:
                        res = subprocess.run(
                            ["git", "diff", "-U0", "HEAD", "--", rel],
                            cwd=self.target_path,
                            capture_output=True,
                            text=True,
                            check=False,
                        )
                        if res.returncode == 0 and res.stdout:
                            removed_asserts = sum(
                                1
                                for ln in res.stdout.splitlines()
                                if ln.startswith("-")
                                and not ln.startswith("---")
                                and "assert " in ln
                            )
                            added_asserts = sum(
                                1
                                for ln in res.stdout.splitlines()
                                if ln.startswith("+")
                                and not ln.startswith("+++")
                                and "assert " in ln
                            )
                            if removed_asserts > added_asserts and added_asserts == 0:
                                tampered = True
                    except Exception:
                        pass
                if tampered:
                    findings.append(
                        VerificationFinding(
                            pass_number=2,
                            rule_id="TDD-002",
                            severity="High",
                            file=rel,
                            line=tamper_line,
                            message=f"Bugfix test tampering detected in '{rel}' (skipped test or removed assertions during bugfix).",
                            remediation="Fix the underlying production bug in 'src/' instead of skipping tests or deleting assertions in 'tests/'.",
                        )
                    )

        return findings

    def _run_pass3_architecture_linter(
        self, resolved: Any = None
    ) -> list[VerificationFinding]:
        findings: list[VerificationFinding] = []
        linter = ArchitectureLinter(target_dir=self.target_path)
        lint_report = linter.lint()
        for lf in lint_report.findings:
            findings.append(
                VerificationFinding(
                    pass_number=3,
                    rule_id=lf.rule_id,
                    severity="High" if lf.severity == "error" else "Medium",
                    file=lf.file,
                    line=lf.line,
                    message=f"({lf.pattern_id}) {lf.message}",
                    remediation=lf.remediation,
                )
            )

        # Proportionate Governance Plan Routing check (ARCH-PATH-B / ARCH-PATH-C)
        plan_target: Path | None = None
        if resolved and hasattr(resolved, "plan_files"):
            for cand in resolved.plan_files:
                p = self.target_path / cand
                if p.is_file():
                    plan_target = p
                    break
        if plan_target:
            from .models import GovernancePath
            from .plan_router import PlanRouter

            router = PlanRouter(target_dir=self.target_path)
            decision = router.route_plan_file(plan_target)
            if decision.status == "blocked":
                findings.append(
                    VerificationFinding(
                        pass_number=3,
                        rule_id="ARCH-PATH-C",
                        severity="High",
                        file=str(plan_target.relative_to(self.target_path)),
                        line=1,
                        message=f"Path C architectural exception blocked: {'; '.join(decision.reasons)}",
                        remediation="Ensure exception record exists, adheres to schema, is signed by an Architect, and is unexpired.",
                    )
                )
            elif decision.path == GovernancePath.PATH_B:
                findings.append(
                    VerificationFinding(
                        pass_number=3,
                        rule_id="ARCH-PATH-B",
                        severity="High",
                        file=str(plan_target.relative_to(self.target_path)),
                        line=1,
                        message=f"Path B architectural novelty detected: {'; '.join(decision.reasons)} (Candidate ADR: {decision.candidate_adr_path})",
                        remediation="Submit candidate ADR for ARB review via 'cas governance publish' before proceeding with implementation.",
                    )
                )

        return findings

    def _run_optional_llm_critic(
        self, diff_files: list[str], resolved: Any
    ) -> list[VerificationFinding]:
        findings: list[VerificationFinding] = []
        try:
            overrides: dict[str, Any] = {"provider": self.provider}
            if self.model:
                overrides["model"] = self.model
            profile = ConfigLoader().resolve_config(
                project="ideas-to-life-cas", cli_overrides=overrides
            )
            client = get_llm_client(profile=profile)
            prompt = (
                "You are the CAS Fresh-Context Verifier subagent. Audit the active change and return JSON "
                'with key "findings" containing objects with fields: pass_number (1|2|3), rule_id, '
                "severity (Critical|High|Medium|Low), file, line, message, remediation.\n"
                f"Resolved profile: {resolved.profile_name}\n"
                f"Changed files: {', '.join(diff_files)}\n"
            )
            resp = client.generate(prompt=prompt)
            raw_content = getattr(resp, "content", "") or str(resp)
            data = json.loads(raw_content)
            for item in data.get("findings", []):
                if isinstance(item, dict):
                    findings.append(
                        VerificationFinding(
                            pass_number=int(item.get("pass_number", 1)),
                            rule_id=str(item.get("rule_id", "LLM-CRITIC-001")),
                            severity=str(item.get("severity", "Low")).capitalize(),
                            file=str(item.get("file", "(diff)")),
                            line=int(item.get("line", 1)),
                            message=str(item.get("message", "")),
                            remediation=str(item.get("remediation", "")),
                        )
                    )
        except Exception:
            pass
        return findings

    def _exceeds_threshold(self, counts: dict[str, int]) -> bool:
        if self.fail_on == "none":
            return False
        if self.fail_on == "critical":
            return counts["Critical"] > 0
        if self.fail_on == "high":
            return counts["Critical"] > 0 or counts["High"] > 0
        if self.fail_on == "medium":
            return counts["Critical"] > 0 or counts["High"] > 0 or counts["Medium"] > 0
        if self.fail_on == "low":
            return sum(counts.values()) > 0
        return counts["Critical"] > 0 or counts["High"] > 0

    def _get_last_commit_message(self) -> str:
        try:
            res = subprocess.run(
                ["git", "log", "--format=%B", "-n", "1"],
                cwd=self.target_path,
                capture_output=True,
                text=True,
                check=False,
            )
            if res.returncode == 0:
                return res.stdout.strip()
        except Exception:
            pass
        return ""
