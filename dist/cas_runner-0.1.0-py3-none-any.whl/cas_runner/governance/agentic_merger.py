from pathlib import Path
from typing import Any

from ..orchestration.reasoning import ReasoningExecutionContract


class AgenticMerger:
    """
    An agentic conflict resolution engine for architectural artifacts.
    Uses LLM reasoning to merge divergent versions of AEM/AID nodes.
    """

    def __init__(self, reasoning_engine: ReasoningExecutionContract):
        self.reasoning_engine = reasoning_engine

    def resolve_aem_conflict(self, local_aem: dict[str, Any], remote_aem: dict[str, Any], base_aem: dict[str, Any] | None = None) -> dict[str, Any]:
        """Resolves a conflict between two versions of an AEM."""
        inputs = {
            "local_aem": local_aem,
            "remote_aem": remote_aem,
            "base_aem": base_aem
        }

        # Use a specialized prompt for AEM merging
        # We assume the prompt 'aem-conflict-resolution' exists or we'll create it
        result = self.reasoning_engine.reason("aem-conflict-resolution", inputs)
        return result.get("merged_aem", local_aem) # Fallback to local if reasoning fails

    def resolve_generic_conflict(self, artifact_path: Path, local_content: str, remote_content: str) -> str:
        """Resolves a conflict in a generic text artifact (e.g. Markdown AID)."""
        inputs = {
            "artifact_name": artifact_path.name,
            "local_content": local_content,
            "remote_content": remote_content
        }

        result = self.reasoning_engine.reason("generic-conflict-resolution", inputs)
        return result.get("merged_content", local_content)
