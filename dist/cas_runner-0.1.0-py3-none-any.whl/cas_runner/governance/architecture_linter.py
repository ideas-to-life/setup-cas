import ast
import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml

FORBIDDEN_VENDOR_PACKAGES = {
    "google-genai",
    "google-generativeai",
    "openai",
    "anthropic",
    "cohere",
    "mistralai",
}

FORBIDDEN_IMPORT_ROOTS = {
    "openai",
    "anthropic",
    "cohere",
    "mistralai",
    "google.genai",
    "google.generativeai",
}

FORBIDDEN_ADAPTER_STEMS = {
    "gemini",
    "openai",
    "anthropic",
    "ollama",
    "cohere",
    "mistral",
}

VENDOR_CLASS_RE = re.compile(
    r"^(Gemini|OpenAI|Anthropic|Ollama|Cohere|Mistral)[A-Za-z0-9_]*(Reasoner|Client|Provider|Adapter|Gateway)$"
)


@dataclass
class ArchitectureLintFinding:
    """Represents a single deterministic architectural guardrail violation."""

    rule_id: str
    pattern_id: str
    severity: str
    file: str
    line: int
    message: str
    remediation: str


@dataclass
class ArchitectureLintReport:
    """Aggregated deterministic architecture lint report for a target repository."""

    target_dir: str
    passed: bool
    findings: list[ArchitectureLintFinding] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "target_dir": self.target_dir,
            "passed": self.passed,
            "violation_count": len(self.findings),
            "findings": [asdict(f) for f in self.findings],
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


class ArchitectureLinter:
    """
    Deterministic static analyzer enforcing CAS architectural invariants and anti-patterns.
    Operates with zero LLM calls and zero network access.
    """

    def __init__(self, target_dir: str | Path = "."):
        self.target_path = Path(target_dir).resolve()

    def lint(self) -> ArchitectureLintReport:
        findings: list[ArchitectureLintFinding] = []
        findings.extend(self._check_dependencies())
        findings.extend(self._check_python_sources())
        findings.extend(self._check_pattern_catalogue())

        report = ArchitectureLintReport(
            target_dir=str(self.target_path),
            passed=len(findings) == 0,
            findings=findings,
        )

        try:
            from .sdlc_state import SDLCStatePublisher

            status = "PASSED" if report.passed else "FAILED"
            details = f"{len(report.findings)} violations"
            publisher = SDLCStatePublisher(target_dir=self.target_path)
            publisher.record_gate(
                gate_name="lint",
                status=status,
                details=details,
                stage=5,
            )
        except Exception:
            pass

        return report

    def _rel(self, path: Path) -> str:
        try:
            return str(path.relative_to(self.target_path))
        except ValueError:
            return str(path)

    def _check_dependencies(self) -> list[ArchitectureLintFinding]:
        findings: list[ArchitectureLintFinding] = []

        req_file = self.target_path / "requirements.txt"
        if req_file.exists():
            lines = req_file.read_text(encoding="utf-8", errors="ignore").splitlines()
            for idx, raw_line in enumerate(lines, start=1):
                if "# cas-lint: allow-vendor-sdk" in raw_line:
                    continue
                stripped = raw_line.split("#", 1)[0].strip()
                if not stripped or stripped.startswith("-"):
                    continue
                pkg = re.split(r"[<>=!~\[\s;]", stripped, maxsplit=1)[0].strip().lower()
                if pkg in FORBIDDEN_VENDOR_PACKAGES:
                    findings.append(
                        ArchitectureLintFinding(
                            rule_id="ARCH-LINT-001",
                            pattern_id="provider-agnostic-llm-client",
                            severity="error",
                            file=self._rel(req_file),
                            line=idx,
                            message=(
                                f"Forbidden direct vendor LLM SDK dependency '{pkg}' in {self._rel(req_file)}."
                            ),
                            remediation=(
                                "Replace direct vendor SDKs with a unified multi-provider router (e.g., 'litellm') "
                                "behind LLMClient per 'provider-agnostic-llm-client'."
                            ),
                        )
                    )

        pyproject_file = self.target_path / "pyproject.toml"
        if pyproject_file.exists():
            raw_text = pyproject_file.read_text(encoding="utf-8", errors="ignore")
            if "# cas-lint: allow-vendor-sdk" not in raw_text:
                lines = raw_text.splitlines()
                for idx, raw_line in enumerate(lines, start=1):
                    if "# cas-lint: allow-vendor-sdk" in raw_line:
                        continue
                    stripped = raw_line.split("#", 1)[0].strip()
                    m = re.match(r'^["\']([A-Za-z0-9_.-]+)', stripped)
                    if not m:
                        continue
                    pkg = m.group(1).lower()
                    if pkg in FORBIDDEN_VENDOR_PACKAGES:
                        findings.append(
                            ArchitectureLintFinding(
                                rule_id="ARCH-LINT-001",
                                pattern_id="provider-agnostic-llm-client",
                                severity="error",
                                file=self._rel(pyproject_file),
                                line=idx,
                                message=(
                                    f"Forbidden direct vendor LLM SDK dependency '{pkg}' in {self._rel(pyproject_file)}."
                                ),
                                remediation=(
                                    "Use 'litellm' unified router dependency instead of direct vendor SDK packages "
                                    "per 'provider-agnostic-llm-client'."
                                ),
                            )
                        )

        return findings

    def _iter_python_files(self) -> list[Path]:
        src_dir = self.target_path / "src"
        if src_dir.exists() and src_dir.is_dir():
            return sorted(src_dir.rglob("*.py"))

        excluded = {".git", ".venv", "venv", "tests", "node_modules", "__pycache__", ".tox", "build", "dist"}
        results: list[Path] = []
        for py_file in sorted(self.target_path.rglob("*.py")):
            rel_parts = py_file.relative_to(self.target_path).parts
            if any(part in excluded for part in rel_parts):
                continue
            results.append(py_file)
        return results

    def _check_python_sources(self) -> list[ArchitectureLintFinding]:
        findings: list[ArchitectureLintFinding] = []

        for py_file in self._iter_python_files():
            source = py_file.read_text(encoding="utf-8", errors="ignore")
            lines = source.splitlines()
            allow_file_import = "# cas-lint: allow-vendor-import" in source
            allow_file_adapter = "# cas-lint: allow-vendor-adapter" in source

            # ARCH-LINT-003: Check file path for vendor-specific adapter module
            if not allow_file_adapter:
                stem = py_file.stem.lower()
                parent_name = py_file.parent.name.lower()
                if stem in FORBIDDEN_ADAPTER_STEMS and parent_name in {"providers", "llm", "adapters", "clients"}:
                    findings.append(
                        ArchitectureLintFinding(
                            rule_id="ARCH-LINT-003",
                            pattern_id="provider-agnostic-llm-client",
                            severity="error",
                            file=self._rel(py_file),
                            line=1,
                            message=(
                                f"Vendor-specific LLM adapter module '{self._rel(py_file)}' violates "
                                "'provider-agnostic-llm-client' (adapter proliferation anti-pattern)."
                            ),
                            remediation=(
                                "Replace vendor-specific provider files with a single unified multi-provider gateway "
                                "(e.g., LiteLLMClient + MockLLMClient) parameterized via declarative config."
                            ),
                        )
                    )

            try:
                tree = ast.parse(source, filename=str(py_file))
            except SyntaxError:
                continue

            for node in ast.walk(tree):
                # ARCH-LINT-002: Forbidden direct vendor SDK imports
                if isinstance(node, ast.Import):
                    lineno = getattr(node, "lineno", 1)
                    line_text = lines[lineno - 1] if 1 <= lineno <= len(lines) else ""
                    if allow_file_import or "# cas-lint: allow-vendor-import" in line_text:
                        continue
                    for alias in node.names:
                        mod_name = alias.name
                        if mod_name in FORBIDDEN_IMPORT_ROOTS or any(
                            mod_name.startswith(f"{root}.") for root in FORBIDDEN_IMPORT_ROOTS
                        ):
                            findings.append(
                                ArchitectureLintFinding(
                                    rule_id="ARCH-LINT-002",
                                    pattern_id="provider-agnostic-llm-client",
                                    severity="error",
                                    file=self._rel(py_file),
                                    line=lineno,
                                    message=f"Forbidden direct vendor LLM SDK import 'import {mod_name}'.",
                                    remediation=(
                                        "Invoke LLMs exclusively through the unified LLMClient / LiteLLMClient "
                                        "abstraction rather than importing vendor SDKs directly."
                                    ),
                                )
                            )

                elif isinstance(node, ast.ImportFrom):
                    lineno = getattr(node, "lineno", 1)
                    line_text = lines[lineno - 1] if 1 <= lineno <= len(lines) else ""
                    if allow_file_import or "# cas-lint: allow-vendor-import" in line_text:
                        continue
                    mod = node.module or ""
                    for alias in node.names:
                        full_import = f"{mod}.{alias.name}" if mod else alias.name
                        if (
                            mod in FORBIDDEN_IMPORT_ROOTS
                            or any(mod.startswith(f"{root}.") for root in FORBIDDEN_IMPORT_ROOTS)
                            or full_import in FORBIDDEN_IMPORT_ROOTS
                        ):
                            findings.append(
                                ArchitectureLintFinding(
                                    rule_id="ARCH-LINT-002",
                                    pattern_id="provider-agnostic-llm-client",
                                    severity="error",
                                    file=self._rel(py_file),
                                    line=lineno,
                                    message=(
                                        f"Forbidden direct vendor LLM SDK import 'from {mod} import {alias.name}'."
                                    ),
                                    remediation=(
                                        "Invoke LLMs exclusively through the unified LLMClient / LiteLLMClient "
                                        "abstraction rather than importing vendor SDKs directly."
                                    ),
                                )
                            )

                # ARCH-LINT-003: Vendor-specific LLM adapter class definitions
                elif isinstance(node, ast.ClassDef) and not allow_file_adapter:
                    lineno = getattr(node, "lineno", 1)
                    line_text = lines[lineno - 1] if 1 <= lineno <= len(lines) else ""
                    if "# cas-lint: allow-vendor-adapter" in line_text:
                        continue
                    if VENDOR_CLASS_RE.match(node.name):
                        findings.append(
                            ArchitectureLintFinding(
                                rule_id="ARCH-LINT-003",
                                pattern_id="provider-agnostic-llm-client",
                                severity="error",
                                file=self._rel(py_file),
                                line=lineno,
                                message=(
                                    f"Vendor-specific LLM adapter class '{node.name}' violates "
                                    "'provider-agnostic-llm-client'."
                                ),
                                remediation=(
                                    "Use a provider-agnostic reasoner/client backed by a unified multi-model "
                                    "router (LiteLLMClient) and deterministic MockLLMClient."
                                ),
                            )
                        )

        return findings

    def _check_pattern_catalogue(self) -> list[ArchitectureLintFinding]:
        findings: list[ArchitectureLintFinding] = []
        cat_path = self.target_path / ".cas" / "patterns" / "patterns-catalogue.yaml"
        if not cat_path.exists():
            return findings

        try:
            data = yaml.safe_load(cat_path.read_text(encoding="utf-8")) or {}
        except Exception as exc:
            findings.append(
                ArchitectureLintFinding(
                    rule_id="ARCH-LINT-004",
                    pattern_id="declarative-agent-command-registry",
                    severity="error",
                    file=self._rel(cat_path),
                    line=1,
                    message=f"Invalid YAML in {self._rel(cat_path)}: {exc}",
                    remediation="Ensure .cas/patterns/patterns-catalogue.yaml is valid YAML.",
                )
            )
            return findings

        patterns = data.get("patterns", []) if isinstance(data, dict) else []
        for entry in patterns:
            if not isinstance(entry, dict):
                continue
            pid = entry.get("id", "<unknown>")
            invariants = entry.get("invariants")
            anti_patterns = entry.get("anti_patterns")
            if not (isinstance(invariants, list) and invariants and isinstance(anti_patterns, list) and anti_patterns):
                findings.append(
                    ArchitectureLintFinding(
                        rule_id="ARCH-LINT-004",
                        pattern_id="build-time-governance",
                        severity="error",
                        file=self._rel(cat_path),
                        line=1,
                        message=(
                            f"Pattern '{pid}' in {self._rel(cat_path)} is missing non-empty 'invariants' "
                            "or 'anti_patterns' guardrails."
                        ),
                        remediation=(
                            "Run 'cas bootstrap --force' or update .cas/patterns/patterns-catalogue.yaml "
                            "to include explicit invariants and anti_patterns for every pattern."
                        ),
                    )
                )

        return findings
