from typing import Any

from .models import GovernanceMetrics, TraceableMetric
from .reference_resolver import resolve_artifact_reference


def _status_icon(status: str) -> str:
    return "✅ PASS" if status == "PASS" else "❌ FAIL"

def _format_metric(metric: TraceableMetric) -> str:
    if metric.portal_url:
        return f"[{metric.count}]({metric.portal_url})"
    elif getattr(metric, 'link', None): # Fallback for old schema if it exists temporarily
        return f"[{metric.count}]({metric.link})"
    return str(metric.count)

def render_health_report(metrics: GovernanceMetrics, report: dict[str, Any]) -> str:
    """
    Renders the GovernanceMetrics and validation findings into a Markdown document.
    """
    md = [
        "# Governance Health Report",
        "",
        f"**Overall Status**: {_status_icon(report.get('status', 'fail').upper())}",
        "",
        "## Status Overview",
        "",
        "| Category | Status |",
        "|---|---|",
        f"| Schemas | {_status_icon(metrics.health.schemas)} |",
        f"| Traceability | {_status_icon(metrics.health.traceability)} |",
        f"| Lifecycle | {_status_icon(metrics.health.lifecycle)} |",
        f"| Governance State | {_status_icon(metrics.health.governance_state)} |",
        "",
        "## Inventory",
        "",
        "| Artifact Type | Count |",
        "|---|---|",
        f"| Proposals | {_format_metric(metrics.inventory.proposals)} |",
        f"| Recommendations | {_format_metric(metrics.inventory.recommendations)} |",
        f"| Decisions | {_format_metric(metrics.inventory.decisions)} |",
        f"| ADRs | {_format_metric(metrics.inventory.adrs)} |",
        f"| Patterns | {_format_metric(metrics.inventory.patterns)} |",
        "",
        "## Throughput",
        "",
        "| Metric | Count |",
        "|---|---|",
        f"| Recommendations Created | {_format_metric(metrics.throughput.recommendations_created)} |",
        f"| Decisions Made | {_format_metric(metrics.throughput.decisions_made)} |",
        f"| ADRs Generated | {_format_metric(metrics.throughput.adrs_generated)} |",
        f"| Patterns Institutionalised | {_format_metric(metrics.throughput.patterns_institutionalised)} |",
        "",
        "## Risks",
        "",
        "| Risk Area | Count |",
        "|---|---|",
        f"| Pending Reviews | {_format_metric(metrics.risks.pending_reviews)} |",
        f"| Deferred Decisions | {_format_metric(metrics.risks.deferred_decisions)} |",
        f"| Conditional ADRs | {_format_metric(metrics.risks.conditional_adrs)} |",
        "",
    ]

    findings = report.get("findings", [])
    if findings:
        md.extend([
            "## Findings",
            "",
            "| Severity | Type | Message |",
            "|---|---|---|"
        ])
        for f in findings:
            sev = "🔴 Error" if f["severity"] == "error" else "🟡 Warning"

            # Simple attempt to extract and linkify known artifact IDs from messages
            msg = f["message"]
            words = msg.split()
            linked_msg = []
            for w in words:
                clean_w = w.strip("':,.")
                if clean_w.startswith(("adr-", "pattern-", "recommendation-", "promotion-decision-")):
                    url = resolve_artifact_reference(clean_w)
                    linked_msg.append(f"[{clean_w}]({url})")
                else:
                    linked_msg.append(w)

            md.append(f"| {sev} | `{f['type']}` | {' '.join(linked_msg)} |")

    md.append("")
    return "\n".join(md)

def render_decision_inbox(pending_actions: list[dict[str, Any]]) -> str:
    """
    Renders the list of pending governance actions into a Markdown Decision Inbox.
    """
    md = [
        "# Governance Decision Inbox",
        "",
        "Surfacing all governance items requiring human action or formal decision.",
        "",
        "| ID | Type | Status | Action |",
        "|---|---|---|---|",
    ]

    if not pending_actions:
        md.append("| - | - | - | All items processed ✅ |")
    else:
        for action in pending_actions:
            art_id = action["id"]
            a_type = action["type"]
            status = action["status"]

            # Resolve portal link
            res = resolve_artifact_reference(art_id)
            link = f"[{art_id}]({res.portal_url})"

            md.append(f"| {link} | `{a_type}` | `{status}` | `cas governance approve {art_id}` |")

    md.append("")
    md.append("## Operational Instructions")
    md.append("")
    md.append("To process an item, use the CAS CLI:")
    md.append("- **Approve**: `cas governance approve <id>`")
    md.append("- **Reject**: `cas governance reject <id> --rationale \"...\"`")
    md.append("- **Defer**: `cas governance defer <id> --rationale \"...\"`")
    md.append("")

    return "\n".join(md)
