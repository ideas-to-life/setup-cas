---
name: architecture-intent
description: Frontmatter template for Architecture Intent Documents (AID)
type: frontmatter_template
source: prompts/intelligence/architecture-intent-generator.v2.md
---

# Architecture Intent Document Frontmatter Template

```yaml
---
id: "aid-<project>-<date>-<N>"
knowledgeType: "architecture_intent"

project: "<project-name>"
scope: "<project|system|meta>"

generated_at: "<ISO timestamp>"

sources:
  patterns:
    project: <number>
    global: <number>
  signals:
    project: <number>
    global: <number>
  learnings:
    project: <number>
    global: <number>
  intent:
    project: <number>
  rules:
    project: <number>
    global: <number>

confidence:
  overall: "<low|medium|high>"
  patterns: "<low|medium|high>"
  gaps: "<low|medium|high>"
  roadmap: "<low|medium|high>"

coverage:
  execution: "<low|medium|high>"
  state: "<low|medium|high>"
  contracts: "<low|medium|high>"
  governance: "<low|medium|high>"
  knowledge_system: "<low|medium|high>"

status: "active"
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `id` | Unique identifier for the AID, prefixed with `aid-` |
| `knowledgeType` | Must be `architecture_intent` for AIDs |
| `project` | Name of the project this AID describes |
| `scope` | Scope level: `project` (single project), `system` (system-wide), or `meta` (CAS itself) |
| `generated_at` | ISO timestamp when the AID was generated |
| `sources.patterns.project` | Count of project-specific patterns used |
| `sources.patterns.global` | Count of global patterns used |
| `sources.signals.project` | Count of project-specific signals used |
| `sources.signals.global` | Count of global signals used |
| `sources.learnings.project` | Count of project-specific learnings used |
| `sources.learnings.global` | Count of global learnings used |
| `sources.intent.project` | Count of project intent/vision files used |
| `sources.rules.project` | Count of project-specific rules used |
| `sources.rules.global` | Count of global rules used |
| `confidence.overall` | Overall confidence in the AID |
| `confidence.patterns` | Confidence in identified patterns |
| `confidence.gaps` | Confidence in identified gaps |
| `confidence.roadmap` | Confidence in proposed roadmap |
| `coverage.execution` | Coverage assessment for execution flows |
| `coverage.state` | Coverage assessment for state management |
| `coverage.contracts` | Coverage assessment for contracts/interfaces |
| `coverage.governance` | Coverage assessment for governance |
| `coverage.knowledge_system` | Coverage assessment for knowledge system |
| `status` | Lifecycle status: `active`, `evolving`, or `experimental` |
