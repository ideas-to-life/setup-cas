---
name: pattern
description: Frontmatter template for Architecture Patterns
type: frontmatter_template
source: knowledge/projects/*/patterns/*.md
---

# Pattern Frontmatter Template

```yaml
---
id: "<kebab-case-id>"
title: "<Pattern Name>"
summary: "<1 sentence describing the problem solved and the structural move>"

date: <YYYY-MM-DD>
tags: ["patterns", "<tag1>", "<tag2>"]
maturity: "exploring"
confidence: "medium"

decision:
  status: "proposed"
  decided_by: "system"
  date: null

domain: ["Agentic AI", "Architecture"]
relatedExperiments: ["<experiment-id>"]
relatedLearnings: ["<learning-id>"]
sources: ["<source-id>"]
diagram: "/architecture/patterns/<name>.svg"

knowledgeId: "<kebab-case-id>"
knowledgeType: "pattern"

scope:
  type: "project"
  project: "<project-name>"

origin:
  type: "code"
  promoted_from: null

source:
  learning: "<learning-id>"
signals: []
applies_to: []
automation_ready: false

promotion:
  candidate: false
  notes: ""
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `patternId` | Unique kebab-case identifier for the pattern |
| `title` | Human-readable pattern name |
| `summary` | One-sentence description of problem and structural move |
| `date` | Date pattern was created (YYYY-MM-DD) |
| `tags` | Array of tags including `patterns` prefix |
| `maturity` | Lifecycle: `exploring`, `validating`, `stable`, `retired` |
| `confidence` | Confidence level: `low`, `medium`, `high` |
| `decision.status` | Decision status: `proposed`, `accepted`, `rejected`, `deferred` |
| `decision.decided_by` | Who decided: `system`, `architect` |
| `decision.date` | Date of decision (null if pending) |
| `domain` | Domain classifications |
| `relatedExperiments` | Referenced experiments |
| `relatedLearnings` | Referenced learnings |
| `sources` | Source artefact IDs |
| `diagram` | Path to pattern diagram |
| `knowledgeId` | Same as patternId, for knowledge layer linking |
| `knowledgeType` | Must be `pattern` |
| `scope.type` | `core`, `supporting`, or `project` |
| `scope.project` | Project name if type is `project` |
| `origin.type` | How discovered: `code` or `heuristic` |
| `origin.promoted_from` | Source artefact if promoted from heuristic |
| `source.learning` | Learning artefact that produced this pattern |
| `signals` | Related signal IDs |
| `applies_to` | Systems/projects this applies to |
| `automation_ready` | Whether pattern can be auto-enforced |
| `promotion.candidate` | Whether candidate for promotion |
| `promotion.notes` | Promotion considerations |
