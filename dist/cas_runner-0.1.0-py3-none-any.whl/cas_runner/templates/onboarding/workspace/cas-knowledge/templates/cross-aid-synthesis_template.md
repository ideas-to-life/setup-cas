---
name: cross-aid-synthesis
description: Frontmatter template for Cross-AID Synthesis (Architecture Maps)
type: frontmatter_template
source: prompts/intelligence/cross-aid-synthesis.v1.md
---

# Cross-AID Synthesis Frontmatter Template

```yaml
---
id: "aim-cross-aid-synthesis-<date>-<N>"
knowledgeType: "architecture_map"

scope: "global"

generated_at: "<ISO timestamp>"

inputs:
  - <aid-id-1>
  - <aid-id-2>
  - <aid-id-3>

summary:
  systems: <number of AIDs>
  grounded: <count>
  hybrid: <count>
  inferred: <count>

---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `id` | Unique identifier, prefixed with `aim-` and includes version |
| `knowledgeType` | Must be `architecture_map` for cross-aid synthesis |
| `scope` | Always `global` for cross-system synthesis |
| `generated_at` | ISO timestamp when the synthesis was generated |
| `inputs` | List of AID IDs that were synthesized (references `id` field from each AID) |
| `summary.systems` | Total number of AIDs processed |
| `summary.grounded` | Count of systems with high project sources (well-grounded) |
| `summary.hybrid` | Count of systems with mixed project/global sources |
| `summary.inferred` | Count of systems with high global sources (inferred) |

## Classification Criteria

| Classification | Criteria |
|----------------|----------|
| `grounded` | High project sources in the AID |
| `inferred` | High global sources in the AID |
| `hybrid` | Mixed project and global sources |
