---
name: heuristic-to-pattern
description: Frontmatter template for Patterns (promoted from heuristics)
type: frontmatter_template
source: prompts/intelligence/heuristic-to-pattern.v1.md
---

# Heuristic-to-Pattern Frontmatter Template

```yaml
---
id: "<kebab-case-id>"
knowledgeType: "pattern"

title: "<Pattern Name>"
summary: "<1 sentence describing the problem solved and the structural move>"

date: <YYYY-MM-DD>
maturity: "exploring"
confidence: "medium"

scope:
  type: "supporting"
  project: null

origin:
  type: "heuristic"
  promoted_from: "<source-artefact-id>"

promotion:
  candidate: true
  notes: "Derived from signals; validate before promoting to core"

sources:
  patterns: []
  signals: ["<signal-id>"]
  learnings: ["<learning-id>"]

domain: ["Agentic AI", "Architecture"]
tags: ["patterns", "<tag>"]

relatedExperiments: []
relatedLearnings: ["<learning-id>"]
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `id` | Unique kebab-case identifier (e.g., `build-time-governance`) |
| `knowledgeType` | Must be `pattern` for pattern artefacts |
| `title` | Human-readable pattern name |
| `summary` | One-sentence description of problem solved and structural move |
| `date` | Date pattern was created (YYYY-MM-DD format) |
| `maturity` | Lifecycle stage: `exploring`, `validating`, `stable`, `retired` |
| `confidence` | Confidence level: `low`, `medium`, `high` |
| `scope.type` | Applicability: `core`, `supporting`, or `project` |
| `scope.project` | If type is `project`, specifies which project |
| `origin.type` | How discovered: `code` or `heuristic` |
| `origin.promoted_from` | ID of source artefact (signal/heuristic document) |
| `promotion.candidate` | Whether this is a promotion candidate |
| `promotion.notes` | Validation requirements or considerations |
| `sources.patterns` | Array of pattern IDs this pattern builds on |
| `sources.signals` | Array of signal IDs that support this pattern |
| `sources.learnings` | Array of learning IDs that support this pattern |
| `domain` | Array of domain classifications |
| `tags` | Array of free-form tags for discovery |
| `relatedExperiments` | Array of experiment IDs demonstrating this pattern |
| `relatedLearnings` | Array of related learning artefact IDs |

## Constraints for Heuristic-Derived Patterns

- `scope.type` should be `supporting` (not `core`)
- `promotion.candidate` should always be `true`
- `origin.promoted_from` must reference the source signal ID(s)
- `maturity` should start at `exploring` until validated
