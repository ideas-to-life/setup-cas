---
name: diagram
description: Frontmatter template for Architecture Diagrams
type: frontmatter_template
source: knowledge/projects/*/diagrams/*.md
---

# Architecture Diagram Frontmatter Template

Note: Diagram files may or may not have frontmatter. When they do, use this format.

```yaml
---
id: "<name>-<project>-<date>-<N>"
knowledgeType: "diagram"
diagramType: "sequence"
project: "<project-name>"
scope: "project"
related_patterns: ["<pattern-id>"]
related_signals: ["<signal-id>"]
derived_from: ["<source-diagram-id>"]
relatedAEM: "<aem-id>"
last_verified: "<YYYY-MM-DD>"
status: "active"
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `id` | Unique diagram identifier |
| `knowledgeType` | Must be `diagram` |
| `type` | Diagram type: `sequence`, `component`, `flow`, `context` |
| `project` | Project this diagram relates to |
| `scope` | Scope: `project`, `system`, `global` |
| `related_patterns` | Patterns this diagram illustrates |
| `related_signals` | Signals that informed this diagram |

## Diagram Formats

Supported formats:
- Mermaid (sequence, flow, component diagrams)
- C4 model diagrams
- SVG/PNG (static exports)

## Notes

- Diagrams are **optional contextual artefacts**
- Should reference patterns they visualize
- Can be generated from patterns or created manually
- Used for architecture understanding and communication
