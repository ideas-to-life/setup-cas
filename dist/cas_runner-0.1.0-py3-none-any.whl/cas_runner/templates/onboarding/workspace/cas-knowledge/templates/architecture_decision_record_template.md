---
name: architecture_decision_record
description: Frontmatter template for Architecture Decision Records (ADR)
type: frontmatter_template
source: knowledge/global/decisions/*.md
---

# Architecture Decision Record Frontmatter Template

```yaml
---
id: "adr-<project>-<date>-<N>"
knowledgeType: "architecture_decision_record"

# Backward compatibility (pattern-based ADRs)
pattern_id: "<pattern-id>"  # optional

# New generalized decision model
decision_scope: "pattern | system | component | workflow | governance"
decision_target: "<pattern-id | component-name | system-element>"

decision:
  type: "adoption | keep | promotion | demotion | creation | definition | refactor"
  status: "proposed | rejected | deferred" # status of the architect decision
  decided_by: "architect"
  date: "<YYYY-MM-DD>"

  rationale:
    summary: "<Decision rationale summary>"

  evidence:
    strength: "low | medium | high"

  confidence: "low | medium | high"

classification: "core | supporting | project | system | component"

governance:
  forum_status: "pending | accepted | rejected | deferred"
  forum_decision_date: "<YYYY-MM-DD | null>"

# Unified traceability
related:
  patterns:
    - "<pattern-id>"
  architecture_work:
    - "<aw-id>"
  findings:
    - "<ALIGN-id>"
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `id` | Unique ADR identifier with pattern/slug and date |
| `knowledgeType` | Must be `architecture_decision_record` |
| `pattern_id` | Optional. Pattern this decision relates to (used when decision_scope = pattern) |
| `decision_scope` | Scope of the decision: `pattern`, `system`, `component`, `workflow`, `governance` |
| `decision.type` | Type of decision: `adoption`, `promotion`, `demotion`, `creation`, `definition`, `refactor` |
| `decision_target` | Target of the decision (pattern id, component name, or system element) |
| `decision.status` | Status of the architect decision: `proposed`, `accepted`, `rejected`, `deferred` |
| `decision.decided_by` | Who decided: `architect`, `system` |
| `decision.date` | Date of decision |
| `decision.rationale.summary` | Summary of decision rationale |
| `decision.evidence.strength` | Evidence strength: `low`, `medium`, `high` |
| `decision.confidence` | Confidence in decision: `low`, `medium`, `high` |
| `governance.forum_status` | Architecture forum status: `pending`, `accepted`, `rejected`, `deferred` |
| `governance.forum_decision_date` | Date of forum decision |
| `related.patterns` | Related pattern IDs (if applicable) |
| `related.architecture_work` | Source architecture_work IDs |
| `related.findings` | Related alignment finding IDs |

## Decision Actions

| Action | Description |
|--------|-------------|
| `keep` | Keep pattern at current/proposed scope |
| `demote` | Demote pattern to lower scope |
| `promote` | Promote pattern to higher scope |
| `create` | Create new pattern/decision |
| `define` | Define a new architectural component, workflow, or governance element |
| `adopt` | Adopt a component or approach into the system |
| `refactor` | Change or restructure an existing architectural element |

## Notes

- ADR is the **single source of truth** for architecture decisions
- All other representations (AEM, patterns) must derive from ADR
- Decisions drive pattern lifecycle and scope classification
- ADRs can represent decisions beyond patterns (components, workflows, governance) using decision_scope and decision_target
- ADR distinguishes between architect decision and architecture forum governance approval
