---
name: architecture_work
description: Frontmatter template for Architecture Work Sessions
type: frontmatter_template
source: knowledge/projects/*/work/*.md
---

# Architecture Work Session Frontmatter Template

```yaml
---
id: "aw-<project>-<date>-<N>"
knowledgeType: "architecture_work"
project: "<project-name>"

date: "<YYYY-MM-DD>"

source: "conversation"  # conversation | alignment_engine | code | audit | workshop
origin_ref: ""          # optional reference (e.g. ALIGN-001)

type: ""                # decision | refactor | pattern_update | governance_update
priority: ""            # high | medium | low

status: "proposed"      # proposed | accepted | in_progress | done | rejected
confidence: "medium"    # low | medium | high
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `id` | Unique identifier with project, date, and sequence number |
| `knowledgeType` | Must be `architecture_work` |
| `project` | Project this work session relates to |
| `date` | Date of the work session |
| `source` | Source of the work: `conversation`, `alignment_engine`, `code`, `audit`, `workshop` |
| `origin_ref` | Optional reference to originating finding or source (e.g. ALIGN-001) |
| `type` | Type of architecture work: `decision`, `refactor`, `pattern_update`, `governance_update` |
| `priority` | Priority level: `high`, `medium`, `low` |
| `status` | Lifecycle status: `proposed`, `accepted`, `in_progress`, `done`, `rejected` |
| `confidence` | Confidence in the captured work: `low`, `medium`, `high` |

## Document Structure

Architecture work sessions contain:

1. **Decisions** - Architecture decisions made during the session
2. **Prompt Changes** - Changes to prompts/intelligence
3. **Pattern Operations** - Patterns created, updated, or refined
4. **Structural Changes** - Schema and structural modifications

## Notes

- Architecture work is a **first-class knowledge type**
- Work sessions are the primary input for AEM generation
- Decisions from work sessions should be formalized as ADRs
- Sequence number allows multiple sessions per day
