---
name: architecture_evolution_map
description: Frontmatter template for Architecture Evolution Maps (AEM)
type: frontmatter_template
source: knowledge/global/maps/*.md
---

# Architecture Evolution Map Frontmatter Template

```yaml
---
id: "aem-<project>-<date>-<N>"
knowledgeType: "architecture_evolution_map"
project: "<project-name>"
date: "<YYYY-MM-DD>"
version: <number>
source_work: "<architecture-work-id>"
source_adrs:
  - "<adr-id-1>"
  - "<adr-id-2>"
source_vision: "<vision-id>"
source_aid: "<aid-id>"
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `id` | Unique identifier with project, date, and version |
| `knowledgeType` | Must be `architecture_evolution_map` |
| `project` | Project this AEM describes |
| `date` | Date of this AEM version |
| `version` | Version number (incremented on updates) |
| `source_work` | Architecture work session that produced this AEM |
| `source_adrs` | Array of ADR IDs that inform this AEM |
| `source_vision` | Vision document ID |
| `source_aid` | Architecture Intent Document ID |

## Notes

- AEM is a **derived artefact** - all data should come from source ADRs
- Version should increment with each regeneration
- The AEM tracks architecture evolution over time through decisions
- Links to vision and AID for forward/backward traceability
