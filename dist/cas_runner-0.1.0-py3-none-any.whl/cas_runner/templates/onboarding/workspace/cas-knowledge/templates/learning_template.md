---
name: learning
description: Frontmatter template for Weekly Learnings
type: frontmatter_template
source: knowledge/projects/*/learnings/*.md
---

# Learning Frontmatter Template

```yaml
---
id: "wl-<YYYYMMDD>"
title: "<Learning Title>"
type: "weekly"
date: <YYYY-MM-DD>
summary: "<1-2 sentence summary>"
tags: ["architecture", "<tag>"]
draft: false
knowledgeId: "wl-<YYYYMMDD>"
knowledgeType: "learning"
produces:
  patterns: []
  signals:
    - "<signal-id>"
    - "<signal-id>"
        
context:
  system: "<project-name>"
  scope: "<scope>"
confidence: "medium"

decision:
  status: "proposed"
  decided_by: "system"
  date: null
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `title` | Human-readable learning title |
| `type` | Learning type (typically `weekly`) |
| `date` | Date of the learning (YYYY-MM-DD) |
| `summary` | Brief summary of the week's focus |
| `tags` | Categorization tags |
| `draft` | Whether this is a draft |
| `knowledgeId` | Unique identifier, format `wl-YYYYMMDD` |
| `knowledgeType` | Must be `learning` |
| `produces.patterns` | Pattern IDs generated from this learning |
| `produces.signals` | Signal IDs generated from this learning |
| `context.system` | Project/system this learning relates to |
| `context.scope` | Scope of the learning |
| `confidence` | Confidence in the learning |
| `decision.status` | Decision status if applicable |
| `decision.decided_by` | Who decided |
| `decision.date` | Decision date |

## Notes

- Weekly Learnings are primary input for signal extraction
- The `produces` field creates traceability to downstream patterns/signals
- `knowledgeId` format is `wl-` followed by date in YYYYMMDD format
