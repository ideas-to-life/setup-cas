---
name: vision
description: Frontmatter template for Architecture Vision Documents
type: frontmatter_template
source: knowledge/projects/*/intent/*.md
---

# Architecture Vision Frontmatter Template

```yaml
---
id: "<vision-id>"
knowledgeType: "vision"

project: "<project-name>"
system: "<system-name>"

scope: "system"
status: "draft"
generated_at: "<ISO timestamp>"

confidence:
  overall: "medium"
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `id` | Unique identifier for the vision document |
| `knowledgeType` | Must be `vision` |
| `project` | Project this vision relates to |
| `system` | Name of the system being described |
| `scope` | Scope level: `project`, `system`, or `meta` |
| `status` | Document status: `draft`, `active`, `evolving` |
| `generated_at` | ISO timestamp when generated |
| `confidence.overall` | Overall confidence in the vision |

## Notes

- Vision documents describe **future direction** and **capability goals**
- Used as input for AID and AEM generation
- Should be grounded in signals and patterns where possible
- `confidence` reflects how well-defined the vision is
