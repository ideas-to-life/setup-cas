---
name: signal
description: Frontmatter template for Architecture Signals
type: frontmatter_template
source: knowledge/projects/*/signals/*.md
---

# Signal Frontmatter Template

```yaml
---
id: "<signal-id>"
title: "<Signal Title>"
slug: "<slug-path>"
type: "<thread|weekly|standalone>"
firstObserved: <YYYY-MM-DD>
lastUpdated: <YYYY-MM-DD>
relatedWeeks: ["<week-id>"]
tags: ["architecture", "<tag>"]
draft: false
knowledgeType: "signal"
signalType: "<curated-thread|emergent|derived>"
category: "<category>"
strength: "<emerging|strong|validated>"
derived_from: ["<learning-id>"]
knowledgeId: "<slug-or-id>"

decision:
  status: "proposed"
  decided_by: "system"
  date: null
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `title` | Human-readable signal title |
| `slug` | URL-safe path identifier |
| `type` | Signal type: `thread`, `weekly`, or `standalone` |
| `firstObserved` | Date signal was first identified |
| `lastUpdated` | Date of last update |
| `relatedWeeks` | Weekly learning IDs this signal relates to |
| `tags` | Categorization tags |
| `draft` | Whether this is a draft |
| `knowledgeType` | Must be `signal` |
| `signalType` | Classification: `curated-thread`, `emergent`, `derived` |
| `category` | Domain category (e.g., `governance`, `observability`) |
| `strength` | Signal strength: `emerging`, `strong`, `validated` |
| `derived_from` | Learning IDs that produced this signal |
| `knowledgeId` | Full path identifier for knowledge layer |
| `decision.status` | Decision status for this signal |
| `decision.decided_by` | Who is deciding |
| `decision.date` | Decision date (null if pending) |

## Signal Types

| Type | Description |
|------|-------------|
| `thread` | Curated collection of related insights |
| `weekly` | Signal extracted from weekly learning |
| `standalone` | Independent signal observation |
