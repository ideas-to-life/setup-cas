---
name: experiment
description: Frontmatter template for Experiment Charters
type: frontmatter_template
source: knowledge/projects/*/experiments/*.md
---

# Experiment Charter Frontmatter Template

```yaml
---
id:: "experiment-<date>-<N>"
knowledgeType: "experiment"
title: "<Experiment Title>"
summary: "<1 sentence describing what this experiment explores>"
description: "<2-3 sentences describing the experiment>"
maturity: "exploring"
domain: ["<domain1>", "<domain2>"]
date: <YYYY-MM-DD>
tags: ["<tag1>", "<tag2>"]
draft: false
image: "/assets/<image>.png"
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `id` | Unique experiment identifier, typically `experiment-<project>` |
| `knowledgeType` | Must be `experiment` |
| `title` | Human-readable experiment title |
| `summary` | One-sentence description of exploration focus |
| `description` | Extended description of the experiment |
| `maturity` | Lifecycle: `exploring`, `validating`, `stable`, `retired` |
| `domain` | Domain classifications |
| `date` | Date experiment was created |
| `tags` | Categorization tags |
| `draft` | Whether this is a draft |
| `image` | Path to experiment cover image |

## Notes

- Experiments are **learning artefacts**, not products
- They test reusable patterns, not one-off implementations
- Follows the Ideas to Life Experiments Charter
- Maturity indicates exploration progress
