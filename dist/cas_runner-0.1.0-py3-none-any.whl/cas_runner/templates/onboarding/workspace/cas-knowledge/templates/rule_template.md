---
name: rule
description: Frontmatter template for Governance Rules
type: frontmatter_template
source: knowledge/global/rules/*.md
---

# Governance Rule Frontmatter Template

```yaml
---
id: "rule-<rule-name>"
knowledgeType: "rule"
category: "governance"
scope: "global"
confidence: "high"
status: "active"
title: "<Rule Title>"
summary: "<1 sentence describing the rule>"
---
```

## Attribute Descriptions

| Attribute | Description |
|-----------|-------------|
| `id` | Unique rule identifier with `rule-` prefix |
| `knowledgeType` | Must be `rule` |
| `category` | Rule category: `governance`, `execution`, `quality` |
| `scope` | Rule scope: `global`, `project` |
| `confidence` | Confidence in rule: `low`, `medium`, `high` |
| `status` | Rule status: `active`, `draft`, `deprecated` |
| `title` | Human-readable rule title |
| `summary` | One-sentence description of the rule |

## Document Structure

After frontmatter, rules contain:

1. **Rule** - The rule statement
2. **Rationale** - Why this rule exists
3. **Applies To** - Artefacts/workflows this rule applies to
4. **Example** - A concrete example of the rule in action

## Rule Precedence

Global rules follow this hierarchy:

```
global > project > prompt-local
```

## Notes

- Rules are **hard constraints** on architecture work
- Global rules cannot be violated by project rules
- Rules should be testable/enforceable
- Rule conflicts should be detected and resolved
