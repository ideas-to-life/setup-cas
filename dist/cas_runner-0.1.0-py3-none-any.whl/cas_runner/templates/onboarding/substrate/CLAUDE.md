# Agent Context: CLAUDE.md

> [!CAUTION]
> ### 🚨 CRITICAL ENFORCEMENT: MANDATORY SDD/TDD & CAS SKILLS WORKFLOW 🚨
> You MUST NOT write, modify, or refactor any production code (`src/**`) without FIRST executing:
> 1. **Git Branch Isolation:** Confirm the active branch matches feature branch naming conventions ('<NNN-feature-name>'); NEVER write or modify production code directly on 'main' or 'master'.
> 2. **SDD Artifact Resolution (`.cas/sdlc-profile.yaml`) & Zero-Hallucination Intent Triage**: Confirm or create the active Intent, Specification, and Implementation Plan (`Files that change`, `Order of work`, `Risks`, `Proof`) matching the repository's configured SDLC profile (`auto`, `speckit`, `anthropic-native`, `superpowers`, or `agent-skills`). Run `cas governance verify-intent --target-dir .` to ensure all `[A]` code evidence citations exist and no unresolved `[Q]` questions block `Status: accepted`.
> 3. **CAS Skills Alignment & Plan Routing**: Invoke the mandatory CAS Skill (`cas-add-or-modify-feature` or `cas-refactor-module` in `.claude/skills/` / `.cas/`), verify all proposed changes against `.cas/patterns/patterns-catalogue.yaml` (`invariants` and `anti_patterns`), and run `cas governance route-plan --target-dir .` to determine the governance path (Path A, B, or C).
> 4. **Proportionate Governance Routing (Path A / B / C)**:
>    - **Path A (Governed Reuse)**: Reuses ratified patterns from `.cas/patterns/patterns-catalogue.yaml` while satisfying all `invariants` and avoiding all `anti_patterns` → unlocked for autonomous TDD build.
>    - **Path B (Architectural Novelty)**: Introduces a net-new architectural pattern or cross-boundary dependency → draft a candidate ADR/proposal and pause for human Architect review.
>    - **Path C (Architectural Exception)**: Intentionally deviates from a rule or invariant → requires an explicit, time-bound exception record (`exc-*.yaml`) approved by an Architect.
> 5. **Test-Driven Development (TDD — Red-Green-Refactor)**: Write or update failing unit tests under `tests/` BEFORE modifying production code under `src/`. Never weaken or delete existing test assertions during bugfixes (`[bugfix]`).
> 6. **Fresh-Context Verification (`.claude/agents/verifier.md`)**: Run deterministic diff verification (`cas governance verify-diff --target-dir .`) and PR review check (`cas governance review-pr --target-dir .`), and invoke the isolated read-only Verifier subagent (`.claude/agents/verifier.md`, canonical `.cas/agents/verifier.md`) before finishing.

## Operational Mandates

1. **Enforce Framework-Agnostic SDD & Two-Key Invariance**: Do not implement features without both a validated specification and plan resolved via `.cas/sdlc-profile.yaml`. Modifying code files not declared in the plan violates `PLAN-002`; adding code without updating the specification violates `SPEC-002`.
2. **Skill-Driven Workflow**: Always execute `.claude/skills/cas-add-or-modify-feature` or `.claude/skills/cas-refactor-module` before structural code changes.
3. **Pattern Invariants & Anti-Patterns**: Check `.cas/rules/architecture_rules.md` and `.cas/patterns/patterns-catalogue.yaml` (`invariants` and `anti_patterns`) before proposing designs.
4. **PreToolUse Hooks & Security**: Never bypass `.claude/settings.json` hooks (`.cas/hooks/path-protection.sh`, `.cas/hooks/production-gate.sh`) or commit secrets, API keys, or unverified dependencies.

## Skill & Subagent Registry

- **`cas-add-or-modify-feature`** (`.claude/skills/cas-add-or-modify-feature`): Mandatory for any new feature or behavioral modification.
- **`cas-refactor-module`** (`.claude/skills/cas-refactor-module`): Mandatory for module restructuring without behavioral change.
- **`cas-audit-agent-rules`** (`.claude/skills/cas-audit-agent-rules`): Mandatory for auditing, deduplicating, and optimizing agent rules and instruction files.
- **`verifier`** (`.claude/agents/verifier.md` → `.cas/agents/verifier.md`): Read-only Fresh-Context Verifier subagent that audits `git diff` against the active spec, plan, `REVIEW.md`, and `.cas/patterns/patterns-catalogue.yaml`.

## Verification

Run the following deterministic commands to prove compliance before completing any task or PR:

*(Note: 'cas' is the installed CLI in onboarded projects. If developing directly inside the CAS runner repository itself, invoke via 'uv run cas'.)*

```bash
# 1. Run unit and regression tests
pytest

# 2. Run deterministic architecture & anti-pattern linter (ARCH-LINT-001..004)
cas governance lint --target-dir .

# 3. Run 3-pass diff/PR verification against active SDD profile and REVIEW.md
cas governance verify-diff --target-dir .
cas governance review-pr --target-dir .
cas governance watch

# 4. Run deterministic agent skill evaluations
cas skills eval
```
