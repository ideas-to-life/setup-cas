from datetime import date


class VisionToAW:
    name = "vision-to-aw"

    def prepare_inputs(self, context):
        return {
            "vision_artifacts": context.get("project_vision"),
            "rule_context": context.get("rule_context"),
            "architectural_state": context.get("architectural_state"),
            "project": context.get("project"),
            "date": context.get("date", date.today().isoformat()),
        }

    def execute(self, inputs, reasoning_engine):
        if reasoning_engine is None:
            return {"architecture_work": []}

        llm_response = reasoning_engine.reason(self.name, inputs)
        aw_items = llm_response.get("architecture_work", [])

        return {"architecture_work": aw_items}

    def validate(self, output):
        assert "architecture_work" in output
