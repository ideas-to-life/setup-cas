import json
from datetime import date
from pathlib import Path

from jsonschema import ValidationError, validate


class PromotionToDecisionRecords:
    name = "promotion-to-decision-records"

    def prepare_inputs(self, context):
        target_pattern = context.get("target_pattern")
        promotion_decisions = context.get("promotion_decisions", [])
        if target_pattern:
            clean_target = (
                target_pattern.removeprefix("reference-architecture-")
                .removeprefix("promotion-decision-")
                .removeprefix("adr-")
                .removeprefix("recommendation-")
            )
            filtered = [
                d
                for d in promotion_decisions
                if d.get("pattern_id") == clean_target
                or d.get("id") == f"promotion-decision-{clean_target}"
                or (
                    isinstance(d.get("id"), str)
                    and d.get("id").removeprefix("promotion-decision-") == clean_target
                )
            ]
            if filtered:
                promotion_decisions = filtered
            else:
                print(
                    f"[CAS][WARN] target_pattern '{clean_target}' specified but not found in promotion decisions."
                )

        return {
            "promotion_decisions": promotion_decisions,
            "target_pattern": target_pattern,
            "pattern_promotion_recommendations": context.get(
                "pattern_promotion_recommendations"
            ),
            "pattern_proposals": context.get("pattern_proposals", []),
            "existing_global_patterns": context.get("patterns", []),
            "architectural_state": context.get("architectural_state"),
            "project": context.get("project"),
        }

    def execute(self, inputs, reasoning_engine):
        if reasoning_engine is None:
            return {"adrs": []}

        promotion_decisions = inputs.get("promotion_decisions", [])
        if not promotion_decisions:
            print(
                f"[CAS][INFO] No accepted promotion decisions found for '{self.name}'. Skipping ADR generation."
            )
            return {"adrs": []}

        llm_response = reasoning_engine.reason(self.name, inputs)

        if isinstance(llm_response, str):
            try:
                llm_response = json.loads(llm_response)
            except json.JSONDecodeError:
                print(
                    f"[CAS][ERROR] Failed to parse reasoning response for '{self.name}'"
                )
                return {"adrs": []}

        # The LLM may return a list of ADRs, a dict with "adrs" key, or a single ADR dict
        adrs = []
        if isinstance(llm_response, list):
            adrs = llm_response
        elif isinstance(llm_response, dict):
            if "adrs" in llm_response and isinstance(llm_response["adrs"], list):
                adrs = llm_response["adrs"]
            else:
                adrs = [llm_response]

        # Ensure metadata is present for each ADR
        for idx, adr in enumerate(adrs):
            # Resolve the matching promotion decision
            target_p = inputs.get("target_pattern")
            dec = None
            if target_p:
                clean_target = (
                    target_p.removeprefix("reference-architecture-")
                    .removeprefix("promotion-decision-")
                    .removeprefix("adr-")
                    .removeprefix("recommendation-")
                )
                for d in promotion_decisions:
                    if (
                        d.get("pattern_id") == clean_target
                        or d.get("id") == f"promotion-decision-{clean_target}"
                        or (
                            isinstance(d.get("id"), str)
                            and d.get("id").removeprefix("promotion-decision-")
                            == clean_target
                        )
                    ):
                        dec = d
                        break
            if not dec:
                adr_pid = adr.get("pattern_id")
                if adr_pid and adr_pid != "dummy_string":
                    for d in promotion_decisions:
                        if d.get("pattern_id") == adr_pid:
                            dec = d
                            break
            if not dec and idx < len(promotion_decisions):
                dec = promotion_decisions[idx]

            if dec:
                p_id = dec.get("pattern_id") or dec.get("id", "").removeprefix(
                    "promotion-decision-"
                )
                dec_id = dec.get("id") or f"promotion-decision-{p_id}"
                if p_id:
                    if not adr.get("id") or adr.get("id") == "dummy_string":
                        adr["id"] = f"adr-{p_id}"
                    if (
                        not adr.get("pattern_id")
                        or adr.get("pattern_id") == "dummy_string"
                    ):
                        adr["pattern_id"] = p_id
                    if (
                        not adr.get("decision_target")
                        or adr.get("decision_target") == "dummy_string"
                    ):
                        adr["decision_target"] = p_id
                    if not adr.get("project") or adr.get("project") == "dummy_string":
                        adr["project"] = inputs.get("project", "unknown")
                    if (
                        not adr.get("source_decision")
                        or adr.get("source_decision") == "dummy_string"
                    ):
                        adr["source_decision"] = dec_id

                    st = adr.setdefault("source_traceability", {})
                    if (
                        not st.get("promotion_decision")
                        or st.get("promotion_decision") == "dummy_string"
                    ):
                        st["promotion_decision"] = dec_id
                    if (
                        not st.get("pattern_proposal")
                        or st.get("pattern_proposal") == "dummy_string"
                    ):
                        st["pattern_proposal"] = p_id
                    if (
                        not st.get("promotion_recommendation")
                        or st.get("promotion_recommendation") == "dummy_string"
                    ):
                        st["promotion_recommendation"] = f"recommendation-{p_id}"
                    sc = st.setdefault("scope_classification", {})
                    if isinstance(sc, dict):
                        if (
                            not sc.get("artifact_id")
                            or sc.get("artifact_id") == "dummy_string"
                        ):
                            sc["artifact_id"] = "pattern-scope-classification"
                        if not sc.get("classification"):
                            sc["classification"] = "global"

            if "knowledgeType" not in adr:
                adr["knowledgeType"] = "architecture_decision_record"
            if "project" not in adr:
                adr["project"] = inputs.get("project", "unknown")
            if "date" not in adr:
                adr["date"] = date.today().isoformat()
            if "version" not in adr:
                adr["version"] = 1
            if "governance" in adr and "forum_status" not in adr["governance"]:
                adr["governance"]["forum_status"] = "pending"

            # Robustness for nested objects that LLM might flatten
            if "sections" in adr:
                context_sec = adr["sections"].get("context", {})
                if (
                    isinstance(context_sec, dict)
                    and "scope_classification" in context_sec
                ):
                    if isinstance(context_sec["scope_classification"], str):
                        val = context_sec["scope_classification"]
                        context_sec["scope_classification"] = {
                            "artifact_id": "pattern-scope-classification",
                            "classification": val,
                        }

                trace_sec = adr["sections"].get("traceability", {})
                if isinstance(trace_sec, dict) and "scope_classification" in trace_sec:
                    if isinstance(trace_sec["scope_classification"], str):
                        val = trace_sec["scope_classification"]
                        trace_sec["scope_classification"] = {
                            "artifact_id": "pattern-scope-classification",
                            "classification": val,
                        }

            if "source_traceability" in adr:
                st = adr["source_traceability"]
                if "scope_classification" in st and isinstance(
                    st["scope_classification"], str
                ):
                    val = st["scope_classification"]
                    st["scope_classification"] = {
                        "artifact_id": "pattern-scope-classification",
                        "classification": val,
                    }

        return {"adrs": adrs}

    def validate(self, output):
        assert "adrs" in output, "Missing 'adrs' in output"
        adr_list = output["adrs"]

        schema_path = (
            Path(__file__).parent.parent
            / "schemas"
            / "architecture_decision_record_schema.json"
        )
        if schema_path.exists():
            with open(schema_path) as f:
                schema = json.load(f)
            try:
                for adr in adr_list:
                    validate(instance=adr, schema=schema)
            except ValidationError as e:
                print(
                    f"[CAS][ERROR] Architecture Decision Record validation failed: {e.message}"
                )
                raise
        else:
            required_keys = [
                "id",
                "knowledgeType",
                "project",
                "date",
                "version",
                "decision_scope",
                "decision_target",
                "decision",
                "classification",
                "governance",
                "related",
                "sections",
            ]
            for adr in adr_list:
                for key in required_keys:
                    assert key in adr, f"Missing required key '{key}' in ADR output"
