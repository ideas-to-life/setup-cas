import json
import os
from pathlib import Path
from typing import Any

import jsonschema
import yaml

from cas_runner.io import get_workspace_root


class RoadmapBootstrapStep:
    name = "roadmap-bootstrap"

    def prepare_inputs(self, context):
        project = context.get("project", "ideas-to-life-cas")
        workspace_root = get_workspace_root()
        roadmap_dir = workspace_root / "projects" / project / "roadmap"

        # Merge configuration variables
        dry_run = context.get("config", {}).get("dry_run", False) or context.get("dry_run", False)

        return {
            "project": project,
            "roadmap_dir": str(roadmap_dir),
            "dry_run": dry_run
        }

    def _load_schema(self, schema_name: str) -> dict:
        schema_path = Path(__file__).parent.parent / "schemas" / schema_name
        with open(schema_path) as f:
            return json.load(f)

    def _load_yaml(self, path: Path) -> dict:
        if not path.exists():
            raise FileNotFoundError(f"Required configuration file missing: {path}")
        with open(path) as f:
            return yaml.safe_load(f)

    def _get_headers(self) -> dict:
        token = (
            os.environ.get("CAS_PERSONAL_ACCESS_TOKEN")
            or os.environ.get("GITHUB_MCP_PAT")
            or os.environ.get("GITHUB_PERSONAL_ACCESS_TOKEN")
        )
        if not token:
            if not self.dry_run:
                raise ValueError("None of CAS_PERSONAL_ACCESS_TOKEN, GITHUB_MCP_PAT, or GITHUB_PERSONAL_ACCESS_TOKEN is set in the environment.")
            token = "dummy-token-for-dry-run"
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "User-Agent": "CAS-Roadmap-Bootstrap",
            "X-Github-Next-Global-ID": "1"
        }

    def _make_github_request(self, url: str, method: str = "GET", data: dict = None) -> Any:
        import urllib.error
        import urllib.request

        headers = self._get_headers()
        req_data = json.dumps(data).encode("utf-8") if data is not None else None

        req = urllib.request.Request(url, headers=headers, method=method, data=req_data)
        try:
            with urllib.request.urlopen(req) as res:
                return json.loads(res.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8")
            raise Exception(f"GitHub API Error: {e.code} {e.reason} - {err_body}")

    def _query_graphql(self, query: str, variables: dict = None) -> dict:
        url = "https://api.github.com/graphql"
        payload = {"query": query}
        if variables:
            payload["variables"] = variables
        res = self._make_github_request(url, method="POST", data=payload)
        if res and "errors" in res:
            raise Exception(f"GraphQL Error: {res['errors']}")
        return res

    def execute(self, inputs, reasoning_engine):
        self.dry_run = inputs.get("dry_run", False)
        roadmap_dir = Path(inputs["roadmap_dir"])

        roadmap_path = roadmap_dir / "roadmap.yaml"
        initiatives_path = roadmap_dir / "initiatives.yaml"
        items_path = roadmap_dir / "roadmap-items.yaml"

        # Load and parse files
        roadmap = self._load_yaml(roadmap_path)
        initiatives_data = self._load_yaml(initiatives_path)
        items_data = self._load_yaml(items_path)

        # Validate against JSON Schemas
        jsonschema.validate(instance=roadmap, schema=self._load_schema("roadmap_schema.json"))
        jsonschema.validate(instance=initiatives_data, schema=self._load_schema("initiatives_schema.json"))
        jsonschema.validate(instance=items_data, schema=self._load_schema("roadmap_items_schema.json"))

        # Unique validations
        initiative_ids = set()
        initiative_names = []
        for init in initiatives_data["initiatives"]:
            init_id = init["id"]
            if init_id in initiative_ids:
                raise ValueError(f"Duplicate initiative ID found: '{init_id}'")
            initiative_ids.add(init_id)
            initiative_names.append(init["name"])

        item_titles = set()
        for item in items_data["items"]:
            title = item["title"]
            if title in item_titles:
                raise ValueError(f"Duplicate roadmap item title found: '{title}'")
            item_titles.add(title)

        for item in items_data["items"]:
            init_id = item["initiative"]
            if init_id not in initiative_ids:
                raise ValueError(f"Roadmap item '{item['title']}' references unknown initiative: '{init_id}'")

        # Dynamically inject Initiative select options into fields configuration
        has_initiative_field = False
        for field in roadmap.get("fields", []):
            if field["name"].lower() == "initiative":
                field["options"] = initiative_names
                has_initiative_field = True
                break
        if not has_initiative_field:
            roadmap.setdefault("fields", []).append({
                "name": "Initiative",
                "type": "single_select",
                "options": initiative_names
            })

        field_options = {}
        for field in roadmap.get("fields", []):
            if field.get("type") == "single_select":
                field_options[field["name"].lower()] = field.get("options", [])

        if "priority" in field_options:
            for item in items_data["items"]:
                prio = item["priority"]
                if prio not in field_options["priority"]:
                    raise ValueError(f"Roadmap item '{item['title']}' has invalid priority '{prio}'. Must be one of: {field_options['priority']}")

        if "lifecycle" in field_options:
            for item in items_data["items"]:
                status = item["lifecycle"]
                if status not in field_options["lifecycle"]:
                    raise ValueError(f"Roadmap item '{item['title']}' has invalid lifecycle '{status}'. Must be one of: {field_options['lifecycle']}")

        if "complexity" in field_options:
            for item in items_data["items"]:
                comp = item["complexity"]
                if comp not in field_options["complexity"]:
                    raise ValueError(f"Roadmap item '{item['title']}' has invalid complexity '{comp}'. Must be one of: {field_options['complexity']}")

        if "value" in field_options:
            for item in items_data["items"]:
                val = item["value"]
                if val not in field_options["value"]:
                    raise ValueError(f"Roadmap item '{item['title']}' has invalid value '{val}'. Must be one of: {field_options['value']}")

        if "effort" in field_options:
            for item in items_data["items"]:
                eff = item["effort"]
                if eff not in field_options["effort"]:
                    raise ValueError(f"Roadmap item '{item['title']}' has invalid effort '{eff}'. Must be one of: {field_options['effort']}")

        if "strategic pillar" in field_options:
            for item in items_data["items"]:
                pillar = item["strategic_pillar"]
                if pillar not in field_options["strategic pillar"]:
                    raise ValueError(f"Roadmap item '{item['title']}' has invalid strategic_pillar '{pillar}'. Must be one of: {field_options['strategic pillar']}")

        # -------------------------------------------------------------
        # Live/Dry Run execution against GitHub
        # -------------------------------------------------------------
        owner = roadmap["owner"]
        repo = roadmap["repo"]
        project_title = roadmap["title"]

        # Step 1: Get Owner ID (organization or user login node ID)
        owner_id = None
        if self.dry_run:
            print(f"[DRY-RUN] Would fetch owner ID for: '{owner}'")
            owner_id = "dry-run-owner-id"
        else:
            owner_query = """
            query GetOwnerId($login: String!) {
              repositoryOwner(login: $login) {
                id
              }
            }
            """
            res = self._query_graphql(owner_query, {"login": owner})
            owner_data = res.get("data", {}).get("repositoryOwner")
            if not owner_data:
                raise Exception(f"GitHub user or organization '{owner}' not found.")
            owner_id = owner_data["id"]

        # Step 2: Get or Create Project v2
        project_id = None
        project_url = None
        if self.dry_run:
            print(f"[DRY-RUN] Would list existing projects or create Project v2: '{project_title}'")
            project_id = "dry-run-project-id"
            project_url = "https://github.com/dry-run-project"
        else:
            projects_query = """
            query GetProjects($login: String!) {
              repositoryOwner(login: $login) {
                ... on User {
                  projectsV2(first: 100) {
                    nodes {
                      id
                      title
                      number
                      url
                    }
                  }
                }
                ... on Organization {
                  projectsV2(first: 100) {
                    nodes {
                      id
                      title
                      number
                      url
                    }
                  }
                }
              }
            }
            """
            res = self._query_graphql(projects_query, {"login": owner})
            owner_data = res.get("data", {}).get("repositoryOwner") or {}
            # Try user projectsV2 first, then organization projectsV2
            projects_data = owner_data.get("projectsV2") or {}
            nodes = projects_data.get("nodes", []) or []
            for node in nodes:
                if not node:
                    continue
                if node["title"] == project_title:
                    project_id = node["id"]
                    project_url = node["url"]
                    print(f"Reusing existing GitHub Project v2: '{project_title}' ({project_id})")
                    break

            if not project_id:
                create_mutation = """
                mutation CreateProject($ownerId: ID!, $title: String!) {
                  createProjectV2(input: {ownerId: $ownerId, title: $title}) {
                    projectV2 {
                      id
                      number
                      url
                    }
                  }
                }
                """
                res = self._query_graphql(create_mutation, {"ownerId": owner_id, "title": project_title})
                proj_data = res.get("data", {}).get("createProjectV2", {}).get("projectV2")
                if not proj_data:
                    raise Exception(f"Failed to create Project v2: {res}")
                project_id = proj_data["id"]
                project_url = proj_data["url"]
                print(f"Created new GitHub Project v2: '{project_title}' ({project_id})")

        # Step 3: Get or Create Project Custom Fields
        field_mappings = {}  # field_name.lower() -> {id, type, options: {option_name.lower() -> option_id}}
        if self.dry_run:
            print(f"[DRY-RUN] Would verify and create custom fields: {[f['name'] for f in roadmap.get('fields', [])]}")
            for field in roadmap.get("fields", []):
                fname = field["name"]
                field_mappings[fname.lower()] = {
                    "id": f"dry-run-field-{fname.lower()}",
                    "type": field["type"],
                    "options": {opt.lower(): f"dry-run-opt-{opt.lower()}" for opt in field.get("options", [])}
                }
        else:
            # Query existing project fields
            fields_query = """
            query GetProjectFields($projectId: ID!) {
              node(id: $projectId) {
                ... on ProjectV2 {
                  fields(first: 50) {
                    nodes {
                      ... on ProjectV2Field {
                        id
                        name
                        dataType
                      }
                      ... on ProjectV2SingleSelectField {
                        id
                        name
                        dataType
                        options {
                          id
                          name
                        }
                      }
                    }
                  }
                }
              }
            }
            """
            res = self._query_graphql(fields_query, {"projectId": project_id})
            existing_fields = res.get("data", {}).get("node", {}).get("fields", {}).get("nodes", [])
            for field in existing_fields:
                fname = field["name"]
                ftype = "single_select" if field["dataType"] == "SINGLE_SELECT" else "number"
                opts = {}
                if "options" in field:
                  for opt in field["options"]:
                      opts[opt["name"].lower()] = opt["id"]
                field_mappings[fname.lower()] = {
                    "id": field["id"],
                    "type": ftype,
                    "options": opts
                }

            # Create missing fields
            for field in roadmap.get("fields", []):
                fname = field["name"]
                ftype = field["type"]
                if fname.lower() not in field_mappings:
                    if ftype == "number":
                        create_num_mutation = """
                        mutation CreateNumberField($projectId: ID!, $name: String!) {
                          createProjectV2Field(input: {
                            projectId: $projectId
                            name: $name
                            dataType: NUMBER
                          }) {
                            projectV2Field {
                              id
                              name
                            }
                          }
                        }
                        """
                        res = self._query_graphql(create_num_mutation, {"projectId": project_id, "name": fname})
                        f_data = res.get("data", {}).get("createProjectV2Field", {}).get("projectV2Field")
                        if not f_data:
                            raise Exception(f"Failed to create field '{fname}': {res}")
                        field_mappings[fname.lower()] = {
                            "id": f_data["id"],
                            "type": "number",
                            "options": {}
                        }
                        print(f"Created custom number field: '{fname}'")
                    elif ftype == "single_select":
                        opts_input = []
                        for opt in field.get("options", []):
                            color_val = "GRAY"
                            desc_val = ""
                            if fname.lower() == "initiative":
                                for init in initiatives_data.get("initiatives", []):
                                    if init.get("name") == opt:
                                        desc_val = init.get("description", "")
                                        c = init.get("color", "").upper().lstrip("#")
                                        color_mapping = {
                                            "0e8a16": "GREEN",
                                            "d4c5f9": "PURPLE",
                                            "f9d0c4": "ORANGE",
                                            "c2e0c6": "GREEN",
                                            "bfdadc": "BLUE",
                                            "fef2c0": "YELLOW",
                                            "1d76db": "BLUE",
                                            "5319e7": "PURPLE"
                                        }
                                        if c in color_mapping:
                                            color_val = color_mapping[c]
                                        elif c in ["BLUE", "GRAY", "GREEN", "ORANGE", "PINK", "PURPLE", "RED", "YELLOW"]:
                                            color_val = c
                                        break
                            opts_input.append({
                                "name": opt,
                                "color": color_val,
                                "description": desc_val
                            })
                        create_ss_mutation = """
                        mutation CreateSingleSelectField($projectId: ID!, $name: String!, $options: [ProjectV2SingleSelectFieldOptionInput!]!) {
                          createProjectV2Field(input: {
                            projectId: $projectId
                            name: $name
                            dataType: SINGLE_SELECT
                            singleSelectOptions: $options
                          }) {
                            projectV2Field {
                              ... on ProjectV2SingleSelectField {
                                id
                                name
                                options {
                                  id
                                  name
                                }
                              }
                            }
                          }
                        }
                        """
                        res = self._query_graphql(create_ss_mutation, {"projectId": project_id, "name": fname, "options": opts_input})
                        f_data = res.get("data", {}).get("createProjectV2Field", {}).get("projectV2Field")
                        if not f_data:
                            raise Exception(f"Failed to create field '{fname}': {res}")
                        opts = {opt["name"].lower(): opt["id"] for opt in f_data.get("options", [])}
                        field_mappings[fname.lower()] = {
                            "id": f_data["id"],
                            "type": "single_select",
                            "options": opts
                        }
                        print(f"Created custom single-select field: '{fname}'")

        # Step 4: Verify and Create Labels in the repository
        existing_labels = []
        if self.dry_run:
            print(f"[DRY-RUN] Would fetch and configure repository labels: {[l['name'] for l in roadmap.get('labels', [])]}")
        else:
            labels_url = f"https://api.github.com/repos/{owner}/{repo}/labels"
            existing_labels_data = self._make_github_request(labels_url)
            existing_labels = [l["name"].lower() for l in existing_labels_data]

            for label in roadmap.get("labels", []):
                lname = label["name"]
                color = label["color"]
                desc = label.get("description", "")
                if lname.lower() not in existing_labels:
                    self._make_github_request(labels_url, method="POST", data={
                        "name": lname,
                        "color": color,
                        "description": desc
                    })
                    print(f"Created repository label: '{lname}'")

        # Step 5: Get or Create Issues for Roadmap Items
        issue_mappings = {}  # item_title -> issue_node_id
        if self.dry_run:
            print(f"[DRY-RUN] Would check and create issues for items: {[item['title'] for item in items_data['items']]}")
            for item in items_data["items"]:
                issue_mappings[item["title"]] = f"dry-run-issue-node-id-{item['title'].lower().replace(' ', '-')}"
        else:
            # Query existing repository issues
            issues_url = f"https://api.github.com/repos/{owner}/{repo}/issues?state=all&per_page=100"
            existing_issues = self._make_github_request(issues_url)

            for item in items_data["items"]:
                title = item["title"]
                desc = item.get("description", "")
                init_id = item["initiative"]

                # Resolve initiative label name
                label_name = f"initiative/{init_id}"

                # Check for existing issue by title
                existing_issue = None
                for issue in existing_issues:
                    if issue["title"] == title:
                        existing_issue = issue
                        break

                if existing_issue:
                    issue_node_id = existing_issue["node_id"]
                    print(f"Reusing existing issue: '{title}' ({issue_node_id})")
                else:
                    create_issue_url = f"https://api.github.com/repos/{owner}/{repo}/issues"
                    issue_res = self._make_github_request(create_issue_url, method="POST", data={
                        "title": title,
                        "body": desc,
                        "labels": [label_name]
                    })
                    issue_node_id = issue_res["node_id"]
                    print(f"Created new repository issue: '{title}' ({issue_node_id})")

                issue_mappings[title] = issue_node_id

        # Step 6: Map Issues to Project Items and Populate Field Values
        if self.dry_run:
            print("[DRY-RUN] Would associate issues with Project and update custom metadata values.")
            print(f"[DRY-RUN] Would simulate provisioning project views: {[v['name'] for v in roadmap.get('views', [])]}")
        elif items_data["items"]:
            # Get existing project items to prevent duplicates
            items_query = """
            query GetProjectItems($projectId: ID!) {
              node(id: $projectId) {
                ... on ProjectV2 {
                  items(first: 100) {
                    nodes {
                      id
                      content {
                        ... on Issue {
                          id
                        }
                      }
                    }
                  }
                }
              }
            }
            """
            res = self._query_graphql(items_query, {"projectId": project_id})
            nodes = res.get("data", {}).get("node", {}).get("items", {}).get("nodes", [])
            existing_project_items = {} # issue_node_id -> project_item_id
            for node in nodes:
                content = node.get("content")
                if content:
                    existing_project_items[content["id"]] = node["id"]

            for item in items_data["items"]:
                title = item["title"]
                issue_node_id = issue_mappings[title]

                project_item_id = None
                if issue_node_id in existing_project_items:
                    project_item_id = existing_project_items[issue_node_id]
                    print(f"Issue '{title}' already mapped to Project item: {project_item_id}")
                else:
                    add_item_mutation = """
                    mutation AddProjectItem($projectId: ID!, $contentId: ID!) {
                      addProjectV2ItemById(input: {projectId: $projectId, contentId: $contentId}) {
                        item {
                          id
                        }
                      }
                    }
                    """
                    res = self._query_graphql(add_item_mutation, {"projectId": project_id, "contentId": issue_node_id})
                    item_res = res.get("data", {}).get("addProjectV2ItemById", {}).get("item")
                    if not item_res:
                        raise Exception(f"Failed to map issue '{title}' to project: {res}")
                    project_item_id = item_res["id"]
                    print(f"Mapped issue '{title}' to Project item: {project_item_id}")

                # Update custom fields for this item
                for key in ["lifecycle", "priority", "initiative", "value", "effort", "complexity", "strategic_pillar"]:
                    if key not in item:
                        continue

                    val = item[key]

                    # Convert raw initiative ID key (e.g. 'runtime') to human initiative name (e.g. 'Runtime')
                    if key == "initiative":
                        for init in initiatives_data["initiatives"]:
                            if init["id"] == val:
                                val = init["name"]
                                break

                    field_key = "strategic pillar" if key == "strategic_pillar" else key
                    field_info = field_mappings.get(field_key)
                    if not field_info:
                        continue

                    field_id = field_info["id"]

                    if field_info["type"] == "number":
                        update_num_mutation = """
                        mutation UpdateNumberFieldValue($projectId: ID!, $itemId: ID!, $fieldId: ID!, $value: Float!) {
                          updateProjectV2ItemFieldValue(input: {
                            projectId: $projectId
                            itemId: $itemId
                            fieldId: $fieldId
                            value: { number: $value }
                          }) {
                            projectV2Item { id }
                          }
                        }
                        """
                        self._query_graphql(update_num_mutation, {
                            "projectId": project_id,
                            "itemId": project_item_id,
                            "fieldId": field_id,
                            "value": float(val)
                        })
                    elif field_info["type"] == "single_select":
                        # Resolve single select option ID
                        option_id = field_info["options"].get(str(val).lower())
                        if option_id:
                            update_ss_mutation = """
                            mutation UpdateSingleSelectFieldValue($projectId: ID!, $itemId: ID!, $fieldId: ID!, $optionId: String!) {
                              updateProjectV2ItemFieldValue(input: {
                                projectId: $projectId
                                itemId: $itemId
                                fieldId: $fieldId
                                value: { singleSelectOptionId: $optionId }
                              }) {
                                projectV2Item { id }
                              }
                            }
                            """
                            self._query_graphql(update_ss_mutation, {
                                "projectId": project_id,
                                "itemId": project_item_id,
                                "fieldId": field_id,
                                "optionId": option_id
                            })
                            print(f"Updated field '{key}' to '{val}' on item '{title}'")

            # Print warnings for configuring views on GitHub (API limitation workaround)
            print("[CAS][INFO] Creating/configuring ProjectV2 views is currently not supported by the GitHub API.")
            print("Please manually configure the following views in your Project v2 UI:")
            for view in roadmap.get("views", []):
                print(f" - View Name: '{view['name']}' (Layout: {view['layout']})")

        return {
            "status": "validated",
            "roadmap": roadmap,
            "initiatives": initiatives_data["initiatives"],
            "items": items_data["items"]
        }

    def validate(self, output):
        assert "status" in output
        assert output["status"] == "validated"
        assert "roadmap" in output
        assert "initiatives" in output
        assert "items" in output
