import json
from pathlib import Path
from typing import Any

from jsonschema import ValidationError, validate
from cas_runner.io import resolve_pattern_details


class ReferenceArchitectureGenerator:
    """Step that synthesizes standardized 8-section Reference Architectures

    for promoted patterns in pattern-promotion-recommendations.yaml.
    """

    name = "reference-architecture-generator"

    def prepare_inputs(self, context: dict[str, Any]) -> dict[str, Any]:
        project = context.get("project", "default")
        recs_data = context.get("pattern_promotion_recommendations") or {}

        recommendations = []
        if isinstance(recs_data, dict):
            recommendations = recs_data.get("promotion_candidates") or recs_data.get("recommendations", [])
        elif isinstance(recs_data, list):
            recommendations = recs_data

        promoted = []
        for rec in recommendations:
            if isinstance(rec, dict) and rec.get("recommendation") == "promote":
                promoted.append(rec)

        return {
            "project": project,
            "promoted_candidates": promoted,
            "governance_context": context.get("governance_context", {}),
        }

    def execute(self, inputs: dict[str, Any], reasoning_engine: Any) -> dict[str, Any]:
        promoted_candidates = inputs.get("promoted_candidates", [])
        project = inputs.get("project", "default")

        if not promoted_candidates:
            print(f"[CAS][INFO] No promoted candidates found for '{self.name}'. Skipping generation.")
            return {"reference_architectures": []}

        if reasoning_engine is None:
            return {"reference_architectures": []}

        reference_architectures = []

        for candidate in promoted_candidates:
            pattern_id = candidate.get("pattern_id")
            if not pattern_id:
                continue

            pattern_details = resolve_pattern_details(project, pattern_id) or {}

            reasoning_inputs = {
                "candidate": candidate,
                "pattern_details": pattern_details,
                "project_name": project,
                "governance_context": inputs.get("governance_context", {}),
            }

            llm_response = reasoning_engine.reason(self.name, reasoning_inputs)

            if isinstance(llm_response, str):
                try:
                    llm_response = json.loads(llm_response)
                except json.JSONDecodeError:
                    print(f"[CAS][ERROR] Failed to parse reasoning response for '{self.name}' on pattern '{pattern_id}'")
                    continue

            if isinstance(llm_response, dict):
                # If markdown_content is missing, assemble basic markdown if fields exist
                if "markdown_content" not in llm_response and "pattern_name" in llm_response:
                    llm_response["markdown_content"] = self._render_markdown(llm_response)

                reference_architectures.append(llm_response)
            elif isinstance(llm_response, list):
                for item in llm_response:
                    if isinstance(item, dict):
                        if "markdown_content" not in item and "pattern_name" in item:
                            item["markdown_content"] = self._render_markdown(item)
                        reference_architectures.append(item)

        return {"reference_architectures": reference_architectures}

    def validate(self, output: dict[str, Any]) -> None:
        assert "reference_architectures" in output, "Missing 'reference_architectures' in output"
        ref_list = output["reference_architectures"]

        schema_path = Path(__file__).parent.parent / "schemas" / "reference_architecture_schema.json"
        if schema_path.exists():
            with open(schema_path, encoding="utf-8") as f:
                schema = json.load(f)
            for item in ref_list:
                validate(instance=item, schema=schema)
        else:
            required_keys = [
                "pattern_id",
                "pattern_name",
                "purpose_when_to_use",
                "overview_mermaid",
                "components",
                "technology_choices",
                "variants",
                "non_functional_characteristics",
                "anti_patterns",
                "adoption_guidance",
                "markdown_content",
            ]
            for item in ref_list:
                for key in required_keys:
                    assert key in item, f"Missing required key '{key}' in Reference Architecture item"

    def _render_markdown(self, data: dict[str, Any]) -> str:
        name = data.get("pattern_name", "Architecture Pattern")
        purpose = data.get("purpose_when_to_use", "")
        mermaid = data.get("overview_mermaid", "").strip()
        components = data.get("components", [])
        tech = data.get("technology_choices", "")
        variants = data.get("variants", "")
        nfr = data.get("non_functional_characteristics", "")
        anti = data.get("anti_patterns", "")
        adoption = data.get("adoption_guidance", "")
        related = data.get("related_links", [])

        md = f"# Reference Architecture: {name}\n\n"
        md += f"## Purpose & when to use this\n\n{purpose}\n\n"
        md += f"## Overview\n\n```mermaid\n{mermaid}\n```\n\n"
        md += "## Components\n\n"
        for comp in components:
            cname = comp.get("name", "Component")
            cpath = comp.get("path", "")
            cresp = comp.get("responsibility", "")
            path_str = f" (`{cpath}`)" if cpath else ""
            md += f"- **{cname}{path_str}:** {cresp}\n"
        md += "\n"
        md += f"## Technology choices\n\n{tech}\n\n"
        md += f"## Variants\n\n{variants}\n\n"
        md += f"## Non-functional characteristics\n\n{nfr}\n\n"
        md += f"## Anti-patterns & known pitfalls\n\n{anti}\n\n"
        md += f"## Adoption guidance\n\n{adoption}\n\n"
        md += "## Related\n\n"
        if related:
            for rel in related:
                rtitle = rel.get("title", "Related Document")
                rpath = rel.get("path", "")
                md += f"- [{rtitle}]({rpath})\n"
        else:
            md += "None.\n"

        return md
