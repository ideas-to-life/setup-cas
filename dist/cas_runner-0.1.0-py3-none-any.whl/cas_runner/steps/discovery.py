from datetime import date

from ..io import load_foundational_assets


class BaselineDiscoveryStep:
    name = "baseline-discovery"

    def prepare_inputs(self, context: dict) -> dict:
        project = context.get("project_context") or context.get("project")
        assets = load_foundational_assets(project)
        project_id = project.project_id if hasattr(project, "project_id") else str(project)
        return {"assets": assets, "project": project_id}

    def execute(self, inputs: dict, reasoning_engine) -> dict:
        # Prompt LLM to synthesize baseline
        # Use 'reason' method of ReasoningExecutionContract
        output = reasoning_engine.reason("baseline-discovery", inputs)

        if "baseline_assessment" not in output:
            # Fallback or partial output
            return output

        # Ensure date provenance (current execution date)
        today = date.today().isoformat()
        if "frontmatter" in output["baseline_assessment"]:
            output["baseline_assessment"]["frontmatter"]["date"] = today

        # US3: Map architecture work candidates to the orchestration context
        # This allows the AlignmentEngine and persist_outputs to see them
        candidates = output["baseline_assessment"].get("sections", {}).get("architecture_work_candidates", [])
        project = inputs.get("project")
        today = date.today().isoformat()

        aw_items = []
        for i, cand in enumerate(candidates):
            description = cand.get("description", "")
            rationale = cand.get("rationale", "")
            priority = cand.get("priority", "medium")

            # Derive title, initiative, and category from description
            desc_lower = description.lower()
            if "execute initial discovery flow" in desc_lower:
                title = "Execute Initial Discovery Flow"
                initiative = "Baseline Discovery"
                category = "workflow"
            elif "create initial architecture decision record" in desc_lower or "core orchestration pipeline" in desc_lower:
                title = "Create Initial ADR for Core Orchestration Pipeline"
                initiative = "Governance Foundation"
                category = "governance"
            elif "validate and populate knowledge layer templates" in desc_lower:
                title = "Validate and Populate Knowledge Layer Templates"
                initiative = "Knowledge Provider"
                category = "model"
            elif "implement automated ci validation" in desc_lower:
                title = "Implement Automated CI Validation"
                initiative = "GovernanceOps"
                category = "automation"
            else:
                title = description.split(".")[0].strip()
                if len(title) > 60:
                    title = title[:57] + "..."

                if "ci validation" in desc_lower or "cas skill enforcement" in desc_lower or "automated ci" in desc_lower:
                    initiative = "GovernanceOps"
                    category = "automation"
                elif "adr" in desc_lower or "orchestration" in desc_lower or "decision record" in desc_lower:
                    initiative = "Governance Foundation"
                    category = "governance"
                elif "knowledge layer templates" in desc_lower or "patterns" in desc_lower or "rules" in desc_lower:
                    initiative = "Knowledge Provider"
                    category = "model"
                else:
                    initiative = "Baseline Discovery"
                    category = "workflow"

            aw_items.append({
                "frontmatter": {
                    "id": f"aw-discovery-{project}-{i+1}",
                    "knowledgeType": "architecture_work",
                    "project": project,
                    "title": title,
                    "date": today,
                    "status": "proposed",
                    "source": "discovery",
                    "initiative": initiative,
                    "category": category,
                    "priority": priority,
                    "related_work": []
                },
                "sections": {
                    "summary": description,
                    "details": rationale
                }
            })

        if aw_items:
            output["architecture_work"] = aw_items

        return output

    def validate(self, output: dict):
        assert "baseline_assessment" in output
