from datetime import date, datetime
from typing import Any

from .rules import RuleEvaluator
from .signals import SignalAnalyzer


class AlignmentEngine:
    """Alignment Engine step in the CAS orchestration flow.

    Evaluates architecture work against governance rules, analyzes signals,
    and performs LLM-powered reasoning to produce an alignment report.
    """

    name = "alignment-engine"

    # Shared severity mapping from RuleEvaluator format to expected format
    SEVERITY_MAP = {
        "critical": "critical",
        "major": "high",
        "high": "high",
        "medium": "medium",
        "minor": "medium",
        "low": "low",
    }

    def __init__(self) -> None:
        """Initialize the AlignmentEngine with rule and signal analyzers."""
        self.rules = RuleEvaluator()
        self.signals = SignalAnalyzer()

    def prepare_inputs(self, context: dict[str, Any]) -> dict[str, Any]:
        """Prepare inputs for the alignment engine execution.

        Extracts and combines context into the expected input structure.

        Args:
            context: The context dictionary containing configuration and data.

        Returns:
            A dictionary with keys: aem, architecture_work, rule_context, aid,
            flow_name, step_name, prompt_base_path.
        """
        config = context.get("config", {})
        # Get the AEM data from the context (stored under the "aem" key)
        aem = context.get("aem", {})
        aid = context.get("aid", {})
        return {
            "aem": aem,
            "architecture_work": context.get("architecture_work", []),
            "rule_context": context.get("rule_context"),
            "aid": aid if aid else context.get("baseline_assessment"),
            "project": context.get("project"),
            "date": context.get("date", date.today().isoformat()),
            "flow_name": context.get("flow_name", "orchestration-flow"),
            "step_name": self.name,
            "prompt_base_path": config.get("prompt_base_path", "src/prompts"),
        }

    def execute(self, inputs: dict[str, Any], reasoning_engine: Any) -> dict[str, Any]:
        """Execute the alignment engine step.

        Processes architecture work through rule evaluation, signal analysis,
        and LLM reasoning to produce an alignment report.

        Args:
            inputs: The prepared inputs dictionary.
            reasoning_engine: An engine capable of reasoning (can be None).

        Returns:
            A dictionary containing frontmatter and sections for the alignment report.

        Raises:
            RuntimeError: If rule evaluation or signal analysis fails unexpectedly.
        """
        aw_items = inputs.get("architecture_work", [])
        aem = inputs.get("aem", {})

        try:
            # 1. Deterministic Rule Evaluation
            rule_findings, rule_aw = self.rules.evaluate(aw_items)
        except Exception as e:
            raise RuntimeError(f"Rule evaluation failed: {e}") from e

        try:
            # 2. Signal Analysis
            signal_findings, signal_aw = self.signals.analyze(aw_items, aem)
        except Exception as e:
            raise RuntimeError(f"Signal analysis failed: {e}") from e

        # 3. LLM-Powered Reasoning (Unified Contract)
        if reasoning_engine is None:
            llm_response = {}
        else:
            llm_response = reasoning_engine.reason(self.name, inputs)

        # Parse LLM response
        llm_findings = llm_response.get("sections",{}).get("alignment_findings", [])
        llm_aw = llm_response.get("sections",{}).get("architecture_work_derived", [])

        # Merge results
        findings = rule_findings + signal_findings + llm_findings
        derived_aw = rule_aw + signal_aw + llm_aw

        # Transform findings to the expected format for alignment_findings and findings_readable_summary
        alignment_findings = []
        findings_readable_summary = []
        for finding in findings:
            # Map severity using the shared map
            severity = self.SEVERITY_MAP.get(finding.get("severity", "medium"), "medium")

            # Build alignment_finding (detailed)
            alignment_finding = {
                "id": finding.get("id", ""),
                "knowledgeType": "alignment_finding",
                "project": self._get_project_from_aem(aem),
                "date": date.today().isoformat(),
                "category": finding.get("type", "unspecified"),
                "severity": severity,
                "severity_rationale": finding.get("severity_rationale", ""),
                "description": finding.get("description", ""),
                "evidence": finding.get("evidence", []),
                "violated_rules": finding.get("violated_rules", []),
                "related_signals": finding.get("related_signals", []),
                "recommendation": finding.get("recommendation", ""),
                "status": finding.get("status", "open"),
                "confidence": finding.get("confidence", "medium")
            }
            alignment_findings.append(alignment_finding)

            # Build simplified finding for readable summary
            readable_finding = {
                "id": finding.get("id", ""),
                "category": finding.get("type", "unspecified"),
                "severity": severity,
                "severity_rationale": finding.get("severity_rationale", ""),
                "description": finding.get("description", ""),
                "recommendation": finding.get("recommendation", "")
            }
            findings_readable_summary.append(readable_finding)

        # Compute alignment summary using the shared severity map
        critical_issues = sum(1 for f in findings if self.SEVERITY_MAP.get(f.get("severity", "medium"), "medium") == "critical")
        high_issues = sum(1 for f in findings if self.SEVERITY_MAP.get(f.get("severity", "medium"), "medium") == "high")
        medium_issues = sum(1 for f in findings if self.SEVERITY_MAP.get(f.get("severity", "medium"), "medium") == "medium")
        low_issues = sum(1 for f in findings if self.SEVERITY_MAP.get(f.get("severity", "medium"), "medium") == "low")

        if critical_issues > 0:
            overall_status = "critical"
        elif high_issues > 0 or medium_issues > 0:
            overall_status = "partially_aligned"
        else:
            overall_status = "aligned"

        alignment_summary = {
            "overall_status": overall_status,
            "critical_issues": critical_issues,
            "high_issues": high_issues,
            "medium_issues": medium_issues,
            "low_issues": low_issues
        }

        # Transform derived architecture work to the expected format
        architecture_work_derived = []
        for aw in derived_aw:
            aw_transformed = {
                "id": aw.get("id", ""),
                "knowledgeType": "architecture_work",
                "source": aw.get("source", "alignment_engine"),
                "origin_ref": aw.get("origin_ref", ""),
                "type": aw.get("type", "unspecified"),
                "priority": aw.get("priority", "medium"),
                "status": aw.get("status", "proposed"),
                "confidence": aw.get("confidence", "medium"),
                "description": aw.get("description", aw.get("summary", ""))
            }
            architecture_work_derived.append(aw_transformed)

        # Build frontmatter
        frontmatter = {
            "id": f"alignment-report-{self._get_project_from_aem(aem)}-{date.today().isoformat()}-1",
            "knowledgeType": "alignment_report",
            "project": self._get_project_from_aem(aem),
            "date": date.today().isoformat(),
            "generated_at": datetime.now().isoformat(),
            "aem_source": aem.get("frontmatter", {}).get("id", ""),
            "aid_source": llm_response.get("frontmatter", {}).get("aid_source",""),
            "rules_applied": llm_response.get("frontmatter", {}).get("rules_applied",0),  # Number of rule-based findings
            "overall_status": alignment_summary.get("overall_status", "unknown"),
            "critical_issues": alignment_summary.get("critical_issues", 0),
            "high_issues": alignment_summary.get("high_issues", 0),
            "medium_issues": alignment_summary.get("medium_issues", 0),
            "low_issues": alignment_summary.get("low_issues", 0)
        }

        # Build sections
        # Note: traceability_matrix and rules_applied_detail are deferred for future implementation.
        sections = {
            "alignment_summary": alignment_summary,
            "alignment_findings": alignment_findings,
            "findings_readable_summary": findings_readable_summary,
            "architecture_work_derived": architecture_work_derived,
            "traceability_matrix": llm_response.get("sections", {}).get("traceability_matrix",[]),  # Deferred: not required for current scope
            "rules_applied_detail": llm_response.get("sections", {}).get("rules_applied_detail",[]),  # Deferred: not required for current scope
        }

        alignment_report_data = {
            "frontmatter": frontmatter,
            "sections": sections
        }
        return {
            "alignment_report": alignment_report_data
        }

    def _get_project_from_aem(self, aem: dict[str, Any]) -> str:
        """Extract project ID from AEM frontmatter.

        Args:
            aem: The AEM dictionary containing frontmatter and sections.

        Returns:
            The project ID string, or "unknown" if not found.
        """
        frontmatter = aem.get("frontmatter", {})
        return frontmatter.get("project", "unknown")

    def validate(self, output: dict[str, Any]) -> None:
        """Validate the output of the alignment engine.

        Args:
            output: The output dictionary from execute.

        Raises:
            ValueError: If the output does not contain the required keys.
        """
        if "alignment_report" not in output:
            raise ValueError("Output must contain 'alignment_report'")
        alignment_report_data = output["alignment_report"]
        if "frontmatter" not in alignment_report_data:
            raise ValueError("Alignment report data must contain 'frontmatter'")
        if "sections" not in alignment_report_data:
            raise ValueError("Alignment report data must contain 'sections'")
