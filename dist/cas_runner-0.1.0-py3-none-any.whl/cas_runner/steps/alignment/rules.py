from datetime import date


class RuleEvaluator:
    def evaluate(self, aw_items):
        findings = []
        derived_aw = []

        # Rule 1: No architecture work → no signal
        if not aw_items:
            findings.append({
                "id": "no-aw",
                "type": "missing",
                "severity": "major",
                "dimension": "signals",
                "description": "No architecture_work found. System has no input signals.",
            })

        # Rule 2: Too many proposed without progress
        proposed_count = sum(1 for aw in aw_items if aw.get("status") == "proposed")

        if proposed_count > 5:
            findings.append({
                "id": "too-many-proposals",
                "type": "drift",
                "severity": "minor",
                "dimension": "execution",
                "description": f"{proposed_count} proposed items without progression.",
            })

            derived_aw.append({
                "id": f"aw-align-{proposed_count}",
                "knowledgeType": "architecture_work",
                "type": "proposal",
                "status": "proposed",
                "source": "alignment_engine",
                "summary": "Too many unprogressed proposals",
                "details": f"{proposed_count} items remain proposed without governance progression.",
                "date": date.today().isoformat(),
            })

        return findings, derived_aw
