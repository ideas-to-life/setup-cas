import json
from datetime import date
from pathlib import Path

from jsonschema import ValidationError, validate


class SignalToPatternProposals:
    name = "signal-to-pattern-proposals"

    def prepare_inputs(self, context):
        return {
            "architectural_state": context.get("architectural_state"),
            "architecture_work": context.get("architecture_work", []),
            "alignment_findings": context.get("alignment_report"),
            "aem": context.get("aem"),
            "existing_patterns": context.get("patterns", []),
            "project": context.get("project"),
            "date": context.get("date", date.today().isoformat()),
        }

    def execute(self, inputs, reasoning_engine):
        if reasoning_engine is None:
            return {"pattern_proposals": []}

        llm_response = reasoning_engine.reason(self.name, inputs)

        # Robustness: if response is a string, try to parse as JSON
        if isinstance(llm_response, str):
            try:
                llm_response = json.loads(llm_response)
            except json.JSONDecodeError:
                print(f"[CAS][ERROR] Failed to parse reasoning response as JSON for step '{self.name}'")
                return {"pattern_proposals": []}

        # The prompt output format has pattern_proposals inside frontmatter or as a top-level key.
        # ReasoningExecutionContract handles extraction if it's structured.
        proposals = llm_response.get("pattern_proposals", []) if isinstance(llm_response, dict) else []

        return {"pattern_proposals": proposals}

    def validate(self, output):
        assert "pattern_proposals" in output, "Missing pattern_proposals in output"
        proposals_data = output["pattern_proposals"]

        if not proposals_data:
            return

        # Load schema
        schema_path = Path(__file__).parent.parent / "schemas" / "pattern_proposal_schema.json"
        if schema_path.exists():
            with open(schema_path) as f:
                schema = json.load(f)
            try:
                # The schema expects an object with "pattern_proposals" key
                validate(instance={"pattern_proposals": proposals_data}, schema=schema)
            except ValidationError as e:
                print(f"[CAS][ERROR] Pattern Proposals validation failed: {e.message}")
                raise
