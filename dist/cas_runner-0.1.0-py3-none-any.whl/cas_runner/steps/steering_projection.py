from datetime import datetime
from pathlib import Path
from typing import Any

from cas_runner.io import load_capability_lineage
from cas_runner.steering.analyzer import (
    ArchitecturalDeltaAnalyzer,
    DeltaBaselineProvider,
)
from cas_runner.steering.artifacts import SteeringArtifactScanner
from cas_runner.steering.capability_extractor import CapabilityExtractor
from cas_runner.steering.detector import SteeringDriftDetector
from cas_runner.steering.indexer import SteeringRuntimeIndexer
from cas_runner.steering.managed_sections import parse_managed_sections
from cas_runner.steering.policies import SteeringProjectionPolicy
from cas_runner.steering.projector import SteeringPatchProjector
from cas_runner.steering.section_renderer import ManagedSectionRenderer
from cas_runner.steering.synthesizer import ArchitectureSynthesizer, SynthesisRequest


class SteeringProjectionStep:
    name = "steering-projection"

    def prepare_inputs(self, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "project": context.get("project"),
            "project_root": context.get("project_root", "."),
            "workspace_root": context.get("workspace_root"),
            "baseline_ref": context.get("baseline_ref", "HEAD~1"),
        }

    def execute(self, inputs: dict[str, Any], reasoning_engine: Any = None) -> dict[str, Any]:
        project_root = Path(inputs.get("project_root", "."))
        workspace_root = Path(inputs.get("workspace_root")) if inputs.get("workspace_root") else project_root
        project = inputs.get("project") or "unknown"
        baseline_ref = inputs.get("baseline_ref") # User can still override
        policy = SteeringProjectionPolicy()

        # 1. Index current state (codebase)
        index = SteeringRuntimeIndexer(root=project_root).build_index()

        # 2. Analyze architectural deltas
        # Use project name to find last projection if baseline_ref not explicitly provided
        baseline_provider = DeltaBaselineProvider(root=project_root, workspace_root=workspace_root)
        actual_baseline_ref = baseline_provider.get_baseline_ref(project=project, ref=baseline_ref)
        analyzer = ArchitecturalDeltaAnalyzer(current=index, root=project_root)
        deltas = analyzer.analyze(baseline_ref=actual_baseline_ref)

        # 2b. Extract capabilities (Deterministic & Lineage-Aware)
        lineage = load_capability_lineage(project)
        known_ids = set(lineage.get("capabilities", {}).keys())
        extractor = CapabilityExtractor(known_capability_ids=known_ids)
        capabilities = extractor.extract(deltas)

        # Update lineage tracking
        for cap in capabilities:
            lineage.setdefault("capabilities", {})[cap.id] = {
                "category": cap.category.value,
                "last_modified": datetime.now().isoformat(),
                "status": "active"
            }

        # Update capability inventory incrementally
        from cas_runner.io import load_capability_inventory, persist_capability_inventory
        from cas_runner.steering.models import CapabilityRecordType

        inventory = load_capability_inventory(project)
        timestamp = datetime.now().isoformat()
        inventory["last_updated"] = timestamp

        for cap in capabilities:
            evidence = []
            target = cap.metadata.get("target")
            if target:
                evidence.append(target)

            is_deleted = (cap.type == CapabilityRecordType.CAPABILITY_REMOVED)
            status = "retired" if is_deleted else "active"

            if cap.id in inventory.setdefault("capabilities", {}):
                entry = inventory["capabilities"][cap.id]
                entry["last_modified"] = timestamp
                entry["description"] = cap.description
                entry["lifecycle_status"] = status
                # Merge evidence paths if not already present
                for ev in evidence:
                    if ev not in entry.get("implementation_evidence", []):
                        entry.setdefault("implementation_evidence", []).append(ev)
            else:
                title = cap.id.split("-")[-2].replace("_", " ").title() if len(cap.id.split("-")) >= 2 else "Untitled Capability"
                inventory["capabilities"][cap.id] = {
                    "id": cap.id,
                    "title": title,
                    "category": cap.category.value,
                    "description": cap.description,
                    "lifecycle_status": status,
                    "first_introduced": timestamp,
                    "last_modified": timestamp,
                    "originating_delta": cap.delta_ref,
                    "lineage": [],
                    "supporting_artifacts": [],
                    "implementation_evidence": evidence,
                }

        persist_capability_inventory(inventory, project)

        # 3. Detect drift and architectural gaps
        claims = SteeringArtifactScanner(root=project_root, policy=policy).scan()
        detector = SteeringDriftDetector(index=index, deltas=deltas)
        findings = detector.detect(claims)

        # 3c. Persona-driven synthesis (LLM-Augmented)
        synthesized_content = {}
        if reasoning_engine:
            synthesizer = ArchitectureSynthesizer(reasoning_engine=reasoning_engine)

            # Map artifacts to personas
            artifact_personas = {
                "README.md": "README",
                "AGENTS.md": "AGENTS",
                "GEMINI.md": "PLATFORM",
                "CLAUDE.md": "PLATFORM",
            }

            # Extract removed capability IDs for US3
            removed_ids = [
                d.target for d in deltas if d.type == "deleted" and d.id.startswith("cap-")
            ]

            from concurrent.futures import ThreadPoolExecutor

            def _synthesize_artifact(artifact, persona):
                path = project_root / artifact
                if not path.exists():
                    return artifact, None

                try:
                    artifact_text = path.read_text()
                    sections = parse_managed_sections(artifact, artifact_text)
                    current_section = next((s for s in sections if s.section_id == "runtime-capabilities"), None)

                    request = SynthesisRequest(
                        project=project,
                        persona=persona,
                        deltas=deltas,
                        removed_capability_ids=removed_ids,
                        current_content=current_section.content if current_section else "",
                        target_artifact=artifact,
                        artifact_content=artifact_text if persona == "PLATFORM" else "",
                    )

                    response = synthesizer.synthesize(request)
                    if response.status == "success":
                        return artifact, response.synthesized_markdown
                except Exception as e:
                    print(f"[CAS][WARN] Synthesis failed for {artifact}: {e}")
                return artifact, None

            with ThreadPoolExecutor(max_workers=len(artifact_personas)) as executor:
                results = list(executor.map(
                    lambda p: _synthesize_artifact(*p),
                    artifact_personas.items()
                ))

            for artifact, content in results:
                if content:
                    synthesized_content[artifact] = content

        # 3b. Render managed sections
        renderer = ManagedSectionRenderer()
        managed_proposals = renderer.render(
            project, deltas, capabilities, synthesized_content=synthesized_content
        )

        # 4. Project and persist
        bundle = SteeringPatchProjector(root=project_root, workspace_root=workspace_root, policy=policy).persist(
            project=project,
            index=index,
            findings=findings,
            deltas=deltas,
            capabilities=capabilities,
            managed_section_proposals=managed_proposals,
            baseline_ref=baseline_ref,
            current_ref="HEAD"
        )

        result = bundle.output
        result["capabilities"] = [
            {
                **cap.__dict__,
                "category": cap.category.value,
                "type": cap.type.value
            } for cap in capabilities
        ]
        result["capability_lineage"] = lineage
        return result

    def validate(self, output: dict[str, Any]) -> None:
        policy = SteeringProjectionPolicy()
        assert policy.output_key in output, "Missing steering_projection output"
        forbidden_keys = policy.excluded_output_keys.intersection(output)
        assert not forbidden_keys, f"Steering projection returned governance outputs: {forbidden_keys}"
