"""Deterministic ControlBandsStep for the Continuous Architecture Loop.

Evaluates repository telemetry against `.cas/bands.yaml` statistical control bands
and auto-drafts a provenance-anchored Stage 1 `intent.md` when a 3sigma anomaly occurs.
"""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any

from cas_runner.governance.control_bands import (
    ControlBandsEngine,
    format_control_bands_text,
)


class ControlBandsStep:
    """Flow step executing `ControlBandsEngine` during `continuous-architecture-loop`."""

    name = "control-bands-check"

    def prepare_inputs(self, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "project": context.get("project"),
            "target_dir": context.get("target_dir") or ".",
        }

    def execute(
        self, inputs: dict[str, Any], reasoning_engine: Any = None
    ) -> dict[str, Any]:
        target_dir = Path(str(inputs.get("target_dir") or ".")).resolve()
        engine = ControlBandsEngine(target_dir=target_dir)
        report = engine.evaluate()
        print("\n" + format_control_bands_text(report))
        return {"control_bands_report": asdict(report)}

    def validate(self, output: dict[str, Any]) -> None:
        assert "control_bands_report" in output
        assert "highest_band" in output["control_bands_report"]
