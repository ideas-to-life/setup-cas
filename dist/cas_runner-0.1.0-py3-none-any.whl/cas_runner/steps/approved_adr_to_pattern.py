import json
from datetime import date
from pathlib import Path

from jsonschema import ValidationError, validate


class ApprovedADRToPattern:
    name = "approved-adr-to-pattern"

    def prepare_inputs(self, context):
        from ..io import is_adr_approved

        # We need the forum-approved ADRs
        adrs = context.get("adrs", [])
        project = context.get("project")

        # Filter only approved/accepted ADRs to guard pattern generation
        approved_adrs = []
        for adr in adrs:
            adr_id = adr.get("id")
            gov_status = str(adr.get("governance", {}).get("forum_status", "")).lower()
            dec_status = str(adr.get("decision", {}).get("status", "")).lower()
            top_status = str(adr.get("status", "")).lower()

            if (
                gov_status in ["accepted", "approved", "conditional"]
                or dec_status in ["accepted", "approved", "conditional"]
                or top_status in ["accepted", "approved", "conditional"]
            ):
                approved_adrs.append(self._make_serializable(adr))
            elif project and adr_id and is_adr_approved(project, adr_id):
                approved_adrs.append(self._make_serializable(adr))

        return {
            "adrs": approved_adrs,
            "promotion_decisions": context.get("promotion_decisions", []),
            "pattern_promotion_recommendations": context.get("pattern_promotion_recommendations"),
            "pattern_proposals": context.get("pattern_proposals", []),
            "existing_global_patterns": context.get("patterns", []),
            "architectural_state": context.get("architectural_state"),
            "project": project,
        }

    def _make_serializable(self, data):
        if isinstance(data, dict):
            return {k: self._make_serializable(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._make_serializable(item) for item in data]
        elif isinstance(data, date):
            return data.isoformat()
        return data

    def execute(self, inputs, reasoning_engine):
        if reasoning_engine is None:
            return {"patterns": []}

        adrs = inputs.get("adrs", [])
        if not adrs:
            print(f"[CAS][INFO] No approved ADRs found for '{self.name}'. Skipping Pattern generation.")
            return {"patterns": []}

        # Process each approved ADR individually to satisfy single-pattern schema constraints
        patterns = []
        for adr in adrs:
            single_input = {**inputs, "adrs": [adr]}
            llm_response = reasoning_engine.reason(self.name, single_input)

            if isinstance(llm_response, str):
                try:
                    llm_response = json.loads(llm_response)
                except json.JSONDecodeError:
                    print(f"[CAS][ERROR] Failed to parse reasoning response for '{self.name}' on ADR {adr.get('id')}")
                    continue

            # The LLM should return a Pattern or list of Patterns
            if isinstance(llm_response, list):
                patterns.extend(llm_response)
            elif isinstance(llm_response, dict):
                p_items = llm_response.get("patterns", [llm_response] if "id" in llm_response else [])
                patterns.extend(p_items)


        # Ensure metadata and governance fields are present for each Pattern
        for pattern in patterns:
            if "knowledgeType" not in pattern:
                pattern["knowledgeType"] = "pattern"
            if "project" not in pattern:
                pattern["project"] = inputs.get("project", "unknown")
            if "date" not in pattern:
                pattern["date"] = date.today().isoformat()

            # Ensure governance block is correctly populated from approved intent
            if "governance" not in pattern:
                pattern["governance"] = {
                    "status": "approved",
                    "approved_by": "Architecture Forum",
                    "approval_date": date.today().isoformat()
                }
            else:
                pattern["governance"]["status"] = "approved"
                if not pattern["governance"].get("approved_by"):
                    pattern["governance"]["approved_by"] = "Architecture Forum"
                if not pattern["governance"].get("approval_date"):
                    pattern["governance"]["approval_date"] = date.today().isoformat()

        return {"patterns": patterns}

    def validate(self, output):
        assert "patterns" in output, "Missing 'patterns' in output"
        pattern_list = output["patterns"]

        schema_path = Path(__file__).parent.parent / "schemas" / "pattern_schema.json"
        if schema_path.exists():
            with open(schema_path) as f:
                schema = json.load(f)
            try:
                for p in pattern_list:
                    validate(instance=p, schema=schema)
            except ValidationError as e:
                print(f"[CAS][ERROR] Pattern validation failed: {e.message}")
                raise
        else:
            required_keys = [
                "id", "knowledgeType", "title", "summary", "date", "tags",
                "maturity", "confidence", "scope", "governance",
                "source_traceability", "forum_review"
            ]
            for p in pattern_list:
                for key in required_keys:
                    assert key in p, f"Missing required key '{key}' in Pattern output"
