from datetime import UTC, datetime
from pathlib import Path
from typing import Any
import yaml
import json
import jsonschema

from cas_runner.io import load_architecture_work, safe_mkdir

def determine_lifecycle_recommendation(current_status: str, coverage: str) -> tuple[str, str]:
    """
    Applies the lifecycle transition rules.
    Returns a tuple of (recommended_status, recommended_action).
    """
    current = current_status.lower().strip()
    cov = coverage.strip().title()  # e.g., "Complete", "Partial", "Substantial", "None"
    
    if current == "done":
        # Done + Complete -> Remain Done; Done + any other -> Verify Implementation Evidence
        if cov == "Complete":
            return "done", "Remain Done"
        else:
            return "done", "Verify Implementation Evidence"
            
    elif current == "active":
        if cov == "Complete":
            return "done", "Promote to Done"
        else:
            return "active", "Verify Implementation Evidence"
            
    elif current == "accepted":
        if cov == "Complete":
            return "done", "Promote to Done"
        else:
            return "accepted", "Verify Implementation Evidence"
            
    elif current == "proposed":
        if cov == "Complete":
            return "done", "Promote to Done"
        elif cov in ["Partial", "Substantial"]:
            return "active", "Promote to Active"
        else:
            return "proposed", "Remain Proposed"
            
    else:
        # Default fallback for retired/superseded or any other status
        return current, "Verify Implementation Evidence"

class ArchitectureWorkAssessmentStep:
    name = "architecture-work-assessment"

    def prepare_inputs(self, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "project": context.get("project"),
            "project_root": context.get("project_root", "."),
            "workspace_root": context.get("workspace_root"),
            "governance_context": context.get("governance_context")
        }

    def execute(self, inputs: dict[str, Any], reasoning_engine: Any = None) -> dict[str, Any]:
        project = inputs.get("project") or "unknown"
        project_root = Path(inputs.get("project_root", "."))
        workspace_root = Path(inputs.get("workspace_root")) if inputs.get("workspace_root") else project_root

        # 1. Load governance_context
        gov_context = inputs.get("governance_context")
        if not gov_context:
            context_path = workspace_root / "projects" / project / "assessment" / "governance_context.json"
            if context_path.exists():
                try:
                    with open(context_path) as f:
                        gov_context = json.load(f)
                except Exception as e:
                    print(f"[CAS][WARN] Failed to load governance_context.json from {context_path}: {e}")
        
        if not gov_context:
            raise ValueError(f"Governance context is required for Architecture Work Assessment step.")

        aw_items = load_architecture_work(project)
        generated_at = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

        # 2. Run reasoning or fallback to deterministic assessment
        output = {}
        reasoning_success = False

        if reasoning_engine:
            try:
                prompt_inputs = {
                    "architecture_work_registry": aw_items,
                    "runtime_capability_snapshot": gov_context.get("runtime_capabilities") or list(gov_context.get("candidate_evidence", {}).values()),
                    "deterministic_matches": gov_context.get("explicit_lineage") or gov_context.get("deterministic_matches") or {},
                    "candidate_matches": gov_context.get("candidate_matches") or {},
                    "governance_data_quality": gov_context.get("metadata_quality") or gov_context.get("governance_data_quality") or [],
                    "unmatched_capabilities": gov_context.get("orphan_capabilities") or gov_context.get("unmatched_capabilities") or []
                }
                
                reasoning_output = reasoning_engine.reason(self.name, prompt_inputs)
                if isinstance(reasoning_output, dict) and "assessments" in reasoning_output:
                    output = reasoning_output
                    reasoning_success = True
            except Exception as e:
                print(f"[CAS][WARN] Project-wide reasoning engine failed: {e}. Falling back to deterministic review.")

        # Helper to extract title
        def get_capability_title(cid: str, details: dict) -> str:
            cap = details.get(cid, {})
            desc = cap.get("description")
            if desc:
                prefix = "Capability impact detected: "
                if desc.startswith(prefix):
                    return desc[len(prefix):]
                return desc
            parts = cid.split("-")
            if len(parts) > 1:
                words = [p for p in parts[1:-1] if not p.strip("0123456789abcdef")]
                # filter out empty words and numbers/hashes
                words = [w for w in parts[1:-1] if not w.isdigit() and len(w) > 2]
                if not words:
                    words = parts[1:]
                return " ".join(words).title()
            return cid

        if not reasoning_success:
            # Deterministic Fallback Review
            assessments = []
            oversized_items = []
            obsolete_items = []
            
            deterministic_matches = gov_context.get("explicit_lineage") or gov_context.get("deterministic_matches") or {}
            candidate_evidence = {}
            if "runtime_capabilities" in gov_context:
                candidate_evidence = {cap["id"]: cap for cap in gov_context.get("runtime_capabilities", [])}
            elif "candidate_evidence" in gov_context:
                candidate_evidence = gov_context.get("candidate_evidence", {})
            candidate_matches = gov_context.get("candidate_matches") or {}

            for aw in aw_items:
                aw_id = aw.get("id")
                if not aw_id:
                    continue

                current_status = aw.get("status", "proposed")
                
                # Check for explicit supersession/retirement metadata first
                superseded_by = aw.get("superseded_by")
                duplicate_of = aw.get("duplicate_of")
                merged_into = aw.get("merged_into")
                approved_retirement = aw.get("approved_retirement")
                governance_decision = aw.get("governance_decision")
                
                is_explicitly_superseded = any([superseded_by, duplicate_of, merged_into, approved_retirement, governance_decision])
                
                if is_explicitly_superseded:
                    obsolete_items.append({
                        "aw_id": aw_id,
                        "title": aw.get("title", "Untitled"),
                        "rationale": f"Explicit governance metadata indicates retirement. superseded_by: {superseded_by}, duplicate_of: {duplicate_of}, merged_into: {merged_into}, approved_retirement: {approved_retirement}, governance_decision: {governance_decision}."
                    })
                    assessments.append({
                        "aw_id": aw_id,
                        "title": aw.get("title", "Untitled"),
                        "current_status": current_status,
                        "recommended_status": "retired",
                        "recommended_action": "Verify Implementation Evidence",
                        "coverage": "None",
                        "evidence_classification": "Explicitly Superseded",
                        "confidence": 1.0,
                        "confidence_reason": "Explicit governance metadata indicating supersession or retirement.",
                        "rationale": f"Architecture Work has explicit governance metadata indicating it is retired/superseded.",
                        "evidence": [],
                        "evidence_ids": [],
                        "suggested_actions": ["retire Architecture Work"],
                        "limitations": ["Evaluated via deterministic fallback matching only."]
                    })
                    continue

                matched = deterministic_matches.get(aw_id, [])
                if not matched:
                    # Fallback to candidate matches
                    matched = [m["target_id"] for m in candidate_matches.get(aw_id, [])]

                if not matched:
                    # Insufficient Evidence, No Change recommended (FR-2, FR-3)
                    rec_status, rec_action = determine_lifecycle_recommendation(current_status, "None")
                    suggested_actions = ["Clarify Scope"]
                    if rec_action == "Verify Implementation Evidence":
                        suggested_actions.append("Verify Implementation Evidence")
                    assessments.append({
                        "aw_id": aw_id,
                        "title": aw.get("title", "Untitled"),
                        "current_status": current_status,
                        "recommended_status": rec_status,
                        "recommended_action": rec_action,
                        "coverage": "None",
                        "evidence_classification": "Insufficient Evidence",
                        "confidence": 0.5,
                        "confidence_reason": "No active capabilities matched this work, indicating insufficient evidence.",
                        "rationale": "No matching active capabilities found. Recommending no status change to remain conservative.",
                        "evidence": [],
                        "evidence_ids": [],
                        "suggested_actions": suggested_actions,
                        "limitations": ["Evaluated via deterministic fallback matching only."]
                    })
                    continue

                # Calculate coverage ratio
                implemented_matched = [c for c in matched if c in candidate_evidence]
                ratio = len(implemented_matched) / len(matched) if matched else 0.0

                if ratio == 1.0:
                    coverage = "Complete"
                    evidence_classification = "Complete Evidence"
                elif ratio >= 0.7:
                    coverage = "Substantial"
                    evidence_classification = "Partial Evidence"
                elif ratio > 0.0:
                    coverage = "Partial"
                    evidence_classification = "Partial Evidence"
                else:
                    coverage = "None"
                    evidence_classification = "Insufficient Evidence"

                # Recommend transition (FR-5)
                recommended_status, recommended_action = determine_lifecycle_recommendation(current_status, coverage)
                suggested_actions = ["retain current scope"]
                if recommended_action == "Verify Implementation Evidence":
                    suggested_actions.append("Verify Implementation Evidence")

                # Flag oversized
                if len(matched) > 1:
                    oversized_items.append({
                        "aw_id": aw_id,
                        "title": aw.get("title", "Untitled"),
                        "matched_capabilities": matched,
                        "rationale": "Maps to multiple independent capabilities."
                    })
                    suggested_actions.append("split Architecture Work")

                # Resolve capability titles for evidence
                evidence_titles = [get_capability_title(c, candidate_evidence) for c in implemented_matched]

                assessments.append({
                    "aw_id": aw_id,
                    "title": aw.get("title", "Untitled"),
                    "current_status": current_status,
                    "recommended_status": recommended_status,
                    "recommended_action": recommended_action,
                    "coverage": coverage,
                    "evidence_classification": evidence_classification,
                    "confidence": 0.5,
                    "confidence_reason": "Deterministic fallback matching.",
                    "rationale": f"Coverage is {coverage} ({len(implemented_matched)}/{len(matched)} capabilities implemented).",
                    "evidence": evidence_titles,
                    "evidence_ids": implemented_matched,
                    "suggested_actions": suggested_actions,
                    "limitations": ["Evaluated via deterministic fallback matching only."]
                })

            # Format orphan capabilities
            orphan_capabilities = []
            for cid in gov_context.get("unmatched_capabilities", []):
                orphan_capabilities.append({
                    "capability_id": cid,
                    "description": candidate_evidence.get(cid, {}).get("description", "No description available.")
                })

            # Summary stats
            completed_count = sum(1 for a in assessments if a["coverage"] == "Complete")
            substantial_count = sum(1 for a in assessments if a["coverage"] == "Substantial")
            partial_count = sum(1 for a in assessments if a["coverage"] == "Partial")
            none_count = sum(1 for a in assessments if a["coverage"] == "None")

            summary = {
                "total_architecture_work": len(aw_items),
                "assessed_items": len(assessments),
                "completed": completed_count,
                "substantial": substantial_count,
                "partial": partial_count,
                "none": none_count,
                "orphan_capabilities": len(orphan_capabilities),
                "oversized_items": len(oversized_items),
                "obsolete_items": len(obsolete_items)
            }

            governance_health = {
                "overall_confidence": 0.5,
                "overall_assessment": "Deterministic fallback review completed.",
                "strengths": ["All active capabilities mapped deterministically."],
                "risks": ["Reasoning engine unavailable; recommendations lack expert semantic reviews."]
            }

            # Standard generic recommendations for fallback mode
            recommendations = [
                {
                    "category": "Governance Quality",
                    "priority": "Medium",
                    "recommendation": "Resolve unresolved metadata and lineage mappings.",
                    "rationale": "Missing capability lineage or metadata reduces overall governance confidence.",
                    "suggested_action": "Manually audit Architecture Work frontmatter metadata."
                }
            ]

            output = {
                "assessment_metadata": {
                    "assessment_timestamp": generated_at,
                    "runtime_snapshot": "latest",
                    "lineage_version": gov_context.get("governance_metadata", {}).get("lineage_version", "unknown"),
                    "reasoning_enabled": False,
                    "prompt_version": "fallback"
                },
                "assessments": assessments,
                "oversized_items": oversized_items,
                "orphan_capabilities": orphan_capabilities,
                "obsolete_items": obsolete_items,
                "summary": summary,
                "governance_health": governance_health,
                "governance_data_quality": gov_context.get("governance_data_quality", {
                    "missing_titles": [],
                    "missing_metadata": [],
                    "missing_lineage": [],
                    "ambiguous_capabilities": [],
                    "observations": []
                }),
                "recommendations": recommendations
            }

        # Post-process to fill in any missing assessments if reasoning was successful but omitted items
        # Clean up and ensure reasoning engine outputs have titles in evidence and IDs in evidence_ids
        if reasoning_success:
            candidate_evidence = gov_context.get("candidate_evidence", {})
            for ass in output.get("assessments", []):
                raw_ev = ass.get("evidence", [])
                ev_ids = ass.get("evidence_ids", [])
                
                # If LLM returned IDs in evidence, move them to evidence_ids
                if not ev_ids and raw_ev:
                    ev_ids = [e for e in raw_ev if e in candidate_evidence or e.startswith("cap-")]
                    ass["evidence_ids"] = ev_ids
                elif not ev_ids:
                    ass["evidence_ids"] = []

                # Ensure evidence has titles
                ass["evidence"] = [get_capability_title(eid, candidate_evidence) for eid in ass.get("evidence_ids", [])]

                # Ensure evidence_classification is present
                if not ass.get("evidence_classification"):
                    cov = ass.get("coverage", "None")
                    if cov == "Complete":
                        ass["evidence_classification"] = "Complete Evidence"
                    elif cov in ["Substantial", "Partial"]:
                        ass["evidence_classification"] = "Partial Evidence"
                    else:
                        ass["evidence_classification"] = "Insufficient Evidence"

                # Ensure recommended_action and status downgrades protection
                if ass.get("current_status", "").lower() == "done" and ass.get("recommended_status", "done").lower() != "done":
                    ass["recommended_status"] = "done"
                    ass["recommended_action"] = "Verify Implementation Evidence"
                    actions = ass.setdefault("suggested_actions", [])
                    if "Verify Implementation Evidence" not in actions:
                        actions.append("Verify Implementation Evidence")
                elif not ass.get("recommended_action"):
                    cov = ass.get("coverage", "None")
                    _, rec_action = determine_lifecycle_recommendation(ass.get("current_status", "proposed"), cov)
                    ass["recommended_action"] = rec_action

            existing_assessed_ids = {a["aw_id"] for a in output.get("assessments", []) if "aw_id" in a}
            missing_aws = [aw for aw in aw_items if aw.get("id") and aw.get("id") not in existing_assessed_ids]
            
            if missing_aws:
                print(f"[CAS][GOVERNANCE] Reasoning engine omitted {len(missing_aws)} Architecture Work items. Generating fallbacks.")
                deterministic_matches = gov_context.get("deterministic_matches", {})
                candidate_evidence = gov_context.get("candidate_evidence", {})
                
                # Retrieve or initialize summary stats
                summary = output.setdefault("summary", {
                    "total_architecture_work": len(aw_items),
                    "assessed_items": len(output.get("assessments", [])),
                    "completed": 0,
                    "substantial": 0,
                    "partial": 0,
                    "none": 0,
                    "orphan_capabilities": len(output.get("orphan_capabilities", [])),
                    "oversized_items": len(output.get("oversized_items", [])),
                    "obsolete_items": len(output.get("obsolete_items", []))
                })

                for aw in missing_aws:
                    aw_id = aw.get("id")
                    current_status = aw.get("status", "proposed")
                    
                    # Check for explicit supersession/retirement metadata first
                    superseded_by = aw.get("superseded_by")
                    duplicate_of = aw.get("duplicate_of")
                    merged_into = aw.get("merged_into")
                    approved_retirement = aw.get("approved_retirement")
                    governance_decision = aw.get("governance_decision")
                    
                    is_explicitly_superseded = any([superseded_by, duplicate_of, merged_into, approved_retirement, governance_decision])
                    
                    if is_explicitly_superseded:
                        output.setdefault("obsolete_items", []).append({
                            "aw_id": aw_id,
                            "title": aw.get("title", "Untitled"),
                            "rationale": f"Explicit governance metadata indicates retirement. superseded_by: {superseded_by}, duplicate_of: {duplicate_of}, merged_into: {merged_into}, approved_retirement: {approved_retirement}, governance_decision: {governance_decision}."
                        })
                        output.setdefault("assessments", []).append({
                            "aw_id": aw_id,
                            "title": aw.get("title", "Untitled"),
                            "current_status": current_status,
                            "recommended_status": "retired",
                            "recommended_action": "Verify Implementation Evidence",
                            "coverage": "None",
                            "evidence_classification": "Explicitly Superseded",
                            "confidence": 1.0,
                            "confidence_reason": "Explicit governance metadata indicating supersession or retirement.",
                            "rationale": f"Architecture Work has explicit governance metadata indicating it is retired/superseded.",
                            "evidence": [],
                            "evidence_ids": [],
                            "suggested_actions": ["retire Architecture Work"],
                            "limitations": ["Omitted by reasoning engine; evaluated via deterministic fallback matching only."]
                        })
                        summary["obsolete_items"] = summary.get("obsolete_items", 0) + 1
                        summary["none"] = summary.get("none", 0) + 1
                        continue

                    matched = deterministic_matches.get(aw_id, [])

                    if not matched:
                        # Insufficient Evidence fallback
                        rec_status, rec_action = determine_lifecycle_recommendation(current_status, "None")
                        suggested_actions = ["Clarify Scope"]
                        if rec_action == "Verify Implementation Evidence":
                            suggested_actions.append("Verify Implementation Evidence")
                        output.setdefault("assessments", []).append({
                            "aw_id": aw_id,
                            "title": aw.get("title", "Untitled"),
                            "current_status": current_status,
                            "recommended_status": rec_status,
                            "recommended_action": rec_action,
                            "coverage": "None",
                            "evidence_classification": "Insufficient Evidence",
                            "confidence": 0.5,
                            "confidence_reason": "No active capabilities matched this work, indicating insufficient evidence. Evaluated via deterministic fallback matching.",
                            "rationale": "No matching active capabilities found. Recommending no status change to remain conservative.",
                            "evidence": [],
                            "evidence_ids": [],
                            "suggested_actions": suggested_actions,
                            "limitations": ["Omitted by reasoning engine; evaluated via deterministic fallback matching only."]
                        })
                        summary["none"] = summary.get("none", 0) + 1
                    else:
                        # Matched fallback
                        implemented_matched = [c for c in matched if c in candidate_evidence]
                        ratio = len(implemented_matched) / len(matched) if matched else 0.0

                        if ratio == 1.0:
                            coverage = "Complete"
                            evidence_classification = "Complete Evidence"
                            summary["completed"] = summary.get("completed", 0) + 1
                        elif ratio >= 0.7:
                            coverage = "Substantial"
                            evidence_classification = "Partial Evidence"
                            summary["substantial"] = summary.get("substantial", 0) + 1
                        elif ratio > 0.0:
                            coverage = "Partial"
                            evidence_classification = "Partial Evidence"
                            summary["partial"] = summary.get("partial", 0) + 1
                        else:
                            coverage = "None"
                            evidence_classification = "Insufficient Evidence"
                            summary["none"] = summary.get("none", 0) + 1

                        recommended_status, recommended_action = determine_lifecycle_recommendation(current_status, coverage)
                        suggested_actions = ["retain current scope"]
                        if recommended_action == "Verify Implementation Evidence":
                            suggested_actions.append("Verify Implementation Evidence")

                        if len(matched) > 1:
                            output.setdefault("oversized_items", []).append({
                                "aw_id": aw_id,
                                "title": aw.get("title", "Untitled"),
                                "matched_capabilities": matched,
                                "rationale": "Maps to multiple independent capabilities."
                            })
                            suggested_actions.append("split Architecture Work")
                            summary["oversized_items"] = summary.get("oversized_items", 0) + 1

                        evidence_titles = [get_capability_title(c, candidate_evidence) for c in implemented_matched]

                        output.setdefault("assessments", []).append({
                            "aw_id": aw_id,
                            "title": aw.get("title", "Untitled"),
                            "current_status": current_status,
                            "recommended_status": recommended_status,
                            "recommended_action": recommended_action,
                            "coverage": coverage,
                            "evidence_classification": evidence_classification,
                            "confidence": 0.5,
                            "confidence_reason": "Deterministic fallback matching.",
                            "rationale": f"Coverage is {coverage} ({len(implemented_matched)}/{len(matched)} capabilities implemented).",
                            "evidence": evidence_titles,
                            "evidence_ids": implemented_matched,
                            "suggested_actions": suggested_actions,
                            "limitations": ["Omitted by reasoning engine; evaluated via deterministic fallback matching only."]
                        })

                # Refresh summary total and assessed items count
                summary["total_architecture_work"] = len(aw_items)
                summary["assessed_items"] = len(output["assessments"])

        # 3. Save aw_assessment.json
        assessment_dir = workspace_root / "projects" / project / "assessment"
        safe_mkdir(assessment_dir, parents=True, exist_ok=True)
        assessment_json_path = assessment_dir / "aw_assessment.json"
        assessment_json_path.write_text(json.dumps(output, indent=2))
        print(f"[CAS][GOVERNANCE] aw_assessment.json created: {assessment_json_path}")

        # 4. Phase 3: Render Markdown Report from output/aw_assessment.json data
        safe_date = generated_at.replace(":", "").replace("-", "")
        report_filename = f"assessment-report-{project}-{safe_date}.md"
        report_path = report_dir = assessment_dir / report_filename

        frontmatter = {
            "id": f"assessment-report-{project}-{safe_date}",
            "knowledgeType": "architecture_work_assessment_report",
            "project": project,
            "generated_at": generated_at,
            "status": "proposed"
        }

        # Build markdown content
        md_lines = []
        md_lines.append("---")
        md_lines.append(yaml.dump(frontmatter, sort_keys=False).strip())
        md_lines.append("---")
        md_lines.append(f"\n# Architecture Work Assessment Report: {project}")
        md_lines.append(f"\nGenerated at: `{generated_at}`")
        
        # 1. Executive Summary
        summary_info = output.get("summary", {})
        md_lines.append("\n## Executive Summary")
        md_lines.append(f"\nEvaluated {summary_info.get('total_architecture_work', len(aw_items))} Architecture Work items against the current capability snapshot.")
        md_lines.append(f"Detected {summary_info.get('oversized_items', 0)} oversized items, {summary_info.get('orphan_capabilities', 0)} orphan capabilities, and {summary_info.get('obsolete_items', 0)} obsolete/superseded items.")

        # 2. Governance Health
        gov_health = output.get("governance_health", {})
        md_lines.append("\n## Governance Health")
        md_lines.append(f"\n- **Overall Confidence**: {gov_health.get('overall_confidence', 'unknown')}")
        md_lines.append(f"- **Overall Assessment**: {gov_health.get('overall_assessment', 'No assessment available.')}")
        
        strengths = gov_health.get("strengths", [])
        if strengths:
            md_lines.append("- **Strengths**:")
            for s in strengths:
                md_lines.append(f"  - {s}")
        
        risks = gov_health.get("risks", [])
        if risks:
            md_lines.append("- **Risks**:")
            for r in risks:
                md_lines.append(f"  - {r}")

        # 3. Coverage Summary
        md_lines.append("\n## Coverage Summary")
        md_lines.append("\n| Architecture Work ID | Title | Current Status | Recommended Status | Recommended Action | Coverage | Classification |")
        md_lines.append("|---|---|---|---|---|---|---|")
        for ass in output.get("assessments", []):
            md_lines.append(f"| {ass['aw_id']} | {ass['title']} | `{ass['current_status']}` | `{ass['recommended_status']}` | **{ass.get('recommended_action', 'None')}** | **{ass['coverage']}** | {ass.get('evidence_classification', 'unknown')} |")

        # 4. Architecture Work Assessment
        md_lines.append("\n## Architecture Work Assessment")
        for ass in output.get("assessments", []):
            md_lines.append(f"\n### {ass['aw_id']}: {ass['title']}")
            
            # Evidence Sub-section
            md_lines.append("\n**Evidence**:")
            evidence_list = ass.get("evidence", [])
            evidence_ids = ass.get("evidence_ids", [])
            if evidence_list:
                md_lines.append("- Supporting Capabilities:")
                for title, eid in zip(evidence_list, evidence_ids):
                    md_lines.append(f"  - {title} (`{eid}`)")
            else:
                md_lines.append("- No supporting capabilities matching this work item.")
            md_lines.append(f"- Classification: **{ass.get('evidence_classification', 'unknown')}** (Confidence: {ass.get('confidence', 'unknown')})")
            
            # Assessment Sub-section
            md_lines.append("\n**Assessment**:")
            md_lines.append(f"- Rationale: {ass.get('rationale', 'No rationale provided.')}")
            if ass.get("confidence_reason"):
                md_lines.append(f"- Confidence Reason: {ass['confidence_reason']}")
            limitations = ass.get("limitations", [])
            if limitations:
                md_lines.append("- Limitations:")
                for lim in limitations:
                    md_lines.append(f"  - {lim}")
            
            # Recommendation Sub-section
            md_lines.append("\n**Recommendation**:")
            md_lines.append(f"- Current Status: `{ass['current_status']}`")
            md_lines.append(f"- Recommended Status: `{ass['recommended_status']}`")
            md_lines.append(f"- Recommended Action: **{ass.get('recommended_action', 'None')}**")
            suggested = ass.get("suggested_actions", [])
            if suggested:
                md_lines.append("- Suggested Actions:")
                for act in suggested:
                    md_lines.append(f"  - {act}")

        # Check if we need to write the appendix header
        has_appendix = (
            bool(output.get("oversized_items")) or
            bool(output.get("orphan_capabilities")) or
            any(a.get("evidence_classification") == "Insufficient Evidence" for a in output.get("assessments", [])) or
            any(a.get("evidence_classification") == "Explicitly Superseded" for a in output.get("assessments", [])) or
            bool(output.get("governance_data_quality"))
        )

        if has_appendix:
            md_lines.append("\n## Appendix: Governance Observations")

        # 5. Oversized Architecture Work
        oversized = output.get("oversized_items", [])
        if oversized:
            md_lines.append("\n### Oversized Architecture Work")
            for item in oversized:
                md_lines.append(f"\n#### {item['aw_id']}: {item['title']}")
                md_lines.append(f"- **Rationale**: {item['rationale']}")
                md_lines.append("- **Matched Capabilities**:")
                for c in item.get("matched_capabilities", []):
                    md_lines.append(f"  - `{c}`")

        # 6. Orphan Runtime Capabilities
        orphans = output.get("orphan_capabilities", [])
        if orphans:
            md_lines.append("\n### Orphan Runtime Capabilities")
            for item in orphans:
                md_lines.append(f"\n- **`{item['capability_id']}`**: {item.get('description', '')}")

        # 7. Insufficient Evidence
        insufficient = [a for a in output.get("assessments", []) if a.get("evidence_classification") == "Insufficient Evidence"]
        if insufficient:
            md_lines.append("\n### Insufficient Evidence")
            for item in insufficient:
                md_lines.append(f"\n- **`{item['aw_id']}`**: {item['title']} - {item['rationale']}")

        # 8. Explicitly Superseded
        superseded = [a for a in output.get("assessments", []) if a.get("evidence_classification") == "Explicitly Superseded"]
        if superseded:
            md_lines.append("\n### Explicitly Superseded")
            for item in superseded:
                md_lines.append(f"\n- **`{item['aw_id']}`**: {item['title']} - {item['rationale']}")

        # 9. Governance Data Quality
        dq = output.get("governance_data_quality", {})
        has_dq = dq and (dq.get("missing_titles") or dq.get("missing_metadata") or dq.get("missing_lineage") or dq.get("ambiguous_capabilities") or dq.get("observations"))
        if has_dq:
            md_lines.append("\n### Governance Data Quality")
            if dq.get("missing_titles"):
                md_lines.append("- **Missing Titles**:")
                for mt in dq["missing_titles"]:
                    md_lines.append(f"  - `{mt}`")
            if dq.get("missing_metadata"):
                md_lines.append("- **Missing Metadata**:")
                for mm in dq["missing_metadata"]:
                    md_lines.append(f"  - `{mm}`")
            if dq.get("missing_lineage"):
                md_lines.append("- **Missing Lineage**:")
                for ml in dq["missing_lineage"]:
                    md_lines.append(f"  - {ml}")
            if dq.get("ambiguous_capabilities"):
                md_lines.append("- **Ambiguous Capabilities**:")
                for ac in dq["ambiguous_capabilities"]:
                    md_lines.append(f"  - `{ac}`")
            if dq.get("observations"):
                md_lines.append("- **Observations**:")
                for obs in dq["observations"]:
                    md_lines.append(f"  - {obs}")

        # 10. Strategic Recommendations
        recs = output.get("recommendations", [])
        if recs:
            md_lines.append("\n## Strategic Recommendations")
            for r in recs:
                md_lines.append(f"\n- **[{r.get('category', 'General')} - {r.get('priority', 'Medium')}]**: {r.get('recommendation')}")
                md_lines.append(f"  - *Rationale*: {r.get('rationale')}")
                md_lines.append(f"  - *Suggested Action*: {r.get('suggested_action')}")

        report_path.write_text("\n".join(md_lines))
        print(f"[CAS][GOVERNANCE] Assessment report created: {report_path}")

        # 5. Validate output against schema
        try:
            schema_path = Path(__file__).parent.parent / "schemas" / "aw_assessment_schema.json"
            if schema_path.exists():
                with open(schema_path) as sf:
                    schema = json.load(sf)
                jsonschema.validate(instance=output, schema=schema)
                print(f"[CAS][GOVERNANCE] aw_assessment.json validated successfully.")
        except Exception as e:
            print(f"[CAS][WARN] Schema validation failed for aw_assessment: {e}")

        # Ensure return contract matches CLI expectations (contains report_path and assessments)
        final_output = output.copy()
        final_output["report_path"] = str(report_path.relative_to(workspace_root))
        return final_output

    def validate(self, output: dict[str, Any]) -> None:
        assert "report_path" in output
        assert "assessments" in output
