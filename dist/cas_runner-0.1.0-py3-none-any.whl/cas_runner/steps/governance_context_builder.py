from datetime import UTC, datetime
from pathlib import Path
from typing import Any
import yaml
import json
import jsonschema

from cas_runner.io import load_capability_lineage, load_architecture_work, safe_mkdir

class GovernanceContextBuilderStep:
    name = "governance-context-builder"

    def prepare_inputs(self, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "project": context.get("project"),
            "project_root": context.get("project_root", "."),
            "workspace_root": context.get("workspace_root"),
        }

    def execute(self, inputs: dict[str, Any], reasoning_engine: Any = None) -> dict[str, Any]:
        project = inputs.get("project") or "unknown"
        project_root = Path(inputs.get("project_root", "."))
        workspace_root = Path(inputs.get("workspace_root")) if inputs.get("workspace_root") else project_root

        lineage = {}
        # 1. Load active capabilities from inventory (fallback to lineage)
        from cas_runner.io import load_capability_inventory
        inventory = load_capability_inventory(project)
        inv_caps = inventory.get("capabilities", {})
        
        capability_details = {}
        if inv_caps:
            active_capabilities = {
                cid: cinfo for cid, cinfo in inv_caps.items()
                if cinfo.get("lifecycle_status") == "active"
            }
            # Populate capability details directly from inventory
            for cid, cinfo in inv_caps.items():
                capability_details[cid] = {
                    "id": cid,
                    "category": cinfo.get("category"),
                    "description": cinfo.get("description"),
                    "title": cinfo.get("title", cid)
                }
        else:
            lineage = load_capability_lineage(project)
            active_capabilities = {
                cid: cinfo for cid, cinfo in lineage.get("capabilities", {}).items()
                if cinfo.get("status") == "active"
            }
            
            # Check delta files first
            deltas_dir = workspace_root / "governance" / "steering" / "deltas"
            if deltas_dir.exists():
                delta_files = sorted(deltas_dir.glob(f"delta-analysis-{project}-*.yaml"), reverse=True)
                if not delta_files:
                    delta_files = sorted(deltas_dir.glob("delta-analysis-*.yaml"), reverse=True)
                for df in delta_files:
                    try:
                        with open(df) as f:
                            data = yaml.safe_load(f) or {}
                            for cap in data.get("capabilities", []):
                                cap_id = cap.get("id")
                                if cap_id and cap_id not in capability_details:
                                    capability_details[cap_id] = cap
                    except Exception as e:
                        print(f"[CAS][WARN] Failed to load delta file {df}: {e}")

            # Check projection files as fallback/supplement
            projections_dir = workspace_root / "governance" / "steering" / "projections"
            if projections_dir.exists():
                proj_files = sorted(projections_dir.glob(f"steering-projection-{project}-*.md"), reverse=True)
                if not proj_files:
                    proj_files = sorted(projections_dir.glob("steering-projection-*.md"), reverse=True)
                for pf in proj_files:
                    try:
                        content = pf.read_text()
                        if content.startswith("---"):
                            parts = content.split("---", 2)
                            if len(parts) >= 3:
                                fm = yaml.safe_load(parts[1]) or {}
                                for cap in fm.get("capabilities", []):
                                    cap_id = cap.get("id")
                                    if cap_id and cap_id not in capability_details:
                                        capability_details[cap_id] = cap
                    except Exception as e:
                        print(f"[CAS][WARN] Failed to load projection file {pf}: {e}")

        # Populate missing details from active_capabilities
        for cid, cinfo in active_capabilities.items():
            if cid not in capability_details:
                capability_details[cid] = {
                    "id": cid,
                    "category": cinfo.get("category", "unknown"),
                    "description": cinfo.get("description") if "description" in cinfo else f"Tracked active capability {cid}"
                }

        # 3. Load all Architecture Work items
        aw_items = load_architecture_work(project)

        # 4. Perform deterministic matching & lineage resolution
        explicit_lineage = {}
        candidate_matches = {}
        
        for aw in aw_items:
            aw_id = aw.get("id")
            if not aw_id:
                continue
            
            # Explicit lineage check
            explicit_caps = aw.get("capabilities", [])
            matched_explicit = []
            if isinstance(explicit_caps, list):
                for c in explicit_caps:
                    if c in active_capabilities:
                        matched_explicit.append(c)
            
            if matched_explicit:
                explicit_lineage[aw_id] = list(set(matched_explicit))
            else:
                # Local deterministic keyword matching
                local_candidates = []
                aw_title = aw.get("title", "").lower()
                aw_details = aw.get("details", "").lower() or aw.get("description", "").lower() or ""
                
                for cid, cdetails in capability_details.items():
                    if cid not in active_capabilities:
                        continue
                    desc = cdetails.get("description", "").lower()
                    
                    if cid.lower() in aw_title or cid.lower() in aw_details:
                        local_candidates.append({
                            "target_id": cid,
                            "confidence": 1.0,
                            "matching_method": "deterministic_text",
                            "supporting_evidence": f"Capability ID '{cid}' matched in title or details."
                        })
                    elif desc and len(desc) > 5 and (desc in aw_title or desc in aw_details):
                        local_candidates.append({
                            "target_id": cid,
                            "confidence": 0.85,
                            "matching_method": "deterministic_text",
                            "supporting_evidence": f"Capability description '{desc}' matched in title or details."
                        })
                
                if local_candidates:
                    candidate_matches[aw_id] = local_candidates

        # 5. Hybrid Fallback: Ask reasoning engine for matches if no lineage/local matches exist
        unresolved_aws = [
            aw for aw in aw_items 
            if aw.get("id") and not explicit_lineage.get(aw["id"]) and not candidate_matches.get(aw["id"])
        ]
        
        if unresolved_aws and reasoning_engine:
            reasoning_inputs = {
                "unresolved_aws": unresolved_aws,
                "active_capabilities": {
                    cid: {"id": cid, "description": cinfo.get("description", ""), "category": cinfo.get("category", "")}
                    for cid, cinfo in active_capabilities.items()
                }
            }
            try:
                reason_output = reasoning_engine.reason(self.name, reasoning_inputs) or {}
                llm_matches = reason_output.get("matches", [])
                for match in llm_matches:
                    target_aw = match.get("aw_id") or (unresolved_aws[0].get("id") if unresolved_aws else None)
                    if target_aw:
                        candidate_matches.setdefault(target_aw, []).append({
                            "target_id": match.get("target_id"),
                            "confidence": float(match.get("confidence", 0.5)),
                            "matching_method": match.get("matching_method", "llm_similarity"),
                            "supporting_evidence": match.get("supporting_evidence", "LLM reasoning match.")
                        })
            except Exception as e:
                print(f"[CAS][WARN] Reasoning engine execution failed: {e}")

        # 6. Status-Evidence Validation
        status_evidence_validation = []
        for aw in aw_items:
            aw_id = aw.get("id")
            if not aw_id:
                continue
            status = aw.get("status", "")
            has_evidence = bool(explicit_lineage.get(aw_id) or candidate_matches.get(aw_id))
            if status.lower() in ("done", "completed", "active") and not has_evidence:
                status_evidence_validation.append({
                    "aw_id": aw_id,
                    "status": status,
                    "issue": "Architecture work status is marked completed/done but has no matching capability evidence.",
                    "severity": "critical"
                })
            elif status.lower() in ("proposed", "draft") and explicit_lineage.get(aw_id):
                status_evidence_validation.append({
                    "aw_id": aw_id,
                    "status": status,
                    "issue": "Architecture work status is proposed/draft but it already has explicit implementation lineage.",
                    "severity": "warning"
                })

        # 7. Duplicate Detection (local Jaccard similarity)
        import re
        duplicates = []
        def get_jaccard_similarity(aw1, aw2):
            t1 = (aw1.get("title", "") + " " + (aw1.get("details", "") or aw1.get("description", "") or "")).lower()
            t2 = (aw2.get("title", "") + " " + (aw2.get("details", "") or aw2.get("description", "") or "")).lower()
            t1 = re.sub(r'[^\w\s]', '', t1)
            t2 = re.sub(r'[^\w\s]', '', t2)
            words1 = set([w for w in t1.split() if len(w) > 2])
            words2 = set([w for w in t2.split() if len(w) > 2])
            if not words1 or not words2:
                return 0.0
            return len(words1 & words2) / len(words1 | words2)

        for idx, aw1 in enumerate(aw_items):
            aw1_id = aw1.get("id")
            if not aw1_id:
                continue
            for aw2 in aw_items[idx+1:]:
                aw2_id = aw2.get("id")
                if not aw2_id:
                    continue
                sim = get_jaccard_similarity(aw1, aw2)
                if sim >= 0.7:
                    duplicates.append({
                        "item_type": "architecture_work",
                        "ids": sorted([aw1_id, aw2_id]),
                        "similarity": round(sim, 2),
                        "rationale": f"High text similarity ({round(sim*100, 1)}%) on title and details."
                    })

        # 8. Oversized Candidates (maps to > 2 capabilities)
        oversized_candidates = []
        for aw in aw_items:
            aw_id = aw.get("id")
            if not aw_id:
                continue
            matched_caps = list(set(
                explicit_lineage.get(aw_id, []) + 
                [m["target_id"] for m in candidate_matches.get(aw_id, [])]
            ))
            if len(matched_caps) > 2:
                oversized_candidates.append({
                    "aw_id": aw_id,
                    "title": aw.get("title", "Untitled"),
                    "matched_capabilities": matched_caps,
                    "rationale": f"Maps to multiple independent capabilities (count: {len(matched_caps)})."
                })

        # 9. Orphan Capabilities
        all_matched_caps = set()
        for caps in explicit_lineage.values():
            all_matched_caps.update(caps)
        for matches in candidate_matches.values():
            all_matched_caps.update(m["target_id"] for m in matches)

        orphan_capabilities = []
        for cid in active_capabilities:
            if cid not in all_matched_caps:
                orphan_capabilities.append({
                    "capability_id": cid,
                    "description": capability_details.get(cid, {}).get("description", "No description available.")
                })

        # 10. Metadata Quality Validation
        metadata_quality = []
        for cid in active_capabilities:
            cinfo = active_capabilities[cid]
            cdetail = capability_details.get(cid, {})
            missing = []
            desc = cdetail.get("description", "")
            if not desc or len(desc) < 15:
                missing.append("description")
            if not cinfo.get("category") or cinfo.get("category") == "unknown":
                missing.append("category")
            if missing:
                metadata_quality.append({
                    "target_id": cid,
                    "target_type": "capability",
                    "missing_fields": missing,
                    "notes": f"Capability {cid} lacks descriptive metadata or category."
                })

        for aw in aw_items:
            aw_id = aw.get("id")
            if not aw_id:
                continue
            missing = []
            if not aw.get("title"):
                missing.append("title")
            if not aw.get("status"):
                missing.append("status")
            if not aw.get("date"):
                missing.append("date")
            if not aw.get("source"):
                missing.append("source")
            if missing:
                metadata_quality.append({
                    "target_id": aw_id,
                    "target_type": "architecture_work",
                    "missing_fields": missing,
                    "notes": f"Architecture Work {aw_id} is missing metadata fields."
                })

        # 11. Traceability Metrics
        total_aw = len(aw_items)
        aw_with_explicit = sum(1 for aw in aw_items if aw.get("id") in explicit_lineage)
        aw_with_candidate = sum(1 for aw in aw_items if aw.get("id") in candidate_matches)
        unmatched_aw = sum(1 for aw in aw_items if aw.get("id") and aw["id"] not in explicit_lineage and aw["id"] not in candidate_matches)

        traceability_metrics = {
            "explicit_lineage_coverage": round(aw_with_explicit / total_aw, 2) if total_aw > 0 else 1.0,
            "candidate_lineage_coverage": round(aw_with_candidate / total_aw, 2) if total_aw > 0 else 0.0,
            "orphan_capability_count": len(orphan_capabilities),
            "unmatched_aw_count": unmatched_aw
        }

        # 12. Evidence Quality Metrics
        total_aw_fields = len(aw_items) * 4
        missing_aw_fields = sum(len(mq["missing_fields"]) for mq in metadata_quality if mq["target_type"] == "architecture_work")
        
        total_cap_fields = len(active_capabilities) * 2
        missing_cap_fields = sum(len(mq["missing_fields"]) for mq in metadata_quality if mq["target_type"] == "capability")
        
        total_fields = total_aw_fields + total_cap_fields
        missing_fields = missing_aw_fields + missing_cap_fields
        
        completeness = round(((total_fields - missing_fields) / total_fields) * 100, 2) if total_fields > 0 else 100.0

        evidence_quality = {
            "metadata_completeness": completeness,
            "status_evidence_mismatch_count": len(status_evidence_validation),
            "duplicate_rate": round((len(duplicates) / total_aw) * 100, 2) if total_aw > 0 else 0.0,
            "oversized_count": len(oversized_candidates)
        }

        # 13. Observations
        observations = []
        if len(status_evidence_validation) > 0:
            observations.append(f"Detected {len(status_evidence_validation)} status-evidence validation issues.")
        if len(duplicates) > 0:
            observations.append(f"Detected {len(duplicates)} candidate duplicates.")
        if len(oversized_candidates) > 0:
            observations.append(f"Detected {len(oversized_candidates)} oversized Architecture Work candidates.")

        # 14. Metadata Block
        metadata = {
            "project": project,
            "generated_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "lineage_version": lineage.get("version", "unknown"),
            "runtime_snapshot": "latest",
            "builder_version": "2.0.0",
            "assessment_scope": "all",
            "reasoning_availability": reasoning_engine is not None
        }

        summary = (
            f"Prepared evidence for {project}. Resolved explicit lineage for {len(explicit_lineage)} items, "
            f"found {sum(len(v) for v in candidate_matches.values())} candidate matches, "
            f"detected {len(status_evidence_validation)} status-evidence mismatches."
        )

        runtime_capabilities = [
            {
                "id": cid, 
                "category": cinfo.get("category", "unknown"), 
                "description": capability_details.get(cid, {}).get("description", f"Tracked active capability {cid}")
            }
            for cid, cinfo in active_capabilities.items()
        ]

        # Consolidated Governance Context Structure
        governance_context = {
            "metadata": metadata,
            "summary": summary,
            "architecture_work": aw_items,
            "runtime_capabilities": runtime_capabilities,
            "explicit_lineage": explicit_lineage,
            "candidate_matches": candidate_matches,
            "status_evidence_validation": status_evidence_validation,
            "duplicates": duplicates,
            "oversized_candidates": oversized_candidates,
            "orphan_capabilities": orphan_capabilities,
            "metadata_quality": metadata_quality,
            "traceability_metrics": traceability_metrics,
            "evidence_quality": evidence_quality,
            "observations": observations
        }

        # Recursive serialization helper for date/datetime objects
        def make_json_serializable(obj):
            if isinstance(obj, dict):
                return {k: make_json_serializable(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [make_json_serializable(x) for x in obj]
            elif hasattr(obj, "isoformat"):
                return obj.isoformat()
            return obj

        governance_context = make_json_serializable(governance_context)

        # Save to projects/<project>/assessment/governance_context.json
        assessment_dir = workspace_root / "projects" / project / "assessment"
        safe_mkdir(assessment_dir, parents=True, exist_ok=True)
        context_path = assessment_dir / "governance_context.json"
        
        context_path.write_text(json.dumps(governance_context, indent=2))
        print(f"[CAS][GOVERNANCE] Governance context created: {context_path}")

        # Validate against schema
        try:
            schema_path = Path(__file__).parent.parent / "schemas" / "governance_context_schema.json"
            if schema_path.exists():
                with open(schema_path) as sf:
                    schema = json.load(sf)
                jsonschema.validate(instance=governance_context, schema=schema)
                print(f"[CAS][GOVERNANCE] Governance context validated successfully against schema.")
        except Exception as e:
            # Raise exception in test/execution to satisfy schema compliance checks
            print(f"[CAS][ERROR] Governance context schema validation failed: {e}")
            raise e

        return {
            "governance_context": governance_context
        }

    def validate(self, output: dict[str, Any]) -> None:
        assert "governance_context" in output
        assert "metadata" in output["governance_context"]
        assert "explicit_lineage" in output["governance_context"]
