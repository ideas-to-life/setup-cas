from datetime import date


class ConversationToAW:
    name = "conversation-to-aw"

    def prepare_inputs(self, context):
        return {
            "ingestion": context.get("ingestion", []),
            "rule_context": context.get("rule_context"),
            "project": context.get("project"),
            "date": context.get("date", date.today().isoformat())
        }

    def execute(self, inputs, reasoning_engine):
        if reasoning_engine is None:
            return {"architecture_work": []}

        llm_response = reasoning_engine.reason(self.name, inputs)
        aw_items = llm_response.get("architecture_work", [])

        output = {"architecture_work": aw_items}
        if aw_items:
            output["archived_conversations"] = [
                item["path"]
                for item in inputs.get("ingestion", [])
                if isinstance(item, dict) and "path" in item
            ]

        return output

    def validate(self, output):
        assert "architecture_work" in output
