import json
from pathlib import Path

from jsonschema import ValidationError, validate


class PatternPromotionWorkflow:
    name = "pattern-promotion-workflow"

    def prepare_inputs(self, context):
        return {
            "pattern_scope_classification": context.get("pattern_scope_classification"),
            "pattern_proposals": context.get("pattern_proposals", []),
            "existing_global_patterns": context.get("patterns", []),
            "architectural_state": context.get("architectural_state"),
            "project": context.get("project")
        }

    def execute(self, inputs, reasoning_engine):
        if reasoning_engine is None:
            return {"pattern_promotion_recommendations": self._empty_response()}

        llm_response = reasoning_engine.reason(self.name, inputs)

        if isinstance(llm_response, str):
            try:
                llm_response = json.loads(llm_response)
            except json.JSONDecodeError:
                print(f"[CAS][ERROR] Failed to parse reasoning response for '{self.name}'")
                return {"pattern_promotion_recommendations": self._empty_response()}

        return {"pattern_promotion_recommendations": llm_response}

    def validate(self, output):
        assert "pattern_promotion_recommendations" in output, "Missing 'pattern_promotion_recommendations' in output"
        recommendations_data = output["pattern_promotion_recommendations"]

        schema_path = Path(__file__).parent.parent / "schemas" / "pattern_promotion_recommendation_schema.json"
        if schema_path.exists():
            with open(schema_path) as f:
                schema = json.load(f)
            try:
                validate(instance=recommendations_data, schema=schema)
            except ValidationError as e:
                print(f"[CAS][ERROR] Pattern Promotion Recommendations validation failed: {e.message}")
                raise
        else:
            required_keys = [
                "promotion_candidates",
                "deferred_candidates",
                "rejected_candidates",
                "duplicate_overlapping_promotion_candidates",
                "promotion_preconditions_not_met",
                "governance_summary"
            ]
            for key in required_keys:
                assert key in recommendations_data, f"Missing required key '{key}' in output"

    def _empty_response(self):
        return {
            "promotion_candidates": [],
            "deferred_candidates": [],
            "rejected_candidates": [],
            "duplicate_overlapping_promotion_candidates": [],
            "promotion_preconditions_not_met": [],
            "governance_summary": {
                "immediate_promotion_candidates": [],
                "deferred_candidates": [],
                "rejected_candidates": [],
                "major_governance_risks": []
            }
        }
