"""
Flow Extractor (CAS-ARCH-STATE v0.2)

Discovers executable flows from repository evidence:
- Layer 4: CI/CD workflow definitions (GitHub Actions)
- Layer 5: CLI and application entrypoints (pyproject.toml scripts, click/argparse CLI)
- Layer 1 & 2: Step registries and pipeline definitions
"""

import ast
import re
from pathlib import Path
from typing import Any

import yaml


def _slugify(text: str) -> str:
    slug = text.lower().strip()
    slug = re.sub(r"[^a-z0-9_.-]+", "-", slug)
    return slug.strip("-") or "unknown"


IGNORED_DIRS = {
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    "dist",
    "build",
    ".specify",
}


def extract_github_workflows(
    target_dir: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Extracts executable flows from .github/workflows/*.yml and *.yaml."""
    target_dir = Path(target_dir).resolve()
    wf_dir = target_dir / ".github" / "workflows"
    flows: list[dict[str, Any]] = []
    evidence_list: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = []

    if not wf_dir.exists() or not wf_dir.is_dir():
        return flows, evidence_list, candidates

    for wf_file in sorted(wf_dir.glob("*.y*ml")):
        rel_path = str(wf_file.relative_to(target_dir))
        ev_id = f"ev-wf-{_slugify(wf_file.stem)}"
        try:
            with open(wf_file, encoding="utf-8") as f:
                content = yaml.safe_load(f)
        except Exception as e:
            candidates.append(
                {
                    "id": f"candidate:unparseable-wf:{_slugify(wf_file.stem)}",
                    "type": "unresolved_flow",
                    "raw_snippet": str(e),
                    "source_path": rel_path,
                    "reason": f"YAML parsing error: {e}",
                    "evidence_id": ev_id,
                }
            )
            continue

        if not isinstance(content, dict):
            continue

        evidence_list.append(
            {
                "id": ev_id,
                "path": rel_path,
                "type": "workflow",
                "snippet": f"name: {content.get('name', wf_file.stem)}",
                "confidence": "high",
            }
        )

        flow_name = content.get("name") or wf_file.stem
        # Extract triggers
        on_field = content.get("on") or content.get(
            True
        )  # YAML sometimes parses 'on' as True
        trigger_events = []
        if isinstance(on_field, str):
            trigger_events.append(on_field)
        elif isinstance(on_field, list):
            trigger_events.extend(str(item) for item in on_field)
        elif isinstance(on_field, dict):
            trigger_events.extend(str(k) for k in on_field.keys())
        else:
            trigger_events.append("workflow_dispatch")

        trigger_summary = ", ".join(trigger_events) if trigger_events else "unknown"

        jobs_dict = content.get("jobs", {})
        steps: list[dict[str, Any]] = []
        job_step_map: dict[str, list[str]] = {}  # job_name -> list of step_ids
        step_seq = 1

        if isinstance(jobs_dict, dict):
            for job_id, job_data in jobs_dict.items():
                if not isinstance(job_data, dict):
                    continue

                needs = job_data.get("needs", [])
                if isinstance(needs, str):
                    needs = [needs]
                elif not isinstance(needs, list):
                    needs = []

                job_step_ids = []
                job_steps = job_data.get("steps", [])
                if isinstance(job_steps, list):
                    for j_step in job_steps:
                        if not isinstance(j_step, dict):
                            continue

                        step_name = (
                            j_step.get("name")
                            or j_step.get("uses")
                            or j_step.get("run")
                            or f"Step {step_seq}"
                        )
                        step_id = f"step:{step_seq}:{_slugify(str(step_name))[:30]}"
                        job_step_ids.append(step_id)

                        # Determine dependencies from job 'needs'
                        depends_on = []
                        if step_seq > 1 and not needs and job_step_ids:
                            # By default depends on previous step within same job
                            prev_in_job = (
                                job_step_ids[-2] if len(job_step_ids) >= 2 else None
                            )
                            if prev_in_job:
                                depends_on.append(prev_in_job)

                        for dep_job in needs:
                            if job_step_map.get(dep_job):
                                depends_on.append(job_step_map[dep_job][-1])

                        implementation = j_step.get("uses") or j_step.get("run") or ""
                        step_obj = {
                            "id": step_id,
                            "name": str(step_name),
                            "sequence": step_seq,
                            "depends_on": depends_on,
                            "implementation": str(implementation),
                            "evidence_ids": [ev_id],
                            "confidence": "high",
                        }
                        steps.append(step_obj)
                        step_seq += 1

                job_step_map[job_id] = job_step_ids

        flow_slug = _slugify(flow_name)
        flow_id = f"flow:workflow:github:{flow_slug}"
        flows.append(
            {
                "id": flow_id,
                "name": flow_name,
                "type": "workflow",
                "description": f"GitHub Actions workflow defined in {rel_path}",
                "trigger": {
                    "type": "event",
                    "event": trigger_summary,
                    "source": "GitHub Actions",
                    "evidence_id": ev_id,
                },
                "entrypoint": {
                    "path": rel_path,
                    "command": f"github workflow {flow_name}",
                    "evidence_id": ev_id,
                },
                "steps": steps,
                "implementation": [rel_path],
                "evidence_ids": [ev_id],
                "confidence": "high",
                "status": "discovered",
            }
        )

    return flows, evidence_list, candidates


def extract_cli_entrypoints(
    target_dir: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Extracts CLI entrypoints from pyproject.toml and click/argparse AST definitions."""
    target_dir = Path(target_dir).resolve()
    flows: list[dict[str, Any]] = []
    evidence_list: list[dict[str, Any]] = []

    # 1. pyproject.toml console scripts
    pyproject_file = target_dir / "pyproject.toml"
    if pyproject_file.exists():
        ev_id = "ev-manifest-pyproject"
        content = pyproject_file.read_text(encoding="utf-8")
        evidence_list.append(
            {
                "id": ev_id,
                "path": "pyproject.toml",
                "type": "manifest",
                "reference": "[project.scripts]",
                "confidence": "high",
            }
        )

        # Regex search for [project.scripts]
        scripts_section = re.search(
            r"\[project\.scripts\](.*?)(?:\[|\Z)", content, re.DOTALL
        )
        if scripts_section:
            for line in scripts_section.group(1).splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                cmd, target = line.split("=", 1)
                cmd = cmd.strip().strip('"').strip("'")
                target = target.strip().strip('"').strip("'")
                flow_id = f"flow:cli:{_slugify(cmd)}:main"
                flows.append(
                    {
                        "id": flow_id,
                        "name": cmd,
                        "type": "cli",
                        "description": f"Console script '{cmd}' pointing to {target}",
                        "trigger": {
                            "type": "cli_command",
                            "event": cmd,
                            "source": "Terminal",
                            "evidence_id": ev_id,
                        },
                        "entrypoint": {
                            "path": "pyproject.toml",
                            "symbol": target,
                            "command": cmd,
                            "evidence_id": ev_id,
                        },
                        "steps": [
                            {
                                "id": f"step:1:{_slugify(cmd)}-entry",
                                "name": f"Execute {cmd}",
                                "sequence": 1,
                                "implementation": target,
                                "evidence_ids": [ev_id],
                                "confidence": "high",
                            }
                        ],
                        "implementation": ["pyproject.toml"],
                        "evidence_ids": [ev_id],
                        "confidence": "high",
                        "status": "discovered",
                    }
                )

    # 2. Inspect Python CLI files (search click/argparse commands)
    for py_file in target_dir.glob("src/**/*.py"):
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except Exception:
            continue

        rel_path = str(py_file.relative_to(target_dir))
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                is_click = any(
                    (
                        isinstance(d, ast.Call)
                        and hasattr(d.func, "attr")
                        and d.func.attr in ("command", "group")
                    )
                    or (isinstance(d, ast.Attribute) and d.attr in ("command", "group"))
                    for d in node.decorator_list
                )
                if is_click and node.name not in ("main", "cli"):
                    ev_cmd_id = f"ev-ast-{_slugify(rel_path)}-{node.name}"
                    evidence_list.append(
                        {
                            "id": ev_cmd_id,
                            "path": rel_path,
                            "type": "ast_symbol",
                            "reference": f"def {node.name}()",
                            "confidence": "high",
                        }
                    )
                    flow_id = f"flow:cli:{_slugify(py_file.stem)}:{_slugify(node.name)}"
                    flows.append(
                        {
                            "id": flow_id,
                            "name": f"{py_file.stem} {node.name}",
                            "type": "cli",
                            "description": f"CLI command '{node.name}' in {rel_path}",
                            "trigger": {
                                "type": "cli_command",
                                "event": node.name,
                                "source": "CLI",
                                "evidence_id": ev_cmd_id,
                            },
                            "entrypoint": {
                                "path": rel_path,
                                "symbol": node.name,
                                "command": node.name,
                                "evidence_id": ev_cmd_id,
                            },
                            "steps": [
                                {
                                    "id": f"step:1:{_slugify(node.name)}",
                                    "name": f"Execute {node.name}",
                                    "sequence": 1,
                                    "implementation": f"{rel_path}:{node.name}",
                                    "evidence_ids": [ev_cmd_id],
                                    "confidence": "high",
                                }
                            ],
                            "implementation": [rel_path],
                            "evidence_ids": [ev_cmd_id],
                            "confidence": "high",
                            "status": "discovered",
                        }
                    )

    return flows, evidence_list


def _extract_step_identifier(node: ast.AST) -> str | None:
    """Extracts step/component identifier from string literal, Name, or Attribute."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parts = []
        curr = node
        while isinstance(curr, ast.Attribute):
            parts.append(curr.attr)
            curr = curr.value
        if isinstance(curr, ast.Name):
            parts.append(curr.id)
            return ".".join(reversed(parts))
        return node.attr
    return None


def extract_step_registries(
    target_dir: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Extracts declared flows from Python dictionaries using structural duck-typing."""
    target_dir = Path(target_dir).resolve()
    flows: list[dict[str, Any]] = []
    evidence_list: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = []

    for py_file in target_dir.glob("src/**/*.py"):
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except Exception:
            continue

        rel_path = str(py_file.relative_to(target_dir))

        for node in ast.walk(tree):
            target_names = []
            dict_value = None

            if isinstance(node, ast.Assign):
                for t in node.targets:
                    if isinstance(t, ast.Name):
                        target_names.append(t.id)
                if isinstance(node.value, ast.Dict):
                    dict_value = node.value
            elif isinstance(node, ast.AnnAssign):
                if isinstance(node.target, ast.Name):
                    target_names.append(node.target.id)
                if isinstance(node.value, ast.Dict):
                    dict_value = node.value

            if not dict_value or not target_names:
                continue

            var_name = target_names[0]

            # Structural duck-typing: check if at least one entry has literal string key and list value
            has_candidate_entry = False
            for k, v in zip(dict_value.keys, dict_value.values, strict=False):
                key_str = getattr(k, "value", None) or getattr(k, "s", None)
                if isinstance(key_str, str) and isinstance(v, ast.List):
                    has_candidate_entry = True
                    break

            if not has_candidate_entry:
                continue

            ev_id = f"ev-reg-{_slugify(rel_path)}-{_slugify(var_name)}"
            evidence_list.append(
                {
                    "id": ev_id,
                    "path": rel_path,
                    "type": "ast_symbol",
                    "reference": var_name,
                    "confidence": "high",
                }
            )

            # Process dictionary entries
            for key_node, val_node in zip(
                dict_value.keys, dict_value.values, strict=False
            ):
                flow_name = getattr(key_node, "value", None) or getattr(
                    key_node, "s", None
                )

                # FR-004 & FR-014: If key is not a literal string, record unresolved candidate
                if not isinstance(flow_name, str):
                    candidates.append(
                        {
                            "id": f"candidate:unresolved-flow:{_slugify(rel_path)}:{_slugify(var_name)}-line-{getattr(key_node, 'lineno', 0)}",
                            "type": "unresolved_flow",
                            "raw_snippet": f"{var_name} entry on line {getattr(key_node, 'lineno', 0)}",
                            "source_path": rel_path,
                            "reason": "Flow key is not a literal string expression",
                            "evidence_id": ev_id,
                        }
                    )
                    continue

                # FR-013 & FR-014: If value is not a list, record unresolved candidate
                if not isinstance(val_node, ast.List):
                    candidates.append(
                        {
                            "id": f"candidate:unresolved-flow:{_slugify(rel_path)}:{_slugify(flow_name)}",
                            "type": "unresolved_flow",
                            "raw_snippet": f"{flow_name}: {ast.dump(val_node)[:60]}",
                            "source_path": rel_path,
                            "reason": f"Flow value for '{flow_name}' is not a list of steps",
                            "evidence_id": ev_id,
                        }
                    )
                    continue

                steps = []
                step_seq = 1
                for elem in val_node.elts:
                    s_name = _extract_step_identifier(elem)
                    if not s_name:
                        # Malformed step entry
                        candidates.append(
                            {
                                "id": f"candidate:unmapped-step:{_slugify(rel_path)}:{_slugify(flow_name)}-step-{step_seq}",
                                "type": "unmapped_step",
                                "raw_snippet": ast.dump(elem)[:60],
                                "source_path": rel_path,
                                "reason": f"Step expression in flow '{flow_name}' could not be resolved to an identifier",
                                "evidence_id": ev_id,
                            }
                        )
                        continue

                    step_id = f"step:{step_seq}:{_slugify(str(s_name))}"
                    # FR-007: Semantic restraint - depends_on is empty [] unless independently evidenced
                    steps.append(
                        {
                            "id": step_id,
                            "name": str(s_name),
                            "sequence": step_seq,
                            "depends_on": [],
                            "implementation": f"{rel_path}:{s_name}",
                            "evidence_ids": [ev_id],
                            "confidence": "high",
                        }
                    )
                    step_seq += 1

                # FR-009, FR-010, FR-011: Semantic restraint - declared_flow, unknown trigger
                flow_id = f"flow:declared_flow:{_slugify(rel_path)}:{_slugify(str(flow_name))}"
                flows.append(
                    {
                        "id": flow_id,
                        "name": str(flow_name),
                        "type": "declared_flow",
                        "description": f"Flow declared in {rel_path}:{var_name}",
                        "trigger": {
                            "type": "unknown",
                            "event": "unspecified",
                            "source": "code_declaration",
                            "evidence_id": ev_id,
                        },
                        "entrypoint": {
                            "path": rel_path,
                            "symbol": var_name,
                            "command": str(flow_name),
                            "evidence_id": ev_id,
                        },
                        "steps": steps,
                        "implementation": [rel_path],
                        "evidence_ids": [ev_id],
                        "confidence": "high",
                        "status": "discovered",
                    }
                )

    return flows, evidence_list, candidates


def extract_skill_flows(
    target_dir: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Extracts executable flows declared inside SKILL.md files."""
    target_dir = Path(target_dir).resolve()
    flows: list[dict[str, Any]] = []
    evidence_list: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = []

    for item in target_dir.rglob("SKILL.md"):
        if not item.is_file():
            continue
        rel_parts = item.relative_to(target_dir).parts
        if any(part in IGNORED_DIRS for part in rel_parts):
            continue

        rel_path = str(item.relative_to(target_dir))
        try:
            content = item.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            candidates.append(
                {
                    "id": f"candidate:unparseable-skill:{_slugify(item.parent.name)}",
                    "type": "unresolved_flow",
                    "raw_snippet": str(e),
                    "source_path": rel_path,
                    "reason": f"Skill reading error: {e}",
                }
            )
            continue

        meta: dict[str, Any] = {}
        fm_match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)$", content, re.DOTALL)
        body = content
        if fm_match:
            try:
                parsed_fm = yaml.safe_load(fm_match.group(1))
                if isinstance(parsed_fm, dict):
                    meta = parsed_fm
            except Exception:
                pass
            body = fm_match.group(2)

        skill_name = meta.get("name") or item.parent.name
        slug = _slugify(skill_name)
        ev_id = f"ev-skill-{slug}"

        evidence_list.append(
            {
                "id": ev_id,
                "path": rel_path,
                "type": "skill",
                "snippet": f"Skill {skill_name} flow",
                "confidence": "high",
            }
        )

        if rel_path.startswith(".cas/"):
            flow_type = "governance"
        elif rel_path.startswith(".agents/"):
            flow_type = "governance"
        else:
            flow_type = "agent"

        # Multi-pattern workflow parser
        # 1. Locate workflow section
        lines = body.splitlines()
        workflow_lines: list[str] = []
        in_workflow = False
        workflow_header_pattern = re.compile(
            r"^##\s+(?:Execution\s+Workflow|Workflow|Steps|Execution\s+Flow|Execution\s+Phases|Delivery\s+Lifecycle)",
            re.IGNORECASE,
        )

        for line in lines:
            if line.startswith("## "):
                if workflow_header_pattern.match(line):
                    in_workflow = True
                    continue
                elif in_workflow:
                    break
            elif in_workflow:
                workflow_lines.append(line)

        # Fallback to entire body if no dedicated header was matched
        search_lines = workflow_lines if workflow_lines else lines

        # 2. Extract steps from search_lines
        parsed_steps: list[tuple[int, str]] = []
        heading_step_pattern = re.compile(
            r"^###\s+(?:Step\s+)?(\d+)[:.]?\s*(.+)$", re.IGNORECASE
        )
        list_step_pattern = re.compile(r"^(\d+)\.\s+(?:\*\*(.+?)\*\*|(.+))$")

        for line in search_lines:
            stripped = line.strip()
            h_match = heading_step_pattern.match(stripped)
            if h_match:
                s_num = int(h_match.group(1))
                s_name = h_match.group(2).strip()
                parsed_steps.append((s_num, s_name))
                continue

            l_match = list_step_pattern.match(stripped)
            if l_match:
                s_num = int(l_match.group(1))
                s_name = (l_match.group(2) or l_match.group(3) or "").strip()
                if s_name:
                    parsed_steps.append((s_num, s_name))

        if not parsed_steps:
            continue

        flow_id = f"flow:{flow_type}:{slug}:execution-workflow"
        steps: list[dict[str, Any]] = []
        for idx, (_s_num, s_name) in enumerate(parsed_steps):
            s_slug = _slugify(s_name)[:30]
            step_id = f"step:{idx + 1}:{s_slug}"
            prev_id = steps[-1]["id"] if steps else None
            steps.append(
                {
                    "id": step_id,
                    "name": s_name,
                    "sequence": idx + 1,
                    "depends_on": [prev_id] if prev_id else [],
                    "implementation": rel_path,
                    "component_id": f"comp-skill-{slug}"
                    if flow_type == "agent"
                    else "",
                    "control_roles": ["Prevent"]
                    if flow_type == "governance"
                    else ["Prevent", "Generate"],
                    "evidence_ids": [ev_id],
                    "confidence": "high",
                }
            )

        display_name = skill_name.replace("-", " ").title()
        flows.append(
            {
                "id": flow_id,
                "name": f"{display_name} Workflow",
                "type": flow_type,
                "description": meta.get("description")
                or f"Execution workflow defined in {rel_path}",
                "trigger": {
                    "type": "cli_command" if flow_type == "governance" else "event",
                    "event": f"skill:{slug}",
                    "source": "skill",
                    "evidence_id": ev_id,
                },
                "entrypoint": {
                    "path": rel_path,
                    "symbol": slug,
                    "evidence_id": ev_id,
                },
                "steps": steps,
                "component_ids": [f"comp-skill-{slug}"] if flow_type == "agent" else [],
                "control_roles": ["Prevent"]
                if flow_type == "governance"
                else ["Prevent", "Generate"],
                "evidence_ids": [ev_id],
                "confidence": "high",
                "status": "discovered",
            }
        )

    return flows, evidence_list, candidates


def extract_all_flows(
    target_dir: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Runs all flow extractors and aggregates raw flows, evidence, and candidates."""
    target_dir = Path(target_dir).resolve()
    all_flows: list[dict[str, Any]] = []
    all_evidence: list[dict[str, Any]] = []
    all_candidates: list[dict[str, Any]] = []

    # 1. CI/CD Workflows
    wf_flows, wf_ev, wf_cand = extract_github_workflows(target_dir)
    all_flows.extend(wf_flows)
    all_evidence.extend(wf_ev)
    all_candidates.extend(wf_cand)

    # 2. CLI Entrypoints
    cli_flows, cli_ev = extract_cli_entrypoints(target_dir)
    all_flows.extend(cli_flows)
    all_evidence.extend(cli_ev)

    # 3. Step Registries
    reg_flows, reg_ev, reg_cand = extract_step_registries(target_dir)
    all_flows.extend(reg_flows)
    all_evidence.extend(reg_ev)
    all_candidates.extend(reg_cand)

    # 4. Skill Flows
    sk_flows, sk_ev, sk_cand = extract_skill_flows(target_dir)
    all_flows.extend(sk_flows)
    all_evidence.extend(sk_ev)
    all_candidates.extend(sk_cand)

    return all_flows, all_evidence, all_candidates
