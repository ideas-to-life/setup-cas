from typing import Any


def detect_contradictions(documented_entities: list[str], code_entities: list[str]) -> list[dict[str, Any]]:
    contradictions = []
    doc_set = set(documented_entities)
    code_set = set(code_entities)

    idx = 1
    # Documented but not in code
    for missing_in_code in sorted(doc_set - code_set):
        contradictions.append({
            "id": f"contra-{idx}",
            "entity_ref": missing_in_code,
            "description": f"Entity '{missing_in_code}' is documented in architecture assets but has no corresponding implementation in code or manifests.",
            "severity": "warning"
        })
        idx += 1

    # In code but not documented
    for missing_in_doc in sorted(code_set - doc_set):
        contradictions.append({
            "id": f"contra-{idx}",
            "entity_ref": missing_in_doc,
            "description": f"Entity '{missing_in_doc}' exists in code/manifests but is absent from documented architectural boundaries.",
            "severity": "info"
        })
        idx += 1

    return contradictions


def build_evidence_report(state: dict[str, Any]) -> str:
    ev_list = state.get("evidence", [])
    rows = []
    for e in ev_list:
        eid = e.get("id", "N/A")
        path = e.get("path", "N/A")
        etype = e.get("type", "unknown")
        conf = e.get("confidence", "low")
        rows.append(f"| `{eid}` | `{path}` | {etype} | {conf} |")

    table = "\n".join(rows) if rows else "| None | None | None | None |"
    return f"""# Forensic Evidence Report

> Catalog of deterministic and semantic evidence backing the architecture state reconstruction.

| Evidence ID | Path | Type | Confidence |
|---|---|---|---|
{table}
"""


def build_contradictions_report(state: dict[str, Any]) -> str:
    diag = state.get("diagnostics", {})
    contradictions = diag.get("contradictions", [])
    rows = []
    for c in contradictions:
        cid = c.get("id", "N/A")
        ref = c.get("entity_ref", "N/A")
        sev = c.get("severity", "info")
        desc = c.get("description", "Discrepancy detected")
        rows.append(f"| `{cid}` | `{ref}` | {sev} | {desc} |")

    table = "\n".join(rows) if rows else "| None | None | None | No architectural contradictions detected |"
    return f"""# Architectural Contradictions Report

> Audit of discrepancies detected between documented intent and empirical repository evidence.

| ID | Entity Ref | Severity | Description |
|---|---|---|---|
{table}
"""


def build_unknowns_report(state: dict[str, Any]) -> str:
    diag = state.get("diagnostics", {})
    unknowns = diag.get("unknowns", [])
    rows = []
    for u in unknowns:
        uid = u.get("id", "N/A")
        desc = u.get("description", "Unknown architectural element")
        impact = u.get("suspected_impact", "Unverified boundary")
        rows.append(f"| `{uid}` | {desc} | {impact} |")

    table = "\n".join(rows) if rows else "| None | No unknown boundaries flagged | None |"
    return f"""# Architecture Unknowns & Opaque Boundaries

> Catalog of system boundaries, dependencies, and external protocols that lack complete evidence.

| ID | Description | Suspected Impact |
|---|---|---|
{table}
"""


def build_coverage_report(state: dict[str, Any]) -> str:
    diag = state.get("diagnostics", {})
    cov = diag.get("coverage_summary", {})
    total = cov.get("total_entities", len(state.get("containers", [])) + len(state.get("components", [])))
    pct = cov.get("evidenced_entities_percentage", 100.0)
    status = state.get("status", "discovered")
    confidence = state.get("confidence", "medium")

    return f"""# Architecture Evidence Coverage Summary

- **Total Entities Discovered**: {total}
- **Evidenced Entities Percentage**: {pct}%
- **Reconstruction Status**: `{status}`
- **Overall Confidence**: `{confidence}`
"""


def generate_diagnostic_pack(state: dict[str, Any]) -> dict[str, str]:
    return {
        "evidence-report": build_evidence_report(state),
        "contradictions": build_contradictions_report(state),
        "unknowns": build_unknowns_report(state),
        "coverage": build_coverage_report(state),
    }
