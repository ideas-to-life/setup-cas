from pathlib import Path
from typing import Any


from cas_runner.steps.forensic.view_pack import render_flow_catalogue_table


def build_architecture_md(state: dict[str, Any], views: dict[str, str], diagrams: dict[str, str]) -> str:
    boundary = state.get("system_boundary", {})
    sys_name = boundary.get("name", "System")
    today = state.get("date", "Undated")
    status = state.get("status", "discovered")
    confidence = state.get("confidence", "medium")

    # 1. Executive Summary & System Boundary (Architecture at a Glance)
    context_view = views.get("system-context", "System architecture overview and boundaries.")
    context_diagram = diagrams.get("system-context", "").strip()
    context_mermaid = f"\n```mermaid\n{context_diagram}\n```\n" if context_diagram else ""

    # 2. System Context
    # (Context view & diagram communicate system boundary and external environment)

    # 3. Architecture Structure (Containers & Components)
    containers_view = views.get("containers", "")
    containers_diagram = diagrams.get("containers", "").strip()
    containers_mermaid = f"\n```mermaid\n{containers_diagram}\n```\n" if containers_diagram else ""

    components_view = views.get("components", "")
    components_diagram = diagrams.get("components", "").strip()
    components_mermaid = f"\n```mermaid\n{components_diagram}\n```\n" if components_diagram else ""

    # 4. Architecture Flows (Overview Diagram + Complete Flow Catalogue Table)
    rich_flows = state.get("flows", [])
    has_rich_flows = any(isinstance(f, dict) and "id" in f for f in rich_flows)

    flow_map_diagram = diagrams.get("flow-map") or diagrams.get("architecture-flow", "").strip()
    flows_mermaid = f"\n```mermaid\n{flow_map_diagram}\n```\n" if flow_map_diagram else ""

    flow_catalogue_table = render_flow_catalogue_table(rich_flows) if has_rich_flows else "No executable flows documented."

    # 5. Detailed Flows (Compact ordered steps for ALL discovered flows)
    detailed_flow_sections = []
    for flow in rich_flows:
        if not isinstance(flow, dict):
            continue
        fname = flow.get("name") or flow.get("id", "Unnamed Flow")
        steps = flow.get("steps", [])
        step_lines = []
        for idx, step in enumerate(steps):
            if isinstance(step, dict):
                sname = step.get("name") or step.get("id", f"Step {idx + 1}")
            else:
                sname = str(step)
            step_lines.append(f"{idx + 1}. {sname}")

        steps_text = "\n".join(step_lines) if step_lines else "1. unspecified-step"
        detailed_flow_sections.append(f"### {fname}\n{steps_text}\n")

    detailed_flows_body = "\n".join(detailed_flow_sections) if detailed_flow_sections else "No detailed flows recorded."

    # 6. Interfaces & Dependencies
    interfaces_view = views.get("interfaces", "")
    if not interfaces_view:
        deps = state.get("dependencies", [])
        dep_lines = [f"- `{d.get('source_id')}` → `{d.get('target_id')}` ({d.get('type', 'dependency')})" for d in deps]
        interfaces_view = "\n".join(dep_lines) if dep_lines else "No explicit inter-module dependencies recorded."

    # 7. Architecture Evidence
    evidence_view = views.get("evidence", "")
    if not evidence_view:
        ev_list = state.get("evidence", [])
        ev_lines = [f"- [`{e.get('id')}`] `{e.get('path')}` ({e.get('type', 'code')})" for e in ev_list[:25]]
        if len(ev_list) > 25:
            ev_lines.append(f"- *... and {len(ev_list) - 25} more evidence items.*")
        evidence_view = "\n".join(ev_lines) if ev_lines else "No evidence citations documented."

    # 8. Gaps, Ambiguities & Confidence
    gaps_view = views.get("gaps", "")
    if not gaps_view:
        diag = state.get("diagnostics", {})
        unknowns = diag.get("unknowns", [])
        gap_lines = [f"- **{u.get('id')}**: {u.get('description')} *(Impact: {u.get('suspected_impact', 'unknown')})*" for u in unknowns]
        controls_view = views.get("governance-controls", "")
        controls_diagram = diagrams.get("governance-controls", "").strip()
        ctrl_mermaid = f"\n```mermaid\n{controls_diagram}\n```\n" if controls_diagram else ""
        controls_part = f"### Governance Controls\n{controls_view}\n{ctrl_mermaid}\n" if controls_view or ctrl_mermaid else ""
        gaps_view = f"{controls_part}### Unknowns & Candidate Gaps\n" + ("\n".join(gap_lines) if gap_lines else "- No unresolved architectural ambiguities identified.")

    return f"""# Architecture: {sys_name}

> **Status**: `{status}` | **Confidence**: `{confidence}` | **Date**: `{today}`
> Reconstructed by Continuous Architecture System (CAS) Forensic Diagnostic.

---

## 1. Executive Summary & System Boundary
{context_view}
{context_mermaid}
---

## 2. System Context
The system boundary encompasses all declared components, workflows, and runtime interfaces identified across the target repository. External dependencies and actors interact through defined CLI, CI/CD, and file system entrypoints.

---

## 3. Architecture Structure
### Containers
{containers_view}
{containers_mermaid}

### Components
{components_view}
{components_mermaid}
---

## 4. Architecture Flows
{flows_mermaid}

### Flow Catalogue
{flow_catalogue_table}

---

## 5. Detailed Flows
> Compact sequence of constituent execution steps for all discovered flows.

{detailed_flows_body}
---

## 6. Interfaces & Dependencies
{interfaces_view}

---

## 7. Architecture Evidence
{evidence_view}

---

## 8. Gaps, Ambiguities & Confidence
{gaps_view}
"""


def publish_architecture_md(architecture_md: str, target_dir: str | Path, publish_root: bool = False) -> Path | None:
    if not publish_root:
        return None

    target_path = Path(target_dir)
    target_path.mkdir(parents=True, exist_ok=True)
    out_file = target_path / "ARCHITECTURE.md"
    with open(out_file, "w", encoding="utf-8") as f:
        f.write(architecture_md)
    return out_file
