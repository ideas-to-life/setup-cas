from pathlib import Path
from typing import Any
import re
from cas_runner.io import save_architecture_state_pack, get_default_base
from cas_runner.steps.forensic.diagnostic_reports import generate_diagnostic_pack


def _slugify(text: str) -> str:
    slug = text.lower().strip()
    slug = re.sub(r"[^a-z0-9_.-]+", "-", slug)
    return slug.strip("-") or "unknown"


def render_flow_catalogue_table(flows: list[dict[str, Any]]) -> str:
    rows = []
    for f in flows:
        fid = f.get("id", "flow:unknown")
        fname = f.get("name", fid)
        ftype = f.get("type", "unknown")
        trig_dict = f.get("trigger", {})
        trig_type = trig_dict.get("type")
        trig_event = trig_dict.get("event")
        if trig_type and trig_event and trig_event != "unspecified":
            trigger = f"{trig_type} ({trig_event})"
        elif trig_type and trig_type != "unknown":
            trigger = trig_type
        elif trig_event and trig_event != "unspecified":
            trigger = trig_event
        else:
            trigger = "unknown"
        steps_count = len(f.get("steps", []))
        entry = f.get("entrypoint", {}).get("path") or f.get("entrypoint", {}).get("command", "N/A")
        roles = ", ".join(f.get("control_roles", [])) or "None"
        conf = f.get("confidence", "medium")
        rows.append(f"| **{fname}** (`{fid}`) | `{ftype}` | `{trigger}` | {steps_count} | `{entry}` | {roles} | `{conf}` |")

    table_body = "\n".join(rows) if rows else "| None | None | None | 0 | None | None | None |"
    return f"""| Flow | Type | Trigger | Steps | Entrypoint | Control Roles | Confidence |
|---|---|---|---|---|---|---|
{table_body}
"""


def render_flow_map_diagram(flows: list[dict[str, Any]]) -> str:
    lines = ["flowchart LR"]
    # Group flows by category or type for high-level representation
    type_groups: dict[str, list[dict[str, Any]]] = {}
    for f in flows:
        ftype = f.get("type", "other")
        type_groups.setdefault(ftype, []).append(f)

    for ftype, group_flows in sorted(type_groups.items()):
        group_id = _slugify(ftype).replace("-", "_")
        group_label = ftype.replace("_", " ").title()
        lines.append(f'    subgraph sg_{group_id}["{group_label}"]')
        for f in group_flows:
            fid = _slugify(f.get("id", "flow")).replace("-", "_").replace(":", "_")
            fname = f.get("name", fid).replace('"', "'")
            lines.append(f'        {fid}["{fname}"]')
            cids = list(f.get("component_ids") or [])
            if not cids:
                for s in f.get("steps", []):
                    if isinstance(s, dict) and s.get("component_id"):
                        if s["component_id"] not in cids:
                            cids.append(s["component_id"])
            for cid in cids:
                clean_cid = _slugify(cid).replace("-", "_")
                lines.append(f'        {fid} -.-> comp_{clean_cid}["{cid}"]')
        lines.append("    end")

    return "\n".join(lines)


def render_individual_flow_diagram(flow: dict[str, Any]) -> str | None:
    steps = flow.get("steps", [])
    if not steps:
        return None

    # Multi-component or governance or workflow
    comp_ids = flow.get("component_ids", [])
    roles = flow.get("control_roles", [])
    flow_type = flow.get("type", "")

    # Check qualification
    if len(comp_ids) < 2 and not roles and flow_type != "workflow":
        return None

    fname = flow.get("name", "Flow").replace('"', "'")
    lines = [f"sequenceDiagram", f"    autonumber", f"    actor Actor as Trigger"]

    # Participants
    participants = set()
    for s in steps:
        if isinstance(s, dict) and s.get("component_id"):
            participants.add(s["component_id"])

    for p in sorted(participants):
        p_clean = _slugify(p).replace("-", "_")
        lines.append(f'    participant {p_clean} as {p}')

    # Trace
    last_target = "Actor"
    for s in steps:
        sname = (s.get("name") if isinstance(s, dict) else str(s)).replace('"', "'")
        target = "Actor"
        if isinstance(s, dict) and s.get("component_id"):
            target = _slugify(s["component_id"]).replace("-", "_")
        if target != last_target:
            lines.append(f'    {last_target}->>{target}: {sname}')
            last_target = target
        else:
            lines.append(f'    {target}->>{target}: {sname}')

    return "\n".join(lines)


def build_flow_views(flows: list[dict[str, Any]]) -> dict[str, str]:
    catalogue_table = render_flow_catalogue_table(flows)
    flow_map_mmd = render_flow_map_diagram(flows)

    # Detailed flows breakdown
    sections = [
        "# Executable Flow Catalogue",
        "",
        "> Discovered executable flows, pipelines, CLI entrypoints, and CI/CD lifecycles.",
        "",
        catalogue_table,
        "",
        "## Discovered Flow Details",
        ""
    ]

    for flow in flows:
        fid = flow.get("id", "unknown")
        fname = flow.get("name", fid)
        ftype = flow.get("type", "unknown")
        desc = flow.get("description", "")
        trig = flow.get("trigger", {})
        entry = flow.get("entrypoint", {})
        steps = flow.get("steps", [])
        comps = ", ".join(flow.get("component_ids", [])) or "None mapped"
        roles = ", ".join(flow.get("control_roles", [])) or "None"

        sections.append(f"### {fname} (`{fid}`)")
        sections.append(f"- **Type**: `{ftype}`")
        sections.append(f"- **Description**: {desc}")
        sections.append(f"- **Trigger**: `{trig.get('type')}` (`{trig.get('event')}`)")
        sections.append(f"- **Entrypoint**: `{entry.get('path')}` (`{entry.get('command', 'N/A')}`)")
        sections.append(f"- **Executing Components**: {comps}")
        sections.append(f"- **Governance Control Roles**: {roles}")
        sections.append(f"- **Confidence**: `{flow.get('confidence', 'medium')}`")
        sections.append("")
        sections.append("#### Steps")
        for s in steps:
            if isinstance(s, dict):
                s_seq = s.get("sequence", 1)
                s_name = s.get("name", "Step")
                s_comp = s.get("component_id", "N/A")
                s_impl = s.get("implementation", "N/A")
                s_deps = ", ".join(s.get("depends_on", [])) or "None"
                sections.append(f"- `{s_seq}`. **{s_name}** (`{s.get('id', '')}`)")
                sections.append(f"  - Component: `{s_comp}`")
                sections.append(f"  - Implementation: `{s_impl}`")
                sections.append(f"  - Depends On: {s_deps}")
            else:
                sections.append(f"- {s}")
        sections.append("")

        ind_diag = render_individual_flow_diagram(flow)
        if ind_diag:
            sections.append("#### Sequence Diagram")
            sections.append("```mermaid")
            sections.append(ind_diag)
            sections.append("```")
            sections.append("")

    flows_view_content = "\n".join(sections)
    flow_map_content = f"""# Architectural Flow Map

> High-level visualization of triggers, execution flows, constituent steps, and participating components.

```mermaid
{flow_map_mmd}
```
"""
    return {
        "flows": flows_view_content,
        "flow-map": flow_map_content,
    }


class ForensicViewPackStep:
    name = "forensic-view-pack"

    def prepare_inputs(self, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "project": context.get("project", "default-project"),
            "architecture_state": context.get("architecture_state", {}),
            "target_dir": context.get("target_dir", "."),
            "publish_root": context.get("publish_root", False),
            "base_path": context.get("base_path")
        }

    def execute(self, inputs: dict[str, Any], reasoning_engine: Any | None = None) -> dict[str, Any]:
        state = inputs.get("architecture_state", {})
        project = inputs.get("project", state.get("project", "default-project"))
        target_dir = inputs.get("target_dir", ".")
        publish_root = inputs.get("publish_root", False)
        base_path = inputs.get("base_path")

        views = self.render_views(state)
        diagrams = self.render_diagrams(state)
        architecture_md = self.render_architecture_md(state, views, diagrams)

        diagnostics = generate_diagnostic_pack(state)

        state_dir = save_architecture_state_pack(
            project=project,
            state_data=state,
            views=views,
            diagrams=diagrams,
            diagnostics=diagnostics,
            architecture_md=architecture_md,
            base_path=Path(base_path) if base_path else None
        )

        if publish_root:
            root_arch_md = Path(target_dir) / "ARCHITECTURE.md"
            with open(root_arch_md, "w", encoding="utf-8") as f:
                f.write(architecture_md)

        output = {
            "views": views,
            "diagrams": diagrams,
            "architecture_md": architecture_md,
            "saved_path": str(state_dir)
        }
        return output

    def render_views(self, state: dict[str, Any]) -> dict[str, str]:
        boundary = state.get("system_boundary", {})
        sys_name = boundary.get("name", "System")
        sys_desc = boundary.get("description", "System architecture description.")
        actors = boundary.get("external_actors", [])
        ext_systems = boundary.get("external_systems", [])

        # 1. System Context View
        actors_list = "\n".join(f"- {a}" for a in actors) or "- None documented"
        systems_list = "\n".join(f"- {s}" for s in ext_systems) or "- None documented"
        system_context = f"""# System Context View: {sys_name}

## Overview
{sys_desc}

## System Boundary
- **System Name**: {sys_name}
- **Status**: {state.get('status', 'discovered')}
- **Confidence**: {state.get('confidence', 'medium')}

## External Actors
{actors_list}

## External Systems
{systems_list}
"""

        # 2. Container View
        containers = state.get("containers", [])
        container_rows = []
        for c in containers:
            c_ev = ", ".join(c.get("evidence_ids", [])) or "None"
            container_rows.append(
                f"| `{c.get('id')}` | **{c.get('name')}** | {c.get('type')} | {c.get('technology', 'N/A')} | {c.get('status')} | {c_ev} |"
            )
        containers_table = "\n".join(container_rows) if container_rows else "| None | None | None | None | None | None |"
        containers_view = f"""# Container View: {sys_name}

| Container ID | Name | Type | Technology | Status | Evidence |
|---|---|---|---|---|---|
{containers_table}
"""

        # 3. Component View
        components = state.get("components", [])
        comp_sections = []
        for comp in components:
            resps = ", ".join(comp.get("responsibilities", [])) or "Core capability"
            ifaces = ", ".join(comp.get("interfaces", [])) or "Internal"
            evs = ", ".join(comp.get("evidence_ids", [])) or "None"
            comp_sections.append(
                f"### {comp.get('name')} (`{comp.get('id')}`)\n"
                f"- **Container**: `{comp.get('container_id')}`\n"
                f"- **Source Path**: `{comp.get('path')}`\n"
                f"- **Responsibilities**: {resps}\n"
                f"- **Interfaces**: {ifaces}\n"
                f"- **Confidence**: {comp.get('confidence')}\n"
                f"- **Evidence**: {evs}\n"
            )
        components_body = "\n".join(comp_sections) if comp_sections else "No components extracted."
        components_view = f"""# Component View: {sys_name}

{components_body}
"""

        # 4. Architecture Flow View
        flows = state.get("flows", [])
        flow_sections = []
        for flow in flows:
            step_lines = []
            for i, st in enumerate(flow.get("steps", [])):
                s_name = st.get("name") if isinstance(st, dict) else str(st)
                step_lines.append(f"  {i+1}. {s_name}")
            step_list = "\n".join(step_lines)
            flow_sections.append(
                f"### Flow: {flow.get('name')} (`{flow.get('id')}`)\n"
                f"- **Type**: {flow.get('type')}\n"
                f"- **Sequence**:\n{step_list}\n"
            )
        flows_body = "\n".join(flow_sections) if flow_sections else "No runtime flows documented."
        flows_view = f"""# Architecture Flow View: {sys_name}

{flows_body}
"""

        # 5. Governance Controls View
        controls = state.get("controls", [])
        ctrl_rows = []
        for ctrl in controls:
            evs = ", ".join(ctrl.get("evidence_ids", [])) or "None"
            ctrl_rows.append(
                f"| `{ctrl.get('id')}` | {ctrl.get('type')} | `{ctrl.get('enforcement_point')}` | {evs} |"
            )
        ctrl_table = "\n".join(ctrl_rows) if ctrl_rows else "| None | None | None | None |"
        governance_view = f"""# Governance Controls View: {sys_name}

| Control ID | Type | Enforcement Point | Evidence |
|---|---|---|---|
{ctrl_table}
"""

        flow_pack = build_flow_views(flows)

        return {
            "system-context": system_context,
            "containers": containers_view,
            "components": components_view,
            "architecture-flow": flows_view,
            "governance-controls": governance_view,
            "flows": flow_pack.get("flows", ""),
            "flow-map": flow_pack.get("flow-map", ""),
        }

    def render_diagrams(self, state: dict[str, Any]) -> dict[str, str]:
        boundary = state.get("system_boundary", {})
        sys_name = boundary.get("name", "System")
        actors = boundary.get("external_actors", [])
        ext_systems = boundary.get("external_systems", [])
        containers = state.get("containers", [])

        # Context Diagram
        actor_nodes = []
        actor_links = []
        for i, a in enumerate(actors):
            aid = f"Actor{i}"
            actor_nodes.append(f'    {aid}["User: {a}"]')
            actor_links.append(f'    {aid} --> SysBoundary')

        sys_nodes = []
        sys_links = []
        for j, s in enumerate(ext_systems):
            sid = f"ExtSys{j}"
            sys_nodes.append(f'    {sid}["System: {s}"]')
            sys_links.append(f'    SysBoundary --> {sid}')

        context_diagram = f"""flowchart TD
    subgraph SysBoundary["{sys_name}"]
        CoreSys["Core: {sys_name}"]
    end
{chr(10).join(actor_nodes)}
{chr(10).join(sys_nodes)}
{chr(10).join(actor_links)}
{chr(10).join(sys_links)}
"""

        # Container Diagram
        c_nodes = []
        for c in containers:
            cid = c.get("id", "c").replace("-", "_")
            c_nodes.append(f'        {cid}["{c.get("name")}<br/><i>[{c.get("technology", "Tech")}]</i>"]')

        containers_diagram = f"""flowchart TD
    subgraph Boundary["{sys_name}"]
{chr(10).join(c_nodes)}
    end
"""

        # 3. Component Diagram
        components = state.get("components", [])
        dependencies = state.get("dependencies", [])
        comp_nodes = []
        for comp in components:
            comp_id = comp.get("id", "comp").replace("-", "_")
            c_name = comp.get("name", "Component").replace('"', "'")
            c_path = comp.get("path", "").replace('"', "'")
            comp_nodes.append(f'        {comp_id}["{c_name}<br/><i>[{c_path}]</i>"]')

        dep_links = []
        for dep in dependencies:
            src = dep.get("source_id", "").replace("-", "_")
            tgt = dep.get("target_id", "").replace("-", "_").replace(".", "_")
            if src and tgt:
                dep_links.append(f'    {src} --> {tgt}')

        components_diagram = f"""flowchart TD
    subgraph Components["{sys_name} Components"]
{chr(10).join(comp_nodes) if comp_nodes else '        NoComponents["No Components Discovered"]'}
    end
{chr(10).join(dep_links)}
"""

        # 4. Architecture Flow Diagram
        flows = state.get("flows", [])
        flow_subgraphs = []
        for idx, flow in enumerate(flows):
            fid = flow.get("id", f"flow_{idx}").replace("-", "_")
            steps = flow.get("steps", [])
            step_nodes = []
            step_arrows = []
            for s_idx, step in enumerate(steps):
                sid = f"{fid}_s{s_idx}"
                clean_step = (step.get("name") if isinstance(step, dict) else str(step)).replace('"', "'")
                step_nodes.append(f'            {sid}["{s_idx + 1}. {clean_step}"]')
                if s_idx > 0:
                    prev_sid = f"{fid}_s{s_idx - 1}"
                    step_arrows.append(f'            {prev_sid} --> {sid}')

            flow_subgraphs.append(f"""    subgraph {fid}["{flow.get('name', fid)}"]
        direction LR
{chr(10).join(step_nodes) if step_nodes else f'            {fid}_empty["No Steps"]'}
{chr(10).join(step_arrows)}
    end""")

        flows_diagram = f"""flowchart LR
{chr(10).join(flow_subgraphs) if flow_subgraphs else '    NoFlows["No Lifecycle Flows Discovered"]'}
"""

        # 5. Governance Controls Diagram
        controls = state.get("controls", [])
        ctrl_by_type = {"prevent": [], "detect": [], "generate": [], "correct": []}
        for ctrl in controls:
            ctype = ctrl.get("type", "prevent")
            if ctype not in ctrl_by_type:
                ctrl_by_type[ctype] = []
            ctrl_by_type[ctype].append(ctrl)

        ctrl_subgraphs = []
        for ctype, c_list in ctrl_by_type.items():
            if c_list:
                nodes = []
                for c in c_list:
                    cid = c.get("id", "ctrl").replace("-", "_")
                    ep = c.get("enforcement_point", "N/A").replace('"', "'")
                    nodes.append(f'        {cid}["{ep}"]')
                ctrl_subgraphs.append(f"""    subgraph {ctype.title()}["{ctype.title()} Controls"]
{chr(10).join(nodes)}
    end""")

        controls_diagram = f"""flowchart TD
{chr(10).join(ctrl_subgraphs) if ctrl_subgraphs else '    NoControls["No Governance Controls Discovered"]'}
"""

        flow_map_markup = render_flow_map_diagram(flows)

        return {
            "system-context": context_diagram,
            "containers": containers_diagram,
            "components": components_diagram,
            "architecture-flow": flows_diagram,
            "governance-controls": controls_diagram,
            "flow-map": flow_map_markup,
        }

    def render_diagnostic_reports(self, state: dict[str, Any]) -> dict[str, str]:
        diag = state.get("diagnostics", {})
        contradictions = diag.get("contradictions", [])
        unknowns = diag.get("unknowns", [])
        cov = diag.get("coverage_summary", {})
        ev_list = state.get("evidence", [])

        # Evidence Report
        ev_rows = [f"| `{e.get('id')}` | `{e.get('path')}` | {e.get('type')} | {e.get('confidence')} |" for e in ev_list]
        evidence_report = f"""# Forensic Evidence Report

| Evidence ID | Path | Type | Confidence |
|---|---|---|---|
{"\n".join(ev_rows) if ev_rows else "| None | None | None | None |"}
"""

        # Contradictions
        c_rows = [f"| `{c.get('id')}` | `{c.get('entity_ref')}` | {c.get('severity')} | {c.get('description')} |" for c in contradictions]
        contradictions_report = f"""# Architectural Contradictions Report

| ID | Entity Ref | Severity | Description |
|---|---|---|---|
{"\n".join(c_rows) if c_rows else "| None | None | None | No contradictions detected |"}
"""

        # Unknowns
        u_rows = [f"| `{u.get('id')}` | {u.get('description')} | {u.get('suspected_impact')} |" for u in unknowns]
        unknowns_report = f"""# Architecture Unknowns & Opaque Boundaries

| ID | Description | Suspected Impact |
|---|---|---|
{"\n".join(u_rows) if u_rows else "| None | No unknown boundaries flagged | None |"}
"""

        # Coverage
        coverage_report = f"""# Architecture Evidence Coverage Summary

- **Total Entities Discovered**: {cov.get('total_entities', len(state.get('containers', [])) + len(state.get('components', [])))}
- **Evidenced Entities Percentage**: {cov.get('evidenced_entities_percentage', 100.0)}%
- **Reconstruction Status**: {state.get('status', 'discovered')}
- **Confidence**: {state.get('confidence', 'medium')}
"""

        return {
            "evidence-report": evidence_report,
            "contradictions": contradictions_report,
            "unknowns": unknowns_report,
            "coverage": coverage_report
        }

    def render_architecture_md(self, state: dict[str, Any], views: dict[str, str], diagrams: dict[str, str]) -> str:
        from cas_runner.steps.forensic.architecture_md_builder import build_architecture_md
        return build_architecture_md(state, views, diagrams)

    def validate(self, output: dict[str, Any]) -> None:
        if not isinstance(output, dict):
            raise ValueError("Output must be a dictionary")
        for key in ("views", "diagrams", "architecture_md"):
            if key not in output:
                raise ValueError(f"Output must contain '{key}'")
