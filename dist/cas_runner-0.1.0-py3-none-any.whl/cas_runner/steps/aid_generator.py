from datetime import date, datetime
from typing import Any


class AIDGenerator:
    name = "architecture-intent-generator"

    @staticmethod
    def _convert_dates_to_iso(data: Any) -> Any:
        """Recursively convert datetime.date and datetime.datetime objects to ISO format strings."""
        if isinstance(data, (date, datetime)):
            return data.isoformat()
        elif isinstance(data, dict):
            return {key: AIDGenerator._convert_dates_to_iso(value) for key, value in data.items()}
        elif isinstance(data, list):
            return [AIDGenerator._convert_dates_to_iso(item) for item in data]
        else:
            return data


    def prepare_inputs(self, context):
        inputs = {
            "aem": context.get("aem"),
            "baseline_assessment": context.get("baseline_assessment"),
            "alignment_report": context.get("alignment_report"),
            "vision": context.get("vision"),
            "project": context.get("project"),
            "date": context.get("date", date.today().isoformat())
        }

        return self._convert_dates_to_iso(inputs)

    def execute(self, inputs, reasoning_engine):
        aem = inputs.get("aem", {})
        alignment = inputs.get("alignment_report", {})
        project = inputs.get("project")

        # 1. Deterministic Base
        today = date.today().isoformat()
        total_aw = 0
        if aem:
            total_aw = aem.get("sections", {}).get("execution_summary", {}).get("total_items", 0)

        # summary.total_findings is now under alignment_summary in the new schema
        total_findings = alignment.get("sections", {}).get("alignment_summary", {}).get("critical_issues", 0) + \
                         alignment.get("sections", {}).get("alignment_summary", {}).get("high_issues", 0)

        # 2. LLM Augmentation
        if reasoning_engine is None:
            llm_response = {}
        else:
            llm_response = reasoning_engine.reason(self.name, inputs)

        # 3. Build Final AID
        if llm_response and "frontmatter" in llm_response and "sections" in llm_response:
            aid_data = llm_response
            # Overlay deterministic project context and sources
            aid_data["frontmatter"]["date"] = inputs.get("date", date.today().isoformat())
            aid_data["frontmatter"]["sources"] = {
                "aem": (aem.get("frontmatter", {}).get("id", "") if aem else ""),
                "alignment": (alignment.get("frontmatter", {}).get("id", "") if alignment else "")
            }
            aid_data["sections"]["scope_project_context"] = {
                "primary_context": project,
                "aw_count": total_aw,
                "alignment_findings": total_findings,
            }
        else:
            # Fallback to manual construction
            version = 1  # TODO: compute version
            generated_at = f"{today}T00:00:00Z"
            frontmatter = {
                "id": f"aid-{project}-{today}-v{version}",
                "knowledgeType": "architecture_intent",
                "project": project,
                "system": "Continuous Architecture System (CAS)",
                "status": "active",
                "generated_at": generated_at,
                "sources": {
                    "aem": (aem.get("frontmatter", {}).get("id", "") if aem else ""),
                    "alignment": (alignment.get("frontmatter", {}).get("id", "") if alignment else "")
                }
            }
            sections = {
                "scope_project_context": {
                    "primary_context": project,
                    "aw_count": total_aw,
                    "alignment_findings": total_findings,
                },
                "vision": {
                    "what_we_are_building": llm_response.get("what_we_are_building", "Establish initial architecture signals"),
                    "why_it_exists": llm_response.get("why_it_exists", ""),
                },
                "current_state": {
                    "alignment_notes": llm_response.get("alignment_notes", ""),
                },
                "gaps_tensions": llm_response.get("gaps_tensions", []),
                "roadmap": llm_response.get("roadmap", []),
            }
            aid_data = {
                "frontmatter": frontmatter,
                "sections": sections,
            }

        return {
            "aid": aid_data
        }

    def validate(self, output):
        assert "aid" in output
        aid_data = output["aid"]
        assert "frontmatter" in aid_data
        assert "sections" in aid_data
