import json
from pathlib import Path

from jsonschema import ValidationError, validate


class PatternScopeClassifier:
    name = "pattern-scope-classifier"

    def prepare_inputs(self, context):
        proposals = list(context.get("pattern_proposals", []))
        seen_ids = {
            p.get("pattern_id") or p.get("id") for p in proposals if isinstance(p, dict)
        }
        for cat_key in ("agentic_pattern_proposals", "structural_pattern_proposals"):
            cat_obj = context.get(cat_key)
            if isinstance(cat_obj, dict):
                for p in cat_obj.get("pattern_proposals", []):
                    pid = p.get("pattern_id") or p.get("id")
                    if pid and pid not in seen_ids:
                        proposals.append(p)
                        seen_ids.add(pid)

        return {
            "pattern_proposals": proposals,
            "existing_global_patterns": context.get("patterns", []),
            "architectural_state": context.get("architectural_state"),
            "project": context.get("project"),
        }

    def execute(self, inputs, reasoning_engine):
        if reasoning_engine is None:
            return {"pattern_scope_classification": self._empty_response()}

        llm_response = reasoning_engine.reason(self.name, inputs)

        if isinstance(llm_response, str):
            try:
                llm_response = json.loads(llm_response)
            except json.JSONDecodeError:
                print(
                    f"[CAS][ERROR] Failed to parse reasoning response for '{self.name}'"
                )
                return {"pattern_scope_classification": self._empty_response()}

        return {"pattern_scope_classification": llm_response}

    def validate(self, output):
        assert "pattern_scope_classification" in output, (
            "Missing 'pattern_scope_classification' in output"
        )
        classification_data = output["pattern_scope_classification"]

        schema_path = (
            Path(__file__).parent.parent
            / "schemas"
            / "pattern_scope_classification_schema.json"
        )
        if schema_path.exists():
            with open(schema_path) as f:
                schema = json.load(f)
            try:
                validate(instance=classification_data, schema=schema)
            except ValidationError as e:
                print(
                    f"[CAS][ERROR] Pattern Scope Classification validation failed: {e.message}"
                )
                raise
        else:
            # Fallback if schema is missing during development
            required_keys = [
                "global_pattern_candidates",
                "project_pattern_candidates",
                "candidate_patterns_requiring_review",
                "duplicate_overlapping_patterns",
                "promotion_recommendations",
            ]
            for key in required_keys:
                assert key in output, f"Missing required key '{key}' in output"

    def _empty_response(self):
        return {
            "global_pattern_candidates": [],
            "project_pattern_candidates": [],
            "candidate_patterns_requiring_review": [],
            "duplicate_overlapping_patterns": [],
            "promotion_recommendations": {
                "immediate_candidates": [],
                "deferred_candidates": [],
                "additional_evidence_required": [],
            },
        }
