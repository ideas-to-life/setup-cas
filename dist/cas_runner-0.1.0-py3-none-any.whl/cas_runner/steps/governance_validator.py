import os
import re
import subprocess
from pathlib import Path

from ..governance.governance_validator import GovernanceValidator


class GovernanceValidatorStep:
    name = "governance-validator"

    def prepare_inputs(self, context):
        return {"project": context.get("project")}

    def _get_current_branch(self) -> str:
        head_ref = os.getenv("GITHUB_HEAD_REF")
        if head_ref:
            return head_ref
        ref_name = os.getenv("GITHUB_REF_NAME")
        if ref_name:
            return ref_name
        try:
            res = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
                check=True
            )
            return res.stdout.strip()
        except Exception:
            return ""

    def _get_changed_files(self) -> list[str]:
        for base in ["origin/main", "main"]:
            try:
                res = subprocess.run(
                    ["git", "diff", "--name-only", f"{base}..."],
                    capture_output=True,
                    text=True,
                    check=True
                )
                return [line.strip() for line in res.stdout.splitlines() if line.strip()]
            except subprocess.CalledProcessError:
                continue
        # Fallback to HEAD~1
        try:
            res = subprocess.run(
                ["git", "diff", "--name-only", "HEAD~1"],
                capture_output=True,
                text=True,
                check=True
            )
            return [line.strip() for line in res.stdout.splitlines() if line.strip()]
        except subprocess.CalledProcessError:
            return []

    def _get_head_commit_message(self) -> str:
        try:
            res = subprocess.run(
                ["git", "log", "-1", "--pretty=%B"],
                capture_output=True,
                text=True,
                check=True
            )
            return res.stdout.strip()
        except Exception:
            return ""

    def execute(self, inputs, reasoning_engine):
        project = inputs.get("project")

        # SDD validation on code changes
        branch = self._get_current_branch()
        is_bypass_branch = any(branch.startswith(prefix) for prefix in ["draft/", "experiment/", "temp/", "hotfix/"])

        if branch and branch != "main" and not is_bypass_branch:
            commit_msg = self._get_head_commit_message()
            is_bypass_commit = "[skip-cas]" in commit_msg or "[skip ci]" in commit_msg

            if not is_bypass_commit:
                changed_files = self._get_changed_files()
                has_src_changes = any(f.startswith("src/") for f in changed_files)

                if has_src_changes:
                    # Regex matches optional prefixes followed by sequential or timestamp feature prefix
                    pattern = r"^(?:feature/|fix/|refactor/|chore/)?([0-9]{3,}|[0-9]{8}-[0-9]{6})(?:-|$)"
                    match = re.match(pattern, branch)
                    if not match:
                        raise ValueError(
                            f"Branch name '{branch}' does not follow naming conventions. "
                            f"When modifying code under 'src/', you must use a feature branch with sequential or timestamp prefix."
                        )
                    prefix = match.group(1)

                    # Check for specs folder matching the prefix
                    specs_dir = Path("specs")
                    matching_specs = list(specs_dir.glob(f"{prefix}-*"))
                    if not matching_specs:
                        raise ValueError(
                            f"No specification directory found under 'specs/' for prefix '{prefix}'."
                        )

        validator = GovernanceValidator(project)
        report = validator.validate()
        validator.save_report()

        # Check if we should fail on error (default: True)
        fail_on_error = reasoning_engine.context.get("config", {}).get("governance_fail_on_error", True)

        # Calculate pass/fail for specific categories for the console report
        schemas_ok = "PASS" if not any(f["type"] == "schema_violation" for f in report["findings"]) else "FAIL"
        traceability_ok = "PASS" if not any(f["type"] == "broken_reference" for f in report["findings"]) else "FAIL"
        lifecycle_ok = "PASS" if not any(f["type"] == "lifecycle_violation" for f in report["findings"]) else "FAIL"
        state_ok = "PASS" if not any(f["type"] == "state_inconsistency" for f in report["findings"]) else "FAIL"

        print("\nGovernance Validation Report")
        print(f"Schemas: {schemas_ok}")
        print(f"Traceability: {traceability_ok}")
        print(f"Lifecycle: {lifecycle_ok}")
        print(f"Governance State: {state_ok}")
        print(f"Warnings: {len(report['warnings'])}")
        print(f"Errors: {len(report['errors'])}")

        if report["status"] == "fail":
            print("\nDetails of Failures:")
            for finding in report["findings"]:
                if finding["severity"] == "error":
                    print(f"[ERROR] {finding['message']}")

            if fail_on_error:
                raise ValueError(f"Governance validation failed with {len(report['errors'])} errors.")
            else:
                print("\n[CAS][WARN] Governance validation failed, but 'governance_fail_on_error' is False. Proceeding with warnings.")

        return {"governance_report": report}

    def validate(self, output):
        assert "governance_report" in output
