from collections import defaultdict
from datetime import date, datetime
from typing import Any


class AEMGenerator:
    name = "architecture-work-to-evolution-map"

    @staticmethod
    def _convert_dates_to_iso(data: Any) -> Any:
        """Recursively convert datetime.date and datetime.datetime objects to ISO format strings."""
        if isinstance(data, (date, datetime)):
            return data.isoformat()
        elif isinstance(data, dict):
            return {key: AEMGenerator._convert_dates_to_iso(value) for key, value in data.items()}
        elif isinstance(data, list):
            return [AEMGenerator._convert_dates_to_iso(item) for item in data]
        else:
            return data

    @staticmethod
    def _summarize_adr(adr: Any) -> Any:
        """Extract essential metadata from an ADR, omitting bulky markdown sections."""
        if not isinstance(adr, dict):
            return adr
        return {
            "id": adr.get("id"),
            "pattern_id": adr.get("pattern_id"),
            "decision": adr.get("decision"),
            "governance": adr.get("governance"),
            "classification": adr.get("classification"),
            "date": adr.get("date"),
        }

    @staticmethod
    def _summarize_aw(aw: Any) -> Any:
        """Retain core planning and classification fields from architecture work while omitting bulky markdown bodies."""
        if not isinstance(aw, dict):
            return aw
        pruned = {k: v for k, v in aw.items() if k not in ["sections", "details"]}
        details = aw.get("details")
        if isinstance(details, str) and len(details) > 300:
            pruned["details"] = details[:300] + "..."
        elif details:
            pruned["details"] = details
        return pruned

    def prepare_inputs(self, context: dict[str, Any]) -> dict[str, Any]:
        """
        Prepare inputs for the AEM generator with bounded context payload.

        Args:
            context: The pipeline context containing architecture work, rule context, project, and date.

        Returns:
            A dictionary with the prepared inputs.
        """
        raw_aw = context.get("architecture_work", [])
        raw_adrs = context.get("decision_records", []) + context.get("adrs", [])

        summarized_aw = [self._summarize_aw(item) for item in raw_aw]
        summarized_adrs = [self._summarize_adr(item) for item in raw_adrs]

        inputs = {
            "architecture_work": summarized_aw,
            "rule_context": context.get("rule_context"),
            "vision": context.get("vision", {}) if "vision" in context else "",
            "adrs": summarized_adrs,
            "project": context.get("project"),
            "date": context.get("date", date.today().isoformat()),
        }
        return self._convert_dates_to_iso(inputs)


    def execute(self, inputs: dict[str, Any], reasoning_engine: Any | None) -> dict[str, Any]:
        """
        Execute the AEM generation process.

        Args:
            inputs: The prepared inputs containing architecture work, rule context, project, and date.
            reasoning_engine: The reasoning engine for LLM augmentation (can be None for deterministic output).

        Returns:
            A dictionary containing the frontmatter and sections of the AEM.

        Raises:
            KeyError: If required inputs are missing.
            TypeError: If inputs are of incorrect type.
        """
        try:
            # Validate required inputs
            if not isinstance(inputs, dict):
                raise TypeError("Inputs must be a dictionary")
            architecture_work = inputs.get("architecture_work")
            if not isinstance(architecture_work, list):
                raise TypeError("architecture_work must be a list")

            # 1. Deterministic Base
            summary, total_items = self._compute_execution_summary(architecture_work)

            # 2. LLM Reasoning (Pure Semantic reasoning)
            llm_response = self._get_llm_response(reasoning_engine, inputs)

            # 3. Build Final AEM
            # If LLM returned a full AEM structure, we use it as the base and overlay deterministic stats
            if llm_response and "frontmatter" in llm_response and "sections" in llm_response:
                aem_data = llm_response
                # Ensure deterministic stats and metadata are correct
                aem_data["frontmatter"]["date"] = inputs.get("date", date.today().isoformat())
                aem_data["sections"]["execution_summary"] = {
                    "summary": summary,
                    "total_items": total_items
                }
            else:
                # Fallback to manual construction if LLM failed or returned partial
                version = 1  # TODO: compute version
                frontmatter = self._build_frontmatter(inputs, version)
                sections = self._build_sections(
                    summary, total_items, architecture_work, llm_response, inputs
                )
                aem_data = {
                    "frontmatter": frontmatter,
                    "sections": sections
                }

            return {
                "aem": aem_data
            }
        except Exception as e:
            # Re-raise with context for better debugging
            raise RuntimeError(f"Failed to generate AEM: {e!s}") from e

    def _compute_execution_summary(
        self, architecture_work: list[dict[str, Any]]
    ) -> tuple[dict[str, int], int]:
        """
        Compute execution summary from architecture work items.

        Args:
            architecture_work: List of architecture work items.

        Returns:
            A tuple of (status summary dictionary, total item count).
        """
        summary = defaultdict(int)
        for aw in architecture_work:
            status = aw.get("status", "unknown")
            summary[status] += 1
        return dict(summary), len(architecture_work)

    def _get_llm_response(
        self, reasoning_engine: Any | None, inputs: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Get LLM augmentation response or empty dict if reasoning_engine is None.

        Args:
            reasoning_engine: The reasoning engine for LLM augmentation.
            inputs: The inputs to pass to the reasoning engine.

        Returns:
            The LLM response as a dictionary, or empty dict if reasoning_engine is None.
        """
        if reasoning_engine is None:
            return {}
        try:
            return reasoning_engine.reason(self.name, inputs)
        except Exception as e:
            # Log the error but continue with empty LLM response to avoid breaking the pipeline
            print(f"[WARNING] LLM reasoning failed: {e!s}")
            return {}

    def _build_frontmatter(self, inputs: dict[str, Any], version: int) -> dict[str, Any]:
        """
        Build the frontmatter section of the AEM.

        Args:
            inputs: The input dictionary containing project and date.
            version: The version number for the AEM.

        Returns:
            A dictionary representing the frontmatter.
        """
        aem_id = f"aem-{inputs['project']}-{inputs['date']}-{version}"
        return {
            "id": aem_id,
            "knowledgeType": "architecture_evolution_map",
            "project": inputs["project"],
            "date": inputs["date"],
            "version": version,
            "status": "active",
            "relationships": {
                "derives_from": [],
                "influences": [],
                "evaluates": [],
                "related_to": []
            }
        }

    def _build_sections(
        self,
        summary: dict[str, int],
        total_items: int,
        architecture_work: list[dict[str, Any]],
        llm_response: dict[str, Any],
        inputs: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Build the sections of the AEM.

        Args:
            summary: Dictionary of status counts.
            total_items: Total number of architecture work items.
            architecture_work: List of architecture work items.
            llm_response: The LLM augmentation response.
            inputs: The input dictionary (unused but kept for consistency).

        Returns:
            A dictionary representing the sections.
        """
        return {
            "execution_summary": {
                "summary": summary,
                "total_items": total_items
            },
            "execution_tag_legend": llm_response.get("execution_tag_legend", {}),
            "todays_actions": llm_response.get("todays_actions", []),
            "evolution_map": llm_response.get("evolution_map", []),
            "key_architectural_decisions": llm_response.get("key_architectural_decisions", []),
            "system_evolution": llm_response.get("system_evolution", ""),
            "intent_direction": llm_response.get("intent_direction", ""),
            "pattern_evolution": llm_response.get("pattern_evolution", {
                "emerging": [],
                "promoted": []
            }),
            "views": llm_response.get("views", []),
            "knowledge_system_health": llm_response.get("knowledge_system_health", {}),
            "relationships": llm_response.get("relationships", {
                "derives_from": [],
                "influences": [],
                "evaluates": [],
                "related_to": []
            })
        }

    def validate(self, output: dict[str, Any]) -> None:
        """
        Validate the AEM generator output.

        Args:
            output: The output dictionary from the execute method.

        Raises:
            AssertionError: If the output does not contain the required keys.
        """
        assert "aem" in output, "Output must contain 'aem' key"
        aem_data = output["aem"]
        assert "frontmatter" in aem_data, "AEM data must contain 'frontmatter' key"
        assert "sections" in aem_data, "AEM data must contain 'sections' key"
