"""Step implementation for projecting extracted pattern catalogues into downstream pattern proposals."""

from datetime import datetime
import json
from pathlib import Path
from typing import Any

import jsonschema


class PatternCatalogueToProposalsStep:
    name = "pattern-catalogue-to-proposals"

    def prepare_inputs(self, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "project": context.get("project", "unknown"),
            "agentic_patterns_catalogue": context.get("agentic_patterns_catalogue"),
            "structural_patterns_catalogue": context.get("structural_patterns_catalogue"),
        }

    def execute(self, inputs: dict[str, Any], reasoning_engine: Any = None) -> dict[str, Any]:
        result = {}

        agentic_cat = inputs.get("agentic_patterns_catalogue")
        if agentic_cat:
            agentic_proposals = self._project_catalogue_to_proposals(agentic_cat, default_classification="intelligence")
            result["agentic_pattern_proposals"] = agentic_proposals

        structural_cat = inputs.get("structural_patterns_catalogue")
        if structural_cat:
            structural_proposals = self._project_catalogue_to_proposals(structural_cat, default_classification="architectural")
            result["structural_pattern_proposals"] = structural_proposals

        return result

    def validate(self, output: dict[str, Any]) -> None:
        schema_path = Path(__file__).parent.parent.parent / "schemas" / "pattern_proposal_schema.json"
        if not schema_path.exists():
            return

        with open(schema_path) as fh:
            schema = json.load(fh)

        if "agentic_pattern_proposals" in output:
            jsonschema.validate(instance=output["agentic_pattern_proposals"], schema=schema)

        if "structural_pattern_proposals" in output:
            jsonschema.validate(instance=output["structural_pattern_proposals"], schema=schema)

    def _project_catalogue_to_proposals(self, catalogue: dict[str, Any], default_classification: str) -> dict[str, Any]:
        patterns = catalogue.get("patterns", [])
        proposals = []

        for p in patterns:
            pattern_id = p.get("id") or p.get("name", "unnamed").lower().replace(" ", "-")
            name = p.get("name", pattern_id)
            summary = p.get("summary") or p.get("intent", "")

            # Classification
            domain = p.get("domain", [])
            classification = default_classification
            if "governance" in domain:
                classification = "governance"
            elif "execution" in domain:
                classification = "execution"
            elif "intelligence" in domain or "ai" in domain:
                classification = "intelligence"
            elif "architecture" in domain or "structural" in domain:
                classification = "architectural"

            # Maturity mapping
            mat_raw = (p.get("maturity") or "emerging").lower()
            if mat_raw in ["stable", "established"]:
                maturity = "established"
            elif mat_raw in ["exploring", "emerging"]:
                maturity = "emerging"
            else:
                maturity = "strategic_direction"

            # Supporting evidence
            supporting_evidence = []
            for ev in p.get("evidence", []):
                if isinstance(ev, dict):
                    path = ev.get("path", "")
                    note = ev.get("note", "")
                    symbols = ", ".join(ev.get("symbols", []))
                    parts = [path]
                    if symbols:
                        parts.append(f"({symbols})")
                    if note:
                        parts.append(f"- {note}")
                    supporting_evidence.append(" ".join(parts).strip())
                elif isinstance(ev, str):
                    supporting_evidence.append(ev)

            # Rationale & forces
            rationale = []
            if p.get("intent"):
                rationale.append(f"Intent: {p.get('intent')}")
            if p.get("context"):
                rationale.append(f"Context: {p.get('context')}")
            for force in p.get("forces", []):
                rationale.append(f"Force: {force}")
            if not rationale:
                rationale = [summary or "Identified from repository evidence"]

            # Confidence & strength
            conf = p.get("confidence", "medium").lower()
            if conf not in ["high", "medium", "low"]:
                conf = "medium"

            strength = p.get("extraction_metadata", {}).get("evidence_strength", conf).lower()
            if strength not in ["high", "medium", "low"]:
                strength = conf

            proposal = {
                "pattern_id": pattern_id,
                "name": name,
                "pattern_classification": classification,
                "pattern_maturity": maturity,
                "knowledgeType": "signal",
                "decision": {
                    "status": "proposed",
                    "decided_by": "system",
                    "date": datetime.now().date().isoformat()
                },
                "derived_from": {
                    "signals": [],
                    "architecture_work": [],
                    "supporting_evidence": supporting_evidence
                },
                "description": summary,
                "pattern_type": "implemented" if maturity == "established" else "emerging",
                "applies_to": [catalogue.get("catalogue_metadata", {}).get("repo_name", "system")],
                "rationale": rationale,
                "evidence_strength": strength,
                "confidence": conf
            }
            proposals.append(proposal)

        return {"pattern_proposals": proposals}
