"""Step implementation for extracting Agentic AI patterns from codebase evidence."""

from datetime import datetime
import json
from pathlib import Path
from typing import Any

import jsonschema

from .evidence_scanner import scan_codebase_evidence


class AgenticPatternsExtractorStep:
    name = "agentic-patterns-extractor"

    def prepare_inputs(self, context: dict[str, Any]) -> dict[str, Any]:
        evidence = scan_codebase_evidence(context)
        return {
            "project": context.get("project", "unknown"),
            "target_dir": context.get("target_dir"),
            "has_code_evidence": evidence.get("has_code_evidence", False),
            "manifests": evidence.get("manifests", []),
            "directory_tree": evidence.get("directory_tree", []),
            "key_files": evidence.get("key_files", []),
            "date": datetime.now().isoformat(),
        }

    def execute(self, inputs: dict[str, Any], reasoning_engine: Any) -> dict[str, Any]:
        project = inputs.get("project", "unknown")

        # Edge case: No code evidence found in target repository
        if not inputs.get("has_code_evidence"):
            print(f"[CAS][WARN] No code evidence found in target for '{self.name}'. Generating empty catalogue.")
            return {
                "agentic_patterns_catalogue": self._empty_catalogue(
                    project=project,
                    reason="No code evidence detected in target repository"
                )
            }

        if reasoning_engine is None:
            return {"agentic_patterns_catalogue": self._empty_catalogue(project=project)}

        llm_response = reasoning_engine.reason(self.name, inputs)

        if isinstance(llm_response, str):
            try:
                llm_response = json.loads(llm_response)
            except json.JSONDecodeError:
                print(f"[CAS][ERROR] Failed to parse reasoning response as JSON for step '{self.name}'")
                return {
                    "agentic_patterns_catalogue": self._empty_catalogue(
                        project=project,
                        reason="Failed to parse LLM response as JSON"
                    )
                }

        if isinstance(llm_response, dict):
            if "agentic_patterns_catalogue" in llm_response:
                catalogue = llm_response["agentic_patterns_catalogue"]
            else:
                catalogue = llm_response
        else:
            catalogue = self._empty_catalogue(project=project, reason="Invalid response format")

        if not catalogue or not isinstance(catalogue, dict) or "catalogue_metadata" not in catalogue:
            catalogue = self._empty_catalogue(project=project, reason="Reasoning response missing required catalogue metadata")

        return {"agentic_patterns_catalogue": catalogue}

    def validate(self, output: dict[str, Any]) -> None:
        assert "agentic_patterns_catalogue" in output, "Missing 'agentic_patterns_catalogue' in output"
        catalogue_data = output["agentic_patterns_catalogue"]

        schema_path = Path(__file__).parent.parent.parent / "schemas" / "agentic_patterns_catalogue_schema.json"
        if schema_path.exists():
            with open(schema_path) as fh:
                schema = json.load(fh)
            jsonschema.validate(instance=catalogue_data, schema=schema)

    def _empty_catalogue(self, project: str, reason: str | None = None) -> dict[str, Any]:
        limits = [reason] if reason else ["No code evidence detected"]
        return {
            "catalogue_metadata": {
                "repo_name": project,
                "repo_version_or_commit": None,
                "focus": "agentic-ai",
                "generated_at": datetime.now().isoformat(),
                "scope_notes": "Automated extraction",
                "analysis_limits": limits,
                "default_domain": ["Architecture"],
                "default_sources": ["Source Code"]
            },
            "system_map": {
                "overview": "No agentic architecture patterns extracted.",
                "agents": [],
                "orchestration": {
                    "style": "unknown",
                    "description": "N/A",
                    "evidence": []
                },
                "tools_and_integrations": [],
                "state_and_memory": []
            },
            "patterns": [],
            "anti_patterns": [],
            "cross_cutting_concerns": [],
            "open_questions": []
        }
