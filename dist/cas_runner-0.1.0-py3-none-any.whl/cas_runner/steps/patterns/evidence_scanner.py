"""Hybrid repository evidence scanner for architecture pattern extraction."""

import ast
from pathlib import Path
from typing import Any

IGNORED_DIRS = {
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    "dist",
    "build",
    ".specify",
    ".cas",
}

MANIFEST_FILENAMES = {
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    "requirements.txt",
    "package.json",
    "go.mod",
    "Cargo.toml",
    "pom.xml",
    "build.gradle",
    "Makefile",
    "Dockerfile",
}

CODE_EXTENSIONS = {
    ".py",
    ".js",
    ".ts",
    ".tsx",
    ".jsx",
    ".go",
    ".rs",
    ".java",
    ".kt",
    ".cs",
    ".rb",
}


def scan_codebase_evidence(context: dict[str, Any], target_dir: str | Path | None = None) -> dict[str, Any]:
    """Extract evidence from execution context or perform a lightweight filesystem scan."""
    # 1. Check if upstream evidence_model exists in context
    if "evidence_model" in context and isinstance(context["evidence_model"], dict):
        model = context["evidence_model"]
        return {
            "source": "evidence_model",
            "repo_name": context.get("project", "unknown"),
            "manifests": model.get("manifests", []),
            "directory_tree": model.get("structure", []),
            "key_files": model.get("code_samples", []),
            "has_code_evidence": bool(model.get("manifests") or model.get("code_samples")),
        }

    # 2. Otherwise, resolve target directory
    repo_path = None
    if target_dir:
        repo_path = Path(target_dir)
    elif context.get("target_dir"):
        repo_path = Path(context["target_dir"])
    elif context.get("project_root"):
        repo_path = Path(context["project_root"])
    else:
        repo_path = Path.cwd()

    repo_path = repo_path.resolve()
    repo_name = context.get("project") or repo_path.name

    if not repo_path.exists() or not repo_path.is_dir():
        return {
            "source": "lightweight_scan",
            "repo_name": repo_name,
            "manifests": [],
            "directory_tree": [],
            "key_files": [],
            "has_code_evidence": False,
        }

    manifests = []
    directory_tree = []
    key_files = []
    code_file_count = 0

    # Scan directory tree up to 3 levels deep
    for item in sorted(repo_path.rglob("*")):
        try:
            rel = item.relative_to(repo_path)
        except ValueError:
            continue

        if any(part in IGNORED_DIRS for part in rel.parts):
            continue

        if len(rel.parts) <= 3:
            directory_tree.append(str(rel) + ("/" if item.is_dir() else ""))

        if not item.is_file():
            continue

        # Check manifests
        if item.name in MANIFEST_FILENAMES:
            snippet = ""
            try:
                snippet = item.read_text(encoding="utf-8", errors="replace")[:1000]
            except Exception:
                pass
            manifests.append({
                "path": str(rel),
                "filename": item.name,
                "snippet": snippet,
            })

        # Check code files
        if item.suffix in CODE_EXTENSIONS:
            code_file_count += 1
            # Sample up to 15 key architectural files (orchestrators, runners, main, steps, controllers)
            name_lower = item.stem.lower()
            is_priority = any(k in name_lower for k in [
                "run", "main", "cli", "orchestrat", "step", "agent", "flow",
                "schema", "model", "service", "handler", "controller", "engine"
            ])
            if (is_priority or code_file_count <= 5) and len(key_files) < 15:
                symbols = _extract_file_symbols(item)
                key_files.append({
                    "path": str(rel),
                    "symbols": symbols,
                })

    has_evidence = bool(manifests or code_file_count > 0)

    return {
        "source": "lightweight_scan",
        "repo_name": repo_name,
        "manifests": manifests,
        "directory_tree": directory_tree[:100],  # Bounded tree size
        "key_files": key_files,
        "has_code_evidence": has_evidence,
    }


def _extract_file_symbols(file_path: Path) -> list[str]:
    """Extract top-level classes and functions if Python, or fallback to empty."""
    symbols = []
    if file_path.suffix == ".py":
        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
            tree = ast.parse(content)
            for node in tree.body:
                if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                    symbols.append(node.name)
        except Exception:
            pass
    return symbols[:10]
