"""Pattern extraction steps and utilities."""
