from ..io import get_provider


class RulesContextLoader:
    name = "rules-context-loader"

    def prepare_inputs(self, context):
        """Prepare inputs by loading rule contents from the knowledge provider."""
        project = context.get("project")
        rules = get_provider().load_rules(project)

        return {
            "rules": rules,
            "project": project
        }

    def execute(self, inputs, reasoning_engine):

        if reasoning_engine is None:
            return {}
        else:
            try:
                llm_response = reasoning_engine.reason(self.name, inputs)
                rules_context = llm_response.get("rule_context", [])
                return {"rule_context": rules_context}
            except Exception as e:
                print(f"[CAS][ERROR] Failed to execute reasoning for rules context: {e}")
                return {}

    def validate(self, output):
        assert "rule_context" in output, "Missing rule_context"
