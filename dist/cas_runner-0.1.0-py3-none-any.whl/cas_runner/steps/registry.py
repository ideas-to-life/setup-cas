from .aem_generator import AEMGenerator
from .aid_generator import AIDGenerator
from .alignment import AlignmentEngine
from .approved_adr_to_pattern import ApprovedADRToPattern
from .architecture_work_assessment import ArchitectureWorkAssessmentStep
from .control_bands import ControlBandsStep
from .conversation_to_aw import ConversationToAW
from .current_architecture_state import CurrentArchitectureStateGenerator
from .discovery import BaselineDiscoveryStep
from .discovery_to_aw import DiscoveryToAW
from .forensic.extractor import ForensicExtractorStep
from .forensic.reconciler import ForensicReconcilerStep
from .forensic.view_pack import ForensicViewPackStep
from .governance_context_builder import GovernanceContextBuilderStep
from .governance_validator import GovernanceValidatorStep
from .pattern_promotion import PatternPromotionWorkflow
from .pattern_proposals import SignalToPatternProposals
from .pattern_scope_classifier import PatternScopeClassifier
from .patterns.agentic_extractor import AgenticPatternsExtractorStep
from .patterns.proposal_projection import PatternCatalogueToProposalsStep
from .patterns.structural_extractor import StructuralPatternsExtractorStep
from .promotion_decision_capture import PromotionDecisionCapture
from .promotion_to_adr import PromotionToDecisionRecords
from .reference_architecture import ReferenceArchitectureGenerator
from .roadmap_bootstrap import RoadmapBootstrapStep
from .rules_context import RulesContextLoader
from .steering_projection import SteeringProjectionStep
from .vision_to_aw import VisionToAW

FLOWS = {
    "roadmap-bootstrap-flow": ["roadmap-bootstrap"],
    "orchestration-flow": [
        "rules-context-loader",
        "architecture-work-to-evolution-map",
        "alignment-engine",
        "architecture-intent-generator",
    ],
    "governance-validator": [
        "governance-validator",
    ],
    "steering-projection-flow": [
        "steering-projection",
    ],
    "flow-discovery-flow": [
        "forensic-extractor",
        "forensic-reconciler",
        "forensic-view-pack",
    ],
    "forensic-diagnostic-flow": [
        "forensic-extractor",
        "forensic-reconciler",
        "forensic-view-pack",
    ],
    "discovery-flow": [
        "forensic-extractor",
        "forensic-reconciler",
        "forensic-view-pack",
        "baseline-discovery",
    ],
    "conversation-to-aw": ["rules-context-loader", "conversation-to-aw"],
    "discovery-to-aw": ["rules-context-loader", "discovery-to-aw"],
    "vision-to-aw": ["rules-context-loader", "vision-to-aw"],
    "current-architecture-state-generator": [
        "rules-context-loader",
        "current-architecture-state-generator",
    ],
    "signal-to-pattern-proposals": [
        "rules-context-loader",
        "signal-to-pattern-proposals",
    ],
    "pattern-scope-classifier": ["rules-context-loader", "pattern-scope-classifier"],
    "pattern-promotion-workflow": [
        "rules-context-loader",
        "pattern-promotion-workflow",
    ],
    "promotion-decision-capture": [
        "rules-context-loader",
        "promotion-decision-capture",
    ],
    "promotion-to-decision-records": [
        "rules-context-loader",
        "promotion-to-decision-records",
    ],
    "approved-adr-to-pattern": ["rules-context-loader", "approved-adr-to-pattern"],
    "continuous-architecture-loop": [
        "rules-context-loader",
        "conversation-to-aw",
        "architecture-work-to-evolution-map",
        "alignment-engine",
        "architecture-intent-generator",
        "governance-validator",
        "control-bands-check",
    ],
    "assessment-flow": ["governance-context-builder", "architecture-work-assessment"],
    "extract-agentic-patterns": ["rules-context-loader", "agentic-patterns-extractor"],
    "extract-structural-patterns": [
        "rules-context-loader",
        "structural-patterns-extractor",
    ],
    "patterns-extraction-flow": [
        "rules-context-loader",
        "agentic-patterns-extractor",
        "structural-patterns-extractor",
        "pattern-catalogue-to-proposals",
    ],
    "reference-architecture-flow": [
        "rules-context-loader",
        "reference-architecture-generator",
    ],
    "pattern-lifecycle-flow": [
        "rules-context-loader",
        "agentic-patterns-extractor",
        "structural-patterns-extractor",
        "pattern-catalogue-to-proposals",
        "signal-to-pattern-proposals",
        "pattern-scope-classifier",
        "pattern-promotion-workflow",
        "reference-architecture-generator",
    ],
}

STEPS = {
    "rules-context-loader": RulesContextLoader(),
    "conversation-to-aw": ConversationToAW(),
    "discovery-to-aw": DiscoveryToAW(),
    "vision-to-aw": VisionToAW(),
    "architecture-work-to-evolution-map": AEMGenerator(),
    "alignment-engine": AlignmentEngine(),
    "architecture-intent-generator": AIDGenerator(),
    "steering-projection": SteeringProjectionStep(),
    "baseline-discovery": BaselineDiscoveryStep(),
    "current-architecture-state-generator": CurrentArchitectureStateGenerator(),
    "signal-to-pattern-proposals": SignalToPatternProposals(),
    "pattern-scope-classifier": PatternScopeClassifier(),
    "pattern-promotion-workflow": PatternPromotionWorkflow(),
    "promotion-decision-capture": PromotionDecisionCapture(),
    "promotion-to-decision-records": PromotionToDecisionRecords(),
    "promotion_to_decision_records": PromotionToDecisionRecords(),
    "approved-adr-to-pattern": ApprovedADRToPattern(),
    "governance-validator": GovernanceValidatorStep(),
    "control-bands-check": ControlBandsStep(),
    "roadmap-bootstrap": RoadmapBootstrapStep(),
    "architecture-work-assessment": ArchitectureWorkAssessmentStep(),
    "governance-context-builder": GovernanceContextBuilderStep(),
    "forensic-extractor": ForensicExtractorStep(),
    "forensic-reconciler": ForensicReconcilerStep(),
    "forensic-view-pack": ForensicViewPackStep(),
    "agentic-patterns-extractor": AgenticPatternsExtractorStep(),
    "structural-patterns-extractor": StructuralPatternsExtractorStep(),
    "pattern-catalogue-to-proposals": PatternCatalogueToProposalsStep(),
    "reference-architecture-generator": ReferenceArchitectureGenerator(),
}


def get_flow_steps(flow_name: str) -> list[str]:
    return FLOWS[flow_name]


def load_step(name: str):
    return STEPS[name]
