import json
from datetime import date
from pathlib import Path

from jsonschema import ValidationError, validate


class CurrentArchitectureStateGenerator:
    name = "current-architecture-state-generator"

    def prepare_inputs(self, context):
        """Prepare inputs for Current Architecture State synthesis."""
        inputs = {
            "project": context.get("project"),
            "date": context.get("date", date.today().isoformat()),
            "architecture_work": context.get("architecture_work", []),
            "aem": context.get("aem"),
            "aid": context.get("aid"),
            "alignment_report": context.get("alignment_report"),
            "vision": context.get("vision"),
            "baseline_assessment": context.get("baseline_assessment"),
            "rule_context": context.get("rule_context", [])
        }
        return self._sanitize(inputs)

    def _sanitize(self, data):
        """Recursively convert non-JSON serializable objects to strings."""
        if isinstance(data, dict):
            return {k: self._sanitize(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._sanitize(v) for v in data]
        elif isinstance(data, (date,)):
            return data.isoformat()
        return data

    def execute(self, inputs, reasoning_engine):
        """Execute reasoning to synthesize Current Architecture State."""
        if reasoning_engine is None:
            return {"current_architecture_state": {}}

        # Prompt execution
        llm_response = reasoning_engine.reason(self.name, inputs)

        # In a real scenario, the LLM response is expected to be structured JSON.
        # The reasoning_engine should handle the JSON parsing if configured with a schema.

        return {"current_architecture_state": llm_response}

    def validate(self, output):
        """Validate the generated state artifact against its schema."""
        assert "current_architecture_state" in output, "Missing current_architecture_state in output"
        state_data = output["current_architecture_state"]

        if not state_data:
            return

        # Load schema
        schema_path = Path(__file__).parent.parent / "schemas" / "current_architecture_state_schema.json"
        if schema_path.exists():
            with open(schema_path) as f:
                schema = json.load(f)
            try:
                validate(instance=state_data, schema=schema)
            except ValidationError as e:
                print(f"[CAS][ERROR] Current Architecture State validation failed: {e.message}")
                raise
