import json
from datetime import date
from pathlib import Path

from jsonschema import ValidationError, validate


class PromotionDecisionCapture:
    name = "promotion-decision-capture"

    def prepare_inputs(self, context):
        # We need the promotion recommendations to trace back the decision
        # We also need an explicit decision payload injected via CLI overrides into config or context
        architect_decision = (
            context.get("architect_decision")
            or context.get("decision")
            or context.get("config", {}).get("architect_decision")
            or context.get("config", {}).get("decision")
            or {}
        )
        # Validate the input decision against a minimal schema or basic rules before proceeding
        self._validate_input_decision(architect_decision)

        return {
            "pattern_promotion_recommendations": context.get("pattern_promotion_recommendations"),
            "architect_decision": architect_decision
        }

    def _validate_input_decision(self, decision_input):
        if not decision_input:
            print("[CAS][WARN] No 'architect_decision' provided. Expected an explicit decision payload.")
            return

        if isinstance(decision_input, list):
            raise ValueError(
                "Architect decision input must be a single decision object (dict), but received a list. "
                "If decisions have already been approved on disk, run 'promotion-to-decision-records' to generate ADRs."
            )

        schema_path = Path(__file__).parent.parent / "schemas" / "promotion_decision_input_schema.json"
        if schema_path.exists():
            with open(schema_path) as f:
                schema = json.load(f)
            try:
                validate(instance=decision_input, schema=schema)
            except ValidationError as e:
                print(f"[CAS][ERROR] Architect Decision input validation failed: {e.message}")
                raise
        else:
            # Fallback validation
            if "pattern_id" not in decision_input:
                raise ValueError("Architect decision must include 'pattern_id'")
            if "decision" not in decision_input or "status" not in decision_input["decision"]:
                raise ValueError("Architect decision must include 'decision.status'")
            status = decision_input["decision"]["status"]
            if status not in ["accepted", "deferred", "rejected"]:
                raise ValueError(f"Invalid decision status '{status}'. Must be accepted, deferred, or rejected.")

    def execute(self, inputs, reasoning_engine):
        # If there's no LLM reasoner, we can't generate the complex artifact from simple input
        if reasoning_engine is None:
            return {"promotion_decision": self._empty_response()}

        # For this specific flow, if 'architect_decision' is entirely missing, we might want to warn
        # But we let the prompt try to handle it or return a default
        architect_decision = inputs.get("architect_decision", {})
        if not architect_decision:
            print(f"[CAS][WARN] No 'architect_decision' provided in config for '{self.name}'. Output will likely be incomplete.")

        llm_response = reasoning_engine.reason(self.name, inputs)

        if isinstance(llm_response, str):
            try:
                llm_response = json.loads(llm_response)
            except json.JSONDecodeError:
                print(f"[CAS][ERROR] Failed to parse reasoning response for '{self.name}'")
                return {"promotion_decision": self._empty_response()}

        # Ensure dynamic fields are somewhat populated if LLM missed them
        if "decision" in llm_response and not llm_response["decision"].get("decision_date"):
            llm_response["decision"]["decision_date"] = date.today().isoformat()

        # Enforce strict ID prefix
        pattern_id = llm_response.get("pattern_id", inputs.get("architect_decision", {}).get("pattern_id", "unknown"))
        expected_id = f"promotion-decision-{pattern_id}"
        if llm_response.get("id") != expected_id:
            llm_response["id"] = expected_id

        # Ensure new schema fields are present
        if "knowledgeType" not in llm_response:
            llm_response["knowledgeType"] = "promotion_decision"
        if "project" not in llm_response:
            llm_response["project"] = inputs.get("project", "unknown")
        if "date" not in llm_response:
            llm_response["date"] = date.today().isoformat()
        if "version" not in llm_response:
            llm_response["version"] = "1.0"

        if "relationships" not in llm_response:
            llm_response["relationships"] = {}

        # Enforce specific derives_from collection rules
        derives_from = llm_response["relationships"].get("derives_from", [])
        expected_derives_from = f"recommendation-{pattern_id}"
        if not derives_from or derives_from == ["pattern-promotion-recommendations"]:
            llm_response["relationships"]["derives_from"] = [expected_derives_from]

        if "source_traceability" not in llm_response:
            llm_response["source_traceability"] = {}

        if "scope_classification" not in llm_response["source_traceability"]:
            llm_response["source_traceability"]["scope_classification"] = {}

        if "artifact_id" not in llm_response["source_traceability"]["scope_classification"]:
            llm_response["source_traceability"]["scope_classification"]["artifact_id"] = "pattern-scope-classification"

        return {"promotion_decision": llm_response}

    def validate(self, output):
        assert "promotion_decision" in output, "Missing 'promotion_decision' in output"
        decision_data = output["promotion_decision"]

        schema_path = Path(__file__).parent.parent / "schemas" / "promotion_decision_schema.json"
        if schema_path.exists():
            with open(schema_path) as f:
                schema = json.load(f)
            try:
                validate(instance=decision_data, schema=schema)
            except ValidationError as e:
                print(f"[CAS][ERROR] Promotion Decision validation failed: {e.message}")
                raise
        else:
            required_keys = [
                "id", "artifact_type", "pattern_id", "decision", "review",
                "rationale", "source_traceability", "governance"
            ]
            for key in required_keys:
                assert key in decision_data, f"Missing required key '{key}' in output"

    def _empty_response(self):
        return {
            "id": "promotion-decision-unknown",
            "artifact_type": "promotion_decision",
            "pattern_id": "unknown",
            "decision": {
                "status": "deferred",
                "decision_date": date.today().isoformat()
            },
            "review": {
                "reviewed_by": "unknown"
            },
            "rationale": {
                "summary": "No decision provided."
            },
            "source_traceability": {},
            "governance": {
                "next_step": "additional_evidence"
            }
        }
