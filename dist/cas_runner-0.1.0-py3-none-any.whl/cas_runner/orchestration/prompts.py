import glob
import re
from dataclasses import dataclass
from pathlib import Path

import yaml


@dataclass(frozen=True)
class ReasoningDefinition:
    flow_name: str
    step_name: str
    content: str
    path: Path | None
    version: str | None
    schema: str | None = None
    semantic_contract: str | None = None


class PromptRepository:
    def __init__(self, base_path: str | Path = "src/prompts"):
        self.base_path = Path(base_path)

    def get_reasoning_definition(
        self,
        flow_name: str,
        step_name: str,
    ) -> ReasoningDefinition:
        prompt_path = self._latest_versioned_prompt(flow_name, step_name)
        if prompt_path is None:
            prompt_path = self._unversioned_prompt(flow_name, step_name)

        # Fallback to patterns-extraction-flow for pattern extraction steps
        if prompt_path is None and flow_name != "patterns-extraction-flow":
            prompt_path = self._latest_versioned_prompt("patterns-extraction-flow", step_name)
            if prompt_path is None:
                prompt_path = self._unversioned_prompt("patterns-extraction-flow", step_name)

        # Fallback to step_name folder directly
        if prompt_path is None:
            prompt_path = self._latest_versioned_prompt(step_name, step_name)
            if prompt_path is None:
                prompt_path = self._unversioned_prompt(step_name, step_name)

        # Fallback to governance folder
        if prompt_path is None:
            prompt_path = self._latest_versioned_prompt("governance", step_name)
            if prompt_path is None:
                prompt_path = self._unversioned_prompt("governance", step_name)

        # Fallback to orchestration-flow for shared steps
        if prompt_path is None and flow_name != "orchestration-flow":
            prompt_path = self._latest_versioned_prompt("orchestration-flow", step_name)
            if prompt_path is None:
                prompt_path = self._unversioned_prompt("orchestration-flow", step_name)

        if prompt_path is None:
            return ReasoningDefinition(
                flow_name=flow_name,
                step_name=step_name,
                content="",
                path=None,
                version=None,
            )

        full_content = prompt_path.read_text()
        content, metadata = self._parse_frontmatter(full_content)

        return ReasoningDefinition(
            flow_name=flow_name,
            step_name=step_name,
            content=content,
            path=prompt_path,
            version=self._extract_version(step_name, prompt_path),
            schema=metadata.get("schema") or metadata.get("cas.prompt_schema"),
            semantic_contract=metadata.get("semantic_contract") or metadata.get("cas.semantic_contract_version"),
        )

    def _parse_frontmatter(self, content: str) -> tuple[str, dict]:
        """Simple YAML frontmatter parser."""
        frontmatter_pattern = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
        match = frontmatter_pattern.match(content)
        if match:
            try:
                metadata = yaml.safe_load(match.group(1))
                if isinstance(metadata, dict):
                    remaining_content = content[match.end():].strip()
                    return remaining_content, metadata
            except yaml.YAMLError:
                pass
        return content.strip(), {}

    def _latest_versioned_prompt(self, flow_name: str, step_name: str) -> Path | None:
        pattern = str(self.base_path / flow_name / f"{step_name}.v*.md")
        files = [Path(path) for path in glob.glob(pattern)]
        if not files:
            return None
        return sorted(files, key=lambda path: self._version_key(step_name, path), reverse=True)[0]

    def _unversioned_prompt(self, flow_name: str, step_name: str) -> Path | None:
        path = self.base_path / flow_name / f"{step_name}.md"
        if path.exists():
            return path
        return None

    def _extract_version(self, step_name: str, path: Path) -> str | None:
        prefix = f"{step_name}."
        if not path.name.startswith(prefix):
            return None
        version = path.name[len(prefix):-3]
        if version.startswith("v"):
            return version
        return None

    def _version_key(self, step_name: str, path: Path) -> tuple[int, ...]:
        version = self._extract_version(step_name, path)
        if version is None:
            return ()
        parts = version.removeprefix("v").split(".")
        key = []
        for part in parts:
            if part.isdigit():
                key.append(int(part))
            else:
                key.append(0)
        return tuple(key)
