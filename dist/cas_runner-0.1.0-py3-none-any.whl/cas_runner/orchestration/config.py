import os
from typing import Any

from pydantic import BaseModel, Field


class ExecutionProfile(BaseModel):
    """Configuration for a single LLM execution."""
    provider: str = "huggingface"
    model: str = "Qwen/Qwen3.5-27B"
    temperature: float = 1.0
    max_tokens: int | None = None
    api_base: str | None = None
    extra_params: dict[str, Any] = Field(default_factory=dict)

class ProjectConfiguration(BaseModel):
    """Project-level configuration model."""
    provider: str | None = None
    model: str | None = None
    temperature: float | None = None
    evaluation_enabled: bool = True
    extra_params: dict[str, Any] = Field(default_factory=dict)

class RuntimeConfig(BaseModel):
    """Global configuration state for the CAS runner session."""
    project: str
    default_profile: ExecutionProfile
    environment: str = "development"
    evaluation_enabled: bool = True

class ConfigLoader:
    """Service responsible for merging configuration sources according to precedence rules."""

    def __init__(self):
        # Global defaults
        self.defaults = {
            "provider": "huggingface",
            "model": "Qwen/Qwen3.6-35B-A3B",
            "temperature": 1.0
        }

    def resolve_config(self, project: str, cli_overrides: dict[str, Any] | None = None) -> ExecutionProfile:
        """Resolve configuration using precedence: CLI > ENV > Project YAML > Defaults."""

        # 1. Start with defaults
        resolved = self.defaults.copy()

        # 2. Project Configuration (YAML)
        project_config = self._load_project_config(project)
        project_overrides = self._extract_project_config(project_config)
        resolved.update({k: v for k, v in project_overrides.items() if v is not None})

        # 3. Environment Variables (CAS_ prefix)
        env_overrides = self._get_env_overrides()
        resolved.update(env_overrides)

        # 4. CLI Overrides
        if cli_overrides:
            resolved.update({k: v for k, v in cli_overrides.items() if v is not None})

        return ExecutionProfile(**resolved)

    def _extract_project_config(self, project_config: dict[str, Any]) -> dict[str, Any]:
        """Normalize project configuration into execution profile overrides."""
        if not isinstance(project_config, dict):
            return {}

        if "cas" in project_config:
            cas_config = project_config.get("cas")
            if isinstance(cas_config, dict):
                llm = cas_config.get("llm")
                if isinstance(llm, dict):
                    defaults = llm.get("defaults")
                    if isinstance(defaults, dict):
                        return defaults
                # Fallback to direct provider/model fields under cas
                return {k: v for k, v in cas_config.items() if k in self.defaults or k == "max_tokens" or k == "api_base" or k == "extra_params"}

        return {k: v for k, v in project_config.items() if k in self.defaults or k == "max_tokens" or k == "api_base" or k == "extra_params"}

    def _load_project_config(self, project: str) -> dict[str, Any]:
        """Loads project-specific configuration from the knowledge layer."""
        from cas_runner.io import load_project_config
        return load_project_config(project)

    def _get_env_overrides(self) -> dict[str, Any]:
        """Maps CAS_ environment variables to configuration fields."""
        mapping = {
            "CAS_DEFAULT_PROVIDER": "provider",
            "CAS_DEFAULT_MODEL": "model",
            "CAS_TEMPERATURE": "temperature",
            "CAS_API_BASE": "api_base",
            "CAS_MAX_TOKENS": "max_tokens"
        }

        overrides = {}
        for env_var, field in mapping.items():
            value = os.getenv(env_var)
            if value is not None:
                if field == "temperature":
                    try:
                        overrides[field] = float(value)
                    except ValueError:
                        print(f"[CAS][WARN] Invalid temperature in {env_var}: {value}. Ignoring.")
                elif field == "max_tokens":
                    try:
                        overrides[field] = int(value)
                    except ValueError:
                        print(f"[CAS][WARN] Invalid max_tokens in {env_var}: {value}. Ignoring.")
                else:
                    overrides[field] = value
        return overrides

    def resolve_project_config(self, project: str) -> ProjectConfiguration:
        """Resolve project configuration including evaluation_enabled setting."""
        raw_config = self._load_project_config(project)
        eval_enabled = True
        if isinstance(raw_config, dict):
            cas_cfg = raw_config.get("cas", {})
            if isinstance(cas_cfg, dict):
                eval_cfg = cas_cfg.get("evaluation", {})
                if isinstance(eval_cfg, dict) and "enabled" in eval_cfg:
                    eval_enabled = bool(eval_cfg["enabled"])
            if "evaluation_enabled" in raw_config:
                eval_enabled = bool(raw_config["evaluation_enabled"])

        env_eval = os.getenv("CAS_EVALUATION_ENABLED")
        if env_eval is not None:
            eval_enabled = env_eval.lower() not in ("false", "0", "no")

        extracted = self._extract_project_config(raw_config) if isinstance(raw_config, dict) else {}
        return ProjectConfiguration(
            provider=extracted.get("provider"),
            model=extracted.get("model"),
            temperature=extracted.get("temperature"),
            evaluation_enabled=eval_enabled,
            extra_params={k: v for k, v in extracted.items() if k not in ("provider", "model", "temperature")},
        )

    def is_evaluation_enabled(self, project: str, cli_overrides: dict[str, Any] | None = None) -> bool:
        """Check whether evaluation should run, factoring in CLI overrides, ENV, and project YAML."""
        if cli_overrides and cli_overrides.get("skip_evaluation"):
            return False

        # Check ENV variable
        env_eval = os.getenv("CAS_EVALUATION_ENABLED")
        if env_eval is not None:
            return env_eval.lower() not in ("false", "0", "no")

        # Check if config dictionary was supplied in overrides/context
        if cli_overrides and "config" in cli_overrides and isinstance(cli_overrides["config"], dict):
            raw_config = cli_overrides["config"]
            cas_cfg = raw_config.get("cas", {})
            if isinstance(cas_cfg, dict):
                eval_cfg = cas_cfg.get("evaluation", {})
                if isinstance(eval_cfg, dict) and "enabled" in eval_cfg:
                    return bool(eval_cfg["enabled"])
            if "evaluation_enabled" in raw_config:
                return bool(raw_config["evaluation_enabled"])

        proj_cfg = self.resolve_project_config(project)
        return proj_cfg.evaluation_enabled
