import json
import os
import tempfile
import time
import uuid
from datetime import datetime
from pathlib import Path

from pydantic import BaseModel, Field
from rich.console import RenderableType
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

# Model pricing catalog: (input_usd_per_1M, output_usd_per_1M)
MODEL_PRICING: dict[str, tuple[float, float]] = {
    "stub": (0.0, 0.0),
    "mock": (0.0, 0.0),
    "gemini-1.5-pro": (3.50, 10.50),
    "gemini-1.5-flash": (0.075, 0.30),
    "gemini-2.0-flash": (0.10, 0.40),
    "claude-3-5-sonnet": (3.00, 15.00),
    "claude-3-haiku": (0.25, 1.25),
    "gpt-4o": (2.50, 10.00),
    "gpt-4o-mini": (0.15, 0.60),
}
DEFAULT_PRICING = (0.15, 0.60)


def calculate_step_cost(model: str | None, tokens_in: int, tokens_out: int) -> float:
    """Calculates step cost in USD based on model pricing per 1M tokens."""
    if not model:
        pricing = DEFAULT_PRICING
    else:
        model_lower = model.lower()
        pricing = None
        for key, rates in MODEL_PRICING.items():
            if key in model_lower:
                pricing = rates
                break
        if pricing is None:
            pricing = DEFAULT_PRICING

    input_cost = (tokens_in / 1_000_000.0) * pricing[0]
    output_cost = (tokens_out / 1_000_000.0) * pricing[1]
    return round(input_cost + output_cost, 6)


class StepProgress(BaseModel):
    name: str
    status: str = "pending"  # pending, running, completed, failed, skipped
    start_time: float | None = None
    end_time: float | None = None
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    error_message: str | None = None

    @property
    def duration_seconds(self) -> float | None:
        if self.start_time and self.end_time:
            return round(self.end_time - self.start_time, 2)
        return None


class ActiveRunState(BaseModel):
    run_id: str
    project: str
    flow_name: str
    status: str = "running"  # initializing, running, completed, failed
    current_step: str | None = None
    step_index: int = 0
    total_steps: int = 0
    start_time: float = Field(default_factory=time.time)
    end_time: float | None = None
    tokens_in: int = 0
    tokens_out: int = 0
    total_cost_usd: float = 0.0
    budget_limit_usd: float | None = None
    next_steps: list[str] = Field(default_factory=list)
    completed_steps: list[StepProgress] = Field(default_factory=list)
    error_message: str | None = None


def get_default_state_path() -> Path:
    return Path(".cas/runtime/active-run.json")


def format_milestone_log(
    step_name: str,
    step_index: int,
    total_steps: int,
    tokens: int,
    cost_usd: float,
    next_step: str | None = None,
) -> str:
    """Formats a non-TTY milestone string without ANSI escape characters."""
    now_str = datetime.now().strftime("%H:%M:%S")
    tokens_str = f"{tokens / 1000.0:.1f}k" if tokens >= 1000 else str(tokens)
    next_str = next_step if next_step else "None"
    return (
        f"[CAS {now_str}] [{step_index}/{total_steps}] Step: {step_name} | "
        f"{tokens_str} tok (${cost_usd:.4f}) | Next: {next_str}"
    )


class RunHUDPublisher:
    """Publishes atomic state updates to the shared active-run.json file."""

    def __init__(
        self,
        flow_name: str,
        project: str,
        steps: list[str],
        state_file: Path | None = None,
        model: str = "gemini-1.5-flash",
        budget_limit_usd: float | None = None,
    ):
        self.flow_name = flow_name
        self.project = project
        self.steps = steps.copy()
        self.state_file = Path(state_file) if state_file else get_default_state_path()
        self.model = model
        self.budget_limit_usd = budget_limit_usd

        self.state = ActiveRunState(
            run_id=uuid.uuid4().hex[:8],
            project=project,
            flow_name=flow_name,
            status="initializing",
            current_step=None,
            step_index=0,
            total_steps=len(steps),
            next_steps=self.steps.copy(),
            budget_limit_usd=budget_limit_usd,
        )

    def _publish(self):
        """Atomically writes state to file via temporary file replace."""
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        dir_path = self.state_file.parent
        with tempfile.NamedTemporaryFile("w", dir=dir_path, delete=False) as tf:
            tf.write(self.state.model_dump_json(indent=2))
            temp_name = tf.name
        os.replace(temp_name, self.state_file)

    def load_state(self) -> ActiveRunState:
        with open(self.state_file, "r") as f:
            data = json.load(f)
        return ActiveRunState(**data)

    def start_run(self):
        self.state.status = "running"
        self.state.start_time = time.time()
        self._publish()

    def start_step(self, step_name: str):
        self.state.current_step = step_name
        self.state.step_index += 1
        if self.state.next_steps and self.state.next_steps[0] == step_name:
            self.state.next_steps.pop(0)
        self._publish()

    def finish_step(
        self,
        step_name: str,
        tokens_in: int = 0,
        tokens_out: int = 0,
        cost_usd: float | None = None,
        status: str = "completed",
        error_message: str | None = None,
    ):
        if cost_usd is None:
            cost_usd = calculate_step_cost(self.model, tokens_in, tokens_out)

        self.state.tokens_in += tokens_in
        self.state.tokens_out += tokens_out
        self.state.total_cost_usd = round(self.state.total_cost_usd + cost_usd, 6)

        step_record = StepProgress(
            name=step_name,
            status=status,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            cost_usd=cost_usd,
            error_message=error_message,
            end_time=time.time(),
        )
        self.state.completed_steps.append(step_record)
        self._publish()

    def record_failure(self, error_message: str):
        self.state.status = "failed"
        self.state.error_message = error_message
        self.state.end_time = time.time()
        if self.state.current_step:
            failed_step = StepProgress(
                name=self.state.current_step,
                status="failed",
                error_message=error_message,
                end_time=time.time(),
            )
            self.state.completed_steps.append(failed_step)
        self._publish()

    def finish_run(self, status: str = "completed"):
        self.state.status = status
        self.state.current_step = None
        self.state.end_time = time.time()
        self._publish()


def render_hud_layout(state: ActiveRunState) -> RenderableType:
    """Renders the Rich terminal HUD layout for an active or completed run."""
    elapsed = (state.end_time or time.time()) - state.start_time
    elapsed_str = f"{elapsed:.1f}s"

    header_table = Table.grid(expand=True)
    header_table.add_column(justify="left", ratio=3)
    header_table.add_column(justify="right", ratio=1)

    status_color = "green" if state.status == "completed" else "cyan" if state.status == "running" else "red"
    header_table.add_row(
        Text.assemble(
            ("CAS LIVE HUD", "bold magenta"),
            (" | ", "dim"),
            (state.flow_name, "bold white"),
            (" (", "dim"),
            (state.project, "yellow"),
            (")", "dim"),
        ),
        Text.assemble(
            (f"[{state.status.upper()}]", f"bold {status_color}"),
            ("  Elapsed: ", "dim"),
            (elapsed_str, "bold white"),
        ),
    )

    kpi_table = Table(expand=True, box=None, padding=(0, 2))
    kpi_table.add_column("Current Step", style="bold cyan")
    kpi_table.add_column("Progress", style="white")
    kpi_table.add_column("Tokens (In / Out)", style="green")
    kpi_table.add_column("Est. Cost (USD)", style="bold yellow")

    step_display = state.current_step or ("Complete" if state.status == "completed" else "None")
    progress_str = f"{state.step_index}/{state.total_steps}"
    tokens_str = f"{state.tokens_in:,} / {state.tokens_out:,}"
    cost_str = f"${state.total_cost_usd:.4f}"
    if state.budget_limit_usd:
        cost_str += f" / ${state.budget_limit_usd:.2f}"

    kpi_table.add_row(step_display, progress_str, tokens_str, cost_str)

    queue_table = Table(title="Execution Queue", expand=True, box=None)
    queue_table.add_column("Status", width=12)
    queue_table.add_column("Step Name")
    queue_table.add_column("Tokens", justify="right")
    queue_table.add_column("Cost", justify="right")

    for s in state.completed_steps:
        st_color = "green" if s.status == "completed" else "red"
        tok_str = f"{s.tokens_in + s.tokens_out:,}"
        cost_step_str = f"${s.cost_usd:.4f}"
        queue_table.add_row(f"[{st_color}]✔ {s.status}[/]", s.name, tok_str, cost_step_str)

    if state.current_step and state.status == "running":
        queue_table.add_row("[bold cyan]● running[/]", f"[bold white]{state.current_step}[/]", "...", "...")

    for ns in state.next_steps:
        queue_table.add_row("[dim]○ queued[/]", f"[dim]{ns}[/]", "-", "-")

    main_table = Table.grid(expand=True)
    main_table.add_row(Panel(header_table, border_style="magenta"))
    main_table.add_row(Panel(kpi_table, border_style="cyan"))
    main_table.add_row(Panel(queue_table, border_style="blue"))

    if state.error_message:
        main_table.add_row(Panel(Text(f"ERROR: {state.error_message}", style="bold red"), border_style="red"))

    return main_table
