import glob
import json
import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from .prompts import PromptRepository
from .reasoning import ReasoningExecutionContract


class EvaluationDimension(BaseModel):
    name: str
    score: float = Field(ge=0.0, le=1.0)
    rationale: str
    metrics: dict[str, float] = Field(default_factory=dict)

class EvaluationRecord(BaseModel):
    evaluation_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    trace_id: str
    project: str
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    overall_score: float = Field(ge=0.0, le=1.0)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    dimensions: list[EvaluationDimension] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

class EvaluationHarness:
    def __init__(self, project: str, provider: Any = None, prompt_repo: PromptRepository | None = None):
        self.project = project
        self.provider = provider
        self.prompt_repo = prompt_repo or PromptRepository()
        self.reasoning_engine = ReasoningExecutionContract(
            provider=self.provider,
            prompt_repo=self.prompt_repo,
            context={"project": project, "flow_name": "orchestration-flow"}
        )

    def _load_baseline(self) -> EvaluationRecord | None:
        """Loads the most recent evaluation for this project to use as a baseline."""
        from cas_runner import io

        eval_dir = io.get_workspace_root() / "runtime" / "evaluations"
        if not eval_dir.exists():
            return None

        # Pattern for evals of this project
        pattern = str(eval_dir / f"eval-{self.project}-*.json")
        files = sorted(glob.glob(pattern), reverse=True)

        # Skip the current one if it was just saved (handled by the caller)
        for f in files:
            try:
                with open(f) as fh:
                    data = json.load(fh)
                    return EvaluationRecord(**data)
            except Exception:
                continue
        return None

    def evaluate(self, trace_data: dict[str, Any], baseline: EvaluationRecord | None = None) -> EvaluationRecord:
        """Evaluates a trace and returns an EvaluationRecord."""
        trace_id = trace_data.get("trace_id", "unknown")

        # Load baseline if not provided
        if baseline is None:
            baseline = self._load_baseline()

        # Filter spans to provide only reasoning spans to the evaluator
        reasoning_spans = [
            span for span in trace_data.get("spans", [])
            if span.get("name", "").startswith("reasoning.")
        ]

        # Aggregate telemetry for metadata
        total_tokens = 0
        total_cost = 0.0
        providers = set()
        models = set()

        for span in reasoning_spans:
            attrs = span.get("attributes", {})
            total_tokens += attrs.get("llm.total_tokens", 0)
            total_cost += attrs.get("llm.estimated_cost", 0.0)
            if "llm.provider" in attrs:
                providers.add(attrs["llm.provider"])
            if "llm.model" in attrs:
                models.add(attrs["llm.model"])

        metadata = {
            "llm_providers": list(providers),
            "llm_models": list(models),
            "total_tokens": total_tokens,
            "total_cost": total_cost
        }

        # Regression indicators
        regressions = {}
        if baseline:
            if baseline.overall_score > 0 and (baseline.overall_score - 0.2) > 0: # Arbitrary threshold
                pass # Logic below will fill this

        inputs = {
            "trace_id": trace_id,
            "reasoning_spans": reasoning_spans,
            "telemetry_summary": metadata,
            "baseline_summary": baseline.model_dump() if baseline else None
        }

        # Use Alignment Quality Evaluator for now as the core US1 implementation
        try:
            result = self.reasoning_engine.reason(
                step_name="evaluation-prompts", # This maps to the prompt file name
                inputs=inputs
            )

            if not result:
                return self._default_record(trace_id)

            # Combine runtime metadata with evaluator metadata
            final_metadata = metadata.copy()
            final_metadata.update(result.get("metadata", {}))

            # Auto-detect regression if not flagged by LLM
            if baseline:
                if result.get("overall_score", 0.0) < (baseline.overall_score * 0.8):
                    final_metadata["regression_detected"] = True
                    final_metadata["baseline_score"] = baseline.overall_score

            return EvaluationRecord(
                trace_id=trace_id,
                project=self.project,
                overall_score=result.get("overall_score", 0.0),
                confidence=result.get("confidence", 1.0),
                dimensions=[
                    EvaluationDimension(**d) for d in result.get("dimensions", [])
                ],
                metadata=final_metadata
            )
        except Exception as e:
            print(f"[CAS][WARN] Evaluation failed: {e}")
            return self._default_record(trace_id)

    def _default_record(self, trace_id: str) -> EvaluationRecord:
        return EvaluationRecord(
            trace_id=trace_id,
            project=self.project,
            overall_score=0.0,
            dimensions=[]
        )
