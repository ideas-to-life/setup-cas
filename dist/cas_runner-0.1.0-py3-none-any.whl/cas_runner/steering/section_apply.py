import difflib
from hashlib import sha256
from pathlib import Path

from .managed_sections import (
    ManagedSectionError,
    parse_managed_sections,
    replace_managed_section,
)
from .models import (
    ManagedSectionApplyPlan,
    ManagedSectionProposal,
    ManagedSectionReplacement,
)
from .section_renderer import STEERING_ARTIFACTS


class ManagedSectionApplier:
    def __init__(self, root: str | Path = ".") -> None:
        self.root = Path(root)

    def plan(
        self, proposals: list[ManagedSectionProposal], dry_run: bool = False
    ) -> ManagedSectionApplyPlan:
        replacements: list[ManagedSectionReplacement] = []

        # Validate all proposals first
        for p in proposals:
            if p.artifact not in STEERING_ARTIFACTS:
                raise ManagedSectionError(
                    p.artifact,
                    f"artifact not allowed for managed steering sections: {p.artifact}",
                    section_id=p.section_id,
                )

            path = self.root / p.artifact
            if not path.exists():
                raise ManagedSectionError(
                    p.artifact,
                    "target steering artifact does not exist",
                    section_id=p.section_id,
                )

            text = path.read_text()
            sections = parse_managed_sections(p.artifact, text)

            # Find the target section
            target_section = next(
                (s for s in sections if s.section_id == p.section_id), None
            )
            if not target_section:
                raise ManagedSectionError(
                    p.artifact,
                    "managed section markers not found in artifact",
                    section_id=p.section_id,
                )

            old_content_hash = sha256(target_section.content.encode("utf-8")).hexdigest()

            # Generate diff
            diff = "".join(
                difflib.unified_diff(
                    target_section.content.splitlines(keepends=True),
                    p.generated_content.splitlines(keepends=True),
                    fromfile=f"{p.artifact}:{p.section_id} (current)",
                    tofile=f"{p.artifact}:{p.section_id} (proposed)",
                )
            )

            replacements.append(
                ManagedSectionReplacement(
                    artifact=p.artifact,
                    section_id=p.section_id,
                    old_content_hash=old_content_hash,
                    new_content_hash=p.content_hash,
                    diff=diff,
                )
            )

        return ManagedSectionApplyPlan(
            projection_id="manual", # Or passed from somewhere
            proposals=proposals,
            replacements=replacements,
            dry_run=dry_run,
        )

    def apply(self, plan: ManagedSectionApplyPlan) -> None:
        if plan.dry_run:
            return

        # Group by artifact to avoid multiple reads/writes
        by_artifact: dict[str, list[ManagedSectionProposal]] = {}
        for p in plan.proposals:
            by_artifact.setdefault(p.artifact, []).append(p)

        for artifact, proposals in by_artifact.items():
            path = self.root / artifact
            text = path.read_text()

            new_text = text
            for p in proposals:
                new_text = replace_managed_section(
                    new_text, p.section_id, p.generated_content
                )

            path.write_text(new_text)
