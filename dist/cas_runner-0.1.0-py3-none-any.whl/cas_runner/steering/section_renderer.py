from hashlib import sha256

from .models import ArchitecturalDelta, CapabilityRecord, ManagedSectionProposal

MANAGED_SECTION_ID = "runtime-capabilities"
STEERING_ARTIFACTS = ("README.md", "AGENTS.md", "GEMINI.md", "CLAUDE.md")


class ManagedSectionRenderer:
    def render(
        self,
        project: str,
        deltas: list[ArchitecturalDelta],
        capabilities: list[CapabilityRecord],
        synthesized_content: dict[str, str] | None = None,
    ) -> list[ManagedSectionProposal]:
        source_delta_ids = sorted({delta.id for delta in deltas})
        source_capability_ids = sorted({capability.id for capability in capabilities})
        sorted_capabilities = sorted(capabilities, key=lambda capability: capability.id)

        return [
            self._proposal(
                project=project,
                artifact=artifact,
                source_delta_ids=source_delta_ids,
                source_capability_ids=source_capability_ids,
                capabilities=sorted_capabilities,
                synthesized_markdown=synthesized_content.get(artifact) if synthesized_content else None,
            )
            for artifact in STEERING_ARTIFACTS
        ]

    def _proposal(
        self,
        project: str,
        artifact: str,
        source_delta_ids: list[str],
        source_capability_ids: list[str],
        capabilities: list[CapabilityRecord],
        synthesized_markdown: str | None = None,
    ) -> ManagedSectionProposal:
        if synthesized_markdown:
            generated_content = synthesized_markdown
        else:
            generated_content = self._content(
                project=project,
                artifact=artifact,
                source_delta_ids=source_delta_ids,
                source_capability_ids=source_capability_ids,
                capabilities=capabilities,
            )
        content_hash = sha256(generated_content.encode("utf-8")).hexdigest()

        return ManagedSectionProposal(
            id=self._proposal_id(project, artifact),
            artifact=artifact,
            section_id=MANAGED_SECTION_ID,
            generated_content=generated_content,
            source_delta_ids=source_delta_ids,
            source_capability_ids=source_capability_ids,
            content_hash=content_hash,
            status="proposed",
        )

    def _content(
        self,
        project: str,
        artifact: str,
        source_delta_ids: list[str],
        source_capability_ids: list[str],
        capabilities: list[CapabilityRecord],
    ) -> str:
        lines = [
            f"## {self._heading(artifact)}",
            "",
            f"Project: `{project}`",
            "",
        ]

        if capabilities:
            lines.append(self._intro(artifact))
            lines.append("")
            lines.extend(self._capability_lines(capabilities))
        else:
            lines.append("No managed steering updates were detected.")

        lines.extend(
            [
                "",
                f"Source delta IDs: {self._inline_ids(source_delta_ids)}",
                f"Source capability IDs: {self._inline_ids(source_capability_ids)}",
                "",
            ]
        )
        return "\n".join(lines)

    def _capability_lines(self, capabilities: list[CapabilityRecord]) -> list[str]:
        lines: list[str] = []
        for capability in capabilities:
            lines.append(
                "- "
                f"`{capability.id}` "
                f"[{capability.category.value}/{capability.type.value}]: "
                f"{capability.description}"
            )
            lines.append(f"  Source delta: `{capability.delta_ref}`")
        return lines

    def _proposal_id(self, project: str, artifact: str) -> str:
        seed = f"{project}:{artifact}:{MANAGED_SECTION_ID}"
        digest = sha256(seed.encode("utf-8")).hexdigest()[:16]
        artifact_slug = artifact.lower().replace(".", "-")
        return f"managed-section-{artifact_slug}-{MANAGED_SECTION_ID}-{digest}"

    def _heading(self, artifact: str) -> str:
        headings = {
            "README.md": "Runtime Capabilities",
            "AGENTS.md": "Agent Runtime Capabilities",
            "GEMINI.md": "Gemini Runtime Capabilities",
            "CLAUDE.md": "Claude Runtime Capabilities",
        }
        return headings[artifact]

    def _intro(self, artifact: str) -> str:
        intros = {
            "README.md": "Current runtime capabilities surfaced for repository readers:",
            "AGENTS.md": "Current runtime capabilities relevant to agent contributors:",
            "GEMINI.md": "Current runtime capabilities relevant to Gemini agents:",
            "CLAUDE.md": "Current runtime capabilities relevant to Claude agents:",
        }
        return intros[artifact]

    def _inline_ids(self, ids: list[str]) -> str:
        if not ids:
            return "none"
        return ", ".join(f"`{item}`" for item in ids)
