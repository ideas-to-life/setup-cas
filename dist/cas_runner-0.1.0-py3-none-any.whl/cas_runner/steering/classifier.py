from pathlib import Path

from .models import ArchitecturalDelta, GitChangeType, RawGitDelta, SteeringRuntimeIndex


class ArchitecturalDeltaClassifier:
    """
    Classifies raw git deltas into semantic architectural deltas.
    """

    def __init__(self, index: SteeringRuntimeIndex) -> None:
        self.index = index

    def classify(self, raw_deltas: list[RawGitDelta]) -> list[ArchitecturalDelta]:
        deltas: list[ArchitecturalDelta] = []

        # We process deltas and deduplicate by target where appropriate
        processed_targets = set()

        for raw in raw_deltas:
            path = raw.path

            # 1. Orchestration Registry
            if path == "src/cas_runner/steps/registry.py":
                if raw.change_type == GitChangeType.MODIFIED:
                    deltas.append(self._registry_delta(raw, "orchestration_component_changed"))
                elif raw.change_type == GitChangeType.ADDED:
                    deltas.append(self._registry_delta(raw, "runtime_module_changed"))

            # 2. Schemas
            elif path.startswith("src/cas_runner/schemas/"):
                schema_name = Path(path).name
                deltas.append(ArchitecturalDelta(
                    id=f"delta-schema-{schema_name}",
                    type="schema_surface_changed",
                    target=f"schemas.{schema_name}",
                    change=f"Schema evolved: {schema_name}" if raw.change_type != GitChangeType.ADDED else f"New schema added: {schema_name}",
                    rationale="Schema modification impacts data exchange contracts between agents.",
                    evidence=[path],
                    severity="high" if raw.change_type != GitChangeType.DELETED else "medium",
                ))

            # 3. Prompts
            elif path.startswith("src/prompts/"):
                # Try to find which prompt it belongs to from the index
                prompt_fact = next((p for p in self.index.prompts if p.path == path), None)
                target = f"prompts.{path}"
                change = f"Prompt evolved: {path}"
                if prompt_fact:
                    target = f"prompts.{prompt_fact.flow_name}.{prompt_fact.step_name}"
                    change = f"Prompt evolved for {prompt_fact.step_name} in {prompt_fact.flow_name}"

                deltas.append(ArchitecturalDelta(
                    id=f"delta-prompt-{hash(path)}",
                    type="prompt_contract_changed",
                    target=target,
                    change=change,
                    rationale="Prompt contract update requires verification of downstream agent logic.",
                    evidence=[path],
                    severity="medium",
                ))

            # 4. Governance (CAS Skills)
            elif path.startswith(".cas/") or path.startswith("src/cas_skills/"):
                skill_name = Path(path).parts[1] if path.startswith(".cas/") else Path(path).parts[2]
                deltas.append(ArchitecturalDelta(
                    id=f"delta-governance-{skill_name}",
                    type="governance_surface_changed",
                    target=f"governance.skills.{skill_name}",
                    change=f"Governance skill {raw.change_type.value}: {skill_name}",
                    rationale="Changes in specialized skills expand or modify automated architectural enforcement.",
                    evidence=[path],
                    severity="high" if raw.change_type == GitChangeType.ADDED else "medium",
                ))

            # 5. CI/CD Workflows
            elif path.startswith(".github/workflows/"):
                workflow_name = Path(path).name
                deltas.append(ArchitecturalDelta(
                    id=f"delta-cicd-{workflow_name}",
                    type="workflow_surface_changed",
                    target=f"cicd.workflows.{workflow_name}",
                    change=f"CI/CD workflow {raw.change_type.value}: {workflow_name}",
                    rationale="Changes in automation workflows impact system delivery and validation.",
                    evidence=[path],
                    severity="medium",
                ))

            # 6. Provider/Runtime Configuration and LLM Gateway
            elif "config" in path.lower() or "provider" in path.lower() or path.startswith("src/cas_runner/llm/"):
                 deltas.append(ArchitecturalDelta(
                    id=f"delta-runtime-{hash(path)}",
                    type="provider_runtime_changed",
                    target="runtime.infrastructure",
                    change=f"Runtime infrastructure changed: {path}",
                    rationale="Changes in provider, configuration, or LLM gateway affect system behavior, stability, or costs.",
                    evidence=[path],
                    severity="medium",
                ))

            # 7. Steering Logic
            elif path.startswith("src/cas_runner/steering/"):
                deltas.append(ArchitecturalDelta(
                    id=f"delta-steering-{hash(path)}",
                    type=f"orchestration_component_{raw.change_type.value}",
                    target="orchestration.steering",
                    change=f"Steering component evolution: {path}",
                    rationale="Modifications to steering logic impact how the system projects and validates operational guidance.",
                    evidence=[path],
                    severity="high",
                ))

            # 8. Rendering Layer
            elif path.startswith("src/cas_runner/rendering/"):
                deltas.append(ArchitecturalDelta(
                    id=f"delta-rendering-{hash(path)}",
                    type=f"orchestration_component_{raw.change_type.value}",
                    target="orchestration.rendering",
                    change=f"Rendering layer changed: {path}",
                    rationale="Updates to rendering components impact the structure and format of persisted architectural artefacts.",
                    evidence=[path],
                    severity="medium",
                ))

            # 9. Core Reasoning and Orchestration Modules
            elif path in ("src/cas_runner/orchestration/reasoning.py", "src/cas_runner/orchestration/prompts.py", "src/cas_runner/runner.py", "src/cas_runner/io.py", "src/cas_runner/cli.py"):
                deltas.append(ArchitecturalDelta(
                    id=f"delta-core-{hash(path)}",
                    type="runtime_module_changed",
                    target="runtime.core",
                    change=f"Core runtime module changed: {path}",
                    rationale="Modifications to core runner, reasoning, or persistence logic affect the fundamental operation of CAS.",
                    evidence=[path],
                    severity="high",
                ))

            # 10. Flow Steps
            elif path.startswith("src/cas_runner/steps/") and path != "src/cas_runner/steps/registry.py":
                step_name = Path(path).stem
                deltas.append(ArchitecturalDelta(
                    id=f"delta-step-{hash(path)}",
                    type=f"orchestration_component_{raw.change_type.value}",
                    target=f"orchestration.steps.{step_name}",
                    change=f"Flow step logic changed: {step_name}",
                    rationale="Changes to individual step logic can alter the behavior of orchestration flows.",
                    evidence=[path],
                    severity="medium",
                ))

            # 11. Observability
            elif path == "src/cas_runner/orchestration/telemetry.py":
                if self.index.observability.get("trace_persistence"):
                    deltas.append(ArchitecturalDelta(
                        id="delta-obs-persistence",
                        type="runtime_module_changed",
                        target="observability.telemetry",
                        change="Enabled trace persistence",
                        rationale="Improved observability allows for better runtime auditing and analysis.",
                        evidence=[path],
                        severity="medium",
                    ))

            # 11. Evaluation
            elif path == "src/cas_runner/orchestration/evaluation.py":
                if self.index.evaluation.get("evaluation_harness"):
                    deltas.append(ArchitecturalDelta(
                        id="delta-eval-harness",
                        type="runtime_module_changed",
                        target="evaluation.harness",
                        change="Enabled evaluation harness",
                        rationale="New evaluation capabilities allow for automated quality assessment of agent outputs.",
                        evidence=[path],
                        severity="medium",
                    ))

        return deltas

    def _registry_delta(self, raw: RawGitDelta, delta_type: str) -> ArchitecturalDelta:
        # For the registry, we'll just report a general orchestration change.
        # In a more advanced version, we could diff the registry content itself.
        return ArchitecturalDelta(
            id="delta-orchestration-registry",
            type=delta_type,
            target="orchestration.registry",
            change="Orchestration registry evolution detected.",
            rationale="Changes in the registry define the available flows and steps in the system.",
            evidence=[raw.path],
            severity="high",
        )
