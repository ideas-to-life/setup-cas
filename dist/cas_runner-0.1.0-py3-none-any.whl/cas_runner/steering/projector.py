import difflib
from datetime import datetime
from pathlib import Path

import yaml

from cas_runner.io import safe_mkdir

from .models import (
    ArchitecturalDelta,
    CapabilityRecord,
    ManagedSectionProposal,
    SteeringDriftFinding,
    SteeringProjectionBundle,
    SteeringRuntimeIndex,
)
from .policies import SteeringProjectionPolicy


class SteeringPatchProjector:
    def __init__(
        self,
        root: str | Path = None,
        workspace_root: str | Path = None,
        policy: SteeringProjectionPolicy | None = None
    ) -> None:
        # root is the project/codebase root
        self.root = Path(root) if root else Path.cwd()
        # workspace_root is the knowledge root
        self.workspace_root = Path(workspace_root) if workspace_root else self.root
        self.policy = policy or SteeringProjectionPolicy()

    def persist(
        self,
        *,
        project: str,
        index: SteeringRuntimeIndex,
        findings: list[SteeringDriftFinding],
        deltas: list[ArchitecturalDelta] | None = None,
        capabilities: list[CapabilityRecord] | None = None,
        managed_section_proposals: list[ManagedSectionProposal] | None = None,
        baseline_ref: str | None = None,
        current_ref: str | None = None,
    ) -> SteeringProjectionBundle:
        generated_at = datetime.now().replace(microsecond=0).isoformat()
        projection_id = f"steering-projection-{project}-{generated_at.replace(':', '').replace('-', '')}"

        content = self.render(
            projection_id=projection_id,
            project=project,
            generated_at=generated_at,
            index=index,
            findings=findings,
            deltas=deltas or [],
            capabilities=capabilities or [],
            managed_section_proposals=managed_section_proposals or [],
            baseline_ref=baseline_ref,
            current_ref=current_ref,
        )

        output_dir = self.workspace_root / self.policy.output_dir
        safe_mkdir(output_dir, parents=True, exist_ok=True)
        path = output_dir / f"{projection_id}.md"
        path.write_text(content)

        output = {
            self.policy.output_key: {
                "id": projection_id,
                "project": project,
                "status": "proposed",
                "path": str(path.relative_to(self.workspace_root)),
                "findings": [finding.__dict__ for finding in findings],
                "deltas": [delta.__dict__ for delta in (deltas or [])],
                "capabilities": [
                    {
                        **cap.__dict__,
                        "category": cap.category.value,
                        "type": cap.type.value
                    } for cap in (capabilities or [])
                ],
                "managed_section_proposals": [p.__dict__ for p in (managed_section_proposals or [])],
                "baseline_ref": baseline_ref,
                "current_ref": current_ref,
            }
        }

        # 5. Persist architectural delta record if any detected
        if deltas:
            delta_set_id = f"delta-analysis-{project}-{generated_at.replace(':', '').replace('-', '')}"
            delta_record = {
                "id": delta_set_id,
                "baseline_ref": baseline_ref or "unknown",
                "current_ref": current_ref or "HEAD",
                "generated_at": generated_at,
                "deltas": [delta.__dict__ for delta in deltas],
                "capabilities": [
                    {
                        **cap.__dict__,
                        "category": cap.category.value,
                        "type": cap.type.value
                    } for cap in (capabilities or [])
                ],
            }
            delta_dir = self.workspace_root / "governance/steering/deltas"
            safe_mkdir(delta_dir, parents=True, exist_ok=True)
            delta_path = delta_dir / f"{delta_set_id}.yaml"
            delta_path.write_text(yaml.dump(delta_record, sort_keys=False))
            output[self.policy.output_key]["delta_record"] = str(delta_path.relative_to(self.workspace_root))

        return SteeringProjectionBundle(
            id=projection_id,
            project=project,
            status="proposed",
            path=path,
            output=output,
            deltas=deltas or [],
            capabilities=capabilities or [],
            baseline_ref=baseline_ref,
            current_ref=current_ref,
        )

    def render(
        self,
        *,
        projection_id: str,
        project: str,
        generated_at: str,
        index: SteeringRuntimeIndex,
        findings: list[SteeringDriftFinding],
        deltas: list[ArchitecturalDelta],
        capabilities: list[CapabilityRecord],
        managed_section_proposals: list[ManagedSectionProposal],
        baseline_ref: str | None = None,
        current_ref: str | None = None,
    ) -> str:
        frontmatter = {
            "id": projection_id,
            "knowledgeType": "steering_projection",
            "project": project,
            "status": "proposed",
            "generated_at": generated_at,
            "baseline_ref": baseline_ref,
            "current_ref": current_ref,
            "applies_to": list(self.policy.allowed_steering_artifacts),
            "governance": {
                "approval_required": self.policy.approval_required,
                "direct_apply_allowed": self.policy.direct_apply_allowed,
            },
            "deltas": [delta.__dict__ for delta in deltas],
            "capabilities": [
                {
                    **cap.__dict__,
                    "category": cap.category.value,
                    "type": cap.type.value
                } for cap in capabilities
            ],
            "managed_section_proposals": [p.__dict__ for p in managed_section_proposals],
        }
        sections = [
            "---",
            yaml.dump(frontmatter, sort_keys=False).strip(),
            "---",
            "",
            f"# Steering Projection: {project}",
            "",
            "Human approval is required before applying any proposed steering artefact changes.",
            "",
            "## Architectural Deltas",
            "",
            self._deltas_table(deltas),
            "",
            "## Operational Capabilities",
            "",
            self._capabilities_table(capabilities),
            "",
            "## Runtime Index Summary",
            "",
            f"- Flows: {', '.join(sorted(index.flows)) if index.flows else 'none detected'}",
            f"- Steps: {', '.join(index.steps) if index.steps else 'none detected'}",
            f"- Prompts: {len(index.prompts)}",
            f"- Schemas: {len(index.schemas)}",
            "",
            "## Build Workflow Index Summary",
            "",
            f"- CAS Skills: {', '.join(index.build_workflow.get('cas_skills', [])) or 'none detected'}",
            f"- Agent skill contracts: {len(index.build_workflow.get('agent_skill_contracts', []))}",
            f"- SDD/specify assets present: {str(index.build_workflow.get('specify_assets', False)).lower()}",
            f"- Specs: {index.build_workflow.get('spec_count', 0)}",
            f"- Tests: {index.build_workflow.get('test_count', 0)}",
            "",
            "## CI/CD Trigger Surface",
            "",
            f"- GitHub Actions present: {str(index.cicd.get('github_actions', False)).lower()}",
            f"- Workflow files: {', '.join(index.cicd.get('workflow_files', [])) or 'none detected'}",
            "",
            "## Drift Findings",
            "",
            self._findings_table(findings),
            "",
            "## Managed Section Proposals",
            "",
            self._managed_proposals_blocks(managed_section_proposals),
            "",
            "## Controlled Patch Proposals",
            "",
            self._patch_blocks(findings),
            "",
            "## Review Instructions",
            "",
            "Review each finding, approve or reject the proposed patch, then apply changes through a separate explicit step. This workflow did not modify README.md, AGENTS.md, GEMINI.md, or CLAUDE.md.",
            "",
        ]
        return "\n".join(sections)

    def _managed_proposals_blocks(self, proposals: list[ManagedSectionProposal]) -> str:
        if not proposals:
            return "No managed section updates detected."
        blocks = []
        for p in proposals:
            block = [
                f"### {p.artifact} - {p.section_id}",
                "",
                f"- **Proposal ID**: `{p.id}`",
                f"- **Source Deltas**: {', '.join(f'`{d}`' for d in p.source_delta_ids)}",
                f"- **Source Capabilities**: {', '.join(f'`{c}`' for c in p.source_capability_ids)}",
                f"- **Content Hash**: `{p.content_hash}`",
                "",
                "```markdown",
                p.generated_content.strip(),
                "```",
            ]
            blocks.append("\n".join(block))
        return "\n\n".join(blocks)

    def _capabilities_table(self, capabilities: list[CapabilityRecord]) -> str:
        if not capabilities:
            return "No operational capabilities detected."
        lines = [
            "| ID | Category | Type | Description | Delta Ref |",
            "| --- | --- | --- | --- | --- |",
        ]
        for cap in capabilities:
            lines.append(
                "| "
                + " | ".join(
                    [
                        cap.id,
                        cap.category.value,
                        cap.type.value,
                        cap.description,
                        cap.delta_ref,
                    ]
                )
                + " |"
            )
        return "\n".join(lines)

    def _deltas_table(self, deltas: list[ArchitecturalDelta]) -> str:
        if not deltas:
            return "No architectural deltas detected."
        lines = [
            "| ID | Type | Target | Change | Rationale | Severity |",
            "| --- | --- | --- | --- | --- | --- |",
        ]
        for delta in deltas:
            lines.append(
                "| "
                + " | ".join(
                    [
                        delta.id,
                        delta.type,
                        delta.target,
                        delta.change,
                        delta.rationale,
                        delta.severity,
                    ]
                )
                + " |"
            )
        return "\n".join(lines)

    def _findings_table(self, findings: list[SteeringDriftFinding]) -> str:
        if not findings:
            return "No steering drift detected."
        lines = [
            "| ID | Severity | Artefact | Line | Expected Fact | Recommendation |",
            "| --- | --- | --- | --- | --- | --- |",
        ]
        for finding in findings:
            lines.append(
                "| "
                + " | ".join(
                    [
                        finding.id,
                        finding.severity,
                        finding.artifact,
                        str(finding.line),
                        finding.expected_fact,
                        finding.recommendation.replace("|", "\\|"),
                    ]
                )
                + " |"
            )
        return "\n".join(lines)

    def _patch_blocks(self, findings: list[SteeringDriftFinding]) -> str:
        blocks = []
        for artifact in sorted({finding.artifact for finding in findings}):
            original_path = self.root / artifact
            if not original_path.exists():
                continue
            original_lines = original_path.read_text().splitlines(keepends=True)
            proposed_lines = original_lines[:]
            for finding in [item for item in findings if item.artifact == artifact]:
                proposed_lines = [
                    self._replace_line(line, finding) for line in proposed_lines
                ]
            diff = difflib.unified_diff(
                original_lines,
                proposed_lines,
                fromfile=artifact,
                tofile=f"{artifact} (proposed)",
            )
            diff_text = "".join(diff).strip()
            if diff_text:
                blocks.append(f"### {artifact}\n\n```diff\n{diff_text}\n```")
        return "\n\n".join(blocks) if blocks else "No patch proposals generated."

    def _replace_line(self, line: str, finding: SteeringDriftFinding) -> str:
        if finding.current_claim not in line:
            return line
        replacement = finding.current_claim
        if "src/cas-flows" in replacement:
            replacement = replacement.replace("src/cas-flows", "src/prompts")
        if "src/cas_runner/skills/registry.py" in replacement:
            replacement = replacement.replace(
                "src/cas_runner/skills/registry.py",
                "src/cas_runner/steps/registry.py",
            )
        return line.replace(finding.current_claim, replacement)
