from pathlib import Path

from .models import SteeringArtifactClaim
from .policies import SteeringProjectionPolicy


class SteeringArtifactScanner:
    def __init__(self, root: str | Path = ".", policy: SteeringProjectionPolicy | None = None) -> None:
        self.root = Path(root)
        self.policy = policy or SteeringProjectionPolicy()

    def scan(self) -> list[SteeringArtifactClaim]:
        claims: list[SteeringArtifactClaim] = []
        for artifact in self.policy.allowed_steering_artifacts:
            path = self.root / artifact
            if not path.exists():
                continue
            for line_number, line in enumerate(path.read_text().splitlines(), start=1):
                claim_type = self._claim_type(line)
                if claim_type:
                    claims.append(
                        SteeringArtifactClaim(
                            artifact=artifact,
                            line=line_number,
                            text=line.strip(),
                            claim_type=claim_type,
                        )
                    )
        return claims

    def _claim_type(self, line: str) -> str | None:
        lowered = line.lower()
        if "src/cas-flows" in line or "src/prompts" in line:
            return "path"
        if "src/cas_runner/skills/registry.py" in line or "src/cas_runner/steps/registry.py" in line:
            return "path"
        if ".cas/" in line or "cas skill" in lowered or "superpowers" in lowered or "sdd" in lowered:
            return "build-workflow"
        if "orchestration-flow" in line or "steering-projection-flow" in line:
            return "flow"
        if "aem" in lowered or "aid" in lowered or "alignment" in lowered or "adr" in lowered:
            return "governance-boundary"
        return None
