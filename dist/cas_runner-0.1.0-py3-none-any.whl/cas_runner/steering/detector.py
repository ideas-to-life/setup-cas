from .models import (
    ArchitecturalDelta,
    CapabilityRecord,
    SteeringArtifactClaim,
    SteeringDriftFinding,
    SteeringRuntimeIndex,
)


class SteeringDriftDetector:
    def __init__(
        self,
        index: SteeringRuntimeIndex,
        deltas: list[ArchitecturalDelta] | None = None,
        capabilities: list[CapabilityRecord] | None = None,
    ) -> None:
        self.index = index
        self.deltas = deltas or []
        self.capabilities = capabilities or []

    def detect(self, claims: list[SteeringArtifactClaim]) -> list[SteeringDriftFinding]:
        findings: list[SteeringDriftFinding] = []

        # 1. Existing claim-based drift detection
        for claim in claims:
            finding = self._detect_claim(claim, len(findings) + 1)
            if finding:
                findings.append(finding)

        # 2. Architectural gap detection (based on deltas)
        findings.extend(self._detect_architectural_gaps(claims, len(findings) + 1))

        return findings

    def _detect_claim(self, claim: SteeringArtifactClaim, sequence: int) -> SteeringDriftFinding | None:
        text = claim.text
        if "src/cas-flows" in text:
            return SteeringDriftFinding(
                id=f"steering-drift-{sequence:03d}",
                severity="high",
                artifact=claim.artifact,
                line=claim.line,
                claim_type="path_drift",
                current_claim=text,
                expected_fact="src/prompts/",
                evidence=[prompt.path for prompt in self.index.prompts] if self.index.prompts else ["src/prompts/"],
                recommendation="Replace stale prompt path references with src/prompts/.",
            )
        if "src/cas_runner/skills/registry.py" in text:
            return SteeringDriftFinding(
                id=f"steering-drift-{sequence:03d}",
                severity="medium",
                artifact=claim.artifact,
                line=claim.line,
                claim_type="path_drift",
                current_claim=text,
                expected_fact="src/cas_runner/steps/registry.py",
                evidence=["src/cas_runner/steps/registry.py"],
                recommendation="Describe flow registration using the steps registry path.",
            )
        return None

    def _detect_architectural_gaps(self, claims: list[SteeringArtifactClaim], start_sequence: int) -> list[SteeringDriftFinding]:
        findings: list[SteeringDriftFinding] = []
        sequence = start_sequence

        # Determine all artifacts involved in steering
        artifacts = sorted({c.artifact for c in claims})
        if not artifacts:
            return []

        for delta in self.deltas:
            target_name = delta.target.split(".")[-1]

            # Find corresponding capability for semantic description
            cap = next((c for c in self.capabilities if c.delta_ref == delta.id), None)
            semantic_change = cap.description if cap else delta.change

            if delta.type in ("runtime_module_changed", "governance_surface_changed", "workflow_surface_changed", "runtime_capability_added", "governance_capability_added", "orchestration_component_added"):
                # Check EACH artifact for the presence of this target
                for artifact in artifacts:
                    artifact_claims = [c for c in claims if c.artifact == artifact]
                    mentioned = any(target_name in c.text for c in artifact_claims)

                    if not mentioned:
                        anchor_claim = artifact_claims[0] if artifact_claims else None
                        if anchor_claim:
                            findings.append(SteeringDriftFinding(
                                id=f"steering-drift-{sequence:03d}",
                                severity=delta.severity,
                                artifact=artifact,
                                line=anchor_claim.line,
                                claim_type="architectural_gap",
                                current_claim="[MISSING]",
                                expected_fact=target_name,
                                evidence=delta.evidence,
                                recommendation=f"Update {artifact} to include the new capability: {semantic_change}. Rationale: {delta.rationale}",
                                delta_id=delta.id
                            ))
                            sequence += 1

            elif delta.type in ("schema_surface_changed", "prompt_contract_changed", "orchestration_component_changed", "provider_runtime_changed", "orchestration_component_modified"):
                # For evolution/change, we notify all artifacts that mention the target.
                # If none mention it, we still generate one high-level finding for AGENTS.md or the first artifact.
                for artifact in artifacts:
                    artifact_claims = [c for c in claims if c.artifact == artifact]
                    mentions = [c for c in artifact_claims if target_name in c.text]

                    if mentions:
                        for mention in mentions:
                            findings.append(SteeringDriftFinding(
                                id=f"steering-drift-{sequence:03d}",
                                severity=delta.severity,
                                artifact=artifact,
                                line=mention.line,
                                claim_type="contract_drift",
                                current_claim=mention.text,
                                expected_fact=delta.target,
                                evidence=delta.evidence,
                                recommendation=f"Review operational guidance in {artifact} for contract evolution: {semantic_change}. Rationale: {delta.rationale}",
                                delta_id=delta.id
                            ))
                            sequence += 1
                    elif artifact == "AGENTS.md" or (artifact == artifacts[0] and "AGENTS.md" not in artifacts):
                        # Even if not mentioned, evolution of a CORE contract should be flagged in AGENTS.md
                        anchor_claim = artifact_claims[0] if artifact_claims else None
                        if anchor_claim:
                            findings.append(SteeringDriftFinding(
                                id=f"steering-drift-{sequence:03d}",
                                severity=delta.severity,
                                artifact=artifact,
                                line=anchor_claim.line,
                                claim_type="contract_drift",
                                current_claim="[EVOLVED]",
                                expected_fact=delta.target,
                                evidence=delta.evidence,
                                recommendation=f"Review operational guidance in {artifact} for contract evolution: {semantic_change}. Rationale: {delta.rationale}",
                                delta_id=delta.id
                            ))
                            sequence += 1

        return findings

    def _finding(
        self,
        sequence: int,
        claim: SteeringArtifactClaim,
        *,
        severity: str,
        expected_fact: str,
        evidence: list[str],
        recommendation: str,
    ) -> SteeringDriftFinding:
        return SteeringDriftFinding(
            id=f"steering-drift-{sequence:03d}",
            severity=severity,
            artifact=claim.artifact,
            line=claim.line,
            claim_type=claim.claim_type,
            current_claim=claim.text,
            expected_fact=expected_fact,
            evidence=evidence,
            recommendation=recommendation,
        )
