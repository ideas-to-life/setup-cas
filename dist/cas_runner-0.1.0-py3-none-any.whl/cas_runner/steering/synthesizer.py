import re
from dataclasses import dataclass
from typing import Any

from .models import ArchitecturalDelta


@dataclass(frozen=True)
class SynthesisRequest:
    project: str
    persona: str
    deltas: list[ArchitecturalDelta]
    removed_capability_ids: list[str]
    current_content: str
    target_artifact: str = ""
    artifact_content: str = ""

@dataclass(frozen=True)
class SynthesisResponse:
    synthesized_markdown: str
    summary: str
    has_changes: bool
    status: str = "success"

class ArchitectureSynthesizer:
    def __init__(self, reasoning_engine: Any = None) -> None:
        self.reasoning_engine = reasoning_engine

    def synthesize(self, request: SynthesisRequest) -> SynthesisResponse:
        """Synthesize persona-specific guidance using the unified reasoning contract."""
        if not self.reasoning_engine:
             return SynthesisResponse(
                synthesized_markdown=request.current_content,
                summary="Skipped: No reasoning engine provided",
                has_changes=False,
                status="skipped"
            )

        persona_prompts = {
            "README": "synthesis-narrative",
            "AGENTS": "synthesis-rules",
            "PLATFORM": "synthesis-context",
        }

        prompt_name = persona_prompts.get(request.persona, "synthesis-narrative")

        # Format deltas for the prompt
        deltas_formatted = ""
        for d in request.deltas:
            deltas_formatted += f"- [{d.type}] {d.target}: {d.change} (Rationale: {d.rationale})\n"

        # Call the unified reasoning engine
        # Note: reasoning_engine.reason is synchronous in the current project
        try:
            response = self.reasoning_engine.reason(
                step_name=prompt_name,
                inputs={
                    "project": request.project,
                    "target_artifact": request.target_artifact or request.persona,
                    "artifact_content": request.artifact_content,
                    "deltas_formatted": deltas_formatted or "No new deltas.",
                    "removed_ids": ", ".join(request.removed_capability_ids) if request.removed_capability_ids else "None.",
                    "current_content": request.current_content
                }
            )

            if not response:
                return SynthesisResponse(
                    synthesized_markdown=request.current_content,
                    summary="Failed: Empty response from reasoning engine",
                    has_changes=False,
                    status="failed"
                )

            # Robust handling of both structured JSON and raw string responses
            if isinstance(response, str):
                cleaned = self._sanitize_markdown(response)
                return SynthesisResponse(
                    synthesized_markdown=cleaned,
                    summary="Updated artifact markdown (raw string)",
                    has_changes=cleaned != request.current_content,
                    status="success"
                )

            if isinstance(response, dict):
                raw_markdown = response.get("synthesized_markdown", request.current_content)
                cleaned = self._sanitize_markdown(raw_markdown)
                return SynthesisResponse(
                    synthesized_markdown=cleaned,
                    summary=response.get("summary", "Synthesis completed"),
                    has_changes=response.get("has_changes", cleaned != request.current_content),
                    status="success"
                )

            return SynthesisResponse(
                synthesized_markdown=request.current_content,
                summary=f"Failed: Unexpected response type {type(response).__name__}",
                has_changes=False,
                status="failed"
            )
        except Exception as e:
            return SynthesisResponse(
                synthesized_markdown=request.current_content,
                summary=f"Error during synthesis: {e!s}",
                has_changes=False,
                status="failed"
            )

    def _sanitize_markdown(self, markdown: str) -> str:
        """Strip markers and low-signal ID boilerplate from synthesis output."""
        lines = []
        for line in markdown.splitlines():
            # 1. ALWAYS strip steering markers to prevent nesting
            if "CAS-STEERING:" in line:
                continue

            # 2. Strip low-signal ID boilerplate
            if line.startswith("Source delta IDs:"):
                continue
            if line.startswith("Source capability IDs:"):
                continue
            if line.strip().startswith("- `cap-"):
                continue
            if line.strip().startswith("Source delta: `delta-"):
                continue
            lines.append(line)
        cleaned = "\n".join(lines)
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()
        return cleaned
