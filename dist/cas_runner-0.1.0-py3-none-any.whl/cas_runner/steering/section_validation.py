from pathlib import Path

from .managed_sections import ManagedSectionError, parse_managed_sections
from .models import (
    ManagedSectionProposal,
    ManagedSectionValidationReport,
    ManagedSteeringSection,
)


class ManagedSectionValidator:
    def __init__(self, root: str | Path = ".") -> None:
        self.root = Path(root)

    def validate_artifacts(
        self, artifacts: list[str]
    ) -> ManagedSectionValidationReport:
        sections: list[ManagedSteeringSection] = []
        errors: list[str] = []

        for artifact in artifacts:
            path = self.root / artifact
            if not path.exists():
                continue

            try:
                artifact_sections = parse_managed_sections(artifact, path.read_text())
                sections.extend(artifact_sections)
            except ManagedSectionError as e:
                errors.append(str(e))

        status = "failed" if errors else "passed"
        return ManagedSectionValidationReport(
            status=status,
            checked_artifacts=artifacts,
            sections=sections,
            errors=errors,
        )

    def validate_proposals(
        self, proposals: list[ManagedSectionProposal]
    ) -> ManagedSectionValidationReport:
        errors: list[str] = []
        for p in proposals:
            if not p.source_delta_ids:
                errors.append(f"Proposal {p.id}: missing source delta IDs")
            if not p.source_capability_ids:
                errors.append(f"Proposal {p.id}: missing source capability IDs")

        status = "failed" if errors else "passed"
        return ManagedSectionValidationReport(
            status=status,
            checked_artifacts=list({p.artifact for p in proposals}),
            errors=errors,
        )
