import ast
import re
from pathlib import Path
from typing import Any

import yaml

from .models import PromptFact, SteeringRuntimeIndex
from .resources import LocalResourceProvider, ResourceProvider


class SteeringRuntimeIndexer:
    def __init__(self, root: str | Path = ".", provider: ResourceProvider | None = None) -> None:
        self.root = Path(root)
        self.provider = provider or LocalResourceProvider(self.root)

    def build_index(self) -> SteeringRuntimeIndex:
        flows, steps = self._load_registry()
        return SteeringRuntimeIndex(
            flows=flows,
            steps=steps,
            prompts=self._discover_prompts(),
            schemas=self._discover_schemas(),
            provider_runtime=self._provider_runtime(),
            observability=self._observability(),
            evaluation=self._evaluation(),
            build_workflow=self._build_workflow(),
            cicd=self._cicd(),
        )

    def _discover_schemas(self) -> dict[str, str]:
        import hashlib

        schemas = {}
        for path_str in sorted(self.provider.glob("src/cas_runner/schemas/*.json")):
            content = self.provider.read_bytes(path_str)
            schemas[Path(path_str).name] = hashlib.sha256(content).hexdigest()
        return schemas

    def _load_registry(self) -> tuple[dict[str, list[str]], list[str]]:
        path_str = "src/cas_runner/steps/registry.py"
        if not self.provider.exists(path_str):
            return {}, []

        tree = ast.parse(self.provider.read_text(path_str))
        flows: dict[str, list[str]] = {}
        steps: list[str] = []
        for node in tree.body:
            if not isinstance(node, ast.Assign):
                continue
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "FLOWS":
                    flows = self._literal_dict_of_lists(node.value)
                elif isinstance(target, ast.Name) and target.id == "STEPS":
                    steps = sorted(self._literal_dict_keys(node.value))
        return flows, steps

    def _literal_dict_of_lists(self, node: ast.AST) -> dict[str, list[str]]:
        if not isinstance(node, ast.Dict):
            return {}
        result: dict[str, list[str]] = {}
        for key_node, value_node in zip(node.keys, node.values, strict=False):
            key = self._literal_string(key_node)
            if not key or not isinstance(value_node, ast.List):
                continue
            values = [value for item in value_node.elts if (value := self._literal_string(item))]
            result[key] = values
        return result

    def _literal_dict_keys(self, node: ast.AST) -> list[str]:
        if not isinstance(node, ast.Dict):
            return []
        return [key for key_node in node.keys if (key := self._literal_string(key_node))]

    def _literal_string(self, node: ast.AST | None) -> str | None:
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        return None

    def _discover_prompts(self) -> list[PromptFact]:
        prompts = []
        for path_str in sorted(self.provider.glob("src/prompts/*/*.md")):
            path = Path(path_str)
            flow_name = path.parent.name
            step_name, version = self._prompt_name_version(path)
            metadata = self._frontmatter(path_str)
            prompts.append(
                PromptFact(
                    step_name=step_name,
                    flow_name=flow_name,
                    path=path_str,
                    version=version,
                    schema=metadata.get("schema") or metadata.get("cas.prompt_schema"),
                    semantic_contract=metadata.get("semantic_contract")
                    or metadata.get("cas.semantic_contract_version"),
                )
            )
        return prompts

    def _prompt_name_version(self, path: Path) -> tuple[str, str | None]:
        match = re.match(r"(?P<step>.+)\.(?P<version>v[0-9][^.]*.*)\.md$", path.name)
        if match:
            return match.group("step"), match.group("version")
        return path.stem, None

    def _frontmatter(self, path_str: str) -> dict[str, Any]:
        content = self.provider.read_text(path_str)
        if not content.startswith("---"):
            return {}
        parts = content.split("---", 2)
        if len(parts) < 3:
            return {}
        data = yaml.safe_load(parts[1]) or {}
        return data if isinstance(data, dict) else {}

    def _discover_names(self, relative_dir: str, pattern: str) -> list[str]:
        return sorted(Path(p).name for p in self.provider.glob(f"{relative_dir}/{pattern}"))

    def _provider_runtime(self) -> dict[str, bool]:
        return {
            "config_loader": self.provider.exists("src/cas_runner/orchestration/config.py"),
            "mock_provider": self.provider.exists("src/cas_runner/llm/mock_client.py"),
            "llm_package": any(self.provider.glob("src/cas_runner/llm/*")),
        }

    def _observability(self) -> dict[str, bool]:
        path_str = "src/cas_runner/orchestration/telemetry.py"
        content = self.provider.read_text(path_str) if self.provider.exists(path_str) else ""
        return {
            "local_telemetry": "LocalTelemetryProvider" in content,
            "trace_persistence": "persist" in content,
        }

    def _evaluation(self) -> dict[str, bool]:
        path_str = "src/cas_runner/orchestration/evaluation.py"
        content = self.provider.read_text(path_str) if self.provider.exists(path_str) else ""
        return {
            "evaluation_harness": "EvaluationHarness" in content,
        }

    def _build_workflow(self) -> dict[str, Any]:
        skill_dirs = {
            Path(p).parent.name
            for p in self.provider.glob(".cas/*/SKILL.md")
        } | {
            Path(p).parent.name
            for p in self.provider.glob("src/cas_skills/*/SKILL.md")
        } | {
            Path(p).parent.name
            for p in self.provider.glob(".agents/skills/cas-*/SKILL.md")
        }

        agent_contracts = sorted(
            p.replace(".cas/", "", 1) if p.startswith(".cas/") else p
            for p in self.provider.glob(".cas/*/agents/*.yaml")
        )

        return {
            "cas_skills": sorted(skill_dirs),
            "agent_skill_contracts": agent_contracts,
            "specify_assets": self.provider.exists(".specify"),
            "spec_count": len(self.provider.glob("specs/*/spec.md")),
            "superpowers_plan_count": len(self.provider.glob("docs/superpowers/plans/*.md")),
            "test_count": len(self.provider.glob("tests/**/test_*.py")),
        }

    def _cicd(self) -> dict[str, Any]:
        files = sorted(self.provider.glob(".github/workflows/*.yml"))
        files.extend(sorted(self.provider.glob(".github/workflows/*.yaml")))
        return {"github_actions": bool(files), "workflow_files": files}

