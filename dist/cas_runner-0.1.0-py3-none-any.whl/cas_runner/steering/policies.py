from pathlib import Path


class SteeringProjectionPolicy:
    allowed_steering_artifacts = ("README.md", "AGENTS.md", "GEMINI.md", "CLAUDE.md")
    excluded_output_keys = frozenset({"aem", "aid", "alignment_report", "architecture_work"})
    output_dir = Path("governance/steering/projections")
    output_key = "steering_projection"
    approval_required = True
    direct_apply_allowed = False
