from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from cas_runner.io import get_workspace_root, persist_capability_inventory
from cas_runner.steering.analyzer import ArchitecturalDeltaAnalyzer
from cas_runner.steering.capability_extractor import CapabilityExtractor
from cas_runner.steering.indexer import SteeringRuntimeIndexer


def bootstrap_inventory(
    project: str,
    project_root: str | Path | None = None,
    workspace_root: str | Path | None = None,
    baseline_ref: str | None = None,
):
    if not project_root:
        project_root = Path(".")
    else:
        project_root = Path(project_root)

    if not workspace_root:
        workspace_root = get_workspace_root()
    else:
        workspace_root = Path(workspace_root)

    if not baseline_ref:
        baseline_ref = "4b825dc642cb6eb9a060e54bf8d69288fbee4904"

    print(f"[CAS][STEERING] Starting one-time bootstrap for project: {project}")

    # 1. Index current state (codebase)
    index = SteeringRuntimeIndexer(root=project_root).build_index()

    # 2. Analyze architectural deltas
    analyzer = ArchitecturalDeltaAnalyzer(current=index, root=project_root)
    deltas = analyzer.analyze(baseline_ref=baseline_ref)

    # 3. Extract capabilities
    extractor = CapabilityExtractor()
    capabilities = extractor.extract(deltas)

    # 4. Construct inventory structure
    inventory_caps = {}
    timestamp = datetime.now(UTC).isoformat()

    for cap in capabilities:
        evidence = []
        target = cap.metadata.get("target")
        if target:
            evidence.append(target)

        # Generate a clean title from ID slug or target
        title = cap.id.split("-")[-2].replace("_", " ").title() if len(cap.id.split("-")) >= 2 else "Untitled Capability"

        inventory_caps[cap.id] = {
            "id": cap.id,
            "title": title,
            "category": cap.category.value,
            "description": cap.description,
            "lifecycle_status": "active",
            "first_introduced": timestamp,
            "last_modified": timestamp,
            "originating_delta": cap.delta_ref,
            "lineage": [],
            "supporting_artifacts": [],
            "implementation_evidence": evidence,
        }

    inventory = {
        "version": "1.0.0",
        "project": project,
        "last_updated": timestamp,
        "capabilities": inventory_caps,
    }

    # 5. Persist and validate
    persist_capability_inventory(inventory, project)

    print(f"[CAS][STEERING] Discovered {len(capabilities)} runtime capabilities from workspace.")
    print(f"[CAS][STEERING] Runtime capability inventory created: knowledge/projects/{project}/capabilities/inventory.yaml")
    print(f"[CAS][STEERING] Inventory validation successful against schema.")
