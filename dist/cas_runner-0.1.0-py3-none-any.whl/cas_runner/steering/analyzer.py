import subprocess
import sys
from pathlib import Path


import yaml

from .classifier import ArchitecturalDeltaClassifier
from .git_extractor import GitDeltaExtractor
from .indexer import SteeringRuntimeIndexer
from .models import ArchitecturalDelta, SteeringRuntimeIndex
from .resources import GitResourceProvider


class DeltaBaselineProvider:
    def __init__(self, root: str | Path = ".", workspace_root: str | Path = None) -> None:
        # root is the project/codebase root (used for git operations)
        self.root = Path(root)
        # workspace_root is the knowledge root (used for projection discovery)
        self.workspace_root = Path(workspace_root) if workspace_root else self.root

    def get_baseline_ref(self, project: str | None = None, ref: str | None = None) -> str | None:
        """
        Discovers the baseline ref.
        If ref is provided, it uses that ref.
        If project is provided, it tries to find the latest projection and its current_ref.
        Defaults to HEAD~1 if no projection or ref is found.
        Returns None if an explicit ref or discovered ref is invalid.
        """
        baseline_ref = ref
        is_explicit = bool(ref)

        if not baseline_ref and project:
            baseline_ref = self._discover_last_ref(project)

        if not baseline_ref:
            baseline_ref = "HEAD~10"

        try:
            # Check if ref exists
            subprocess.run(
                ["git", "rev-parse", "--verify", baseline_ref],
                check=True,
                capture_output=True,
                cwd=self.root,
            )
            return baseline_ref
        except subprocess.CalledProcessError as e:
            if sys.platform == "darwin" and b"libxcrun" in getattr(e, "stderr", b""):
                try:
                    subprocess.run(
                        ["arch", "-arm64", "git", "rev-parse", "--verify", baseline_ref],
                        check=True,
                        capture_output=True,
                        cwd=self.root,
                    )
                    return baseline_ref
                except (subprocess.CalledProcessError, FileNotFoundError):
                    pass
            if is_explicit:
                return None
            return "HEAD~1"  # Fallback only for non-explicit or failed discovery
        except FileNotFoundError:
            if is_explicit:
                return None
            return "HEAD~1"


    def get_baseline_index(self, project: str | None = None, ref: str | None = None) -> SteeringRuntimeIndex | None:
        """
        Reconstructs the SteeringRuntimeIndex from a baseline.
        """
        baseline_ref = self.get_baseline_ref(project, ref)
        if not baseline_ref:
            return None

        try:
            provider = GitResourceProvider(ref=baseline_ref, root=self.root)
            indexer = SteeringRuntimeIndexer(root=self.root, provider=provider)
            return indexer.build_index()
        except Exception:
            return None

    def _discover_last_ref(self, project: str) -> str | None:
        projection_dir = self.workspace_root / "governance/steering/projections"
        if not projection_dir.exists():
            return None

        # Projections are named steering-projection-{project}-{timestamp}.md
        pattern = f"steering-projection-{project}-*.md"
        projections = sorted(projection_dir.glob(pattern), reverse=True)

        for projection_path in projections:
            try:
                content = projection_path.read_text()
                # Parse YAML frontmatter
                if content.startswith("---"):
                    parts = content.split("---", 2)
                    if len(parts) >= 3:
                        data = yaml.safe_load(parts[1])
                        if isinstance(data, dict) and data.get("current_ref"):
                            return data["current_ref"]
            except Exception:
                continue

        return None


class ArchitecturalDeltaAnalyzer:

    def __init__(self, current: SteeringRuntimeIndex, root: str | Path = ".") -> None:
        self.current = current
        self.root = Path(root)

    def analyze(self, baseline_ref: str | None) -> list[ArchitecturalDelta]:
        """
        Performs architectural delta analysis using the Git Delta Extraction layer.
        """
        if not baseline_ref:
            return []

        extractor = GitDeltaExtractor(root=self.root)
        classifier = ArchitecturalDeltaClassifier(index=self.current)

        raw_deltas = extractor.extract(baseline_ref=baseline_ref)
        deltas = classifier.classify(raw_deltas)

        return deltas

