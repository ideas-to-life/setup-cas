import subprocess
from pathlib import Path

from .models import GitChangeType, RawGitDelta


class GitDeltaExtractor:
    """
    Extracts raw file changes between two git references.
    """

    def __init__(self, root: str | Path = ".") -> None:
        self.root = Path(root)

    def extract(self, baseline_ref: str, current_ref: str = "HEAD") -> list[RawGitDelta]:
        """
        Executes git diff and parses the output into RawGitDelta objects.
        """
        try:
            # --name-status gives:
            # A	file/path
            # M	file/path
            # D	file/path
            # R100	old/path	new/path
            output = subprocess.check_output(
                ["git", "diff", "--name-status", baseline_ref, current_ref],
                cwd=self.root,
                stderr=subprocess.PIPE,
            ).decode("utf-8")
        except subprocess.CalledProcessError:
            # If refs are invalid or not in a git repo, return empty list
            return []

        deltas: list[RawGitDelta] = []
        for line in output.splitlines():
            if not line.strip():
                continue

            parts = line.split("\t")
            status = parts[0]

            if status.startswith("A"):
                deltas.append(RawGitDelta(path=parts[1], change_type=GitChangeType.ADDED))
            elif status.startswith("M"):
                deltas.append(RawGitDelta(path=parts[1], change_type=GitChangeType.MODIFIED))
            elif status.startswith("D"):
                deltas.append(RawGitDelta(path=parts[1], change_type=GitChangeType.DELETED))
            elif status.startswith("R"):
                # Renamed: R<score> \t old_path \t new_path
                deltas.append(RawGitDelta(
                    path=parts[2],
                    change_type=GitChangeType.RENAMED,
                    old_path=parts[1]
                ))

        return deltas
