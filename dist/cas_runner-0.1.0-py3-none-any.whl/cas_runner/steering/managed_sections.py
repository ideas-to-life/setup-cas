import re

from .models import ManagedSteeringSection

BEGIN_MARKER_PREFIX = "<!-- CAS-STEERING:BEGIN "
END_MARKER_PREFIX = "<!-- CAS-STEERING:END "
MARKER_SUFFIX = " -->"
MARKER_PATTERN = re.compile(
    r"^<!-- CAS-STEERING:(BEGIN|END) ([A-Za-z0-9][A-Za-z0-9_-]*) -->$"
)


class ManagedSectionError(ValueError):
    def __init__(
        self,
        artifact: str,
        message: str,
        *,
        section_id: str | None = None,
        marker: str | None = None,
        line: int | None = None,
    ) -> None:
        details = [f"artifact={artifact}"]
        if section_id is not None:
            details.append(f"section_id={section_id}")
        if marker is not None:
            details.append(f"marker={marker}")
        if line is not None:
            details.append(f"line={line}")
        super().__init__(f"{message} ({', '.join(details)})")
        self.artifact = artifact
        self.section_id = section_id
        self.marker = marker
        self.line = line


def begin_marker(section_id: str) -> str:
    return f"{BEGIN_MARKER_PREFIX}{section_id}{MARKER_SUFFIX}"


def end_marker(section_id: str) -> str:
    return f"{END_MARKER_PREFIX}{section_id}{MARKER_SUFFIX}"


def parse_managed_sections(artifact: str, text: str) -> list[ManagedSteeringSection]:
    sections: list[ManagedSteeringSection] = []
    seen_section_ids: set[str] = set()
    open_section_id: str | None = None
    open_begin_line: int | None = None
    open_content_start: int | None = None
    lines = text.splitlines(keepends=True)

    for index, line in enumerate(lines):
        line_number = index + 1
        marker_text = line.rstrip("\r\n")
        marker_match = MARKER_PATTERN.fullmatch(marker_text)

        if marker_text.startswith("<!-- CAS-STEERING:") and marker_match is None:
            section_id = _extract_marker_section_id(marker_text)
            raise ManagedSectionError(
                artifact,
                "malformed managed section marker",
                section_id=section_id,
                marker=marker_text,
                line=line_number,
            )

        if marker_match is None:
            continue

        marker_kind, section_id = marker_match.groups()
        if marker_kind == "BEGIN":
            if open_section_id is not None:
                raise ManagedSectionError(
                    artifact,
                    "nested managed section marker",
                    section_id=section_id,
                    marker=marker_text,
                    line=line_number,
                )
            if section_id in seen_section_ids:
                raise ManagedSectionError(
                    artifact,
                    "duplicate managed section id",
                    section_id=section_id,
                    marker=marker_text,
                    line=line_number,
                )
            open_section_id = section_id
            open_begin_line = line_number
            open_content_start = index + 1
            continue

        if open_section_id is None:
            raise ManagedSectionError(
                artifact,
                "unmatched managed section end marker",
                section_id=section_id,
                marker=marker_text,
                line=line_number,
            )
        if section_id != open_section_id:
            raise ManagedSectionError(
                artifact,
                "mismatched managed section end marker",
                section_id=open_section_id,
                marker=marker_text,
                line=line_number,
            )

        assert open_begin_line is not None
        assert open_content_start is not None
        sections.append(
            ManagedSteeringSection(
                artifact=artifact,
                section_id=section_id,
                begin_marker=begin_marker(section_id),
                end_marker=end_marker(section_id),
                content="".join(lines[open_content_start:index]),
                start_line=open_begin_line,
                end_line=line_number,
            )
        )
        seen_section_ids.add(section_id)
        open_section_id = None
        open_begin_line = None
        open_content_start = None

    if open_section_id is not None:
        raise ManagedSectionError(
            artifact,
            "unmatched managed section begin marker",
            section_id=open_section_id,
            marker=begin_marker(open_section_id),
            line=open_begin_line,
        )

    return sections


def replace_managed_section(text: str, section_id: str, generated_content: str) -> str:
    artifact = "<memory>"
    sections = parse_managed_sections(artifact, text)
    if not any(section.section_id == section_id for section in sections):
        raise ManagedSectionError(
            artifact,
            "managed section id not found",
            section_id=section_id,
            marker=begin_marker(section_id),
        )

    lines = text.splitlines(keepends=True)
    begin = begin_marker(section_id)
    end = end_marker(section_id)
    begin_index: int | None = None
    end_index: int | None = None

    for index, line in enumerate(lines):
        marker_text = line.rstrip("\r\n")
        if marker_text == begin:
            begin_index = index
        elif marker_text == end and begin_index is not None:
            end_index = index
            break

    if begin_index is None or end_index is None:
        raise ManagedSectionError(
            artifact,
            "managed section marker pair not found",
            section_id=section_id,
            marker=begin,
        )

    normalized_content = _ensure_trailing_newline(generated_content)

    return "".join(
        [
            *lines[: begin_index + 1],
            normalized_content,
            *lines[end_index:],
        ]
    )


def _extract_marker_section_id(marker_text: str) -> str | None:
    parts = marker_text.split()
    if len(parts) >= 3 and parts[0] == "<!--" and parts[1].startswith("CAS-STEERING:"):
        candidate = parts[2]
        if candidate != "-->":
            return candidate
    return None


def _ensure_trailing_newline(content: str) -> str:
    if content.endswith(("\n", "\r")):
        return content
    return f"{content}\n"
