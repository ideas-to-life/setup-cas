import subprocess
import sys
from pathlib import Path
from typing import Protocol, runtime_checkable



@runtime_checkable
class ResourceProvider(Protocol):
    def read_text(self, relative_path: str) -> str:
        """Reads text from a file at the given relative path."""
        ...

    def read_bytes(self, relative_path: str) -> bytes:
        """Reads bytes from a file at the given relative path."""
        ...

    def exists(self, relative_path: str) -> bool:
        """Checks if a file exists at the given relative path."""
        ...

    def glob(self, pattern: str) -> list[str]:
        """Returns a list of relative paths matching the glob pattern."""
        ...


class LocalResourceProvider:
    def __init__(self, root: str | Path = ".") -> None:
        self.root = Path(root)

    def read_text(self, relative_path: str) -> str:
        return (self.root / relative_path).read_text()

    def read_bytes(self, relative_path: str) -> bytes:
        return (self.root / relative_path).read_bytes()

    def exists(self, relative_path: str) -> bool:
        return (self.root / relative_path).exists()

    def glob(self, pattern: str) -> list[str]:
        return [
            str(p.relative_to(self.root))
            for p in self.root.glob(pattern)
        ]


class GitResourceProvider:
    def __init__(self, ref: str, root: str | Path = ".") -> None:
        self.ref = ref
        self.root = Path(root)
        self._file_list: list[str] | None = None

    def _git_run(self, args: list[str]) -> bytes:
        try:
            return subprocess.check_output(
                ["git", *args],
                cwd=self.root,
                stderr=subprocess.PIPE,
            )
        except subprocess.CalledProcessError as e:
            if sys.platform == "darwin" and b"libxcrun" in e.stderr:
                return subprocess.check_output(
                    ["arch", "-arm64", "git", *args],
                    cwd=self.root,
                    stderr=subprocess.PIPE,
                )
            raise


    def read_text(self, relative_path: str) -> str:
        try:
            return self._git_run(["show", f"{self.ref}:{relative_path}"]).decode("utf-8")
        except subprocess.CalledProcessError as e:
            raise FileNotFoundError(f"Could not read {relative_path} at {self.ref}") from e

    def read_bytes(self, relative_path: str) -> bytes:
        try:
            return self._git_run(["show", f"{self.ref}:{relative_path}"])
        except subprocess.CalledProcessError as e:
            raise FileNotFoundError(f"Could not read {relative_path} at {self.ref}") from e

    def exists(self, relative_path: str) -> bool:
        try:
            self._git_run(["cat-file", "-e", f"{self.ref}:{relative_path}"])
            return True
        except subprocess.CalledProcessError:
            return False

    def glob(self, pattern: str) -> list[str]:
        if self._file_list is None:
            output = self._git_run(["ls-tree", "-r", "--name-only", self.ref])
            self._file_list = output.decode("utf-8").splitlines()

        return [f for f in self._file_list if Path(f).match(pattern)]
