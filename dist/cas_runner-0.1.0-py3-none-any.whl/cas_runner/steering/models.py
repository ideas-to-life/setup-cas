from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import Any


class GitChangeType(Enum):
    ADDED = "added"
    MODIFIED = "modified"
    DELETED = "deleted"
    RENAMED = "renamed"


@dataclass(frozen=True)
class RawGitDelta:
    path: str
    change_type: GitChangeType
    old_path: str | None = None


@dataclass(frozen=True)
class PromptFact:
    step_name: str
    flow_name: str
    path: str
    version: str | None = None
    schema: str | None = None
    semantic_contract: str | None = None


@dataclass(frozen=True)
class SteeringRuntimeIndex:
    flows: dict[str, list[str]] = field(default_factory=dict)
    steps: list[str] = field(default_factory=list)
    prompts: list[PromptFact] = field(default_factory=list)
    schemas: dict[str, str] = field(default_factory=dict)
    provider_runtime: dict[str, Any] = field(default_factory=dict)
    observability: dict[str, Any] = field(default_factory=dict)
    evaluation: dict[str, Any] = field(default_factory=dict)
    build_workflow: dict[str, Any] = field(default_factory=dict)
    cicd: dict[str, Any] = field(default_factory=dict)


class CapabilityCategory(Enum):
    GOVERNANCE_PROJECTION = "governance_projection"
    ORCHESTRATION_GOVERNANCE = "orchestration_governance"
    SEMANTIC_CONTRACTS = "semantic_contracts"
    EVALUATION_GOVERNANCE = "evaluation_governance"
    OBSERVABILITY = "observability"
    RUNTIME_CONFIGURATION = "runtime_configuration"
    PROVIDER_ABSTRACTION = "provider_abstraction"
    ORCHESTRATION_REASONING = "orchestration_reasoning"
    STEERING_PROJECTION = "steering_projection"
    BUILD_WORKFLOW_GOVERNANCE = "build_workflow_governance"
    CAPABILITY_ROUTING = "capability_routing"
    ARCHITECTURE_LINEAGE = "architecture_lineage"


class CapabilityRecordType(Enum):
    CAPABILITY_INTRODUCED = "capability_introduced"
    CAPABILITY_EVOLVED = "capability_evolved"
    CAPABILITY_REMOVED = "capability_removed"
    GOVERNANCE_CAPABILITY_CHANGED = "governance_capability_changed"
    RUNTIME_CAPABILITY_CHANGED = "runtime_capability_changed"
    OPERATIONAL_CAPABILITY_CHANGED = "operational_capability_changed"


@dataclass(frozen=True)
class CapabilityRecord:
    id: str
    category: CapabilityCategory
    type: CapabilityRecordType
    delta_ref: str
    description: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CapabilitySet:
    run_id: str
    project: str
    capabilities: list[CapabilityRecord] = field(default_factory=list)
    timestamp: str = field(
        default_factory=lambda: datetime.now(UTC).isoformat()
    )
    baseline_ref: str | None = None


@dataclass(frozen=True)
class CapabilityLineage:
    capability_id: str
    history: list[CapabilityRecord] = field(default_factory=list)
    current_status: str = "active"


@dataclass(frozen=True)
class ArchitecturalDelta:
    id: str
    type: str
    target: str
    change: str
    rationale: str
    evidence: list[str]
    severity: str


@dataclass(frozen=True)
class ArchitecturalDeltaSet:
    id: str
    baseline_ref: str
    current_ref: str
    generated_at: str = field(
        default_factory=lambda: datetime.now(UTC).isoformat()
    )
    deltas: list[ArchitecturalDelta] = field(default_factory=list)
    capabilities: CapabilitySet | None = None


@dataclass(frozen=True)
class SteeringArtifactClaim:
    artifact: str
    line: int
    text: str
    claim_type: str


@dataclass(frozen=True)
class SteeringDriftFinding:
    id: str
    severity: str
    artifact: str
    line: int
    claim_type: str
    current_claim: str
    expected_fact: str
    evidence: list[str]
    recommendation: str
    delta_id: str | None = None


@dataclass(frozen=True)
class SteeringProjectionBundle:
    id: str
    project: str
    status: str
    path: Path | None
    output: dict[str, Any]
    deltas: list[ArchitecturalDelta] = field(default_factory=list)
    capabilities: list[CapabilityRecord] = field(default_factory=list)
    baseline_ref: str | None = None
    current_ref: str | None = None


@dataclass(frozen=True)
class ManagedSteeringSection:
    artifact: str
    section_id: str
    begin_marker: str
    end_marker: str
    content: str
    start_line: int
    end_line: int
    synthesized_content: str | None = None
    is_synthesized: bool = False


@dataclass(frozen=True)
class ManagedSectionProposal:
    id: str
    artifact: str
    section_id: str
    generated_content: str
    source_delta_ids: list[str] = field(default_factory=list)
    source_capability_ids: list[str] = field(default_factory=list)
    content_hash: str = ""
    status: str = "proposed"


@dataclass(frozen=True)
class ManagedSectionReplacement:
    artifact: str
    section_id: str
    old_content_hash: str
    new_content_hash: str
    diff: str


@dataclass(frozen=True)
class ManagedSectionApplyPlan:
    projection_id: str
    proposals: list[ManagedSectionProposal] = field(default_factory=list)
    replacements: list[ManagedSectionReplacement] = field(default_factory=list)
    dry_run: bool = False


@dataclass(frozen=True)
class ManagedSectionValidationReport:
    status: str
    checked_artifacts: list[str] = field(default_factory=list)
    sections: list[ManagedSteeringSection] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
