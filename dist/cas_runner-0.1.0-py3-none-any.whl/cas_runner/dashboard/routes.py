from cas_runner.dashboard.api import DashboardAPI


def generate_dashboard_markdown(project: str, is_project_page: bool = False) -> str:
    """
    Generates the dashboard Markdown content for the portal landing page or project context page.
    Uses MkDocs Material syntax for a rich visual experience.
    """
    api = DashboardAPI(project)
    data = api.get_summary()

    health = data["health"]
    metrics = data["metrics"]
    evolution = data["evolution"]

    # Health status color mapping for MkDocs admonitions
    health_color = {
        "green": "success",
        "amber": "warning",
        "red": "failure"
    }.get(health["status"], "info")

    # Relative path prefixes based on page location
    if is_project_page:
        work_prefix = "work/index.md"
        alignment_prefix = "alignment/index.md"
        decisions_prefix = "adrs/index.md"
        traces_prefix = "traces/index.md"
        proposals_prefix = "work/index.md"
        evidence_prefix = "alignment/index.md"
    elif project:
        work_prefix = f"projects/{project}/work/index.md"
        alignment_prefix = f"projects/{project}/alignment/index.md"
        decisions_prefix = f"projects/{project}/adrs/index.md"
        traces_prefix = f"projects/{project}/traces/index.md"
        proposals_prefix = f"projects/{project}/work/index.md"
        evidence_prefix = f"projects/{project}/alignment/index.md"
    else:
        # Workspace level (project is None): master workspace routes or Projects Hub
        work_prefix = "projects/index.md"
        alignment_prefix = "projects/index.md"
        decisions_prefix = "governance/adrs/index.md"
        traces_prefix = "runtime/traces/index.md"
        proposals_prefix = "governance/proposals/index.md"
        evidence_prefix = "evidence/index.md"

    content = "# Governance Health Dashboard\n\n"

    # --- Health Status Section ---
    content += f"!!! {health_color} \"Governance Health: {health['status'].upper()}\"\n"
    for reason in health["reasons"]:
        content += f"    - {reason}\n"
    content += "\n"

    # --- Metrics Grid ---
    content += "## Governance Metrics\n\n"
    content += "<div class=\"grid cards\" markdown>\n\n"

    # Architecture Work Health Card
    content += "-   :material-briefcase-check: **Architecture Work Health**\n\n"
    content += "    ---\n\n"
    content += f"    **{metrics['architecture_work']['total']}** Total\n\n"
    content += f"    ▲ Ready for Review: {metrics['architecture_work']['ready_for_review']}\n\n"
    content += f"    ✓ Completed & Verified: {metrics['architecture_work']['stable']}\n\n"
    content += f"    ⚠ Verify Evidence: {metrics['architecture_work']['requires_evidence_verification']}\n\n"
    content += f"    ○ Awaiting Implementation: {metrics['architecture_work']['awaiting_implementation']}\n\n"
    content += f"    [:octicons-arrow-right-24: View Architecture Work]({work_prefix})\n\n"

    # Human Approval Card
    content += "-   :material-account-check: **Human Approval**\n\n"
    content += "    ---\n\n"
    content += f"    Pending Reviews: {metrics['human_approval']['pending_reviews']}\n\n"
    content += f"    Ready for Completion: {metrics['human_approval']['ready_for_completion']}\n\n"
    content += f"    Blocked: {metrics['human_approval']['blocked']}\n\n"
    content += f"    [:octicons-arrow-right-24: View Approval Queue]({proposals_prefix})\n\n"

    # Governance Debt Card
    content += "-   :material-alert-circle-outline: **Governance Debt**\n\n"
    content += "    ---\n\n"
    content += f"    Duplicate Work: {metrics['governance_debt']['duplicate_work']}\n\n"
    content += f"    Oversized Work: {metrics['governance_debt']['oversized_work']}\n\n"
    content += f"    Capability Reviews: {metrics['governance_debt']['runtime_cap_reviews']}\n\n"
    content += f"    Missing Lineage: {metrics['governance_debt']['missing_lineage']}\n\n"
    content += f"    [:octicons-arrow-right-24: View Observations]({alignment_prefix})\n\n"

    # ADR Status Card
    content += "-   :material-gavel: **Architecture Decisions**\n\n"
    content += "    ---\n\n"
    content += f"    **{metrics['adr_distribution'].get('accepted', 0)}** Accepted\n\n"
    content += f"    **{metrics['adr_distribution'].get('proposed', 0)}** Proposed\n\n"
    content += f"    [:octicons-arrow-right-24: View Records]({decisions_prefix})\n\n"

    # Risk Findings Card
    content += "-   :material-alert-decagram: **Risk Findings**\n\n"
    content += "    ---\n\n"
    content += f"    **{metrics['risk_counts']['high']}** High\n\n"
    content += f"    **{metrics['risk_counts']['medium']}** Medium\n\n"
    content += f"    [:octicons-arrow-right-24: View Reports]({alignment_prefix})\n\n"

    # Operational Health Card
    op = metrics.get("operational", {})
    content += "-   :material-monitor-dashboard: **Operational Health**\n\n"
    content += "    ---\n\n"
    content += f"    **${op.get('total_recorded_cost', 0)}** Token Cost\n\n"
    content += f"    **{op.get('trace_count', 0)}** Traces Captured\n\n"
    content += f"    [:octicons-arrow-right-24: View Traces]({traces_prefix})\n\n"

    # Implementation Evidence Card
    content += "-   :material-chart-donut: **Implementation Evidence**\n\n"
    content += "    ---\n\n"
    content += f"    🟢 Complete: {metrics['implementation_evidence']['complete']}\n\n"
    content += f"    🟡 Substantial: {metrics['implementation_evidence']['substantial']}\n\n"
    content += f"    🟠 Partial: {metrics['implementation_evidence']['partial']}\n\n"
    content += f"    ⚪ None: {metrics['implementation_evidence']['none']}\n\n"
    content += f"    [:octicons-arrow-right-24: View Evidence Reports]({evidence_prefix})\n\n"

    content += "</div>\n\n"


    # --- Insights Section ---
    if data.get("insights"):
        content += "## Systemic Insights\n\n"
        for insight in data["insights"]:
            icon = ":material-information-outline:"
            if insight["severity"] == "high": icon = ":material-alert-circle-outline:"
            elif insight["severity"] == "medium": icon = ":material-alert-outline:"

            content += f"!!! info \"{icon} {insight['description']}\"\n\n"

    # --- Recent Evolution ---
    content += "## Recent Architectural Evolution\n\n"
    content += "| Item | Date | Status | Description |\n"
    content += "|------|------|--------|-------------|\n"
    for item in evolution:
        title = item.get("title") or item.get("id") or "Unknown"
        date = item.get("date") or "N/A"
        status = item.get("status") or "N/A"
        summary = item.get("summary", "No summary available")
        # Truncate summary
        summary = (summary[:75] + '...') if len(summary) > 75 else summary
        content += f"| [[{item.get('id', title)}]] | {date} | {status} | {summary} |\n"

    content += f"\n[View all architecture work]({work_prefix})\n"

    return content

