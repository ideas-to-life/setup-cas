from typing import Any


class HealthStatus:
    GREEN = "green"
    AMBER = "amber"
    RED = "red"

def calculate_health(indicators: dict[str, Any]) -> str:
    """
    Calculates the overall governance health status based on heuristics.
    """
    # RED TRIGGERS
    if indicators.get("high_risk_findings"):
        return HealthStatus.RED

    if indicators.get("pending_decisions_count", 0) > 10:
        return HealthStatus.RED

    if indicators.get("pending_reviews_count", 0) > 10:
        return HealthStatus.RED

    if indicators.get("verify_evidence_count", 0) > 5:
        return HealthStatus.RED

    # AMBER TRIGGERS
    if indicators.get("active_work_count", 0) > 5:
        return HealthStatus.AMBER

    if indicators.get("pending_reviews_count", 0) > 0:
        return HealthStatus.AMBER

    if indicators.get("verify_evidence_count", 0) > 0:
        return HealthStatus.AMBER

    if indicators.get("duplicate_work_count", 0) > 0:
        return HealthStatus.AMBER

    if indicators.get("oversized_work_count", 0) > 0:
        return HealthStatus.AMBER

    if indicators.get("runtime_cap_reviews_count", 0) > 0:
        return HealthStatus.AMBER

    if indicators.get("missing_lineage_count", 0) > 0:
        return HealthStatus.AMBER

    return HealthStatus.GREEN

def get_health_reasons(indicators: dict[str, Any]) -> list[str]:
    """
    Returns a list of reasons for the current health status.
    """
    reasons = []

    findings = indicators.get("high_risk_findings", [])
    if findings:
        reasons.append(f"High-risk findings detected: {len(findings)}")

    pending = indicators.get("pending_decisions_count", 0)
    if pending > 10:
        reasons.append(f"High volume of pending decisions ({pending})")

    pending_reviews = indicators.get("pending_reviews_count", 0)
    if pending_reviews > 0:
        reasons.append(f"Pending lifecycle reviews: {pending_reviews}")

    verify_evidence = indicators.get("verify_evidence_count", 0)
    if verify_evidence > 0:
        reasons.append(f"Evidence verification requests: {verify_evidence}")

    active = indicators.get("active_work_count", 0)
    if active > 5:
        reasons.append(f"High volume of active architecture work ({active})")

    duplicates = indicators.get("duplicate_work_count", 0)
    if duplicates > 0:
        reasons.append(f"Duplicate Architecture Work items detected: {duplicates}")

    oversized = indicators.get("oversized_work_count", 0)
    if oversized > 0:
        reasons.append(f"Oversized Architecture Work items detected: {oversized}")

    orphans = indicators.get("runtime_cap_reviews_count", 0)
    if orphans > 0:
        reasons.append(f"Orphan runtime capabilities: {orphans}")

    missing_lineage = indicators.get("missing_lineage_count", 0)
    if missing_lineage > 0:
        reasons.append(f"Capabilities missing lineage: {missing_lineage}")

    if not reasons:
        reasons.append("All governance indicators are within healthy thresholds.")

    return reasons

