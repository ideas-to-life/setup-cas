from typing import Any

from cas_runner.dashboard import health_model
from cas_runner.dashboard.data_access import DashboardDataAccess


class DashboardAPI:
    """
    API layer for the Governance Dashboard.
    Aggregates data from data access and applies health logic.
    """
    def __init__(self, project: str | None = None):
        self.project = project
        self.data_access = DashboardDataAccess(project)

    def get_summary(self) -> dict[str, Any]:
        """
        Returns a complete summary for the dashboard landing page.
        """
        indicators = self.data_access.get_health_indicators()
        metrics = self.data_access.get_governance_metrics()
        evolution = self.data_access.get_recent_evolution()
        insights = self.data_access.get_cross_artifact_insights()

        health_status = health_model.calculate_health(indicators)
        health_reasons = health_model.get_health_reasons(indicators)

        return {
            "project": self.project,
            "health": {
                "status": health_status,
                "reasons": health_reasons
            },
            "metrics": metrics,
            "evolution": evolution,
            "insights": insights,
            "indicators": indicators # For debugging/traceability
        }
