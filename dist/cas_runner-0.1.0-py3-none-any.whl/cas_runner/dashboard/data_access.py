from typing import Any
import glob
from cas_runner.io import get_provider, get_telemetry_root


class DashboardDataAccess:
    """
    Data access layer for the Governance Dashboard.
    Provides synthesized views of governance artifacts.
    When project is None, aggregates metrics across all onboarded projects in the workspace.
    """
    def __init__(self, project: str | None = None):
        self.project = project
        self.provider = get_provider()

    def _get_project_ids(self) -> list[str]:
        if not hasattr(self.provider, "base"):
            return []
        p_dir = self.provider.base / "projects"
        if not p_dir.exists():
            return []
        return [p.name for p in sorted(p_dir.iterdir()) if p.is_dir()]

    def _parse_coverage_summary(self, latest_assessment: dict[str, Any] | None) -> list[dict[str, str]]:
        if not latest_assessment:
            return []
        
        coverage_section = latest_assessment.get("sections", {}).get("coverage_summary", "")
        if not coverage_section:
            return []
            
        items = []
        for line in coverage_section.split("\n"):
            line = line.strip()
            if not line.startswith("|") or "Architecture Work ID" in line or "---|---" in line:
                continue
            parts = [p.strip().replace("**", "").replace("`", "") for p in line.split("|")]
            if len(parts) >= 8:
                items.append({
                    "id": parts[1],
                    "title": parts[2],
                    "current_status": parts[3],
                    "recommended_status": parts[4],
                    "recommended_action": parts[5],
                    "coverage": parts[6],
                    "classification": parts[7]
                })
        return items

    def _parse_observations(self, latest_assessment: dict[str, Any] | None) -> dict[str, int]:
        res = {
            "duplicate_work": 0,
            "oversized_work": 0,
            "runtime_cap_reviews": 0,
            "missing_lineage": 0
        }
        if not latest_assessment:
            return res
            
        observations_section = latest_assessment.get("sections", {}).get("appendix:_governance_observations", "")
        if not observations_section:
            return res
            
        current_sub = None
        missing_lineage_mode = False
        
        for line in observations_section.split("\n"):
            line = line.strip()
            if line.startswith("### "):
                current_sub = line[4:].lower().strip()
                missing_lineage_mode = False
            elif line.startswith("#### ") and current_sub == "oversized architecture work":
                res["oversized_work"] += 1
            elif line.startswith("-") and current_sub == "orphan runtime capabilities":
                if "cap-" in line:
                    res["runtime_cap_reviews"] += 1
            elif "missing lineage" in line.lower() or "missing_lineage" in line.lower():
                missing_lineage_mode = True
            elif line.startswith("- **") or line.startswith("* **"):
                missing_lineage_mode = False
            elif missing_lineage_mode and (line.startswith("-") or line.startswith("*")):
                if "cap-" in line:
                    res["missing_lineage"] += 1
            elif "duplicate" in line.lower():
                res["duplicate_work"] += 1

        return res

    def _load_architecture_work(self) -> list[dict[str, Any]]:
        if self.project:
            return self.provider.load_architecture_work(self.project)
        work_items = []
        for pid in self._get_project_ids():
            work_items.extend(self.provider.load_architecture_work(pid))
        return work_items

    def _load_all_assessments(self) -> list[dict[str, Any]]:
        if not hasattr(self.provider, "base"):
            return []
        assessments = []
        if self.project:
            pattern = self.provider.base / "projects" / self.project / "assessment" / "*.md"
            files = sorted(glob.glob(str(pattern)), reverse=True)
            if files:
                parsed = self.provider._parse_markdown_with_frontmatter(files[0])
                if parsed:
                    assessments.append(parsed)
        else:
            for pid in self._get_project_ids():
                pattern = self.provider.base / "projects" / pid / "assessment" / "*.md"
                files = sorted(glob.glob(str(pattern)), reverse=True)
                if files:
                    parsed = self.provider._parse_markdown_with_frontmatter(files[0])
                    if parsed:
                        assessments.append(parsed)
        return assessments

    def _load_all_alignments(self) -> list[dict[str, Any]]:
        if not hasattr(self.provider, "base"):
            return []
        alignments = []
        if self.project:
            pattern = self.provider.base / "projects" / self.project / "alignment" / "*.md"
            files = sorted(glob.glob(str(pattern)), reverse=True)
            if files:
                parsed = self.provider._parse_markdown_with_frontmatter(files[0])
                if parsed:
                    alignments.append(parsed)
        else:
            for pid in self._get_project_ids():
                pattern = self.provider.base / "projects" / pid / "alignment" / "*.md"
                files = sorted(glob.glob(str(pattern)), reverse=True)
                if files:
                    parsed = self.provider._parse_markdown_with_frontmatter(files[0])
                    if parsed:
                        alignments.append(parsed)
        return alignments

    def _load_all_decisions(self) -> list[dict[str, Any]]:
        if not hasattr(self.provider, "base"):
            return []

        all_files = []
        global_pattern = str(self.provider.base / "global" / "decisions" / "*.md")
        all_files.extend(glob.glob(global_pattern))

        if self.project:
            proj_adrs_pattern = str(self.provider.base / "projects" / self.project / "adrs" / "*.md")
            all_files.extend(glob.glob(proj_adrs_pattern))
            proj_decisions_pattern = str(self.provider.base / "projects" / self.project / "decisions" / "*.md")
            all_files.extend(glob.glob(proj_decisions_pattern))
        else:
            for pid in self._get_project_ids():
                all_files.extend(glob.glob(str(self.provider.base / "projects" / pid / "adrs" / "*.md")))
                all_files.extend(glob.glob(str(self.provider.base / "projects" / pid / "decisions" / "*.md")))

        decisions = []
        seen_files = set()

        for f in all_files:
            if f in seen_files or f.endswith("index.md"):
                continue
            seen_files.add(f)

            parsed = self.provider._parse_markdown_with_frontmatter(f)
            if not parsed:
                continue

            adr_project = parsed.get("project")

            if self.project is None or self.project in ("global", "cas-knowledge-workspace"):
                decisions.append(parsed)
            elif adr_project == self.project or f"projects/{self.project}/" in f.replace("\\", "/"):
                decisions.append(parsed)

        return decisions

    def _extract_high_risk_findings(self, alignments: list[dict[str, Any]]) -> list[str]:
        high_risks = []
        for alignment_report in alignments:
            if not alignment_report:
                continue
            raw_findings = alignment_report.get("sections", {}).get("alignment_findings", "")
            if not isinstance(raw_findings, str):
                continue
            lines = raw_findings.split("\n")
            for line in lines:
                line = line.strip()
                if line.startswith("- [HIGH]") or line.startswith("- [CRITICAL]"):
                    high_risks.append(line[8:].strip())
        return high_risks

    def get_health_indicators(self) -> dict[str, Any]:
        work_items = self._load_architecture_work()
        alignments = self._load_all_alignments()
        decisions = self._load_all_decisions()
        assessments = self._load_all_assessments()

        active_work = [w for w in work_items if w.get("status") in ["active", "in progress"] or w.get("lifecycle_state") == "active"]

        pending_reviews = 0
        verify_evidence = 0
        duplicate_work = 0
        oversized_work = 0
        runtime_cap_reviews = 0
        missing_lineage = 0

        for ass in assessments:
            assessment_items = self._parse_coverage_summary(ass)
            pending_reviews += sum(1 for item in assessment_items if "Promote" in item.get("recommended_action", ""))
            verify_evidence += sum(1 for item in assessment_items if "Verify" in item.get("recommended_action", ""))
            debt_counts = self._parse_observations(ass)
            duplicate_work += debt_counts.get("duplicate_work", 0)
            oversized_work += debt_counts.get("oversized_work", 0)
            runtime_cap_reviews += debt_counts.get("runtime_cap_reviews", 0)
            missing_lineage += debt_counts.get("missing_lineage", 0)

        latest_date = None
        for a in alignments:
            d = a.get("frontmatter", {}).get("date")
            if d and (latest_date is None or d > latest_date):
                latest_date = d

        return {
            "active_work_count": len(active_work),
            "pending_decisions_count": len([d for d in decisions if d.get("decision", {}).get("status") == "proposed"]),
            "high_risk_findings": self._extract_high_risk_findings(alignments),
            "latest_alignment_date": latest_date,
            "pending_reviews_count": pending_reviews,
            "verify_evidence_count": verify_evidence,
            "duplicate_work_count": duplicate_work,
            "oversized_work_count": oversized_work,
            "runtime_cap_reviews_count": runtime_cap_reviews,
            "missing_lineage_count": missing_lineage
        }

    def get_governance_metrics(self) -> dict[str, Any]:
        work_items = self._load_architecture_work()
        decisions = self._load_all_decisions()
        alignments = self._load_all_alignments()
        assessments = self._load_all_assessments()
        operational = self.get_operational_health()

        adr_stats = {}
        for d in decisions:
            gov = d.get("governance") if isinstance(d.get("governance"), dict) else {}
            dec = d.get("decision") if isinstance(d.get("decision"), dict) else {}
            status = gov.get("forum_status") if gov.get("forum_decision_date") else (
                dec.get("status") or (d.get("decision") if isinstance(d.get("decision"), str) else None) or d.get("status") or "unknown"
            )
            adr_stats[status] = adr_stats.get(status, 0) + 1

        risk_stats = {"high": 0, "medium": 0, "low": 0}
        for alignment in alignments:
            raw_findings = alignment.get("sections", {}).get("alignment_findings", "")
            if isinstance(raw_findings, str):
                for line in raw_findings.split("\n"):
                    line = line.strip()
                    if "[HIGH]" in line.upper() or "[CRITICAL]" in line.upper():
                        risk_stats["high"] += 1
                    elif "[MEDIUM]" in line.upper():
                        risk_stats["medium"] += 1
                    elif "[LOW]" in line.upper():
                        risk_stats["low"] += 1

        total = len(work_items)
        stable = 0
        ready_for_review = 0
        requires_evidence = 0
        awaiting_impl = 0
        evidence_counts = {"complete": 0, "substantial": 0, "partial": 0, "none": 0}

        all_assessment_items = []
        for ass in assessments:
            items = self._parse_coverage_summary(ass)
            if items:
                all_assessment_items.extend(items)

        if all_assessment_items:
            total = len(all_assessment_items)
            for item in all_assessment_items:
                action = item["recommended_action"].lower()
                status = item["current_status"].lower()
                rec_status = item["recommended_status"].lower()

                if "verify" in action:
                    requires_evidence += 1
                elif "remain done" in action or (status == "done" and rec_status == "done"):
                    stable += 1
                elif "promote" in action:
                    ready_for_review += 1
                else:
                    awaiting_impl += 1

                cov = item["coverage"].lower()
                if "complete" in cov:
                    evidence_counts["complete"] += 1
                elif "substantial" in cov:
                    evidence_counts["substantial"] += 1
                elif "partial" in cov:
                    evidence_counts["partial"] += 1
                else:
                    evidence_counts["none"] += 1
        else:
            active_work = [w for w in work_items if w.get("status") in ["active", "in progress"] or w.get("lifecycle_state") == "active"]
            completed_work = [w for w in work_items if w.get("status") in ["done", "completed"] or w.get("lifecycle_state") == "completed"]
            stable = len(completed_work)
            awaiting_impl = len(active_work)

        human_approval = {
            "pending_reviews": ready_for_review,
            "ready_for_completion": requires_evidence,
            "blocked": 0
        }

        debt_counts = {"duplicate_work": 0, "oversized_work": 0, "runtime_cap_reviews": 0, "missing_lineage": 0}
        for ass in assessments:
            obs = self._parse_observations(ass)
            for k, v in obs.items():
                debt_counts[k] = debt_counts.get(k, 0) + v

        governance_debt = {
            "duplicate_work": debt_counts.get("duplicate_work", 0),
            "oversized_work": debt_counts.get("oversized_work", 0),
            "runtime_cap_reviews": debt_counts.get("runtime_cap_reviews", 0),
            "missing_lineage": debt_counts.get("missing_lineage", 0)
        }

        return {
            "architecture_work": {
                "total": total,
                "stable": stable,
                "ready_for_review": ready_for_review,
                "requires_evidence_verification": requires_evidence,
                "awaiting_implementation": awaiting_impl
            },
            "human_approval": human_approval,
            "governance_debt": governance_debt,
            "implementation_evidence": evidence_counts,
            "adr_distribution": adr_stats,
            "risk_counts": risk_stats,
            "operational": operational
        }

    def get_operational_health(self) -> dict[str, Any]:
        import json

        trace_dir = get_telemetry_root()
        if self.project:
            trace_files = glob.glob(str(trace_dir / f"trace-{self.project}-*.json"))
        else:
            trace_files = glob.glob(str(trace_dir / "trace-*.json"))

        total_tokens = 0
        total_cost = 0.0
        step_metrics = {}

        for tf in trace_files:
            try:
                with open(tf) as f:
                    data = json.load(f)
                    for span in data.get("spans", []):
                        attrs = span.get("attributes", {})
                        tokens = attrs.get("llm.total_tokens", 0)
                        cost = attrs.get("llm.estimated_cost", 0.0)

                        total_tokens += tokens
                        total_cost += cost

                        name = span.get("name", "unknown")
                        if name not in step_metrics:
                            step_metrics[name] = {"cost": 0.0, "tokens": 0, "latency": 0.0, "count": 0}

                        m = step_metrics[name]
                        m["cost"] += cost
                        m["tokens"] += tokens
                        m["count"] += 1

                        start = span.get("start_time")
                        end = span.get("end_time")
                        if start and end:
                            m["latency"] += (end - start)
            except Exception:
                continue

        breakdown = []
        for name, m in step_metrics.items():
            breakdown.append({
                "name": name,
                "avg_cost": round(m["cost"] / m["count"], 4) if m["count"] > 0 else 0,
                "avg_latency": round(m["latency"] / m["count"], 2) if m["count"] > 0 else 0,
                "total_cost": round(m["cost"], 4),
                "count": m["count"]
            })

        return {
            "total_recorded_cost": round(total_cost, 4),
            "total_tokens": total_tokens,
            "trace_count": len(trace_files),
            "step_breakdown": sorted(breakdown, key=lambda x: x["total_cost"], reverse=True)
        }

    def get_recent_evolution(self, limit: int = 5) -> list[dict[str, Any]]:
        work_items = self._load_architecture_work()
        sorted_work = sorted(work_items, key=lambda x: x.get("date", ""), reverse=True)

        items = []
        for item in sorted_work[:limit]:
            if not item.get("summary"):
                sections = item.get("sections", {})
                fallback_keys = ["summary", "problem_statement", "vision_driver", "why_this_matters", "current_state"]
                summary_text = None
                for k in fallback_keys:
                    if sections.get(k):
                        summary_text = sections[k]
                        break

                if not summary_text:
                    details = item.get("details", "")
                    snippet = details.strip().split("\n\n")[0]
                    summary_text = snippet if snippet else "No description available."

                item["summary"] = summary_text

            items.append(item)

        return items

    def get_cross_artifact_insights(self) -> list[dict[str, Any]]:
        insights = []
        metrics = self.get_governance_metrics()

        active_work = (
            metrics["architecture_work"].get("ready_for_review", 0) +
            metrics["architecture_work"].get("requires_evidence_verification", 0) +
            metrics["architecture_work"].get("awaiting_implementation", 0)
        )
        accepted_adrs = metrics["adr_distribution"].get("accepted", 0)

        if active_work > 0 and accepted_adrs == 0:
            insights.append({
                "type": "imbalance",
                "severity": "medium",
                "description": "System has active architecture work but no accepted ADRs to guide implementation."
            })
        elif active_work > accepted_adrs * 2:
            insights.append({
                "type": "velocity",
                "severity": "low",
                "description": f"Architecture work ({active_work}) is outpacing decision ratification ({accepted_adrs})."
            })

        risk_counts = metrics["risk_counts"]
        if risk_counts["high"] > 2:
            insights.append({
                "type": "risk",
                "severity": "high",
                "description": "High concentration of critical governance findings requires immediate attention."
            })

        return insights
