# CAS Runner - Scoped Context

## Overview

The `cas_runner` is the core orchestration engine for CAS. It handles flow execution, LLM reasoning, and knowledge layer interaction.

## Tech Stack
- **Pydantic**: Used for structured output guidance and internal models.
- **jsonschema**: Used for validating LLM responses against schemas in `src/cas_runner/schemas/`.
- **LiteLLM**: (Indirectly via provider) for multi-model support.

## Orchestration Patterns

### Reasoning Contract
The `ReasoningExecutionContract` (in `src/cas_runner/orchestration/reasoning.py`) is the primary interface for steps to interact with the LLM. It:
1. Injects `## RUNTIME INPUT CONTEXT` as JSON.
2. Loads schemas from `src/cas_runner/schemas/`.
3. Handles telemetry and span management.

### Flow Execution
Flows are defined in `src/cas_runner/steps/registry.py` and executed by `FlowRunner` (in `src/cas_runner/runner.py`).

## Conventions

- **Deterministic Prompts**: Prompts in `src/prompts/` should be designed to be idempotent.
- **Initialization**: Always initialize `rule_context` as `[]` in `FlowRunner` to avoid `NoneType` errors.
- **Schema Mapping**: Every step requiring reasoning MUST have a corresponding schema in `src/cas_runner/schemas/`.

## Commands
- **Test Runner Module**: `uv run pytest tests/cas_runner/test_runner.py`
- **Test Orchestration**: `uv run pytest tests/cas_runner/orchestration/`
