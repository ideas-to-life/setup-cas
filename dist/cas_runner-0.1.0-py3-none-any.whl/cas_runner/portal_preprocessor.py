import os
import re
import shutil
from pathlib import Path

import yaml

from cas_runner.io import safe_mkdir


class MetadataExtractor:
    """Extracts metadata from CAS knowledge artifacts."""

    @staticmethod
    def extract_frontmatter(file_path: Path) -> dict:
        """Parses YAML frontmatter from a markdown file."""
        if not file_path.exists():
            return {}

        content = file_path.read_text()
        # Match frontmatter between --- markers (flexible on trailing newline)
        match = re.search(r'^---\s*\n(.*?)\n---\s*(?:\n|$)', content, re.DOTALL)
        if match:
            try:
                data = yaml.safe_load(match.group(1)) or {}
                # Extract title from H1 if not in metadata
                if "title" not in data:
                    h1_match = re.search(r'^# (.*)', content, re.MULTILINE)
                    if h1_match:
                        data["title"] = h1_match.group(1).strip()
                return data
            except yaml.YAMLError:
                return {}
        return {}

    @staticmethod
    def extract_rule_metadata(file_path: Path) -> dict:
        """Extracts and normalizes metadata specifically for Governance Rules."""
        data = MetadataExtractor.extract_frontmatter(file_path)

        # Ensure required fields exist with defaults
        return {
            "id": data.get("id") or file_path.stem,
            "title": data.get("title") or file_path.stem,
            "category": data.get("category", "N/A"),
            "status": data.get("status", "N/A"),
            "compliance": data.get("compliance", {}).get("enabled") if isinstance(data.get("compliance"), dict) else False,
            "summary": data.get("summary", "No summary provided."),
            "path": file_path
        }

class LinkNormalizer:
    """Normalizes relative links to wikilinks for robust portal resolution."""

    def __init__(self, portal_docs_root: Path):
        self.portal_docs_root = portal_docs_root
        self.artifact_map = {} # stem -> relative_path

    def build_artifact_map(self):
        """Builds a map of all markdown files in the portal docs."""
        for p in self.portal_docs_root.glob("**/*.md"):
            if p.name == "index.md":
                continue
            self.artifact_map[p.stem] = p.relative_to(self.portal_docs_root)

    def normalize_content(self, content: str) -> str:
        """Replaces standard relative links with wikilinks for better ezlinks compatibility."""
        # Regex for [text](path)
        # Matches [some text](../relative/path/artifact) or [some text](artifact.md#anchor)
        def replace_link(match):
            text = match.group(1)
            path = match.group(2)

            # If it's an external link, site-absolute, or already a wikilink, ignore
            if path.startswith("http") or path.startswith("mailto") or path.startswith("/") or (path.startswith("[[") and path.endswith("]]")):
                return match.group(0)

            # Split path from anchor
            parts = path.split("#", 1)
            base_path = parts[0]
            anchor = f"#{parts[1]}" if len(parts) > 1 else ""

            # Extract the filename stem
            target_stem = Path(base_path).stem

            if target_stem in self.artifact_map:
                # Use wikilink format: [[stem#anchor|text]]
                if text.lower() == target_stem.lower().replace("-", " "):
                    return f"[[{target_stem}{anchor}]]"
                return f"[[{target_stem}{anchor}|{text}]]"

            return match.group(0)

        # Catch both [text](path) and bare wikilink style pointers in some legacy docs
        normalized = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', replace_link, content)
        return normalized

class LateralLinker:
    """Injects cross-section links into knowledge artifacts."""

    RELATIONSHIP_MAP = {
        "diagram": [
            {"label": "Rules & Constraints", "target": "global/rules/index.md"}
        ],
        "rule": [
            {"label": "Architecture Governance", "target": "global/rules/index.md"}
        ],
        "adr": [
            {"label": "Architecture Evolution Map", "target": "global/maps/index.md"}
        ]
    }

    @staticmethod
    def inject_links(file_path: Path, meta: dict):
        """Appends 'See Also' section if relationships exist for the artifact type."""
        k_type = meta.get("knowledgeType")
        if not k_type or k_type not in LateralLinker.RELATIONSHIP_MAP:
            return

        links = LateralLinker.RELATIONSHIP_MAP[k_type]
        if not links:
            return

        content = file_path.read_text()
        if "## See Also" in content:
            return

        see_also = "\n\n---\n\n## See Also\n"
        for link in links:
            # Calculate the relative path from the current file's parent to the target
            # link['target'] is relative to the docs root (e.g. 'global/rules/index.md')
            # file_path is the absolute path to the generated file in portal/docs/

            # We need the portal/docs root to calculate relpath correctly
            # Assuming standard structure: portal/docs is 2 levels up from src/cas_runner/portal_preprocessor.py
            # But it's safer to pass it or derive it from the file_path if we know it's under portal/docs/

            # For simplicity, since targets are relative to root, we just need to know how many levels up to go.
            # A better way: find 'portal/docs' in the path and get the suffix
            parts = list(file_path.parts)
            try:
                docs_idx = parts.index("docs")
                # Path from docs root to current file
                rel_from_root = Path(*parts[docs_idx+1:])
                # Path from current file's parent back to docs root
                up_levels = "../" * (len(rel_from_root.parts) - 1)
                final_target = f"{up_levels}{link['target']}"

                see_also += f"- [{link['label']}]({final_target})\n"
            except (ValueError, IndexError):
                # Fallback to absolute-looking path if we can't determine depth
                see_also += f"- [{link['label']}](/{link['target']})\n"

        file_path.write_text(content + see_also)

class IndexGenerator:
    """Generates intelligence-driven index.md files for the portal."""

    @staticmethod
    def _format_pattern_proposal_markdown(proposal: dict) -> str:
        """Projects a Pattern Proposal (dict) to Markdown."""
        pattern_id = proposal.get("pattern_id") or "unknown"
        frontmatter = {
            "id": f"proposal-{pattern_id}",
            "knowledgeType": "pattern_proposal",
            "title": f"Pattern Proposal: {proposal.get('name', pattern_id)}",
            "status": proposal.get("decision", {}).get("status", "proposed"),
            "date": proposal.get("decision", {}).get("date") or "N/A"
        }

        content = f"---\n{yaml.dump(frontmatter, sort_keys=False)}---\n\n"
        content += f"# Pattern Proposal: {proposal.get('name', 'N/A')}\n\n"

        content += "## Summary\n"
        content += f"{proposal.get('description', 'N/A')}\n\n"

        content += "## Candidate Pattern\n"
        content += f"- **ID**: `{pattern_id}`\n"
        content += f"- **Classification**: {proposal.get('pattern_classification', 'N/A')}\n"
        content += f"- **Maturity**: {proposal.get('pattern_maturity', 'N/A')}\n"
        content += f"- **Type**: {proposal.get('pattern_type', 'N/A')}\n\n"

        content += "## Observed Signals\n"
        signals = proposal.get("derived_from", {}).get("signals", [])
        if signals:
            for s in signals:
                content += f"- {s}\n"
        else:
            content += "No specific signals listed.\n"
        content += "\n"

        content += "## Evidence\n"
        aw = proposal.get("derived_from", {}).get("architecture_work", [])
        if aw:
            content += "### Architecture Work\n"
            for item in aw:
                content += f"- [[{item}]]\n"

        evidence = proposal.get("derived_from", {}).get("supporting_evidence", [])
        if evidence:
            content += "### Supporting Evidence\n"
            for item in evidence:
                content += f"- [[{item}]]\n"
        content += "\n"

        content += "## Scope Assessment\n"
        content += f"- **Evidence Strength**: {proposal.get('evidence_strength', 'N/A')}\n"
        content += f"- **Confidence**: {proposal.get('confidence', 'N/A')}\n"
        content += f"- **Applies to**: {', '.join(proposal.get('applies_to', [])) if proposal.get('applies_to') else 'N/A'}\n\n"

        content += "## Rationale\n"
        rationale = proposal.get("rationale", [])
        if isinstance(rationale, list):
            for r in rationale:
                content += f"- {r}\n"
        else:
            content += f"{rationale}\n"
        content += "\n"

        content += "## Traceability\n"
        content += "Artifact source: `proposed-patterns`\n"

        return content

    @staticmethod
    def _format_promotion_recommendation_markdown(recommendation: dict) -> str:
        """Projects a Promotion Recommendation (dict) to Markdown."""
        pattern_id = recommendation.get("pattern_id") or "unknown"
        frontmatter = {
            "id": f"recommendation-{pattern_id}",
            "knowledgeType": "promotion_recommendation",
            "title": f"Promotion Recommendation: {pattern_id}",
            "status": recommendation.get("recommendation", "pending")
        }

        content = f"---\n{yaml.dump(frontmatter, sort_keys=False)}---\n\n"
        content += f"# Promotion Recommendation: {pattern_id}\n\n"

        content += "## Recommendation\n"
        content += f"**Action**: {recommendation.get('recommendation', 'N/A')}\n"
        content += f"**Readiness**: {recommendation.get('promotion_readiness', 'N/A')}\n\n"

        content += "## Rationale\n"
        content += f"{recommendation.get('promotion_rationale', 'N/A')}\n\n"

        content += "## Evidence\n"
        evidence = recommendation.get("promotion_evidence", [])
        for e in evidence:
            content += f"- {e.replace('_', ' ').title()}\n"
        content += "\n"

        content += "## Promotion Criteria\n"
        criteria = recommendation.get("promotion_criteria_met", [])
        for c in criteria:
            content += f"- [x] {c.replace('_', ' ').title()}\n"
        content += "\n"

        content += "## Classification Recommendation\n"
        content += f"- **Target Scope**: {recommendation.get('scope_alignment', 'N/A')}\n"
        content += f"- **Evidence Strength**: {recommendation.get('evidence_strength', 'N/A')}\n"
        content += f"- **Confidence**: {recommendation.get('confidence', 'N/A')}\n\n"

        content += "## Traceability\n"
        content += "This recommendation is derived from automated pattern analysis and architect review.\n"

        return content

    @staticmethod
    def _format_promotion_decision_markdown(decision: dict) -> str:
        """Projects a Promotion Decision (dict) to Markdown."""
        pattern_id = decision.get("pattern_id") or "unknown"
        frontmatter = {
            "id": decision.get("id") or f"decision-{pattern_id}",
            "knowledgeType": "promotion_decision",
            "title": f"Promotion Decision: {pattern_id}",
            "project": decision.get("project", "N/A"),
            "date": decision.get("date", "N/A")
        }

        content = f"---\n{yaml.dump(frontmatter, sort_keys=False)}---\n\n"
        content += f"# Promotion Decision: {pattern_id}\n\n"

        dec = decision.get("decision", {})
        content += "## Decision\n"
        content += f"**Status**: {dec.get('status', 'N/A')}\n"
        content += f"**Date**: {dec.get('decision_date', 'N/A')}\n\n"

        content += "## Rationale\n"
        content += f"{decision.get('rationale', {}).get('summary', 'N/A')}\n\n"

        content += "## Evidence Summary\n"
        evidence = decision.get("promotion_evidence", [])
        for e in evidence:
            content += f"- {e.replace('_', ' ').title()}\n"
        content += "\n"

        content += "## Governance Assessment\n"
        content += "### Criteria Met\n"
        for c in decision.get("promotion_criteria_met", []):
            content += f"- [x] {c.replace('_', ' ').title()}\n"

        risks = decision.get("governance_risks", [])
        if risks:
            content += "\n### Governance Risks\n"
            for r in risks:
                content += f"- {r}\n"
        content += "\n"

        content += "## Traceability\n"
        trace = decision.get("source_traceability", {})
        if trace:
            for k, v in trace.items():
                v_id = v.get("id") if isinstance(v, dict) else v
                if v_id:
                    content += f"- **{k.replace('_', ' ').title()}**: [[{v_id}]]\n"

        content += "\n"
        next_step = decision.get("governance", {}).get("next_step")
        if next_step:
            content += f"**Next Step**: {next_step.replace('_', ' ').title()}\n"

        return content

    @staticmethod
    def generate_latest_first_index(items: list, title: str, intro: str = "") -> str:
        """Generates an index that shows the latest artifact content first."""
        if not items:
            return f"# {title}\n\n{intro}\n\n*No artifacts available yet.*\n"

        # Sort by date/filename descending
        sorted_items = sorted(items, key=lambda x: x.get("date") or x["path"].name, reverse=True)
        latest = sorted_items[0]

        # Read latest content
        try:
            latest_content = latest["path"].read_text()
            # Strip existing frontmatter from the embedded view
            latest_content = re.sub(r'^---\s*\n.*?\n---\s*(?:\n|$)', '', latest_content, flags=re.DOTALL)
        except Exception:
            latest_content = f"*Error loading latest artifact: {latest['path'].name}*"

        content = f"# {title}\n\n"
        if intro:
            content += f"{intro}\n\n"

        content += "!!! info \"Latest State\"\n"
        content += f"    Showing latest version: [[{latest['path'].stem}]] ({latest.get('date', 'N/A')})\n\n"

        content += "---\n\n"
        content += latest_content
        content += "\n\n---\n\n"

        if len(sorted_items) > 1:
            content += "## Historical Archive\n\n"
            content += "| Version | Date | Status |\n"
            content += "|---------|------|--------|\n"
            for item in sorted_items:
                content += f"| [[{item['path'].stem}]] | {item.get('date', 'N/A')} | {item.get('status', 'N/A')} |\n"

        return content

    @staticmethod
    def generate_aw_index(items: list, assessment_data: dict = None) -> str:
        """Generates an index for Architecture Work."""
        sections = {
            "In progress": [i for i in items if i.get("status") in ["in progress", "active"] or i.get("lifecycle_state") == "active"],
            "Proposed": [i for i in items if i.get("status") == "proposed" or i.get("lifecycle_state") == "new"],
            "Accepted": [i for i in items if i.get("status") == "accepted"],
            "Rejected": [i for i in items if i.get("status") == "rejected"],
            "Completed": [i for i in items if i.get("status") in ["done", "completed"] or i.get("lifecycle_state") == "completed"],
            "Superseded": [i for i in items if i.get("lifecycle_state") == "superseded"],
        }

        assessments_map = {}
        if assessment_data and "assessments" in assessment_data:
            for ass in assessment_data["assessments"]:
                aw_id = ass.get("aw_id")
                if aw_id:
                    assessments_map[aw_id] = ass

        # Emojis for coverage
        coverage_badges = {
            "Complete": "🟢 Complete",
            "Substantial": "🟡 Substantial",
            "Partial": "🟠 Partial",
            "None": "⚪ None"
        }
        
        # Friendly action mapping
        action_mapping = {
            "Promote to Active": "Review",
            "Promote to Done": "Approve",
            "Verify Implementation Evidence": "Verify Evidence"
        }

        def get_coverage_badge(cov_val: str) -> str:
            if not cov_val:
                return "⚪ None"
            clean = str(cov_val).strip()
            if clean in coverage_badges:
                return coverage_badges[clean]
            for k, v in coverage_badges.items():
                if k.lower() == clean.lower():
                    return v
            return f"⚪ {clean}"

        def get_mapped_action(act_val: str) -> str:
            if not act_val:
                return "N/A"
            clean = str(act_val).strip()
            if clean in action_mapping:
                return action_mapping[clean]
            for k, v in action_mapping.items():
                if k.lower() == clean.lower():
                    return v
            return clean

        def get_change_status(current_st: str, rec_action: str) -> str:
            current = (current_st or "").lower().strip()
            action = (rec_action or "").strip()
            
            if current == "proposed" and action == "Promote to Active":
                return "▲ Ready"
            elif current in ["active", "accepted", "in progress"] and action == "Promote to Done":
                return "▲ Ready"
            elif current == "done" and action == "Remain Done":
                return "✓ Complete & Verified"
            elif current == "done" and action == "Verify Implementation Evidence":
                return "⚠ Review"
            
            return "✓ Complete & Verified"

        content = "# Architecture Work\n\n"
        content += "Architecture Work is the authoritative architectural change backlog. Browse the active evolution below.\n\n"

        for name, sub_items in sections.items():
            if sub_items:
                content += f"## {name}\n\n"
                if assessment_data:
                    content += "| Item | Initiative | Category | Priority | Status | Recommended Status | Recommended Action | Coverage | Change |\n"
                    content += "|------|------------|----------|----------|--------|-------------------|--------------------|----------|--------|\n"
                else:
                    content += "| Item | Initiative | Category | Priority | Status |\n"
                    content += "|------|------------|----------|----------|--------|\n"
                
                # Sort by priority and then status
                sorted_items = sorted(sub_items, key=lambda x: (x.get("priority") != "high", x.get("priority") != "medium", x.get("status", "")))
                for item in sorted_items:
                    title = item.get("title") or item.get("id") or item["path"].stem
                    initiative = item.get("initiative") or "N/A"
                    category = item.get("category") or "N/A"
                    priority = item.get("priority") or "N/A"
                    status = item.get("status") or "N/A"
                    if assessment_data:
                        aw_id = item.get("id") or item["path"].stem
                        ass = assessments_map.get(aw_id, {})
                        rec_status = ass.get("recommended_status") or "N/A"
                        raw_action = ass.get("recommended_action") or "N/A"
                        raw_coverage = ass.get("coverage") or "N/A"
                        
                        rec_action = get_mapped_action(raw_action)
                        coverage = get_coverage_badge(raw_coverage)
                        change = get_change_status(status, raw_action)
                        
                        content += f"| [[{item['path'].stem}|{title}]] | {initiative} | {category} | {priority} | {status} | `{rec_status}` | **{rec_action}** | **{coverage}** | {change} |\n"
                    else:
                        content += f"| [[{item['path'].stem}|{title}]] | {initiative} | {category} | {priority} | {status} |\n"
                content += "\n"

        # Group by Initiative
        initiatives = {}
        for item in items:
            init = item.get("initiative") or "Uncategorized"
            if init not in initiatives:
                initiatives[init] = []
            initiatives[init].append(item)

        if initiatives:
            content += "## By Initiative\n\n"
            for init, sub_items in sorted(initiatives.items()):
                content += f"### {init}\n\n"
                for item in sorted(sub_items, key=lambda x: x["path"].stem):
                    title = item.get("title") or item.get("id") or item["path"].stem
                    content += f"- [[{item['path'].stem}|{title}]]\n"
                content += "\n"

        # Appendix: Governance Observations
        if assessment_data:
            content += "## Appendix: Governance Observations\n\n"
            
            # Oversized Items
            oversized = assessment_data.get("oversized_items")
            if oversized:
                content += "### Oversized Items\n\n"
                content += "| Item | Matched Capabilities | Rationale |\n"
                content += "|------|----------------------|-----------|\n"
                for o in oversized:
                    caps = ", ".join([f"`{c}`" for c in o.get("matched_capabilities", [])])
                    content += f"| {o.get('aw_id')} | {caps} | {o.get('rationale')} |\n"
                content += "\n"

            # Orphan Capabilities
            orphans = assessment_data.get("orphan_capabilities")
            if orphans:
                content += "### Orphan Runtime Capabilities\n\n"
                content += "| Capability ID | Description |\n"
                content += "|---------------|-------------|\n"
                for o in orphans:
                    content += f"| `{o.get('capability_id')}` | {o.get('description', 'N/A')} |\n"
                content += "\n"

            # Obsolete Items
            obsolete = assessment_data.get("obsolete_items")
            if obsolete:
                content += "### Obsolete Items\n\n"
                content += "| Item | Rationale |\n"
                content += "|------|-----------|\n"
                for o in obsolete:
                    content += f"| {o.get('aw_id')} | {o.get('rationale')} |\n"
                content += "\n"

            # Governance Data Quality
            dq = assessment_data.get("governance_data_quality")
            if dq:
                content += "### Governance Data Quality Observations\n\n"
                for key, display_name in [
                    ("missing_titles", "Missing Titles"),
                    ("missing_metadata", "Missing Metadata"),
                    ("missing_lineage", "Missing Lineage"),
                    ("ambiguous_capabilities", "Ambiguous Capabilities"),
                    ("observations", "Other Observations")
                ]:
                    items_list = dq.get(key)
                    if items_list:
                        content += f"#### {display_name}\n"
                        for item_str in items_list:
                            content += f"- {item_str}\n"
                        content += "\n"

        return content

    @staticmethod
    def generate_adr_index(items: list) -> str:
        """Generates an index for ADRs."""
        sections = {
            "Accepted": [i for i in items if i.get("governance", {}).get("forum_status") == "accepted"],
            "Pending Review": [i for i in items if i.get("governance", {}).get("forum_status") == "pending" or i.get("governance", {}).get("forum_status") == "pending"],
            "Rejected": [i for i in items if i.get("decision", {}).get("status") == "rejected" or i.get("governance", {}).get("forum_status") == "rejected"],
            "Other": [i for i in items if i.get("decision", {}).get("status") != "rejected" and i.get("governance", {}).get("forum_status") not in ["accepted", "pending", "rejected"]]
        }

        content = "# Decision Records\n\n"
        content += "The single source of truth for architectural decisions.\n\n"

        if not items:
            content += "*No decision records found yet.*\n"
            return content

        for name, sub_items in sections.items():
            if sub_items:
                content += f"## {name}\n\n"
                content += "| ADR | Date | Decided By | Forum Status |\n"
                content += "|-----|------|------------|--------------|\n"
                for item in sorted(sub_items, key=lambda x: x["path"].stem):
                    title = item.get("title") or item.get("id") or item["path"].stem
                    date = item.get("governance", {}).get("forum_decision_date") or item.get("decision", {}).get("date") or item.get("date") or "N/A"
                    forum_status = item.get("governance", {}).get("forum_status") or "N/A"
                    decided_by = "governance forum" if item.get("governance", {}).get("forum_decision_date") else item.get("decision", {}).get("decided_by") or "N/A"
                    content += f"| [[{item['path'].stem}|{title}]] | {date} | {decided_by} | {forum_status} |\n"
                content += "\n"
        return content

    @staticmethod
    def generate_alignment_index(items: list) -> str:
        """Generates an index for Alignment Reports using latest-first."""
        return IndexGenerator.generate_latest_first_index(
            items,
            "Alignment Reports",
            "Architecture Alignment reports highlight governance concerns and required corrections."
        )

    @staticmethod
    def generate_pattern_index(items: list) -> str:
        """Generates an index for Patterns."""
        content = "# Institutional Patterns\n\n"
        content += "Reusable architectural patterns approved by the Architecture Forum.\n\n"

        if items:
            content += "| Pattern | Classification | Maturity | Confidence |\n"
            content += "|---------|----------------|----------|------------|\n"
            for item in sorted(items, key=lambda x: (x.get("classification") != "core", x.get("title", ""))):
                title = item.get("title") or item.get("id") or item["path"].stem
                classification = item.get("classification") or "N/A"
                maturity = item.get("maturity") or "N/A"
                confidence = item.get("confidence") or "N/A"
                content += f"| [[{item['path'].stem}|{title}]] | {classification} | {maturity} | {confidence} |\n"
        else:
            content += "*No institutional patterns available yet.*\n"
        return content

    @staticmethod
    def generate_signal_index(items: list) -> str:
        """Generates an index for Signals."""
        content = "# Architectural Signals\n\n"
        content += "Observations and signals detected during architectural analysis.\n\n"

        if items:
            content += "| Signal | Type | Strength | Date |\n"
            content += "|--------|------|----------|------|\n"
            for item in sorted(items, key=lambda x: x.get("date") or "", reverse=True):
                title = item.get("title") or item.get("id") or item["path"].stem
                sig_type = item.get("type") or "N/A"
                strength = item.get("strength") or "N/A"
                date = item.get("date") or "N/A"
                content += f"| [[{item['path'].stem}|{title}]] | {sig_type} | {strength} | {date} |\n"
        else:
            content += "*No architectural signals detected yet.*\n"
        return content

    @staticmethod
    def generate_rules_index(items: list) -> str:
        """Generates an index for Governance Rules as a Markdown table."""
        content = "# Rules & Constraints\n\n"
        content += "Active architectural constraints and governance rules.\n\n"

        if items:
            content += "| Rule | Category | Status | Compliance | Summary |\n"
            content += "|------|----------|--------|------------|---------|\n"
            # Sort by category then title
            sorted_items = sorted(items, key=lambda x: (x.get("category", ""), x.get("title", "")))
            for item in sorted_items:
                title = item.get("title") or item.get("id") or item["path"].stem
                category = item.get("category") or "N/A"
                status = item.get("status") or "N/A"
                compliance = "Enabled" if item.get("compliance") else "Disabled"
                summary = item.get("summary") or "No summary provided."
                content += f"| [[{item['path'].stem}|{title}]] | {category} | {status} | {compliance} | {summary} |\n"
        else:
            content += "*No governance rules defined yet.*\n"
        return content

    @staticmethod
    def generate_lifecycle_overview(counts: dict) -> str:
        """Generates a summary of the governance lifecycle state."""
        content = "## Governance Lifecycle\n\n"
        content += "The Continuous Architecture System manages the full lifecycle of architectural knowledge.\n\n"
        content += "| Lifecycle Stage | Artifact Count |\n"
        content += "|-----------------|----------------|\n"
        content += f"| **1. Pattern Proposals** | {counts.get('proposals', 0)} |\n"
        content += f"| **2. Promotion Recommendations** | {counts.get('recommendations', 0)} |\n"
        content += f"| **3. Promotion Decisions** | {counts.get('decisions', 0)} |\n"
        content += f"| **4. ADRs Pending Review** | {counts.get('adrs_pending', 0)} |\n"
        content += f"| **5. ADRs Approved** | {counts.get('adrs_approved', 0)} |\n"
        content += f"| **6. Institutional Patterns** | {counts.get('patterns', 0)} |\n"
        content += "\n"
        return content

def generate_operations_audit_index(trace_items: list, active_project_id: str | None = None, breakdown: list | None = None) -> str:
    """Generates dual-scoped Operations Audit index distinguishing Workspace vs Project traces."""
    content = "# Operations Audit & OTEL History\n\n"
    content += "Historical record of all CAS reasoning, orchestration, and operational execution runs.\n\n"

    if breakdown:
        content += "## Reasoning Economics (Workspace Level)\n\n"
        content += "Aggregate cost and performance metrics per reasoning step.\n\n"
        content += "| Span Name | Total Runs | Avg Cost | Avg Latency (s) | Total Cost |\n"
        content += "|-----------|------------|----------|-----------------|------------|\n"
        for step in breakdown:
            content += f"| `{step['name']}` | {step['count']} | ${step['avg_cost']} | {step['avg_latency']}s | ${step['total_cost']} |\n"
        content += "\n"

    content += "## Workspace Operational Audit\n\n"
    content += "System-wide orchestration traces across the CAS Knowledge Workspace.\n\n"
    content += "| Trace ID | Timestamp | Attributed Project | Steps |\n"
    content += "|----------|-----------|--------------------|-------|\n"
    for item in trace_items:
        t_id = item['id'] if len(item['id']) <= 16 else item['id'][:8]
        content += f"| `{t_id}` | {item['timestamp']} | `{item['project']}` | {item['span_count']} |\n"
    content += "\n"

    if active_project_id:
        content += f"## Project Operational Audit ({active_project_id})\n\n"
        proj_traces = [t for t in trace_items if t.get("project") == active_project_id]
        if proj_traces:
            content += "| Trace ID | Timestamp | Steps |\n"
            content += "|----------|-----------|-------|\n"
            for item in proj_traces:
                t_id = item['id'] if len(item['id']) <= 16 else item['id'][:8]
                content += f"| `{t_id}` | {item['timestamp']} | {item['span_count']} |\n"
        else:
            content += f"!!! info \"No Project Operations Audit Data Available\"\n"
            content += f"    Project `{active_project_id}` has no project-attributed operational execution logs in this workspace.\n"
        content += "\n"

    return content


def generate_project_operations_audit_index(project_id: str, proj_traces: list, breakdown: list | None = None) -> str:
    """Generates project-specific Operations Audit index."""
    content = f"# Operations & Execution Traces: {project_id}\n\n"
    content += f"Historical execution traces and operational metrics for project **{project_id}**.\n\n"

    if breakdown:
        content += "## Reasoning Economics\n\n"
        content += "Cost and performance metrics per reasoning step for this project.\n\n"
        content += "| Span Name | Total Runs | Avg Cost | Avg Latency (s) | Total Cost |\n"
        content += "|-----------|------------|----------|-----------------|------------|\n"
        for step in breakdown:
            content += f"| `{step['name']}` | {step['count']} | ${step['avg_cost']} | {step['avg_latency']}s | ${step['total_cost']} |\n"
        content += "\n"

    content += "## Operational Execution Traces\n\n"
    if proj_traces:
        content += "| Trace ID | Timestamp | Steps |\n"
        content += "|----------|-----------|-------|\n"
        for item in proj_traces:
            t_id = item['id'] if len(item['id']) <= 16 else item['id'][:8]
            content += f"| `{t_id}` | {item['timestamp']} | {item['span_count']} |\n"
    else:
        content += f"!!! info \"No Project Execution Traces\"\n"
        content += f"    Project `{project_id}` has no project-attributed operational execution logs recorded yet.\n"

    return content


def generate_project_home_landing(project_id: str, display_name: str | None = None) -> str:
    """Generates project-specific landing page containing project Governance Health Dashboard & Governance Metrics."""
    disp = display_name or project_id
    from cas_runner.dashboard.routes import generate_dashboard_markdown
    from cas_runner.tasks.portal.models import OnboardedProject
    from cas_runner.tasks.portal.project_context import ProjectContextResolver, resolve_project_metric_context
    from cas_runner.tasks.portal.evidence_processor import render_project_evidence_matrix_table

    dash_content = generate_dashboard_markdown(project=project_id, is_project_page=True)

    proj = OnboardedProject(project_id=project_id, display_name=disp, status="active", base_path=f"projects/{project_id}")
    resolver = ProjectContextResolver([proj])
    resolver.set_active_project(project_id)
    proj_ctx = resolve_project_metric_context(resolver)
    matrix_table = render_project_evidence_matrix_table(proj_ctx, is_project_landing=True)

    content = f"# Project Context: {disp}\n\n"
    content += f"Welcome to the architecture and governance portal context for **{disp}** (`{project_id}`).\n\n"
    content += "## Product Discovery Evidence & Metrics Matrix\n\n"
    content += matrix_table + "\n\n"
    content += "---\n\n"
    content += dash_content + "\n\n"
    content += "---\n\n"
    content += "## Project Scope Navigation\n\n"
    content += f"- [Architecture State & Evolution Maps](state/index.md)\n"
    content += f"- [Architecture Intent Documents (AID)](intent/index.md)\n"
    content += f"- [Architecture Work (AW)](work/index.md)\n"
    content += f"- [Alignment Reports](alignment/index.md)\n"
    content += f"- [Architecture Decision Records (ADR)](adrs/index.md)\n"
    content += f"- [Operational Execution Traces](traces/index.md)\n"
    content += f"- [Signals](signals/index.md)\n"
    content += f"- [Diagrams](diagrams/index.md)\n\n"

    return content


def generate_workspace_home_landing(context, lifecycle_summary: str = "", narrative_content: str = "") -> str:
    """Generates a true workspace-level home overview with aggregate project directory, Product Hypotheses & Evidence, Candidate Metrics Matrix, and Governance Health Dashboard + Metrics."""
    from cas_runner.dashboard.routes import generate_dashboard_markdown
    from cas_runner.tasks.portal.workspace_discovery import aggregate_workspace_metrics
    from cas_runner.tasks.portal.evidence_processor import (
        render_workspace_governance_dashboard_table,
        format_evidence_domain_view,
        render_evidence_table,
    )
    from cas_runner.tasks.portal.project_context import ProjectContextResolver, resolve_project_metric_context

    active_pid = getattr(context, "active_project_id", None)
    dash_content = generate_dashboard_markdown(project=active_pid)

    proj_contexts = []
    for p in context.projects:
        r = ProjectContextResolver(context.projects)
        r.set_active_project(p.project_id)
        proj_contexts.append(resolve_project_metric_context(r))

    workspace_aggregates = aggregate_workspace_metrics(context.workspace_id, context.projects, proj_contexts)
    ws_metrics_table = render_workspace_governance_dashboard_table(workspace_aggregates)

    content = "# CAS Knowledge Workspace\n\n"
    content += "Welcome to the Continuous Architecture System (CAS) Knowledge Workspace.\n\n"
    content += f"- **Workspace ID**: `{context.workspace_id}`\n"
    content += f"- **Onboarded Projects**: {len(context.projects)}\n"
    if hasattr(context, "product_discovery") and hasattr(context.product_discovery, "evidence_nodes"):
        content += f"- **Product Discovery Evidence Nodes**: {len(context.product_discovery.evidence_nodes)}\n"
    if hasattr(context, "cross_project_insights"):
        content += f"- **Cross-Project Insights**: {len(context.cross_project_insights)}\n"
    content += "\n"

    content += "## Workspace Governance Metrics Aggregates\n\n"
    content += ws_metrics_table + "\n\n"

    if hasattr(context, "product_discovery") and hasattr(context.product_discovery, "evidence_nodes"):
        content += "## Product Hypotheses & Evidence\n\n"
        content += format_evidence_domain_view(context.product_discovery.evidence_nodes) + "\n\n"

        content += "## Product Discovery Candidate Metrics Matrix\n\n"
        content += render_evidence_table(context.product_discovery.evidence_nodes) + "\n\n"

    content += "## Onboarded Projects\n\n"
    if context.projects:
        content += "| Project Identity | Status | Context Link |\n"
        content += "|-------------------|--------|--------------|\n"
        for proj in context.projects:
            content += f"| **{proj.display_name}** (`{proj.project_id}`) | `{proj.status}` | [Enter Project Context](projects/{proj.project_id}/index.md) |\n"
    else:
        content += "*No onboarded projects found in workspace.*\n"

    content += "\n---\n\n" + dash_content

    if lifecycle_summary:
        content += "\n\n---\n\n" + lifecycle_summary

    return content



def prepare_portal_docs(knowledge_root: str, portal_docs_root: str):

    """
    Prepares the portal/docs directory by copying and restructuring knowledge artifacts.
    """
    workspace_path = Path(knowledge_root)
    portal_docs_path = Path(portal_docs_root)

    # 1. Clean portal_docs_root
    if portal_docs_path.exists():
        shutil.rmtree(portal_docs_path)
    safe_mkdir(portal_docs_path, parents=True, exist_ok=True)

    print(f"[Portal] Processing knowledge from {workspace_path} to {portal_docs_path}")

    # 2. Copy relevant directories
    dirs_to_copy = ["global", "projects", "runtime"]
    for d in dirs_to_copy:
        src = workspace_path / d
        if src.exists():
            dst = portal_docs_path / d
            # Ignore ingestion directories as they contain massive raw files that hang MkDocs builds
            shutil.copytree(src, dst, dirs_exist_ok=True, ignore=shutil.ignore_patterns("ingestion"))
            print(f"[Portal] Copied {d}")

    # Copy static assets (CSS/JS)
    static_src = Path(__file__).parent.parent.parent / "static"
    if static_src.exists():
        static_dst = portal_docs_path / "static"
        shutil.copytree(static_src, static_dst, dirs_exist_ok=True)
        print("[Portal] Copied static assets")

    # 3. Intelligence Data Extraction
    extractor = MetadataExtractor()
    generator = IndexGenerator()

    # Process ADR
    adr_paths = list(portal_docs_path.glob("global/decisions/*.md")) + list(portal_docs_path.glob("projects/*/adrs/*.md"))
    adr_items = []
    for p in adr_paths:
        if p.name == "index.md": continue
        meta = extractor.extract_frontmatter(p)
        meta["path"] = p
        adr_items.append(meta)

    # Global Decisions Index
    global_adr_items = [i for i in adr_items if "global/decisions" in str(i["path"])]
    if global_adr_items:
        (portal_docs_path / "global" / "decisions" / "index.md").write_text(generator.generate_adr_index(global_adr_items))

    # Project-specific ADR indices
    for project_dir in (portal_docs_path / "projects").iterdir():
        if project_dir.is_dir() and (project_dir / "adrs").exists():
            proj_adrs = [i for i in adr_items if str(project_dir / "adrs") in str(i["path"])]
            if proj_adrs:
                (project_dir / "adrs" / "index.md").write_text(generator.generate_adr_index(proj_adrs))

    # Master ADR Review Queue (All projects + Global)
    if adr_items:
        target_path = portal_docs_path / "governance" / "adrs" / "index.md"
        safe_mkdir(target_path.parent, parents=True, exist_ok=True)
        target_path.write_text(generator.generate_adr_index(adr_items))

    # Process Patterns
    pattern_paths = list(portal_docs_path.glob("global/patterns/*.md")) + list(portal_docs_path.glob("projects/*/patterns/*.md"))
    pattern_items = []
    for p in pattern_paths:
        if p.name == "index.md": continue
        meta = extractor.extract_frontmatter(p)
        meta["path"] = p
        pattern_items.append(meta)

    # Global Patterns Index
    global_pattern_items = [i for i in pattern_items if "global/patterns" in str(i["path"])]
    if global_pattern_items:
        (portal_docs_path / "global" / "patterns" / "index.md").write_text(generator.generate_pattern_index(global_pattern_items))

    # Project-specific Pattern indices
    for project_dir in (portal_docs_path / "projects").iterdir():
        if project_dir.is_dir() and (project_dir / "patterns").exists():
            proj_patterns = [i for i in pattern_items if str(project_dir / "patterns") in str(i["path"])]
            if proj_patterns:
                (project_dir / "patterns" / "index.md").write_text(generator.generate_pattern_index(proj_patterns))

    # Master Institutional Patterns Index
    if pattern_items:
        target_path = portal_docs_path / "governance" / "patterns" / "index.md"
        safe_mkdir(target_path.parent, parents=True, exist_ok=True)
        target_path.write_text(generator.generate_pattern_index(pattern_items))

    # Process Signals
    signal_paths = list(portal_docs_path.glob("global/signals/*.md")) + list(portal_docs_path.glob("projects/*/signals/*.md"))
    signal_items = []
    for p in signal_paths:
        if p.name == "index.md": continue
        meta = extractor.extract_frontmatter(p)
        meta["path"] = p
        signal_items.append(meta)

    if signal_items:
        # Global Signals Index
        global_signal_items = [i for i in signal_items if "global/signals" in str(i["path"])]
        if global_signal_items:
            (portal_docs_path / "global" / "signals" / "index.md").write_text(generator.generate_signal_index(global_signal_items))

        # Project-specific Signals
        for project_dir in (portal_docs_path / "projects").iterdir():
            if project_dir.is_dir() and (project_dir / "signals").exists():
                proj_signals = [i for i in signal_items if str(project_dir / "signals") in str(i["path"])]
                if proj_signals:
                    (project_dir / "signals" / "index.md").write_text(generator.generate_signal_index(proj_signals))

    # Process Rules
    rule_paths = list(portal_docs_path.glob("global/rules/*.md")) + list(portal_docs_path.glob("projects/*/rules/*.md"))
    rule_items = []
    for p in rule_paths:
        if p.name == "index.md": continue
        meta = extractor.extract_rule_metadata(p)
        rule_items.append(meta)

    if rule_items:
        # Global Rules Index
        global_rule_items = [i for i in rule_items if "global/rules" in str(i["path"])]
        if global_rule_items:
            (portal_docs_path / "global" / "rules" / "index.md").write_text(generator.generate_rules_index(global_rule_items))

        # Project-specific Rules
        for project_dir in (portal_docs_path / "projects").iterdir():
            if project_dir.is_dir() and (project_dir / "rules").exists():
                proj_rules = [i for i in rule_items if str(project_dir / "rules") in str(i["path"])]
                if proj_rules:
                    (project_dir / "rules" / "index.md").write_text(generator.generate_rules_index(proj_rules))

    # Process Maps (AEM) - Latest First
    aem_paths = list(portal_docs_path.glob("global/maps/*.md")) + list(portal_docs_path.glob("projects/*/maps/*.md"))
    aem_items = []
    for p in aem_paths:
        if p.name == "index.md": continue
        meta = extractor.extract_frontmatter(p)
        meta["path"] = p
        aem_items.append(meta)

    # Global Maps Index
    global_aem_items = [i for i in aem_items if "global/maps" in str(i["path"])]
    global_maps_dir = portal_docs_path / "global" / "maps"
    safe_mkdir(global_maps_dir, parents=True, exist_ok=True)
    if global_aem_items:
        (global_maps_dir / "index.md").write_text(generator.generate_latest_first_index(global_aem_items, "Architecture Evolution Maps"))

    # Process AW
    aw_paths = list(portal_docs_path.glob("projects/*/work/*.md"))
    aw_items = []
    for p in aw_paths:
        if p.name == "index.md": continue
        meta = extractor.extract_frontmatter(p)
        meta["path"] = p
        aw_items.append(meta)

    # Handle project-specific AW
    for project_dir in (portal_docs_path / "projects").iterdir():
        if project_dir.is_dir() and (project_dir / "work").exists():
            proj_aw = [i for i in aw_items if str(i["path"]).startswith(str(project_dir / "work"))]
            if proj_aw:
                assessment_data = None
                assessment_file = project_dir / "assessment" / "aw_assessment.json"
                if assessment_file.exists():
                    try:
                        import json
                        with open(assessment_file, "r") as f:
                            assessment_data = json.load(f)
                    except Exception as e:
                        print(f"[Portal] Warning: Failed to load assessment data from {assessment_file}: {e}")
                
                (project_dir / "work" / "index.md").write_text(generator.generate_aw_index(proj_aw, assessment_data))

    # Process Alignment
    alignment_paths = list(portal_docs_path.glob("projects/*/alignment/*.md"))
    alignment_items = []
    for p in alignment_paths:
        if p.name == "index.md": continue
        meta = extractor.extract_frontmatter(p)
        meta["path"] = p
        alignment_items.append(meta)

    for project_dir in (portal_docs_path / "projects").iterdir():
        if project_dir.is_dir() and (project_dir / "alignment").exists():
            proj_alignment = [i for i in alignment_items if str(i["path"]).startswith(str(project_dir / "alignment"))]
            if proj_alignment:
                (project_dir / "alignment" / "index.md").write_text(generator.generate_alignment_index(proj_alignment))

    # Process Intent (AID) - Latest First
    aid_paths = list(portal_docs_path.glob("projects/*/intent/*.md"))
    aid_items = []
    for p in aid_paths:
        if p.name == "index.md": continue
        meta = extractor.extract_frontmatter(p)
        meta["path"] = p
        aid_items.append(meta)

    for project_dir in (portal_docs_path / "projects").iterdir():
        if project_dir.is_dir() and (project_dir / "intent").exists():
            proj_aid = [i for i in aid_items if str(i["path"]).startswith(str(project_dir / "intent"))]
            if proj_aid:
                (project_dir / "intent" / "index.md").write_text(generator.generate_latest_first_index(proj_aid, "Architecture Intent Documents"))

    # Process Vision - Latest First
    vision_paths = list(portal_docs_path.glob("projects/*/vision/*.md"))
    vision_items = []
    for p in vision_paths:
        if p.name == "index.md": continue
        meta = extractor.extract_frontmatter(p)
        meta["path"] = p
        vision_items.append(meta)

    for project_dir in (portal_docs_path / "projects").iterdir():
        if project_dir.is_dir() and (project_dir / "vision").exists():
            proj_vision = [i for i in vision_items if str(i["path"]).startswith(str(project_dir / "vision"))]
            if proj_vision:
                (project_dir / "vision" / "index.md").write_text(generator.generate_latest_first_index(proj_vision, "Vision & Strategy"))

    # Process State - Latest First
    state_paths = list(portal_docs_path.glob("projects/*/state/*.md"))
    state_items = []
    for p in state_paths:
        if p.name == "index.md": continue
        meta = extractor.extract_frontmatter(p)
        meta["path"] = p
        state_items.append(meta)

    for project_dir in (portal_docs_path / "projects").iterdir():
        if project_dir.is_dir() and (project_dir / "state").exists():
            proj_state = [i for i in state_items if str(i["path"]).startswith(str(project_dir / "state"))]
            if proj_state:
                (project_dir / "state" / "index.md").write_text(generator.generate_latest_first_index(proj_state, "Current Architecture State"))

    # Process Diagrams - Hero Promotion
    for project_dir in (portal_docs_path / "projects").iterdir():
        if project_dir.is_dir() and (project_dir / "diagrams").exists():
            diag_dir = project_dir / "diagrams"
            hero_candidates = ["cas-why-what-who-how.md"]
            hero_path = None
            for cand in hero_candidates:
                if (diag_dir / cand).exists():
                    hero_path = diag_dir / cand
                    break

            if hero_path:
                index_path = diag_dir / "index.md"
                hero_content = hero_path.read_text()
                hero_meta = extractor.extract_frontmatter(hero_path)

                # Strip frontmatter but keep the content
                hero_body = re.sub(r'^---\s*\n.*?\n---\s*(?:\n|$)', '', hero_content, flags=re.DOTALL)

                # If hero_body starts with an H1 that is the same as the meta title,
                # keep it as the primary title for the page.

                other_diags = []
                for p in sorted(diag_dir.glob("*.md")):
                    if p.name in ["index.md", hero_path.name]: continue
                    meta = extractor.extract_frontmatter(p)
                    title = meta.get("title") or p.stem
                    other_diags.append(f"- [[{p.stem}|{title}]]")

                with open(index_path, "w") as f:
                    # Preserve metadata so LateralLinker knows this is a diagram index
                    if hero_meta:
                        f.write(f"---\n{yaml.dump(hero_meta, sort_keys=False)}---\n\n")
                    f.write(hero_body)
                    if other_diags:
                        f.write("\n\n---\n\n## More Diagrams\n\n")
                        f.write("\n".join(other_diags))
                print(f"[Portal] Promoted {hero_path.name} to {index_path.relative_to(portal_docs_path)}")

    # --- Trace History (Runtime) ---
    trace_files = list(portal_docs_path.glob("runtime/traces/*.json"))
    trace_items = []
    if trace_files:
        for tf in trace_files:

            try:
                import json
                with open(tf) as f:
                    data = json.load(f)
                    trace_items.append({
                        "id": data.get("trace_id", tf.stem),
                        "timestamp": data.get("timestamp", "N/A"),
                        "project": data.get("project", "N/A"),
                        "span_count": len(data.get("spans", []))
                    })
            except Exception:
                continue

        # Sort by timestamp descending
        trace_items = sorted(trace_items, key=lambda x: x["timestamp"], reverse=True)

        # Fetch operational health for the breakdown
        from cas_runner.dashboard.data_access import DashboardDataAccess
        from cas_runner.io import resolve_target_project_context
        ctx = resolve_target_project_context()
        da = DashboardDataAccess(ctx.project_id)
        op_health = da.get_operational_health()
        breakdown = op_health.get("step_breakdown", [])

        trace_index_md = generate_operations_audit_index(trace_items, active_project_id=None, breakdown=breakdown)
        (portal_docs_path / "runtime" / "traces" / "index.md").write_text(trace_index_md)


    # --- Governance Lifecycle Data ---

    # 1. Pattern Proposals
    proposal_items = []
    proposal_files = list(workspace_path.glob("projects/*/proposed-patterns/*.yaml")) + \
                     list(workspace_path.glob("projects/*/proposed-patterns/*.json"))

    for pf in proposal_files:
        try:
            with open(pf) as f:
                if pf.suffix == ".json":
                    import json
                    data = json.load(f)
                else:
                    data = yaml.safe_load(f) or {}

                items = data.get("pattern_proposals", []) if isinstance(data, dict) else data
                if isinstance(items, list):
                    for item in items:
                        # Project to Markdown
                        md_content = generator._format_pattern_proposal_markdown(item)
                        pattern_id = item.get("pattern_id", "unknown")
                        target_path = portal_docs_path / "governance" / "proposals" / f"proposal-{pattern_id}.md"
                        safe_mkdir(target_path.parent, parents=True, exist_ok=True)
                        target_path.write_text(md_content)

                        # Track for index
                        item["path"] = target_path
                        proposal_items.append(item)
        except Exception as e:
            print(f"[Portal][WARN] Failed to project proposal {pf}: {e}")

    # Generate Proposals Index
    if proposal_items:
        index_content = "# Pattern Proposals\n\n"
        index_content += "Proposed patterns undergoing initial classification and assessment.\n\n"
        index_content += "| Proposal | Classification | Status |\n"
        index_content += "|----------|----------------|--------|\n"
        for item in sorted(proposal_items, key=lambda x: x.get("pattern_id", "")):
            title = item.get("name") or item.get("pattern_id")
            index_content += f"| [[{item['path'].stem}|{title}]] | {item.get('pattern_classification', 'N/A')} | {item.get('decision', {}).get('status', 'proposed')} |\n"
        (portal_docs_path / "governance" / "proposals" / "index.md").write_text(index_content)

    # 2. Promotion Recommendations
    recommendation_items = []
    rec_files = list(workspace_path.glob("projects/*/governance/pattern-promotion-recommendations.yaml"))
    for rf in rec_files:
        try:
            with open(rf) as f:
                data = yaml.safe_load(f) or {}
                items = data.get("recommendations", []) or data.get("promotion_candidates", [])
                if isinstance(items, list):
                    for item in items:
                        # Project to Markdown
                        md_content = generator._format_promotion_recommendation_markdown(item)
                        pattern_id = item.get("pattern_id", "unknown")
                        target_path = portal_docs_path / "governance" / "recommendations" / f"recommendation-{pattern_id}.md"
                        safe_mkdir(target_path.parent, parents=True, exist_ok=True)
                        target_path.write_text(md_content)

                        # Track for index
                        item["path"] = target_path
                        recommendation_items.append(item)
        except Exception as e:
            print(f"[Portal][WARN] Failed to project recommendation {rf}: {e}")

    # Generate Recommendations Index
    if recommendation_items:
        index_content = "# Promotion Recommendations\n\n"
        index_content += "Patterns recommended for promotion to global or project institutionalization.\n\n"
        index_content += "| Recommendation | Classification | Readiness |\n"
        index_content += "|----------------|----------------|-----------|\n"
        for item in sorted(recommendation_items, key=lambda x: x.get("pattern_id", "")):
            title = f"Rec: {item.get('pattern_id')}"
            index_content += f"| [[{item['path'].stem}|{title}]] | {item.get('scope_alignment', 'N/A')} | {item.get('promotion_readiness', 'N/A')} |\n"
        (portal_docs_path / "governance" / "recommendations" / "index.md").write_text(index_content)

    # 3. Promotion Decisions
    decision_items = []
    decision_files = list(workspace_path.glob("projects/*/governance/promotion-decisions/*.yaml"))
    for df in decision_files:
        try:
            with open(df) as f:
                data = yaml.safe_load(f) or {}
                # Project to Markdown
                md_content = generator._format_promotion_decision_markdown(data)
                pattern_id = data.get("pattern_id", "unknown")
                target_path = portal_docs_path / "governance" / "decisions" / f"decision-{pattern_id}.md"
                safe_mkdir(target_path.parent, parents=True, exist_ok=True)
                target_path.write_text(md_content)

                # Track for index
                data["path"] = target_path
                decision_items.append(data)
        except Exception as e:
            print(f"[Portal][WARN] Failed to project decision {df}: {e}")

    # Generate Decisions Index
    if decision_items:
        index_content = "# Promotion Decisions\n\n"
        index_content += "Formal decisions on pattern promotion and institutionalization.\n\n"
        index_content += "| Decision | Status | Date |\n"
        index_content += "|----------|--------|------|\n"
        for item in sorted(decision_items, key=lambda x: x.get("pattern_id", "")):
            title = f"Decision: {item.get('pattern_id')}"
            index_content += f"| [[{item['path'].stem}|{title}]] | {item.get('decision', {}).get('status', 'N/A')} | {item.get('date', 'N/A')} |\n"
        (portal_docs_path / "governance" / "decisions" / "index.md").write_text(index_content)

    # 4. ADRs (AGGREGATED)
    adrs_pending = len([i for i in adr_items if i.get("decision", {}).get("status") == "pending" or i.get("governance", {}).get("forum_status") == "pending"])
    adrs_approved = len([i for i in adr_items if i.get("decision", {}).get("status") == "accepted" or i.get("governance", {}).get("forum_status") == "accepted"])

    # Handle landing page (index.md)
    from cas_runner.tasks.portal.preprocessor import PortalPreprocessor
    portal_task = PortalPreprocessor(workspace_path, portal_docs_path)
    discovery_context = portal_task.run_discovery()

    # Lifecycle summary
    counts = {
        "proposals": len(proposal_items),
        "recommendations": len(recommendation_items),
        "decisions": len(decision_items),
        "adrs_pending": adrs_pending,
        "adrs_approved": adrs_approved,
        "patterns": len(pattern_items),
        "signals": len(signal_items),
        "aw": len(aw_items)
    }
    lifecycle_summary = generator.generate_lifecycle_overview(counts)

    # Generate About section (Feature 074)
    about_dir = portal_docs_path / "about"
    safe_mkdir(about_dir, parents=True, exist_ok=True)

    landing_page = workspace_path / "global" / "narratives" / "cas.md"
    narrative_content = ""
    if landing_page.exists():
        narrative_content = landing_page.read_text(encoding="utf-8")

    about_index = "# What is CAS?\n\n"
    about_index += "The **Continuous Architecture System (CAS)** is a governed, decision-driven knowledge system designed to transform architecture from static documentation into a continuously updated and queryable operational asset.\n\n"
    about_index += "## Core Rationale & Navigation\n\n"
    about_index += "- **[Why CAS?](why-cas.md)**: Rationale, traditional architecture governance challenges, and Shift-Left Governance.\n"
    about_index += "- **[How CAS Works](how-cas-works.md)**: Operating loop (`Prevent → Architecture Workflow → Detect & Correct`).\n"
    about_index += "- **[Operating Model](operating-model.md)**: Core concepts (ADR, AEM, AID, AW).\n"
    about_index += "- **[Platform Documentation](platform-docs/index.md)**: Detailed technical platform documentation.\n"

    (about_dir / "index.md").write_text(about_index, encoding="utf-8")

    why_cas_content = "# Why CAS?\n\n"
    if narrative_content:
        why_cas_content += re.sub(r'^# .*\n', '', narrative_content)
    else:
        why_cas_content += "CAS addresses the breakdown of traditional architecture governance in modern software delivery.\n"

    (about_dir / "why-cas.md").write_text(why_cas_content, encoding="utf-8")

    how_cas_works_content = "# How CAS Works\n\n"
    how_cas_works_content += "CAS operates as a dual-control governance loop:\n\n"
    how_cas_works_content += "1. **Prevent**: CAS Agent Skills enforce architectural constraints directly during coding and refactoring.\n"
    how_cas_works_content += "2. **Architecture Workflow**: Governed flows generate Architecture Work (AW), Architecture Evolution Maps (AEM), and Intent Documents (AID).\n"
    how_cas_works_content += "3. **Detect & Correct**: Alignment Engine flags architectural drift and provides actionable remediation.\n"

    (about_dir / "how-cas-works.md").write_text(how_cas_works_content, encoding="utf-8")

    operating_model_content = "# CAS Architecture & Operating Model\n\n"
    operating_model_content += "CAS is built on decision-driven governance where the ADR (Architecture Decision Record) is the authoritative Single Source of Truth (SSOT).\n\n"
    operating_model_content += "- **ADR**: Single Source of Truth for architecture decisions.\n"
    operating_model_content += "- **AEM**: System state derived directly from decisions.\n"
    operating_model_content += "- **AID**: Architectural intent and strategic direction.\n"
    operating_model_content += "- **AW**: Authoritative architectural change backlog.\n"

    (about_dir / "operating-model.md").write_text(operating_model_content, encoding="utf-8")

    # Reposition Platform Documentation under about/platform-docs/
    platform_docs_dir = about_dir / "platform-docs"
    safe_mkdir(platform_docs_dir, parents=True, exist_ok=True)
    narratives_src = workspace_path / "global" / "narratives"
    if narratives_src.exists():
        for f in narratives_src.glob("*.md"):
            shutil.copy(f, platform_docs_dir / f.name)

    workspace_home_content = generate_workspace_home_landing(discovery_context, lifecycle_summary)

    with open(portal_docs_path / "index.md", "w", encoding="utf-8") as f:
        f.write(workspace_home_content)

    print("[Portal] Generated workspace home landing page and About section.")


    # 5. Lateral Linking Pass
    for p in portal_docs_path.glob("**/*.md"):
        meta = extractor.extract_frontmatter(p)
        LateralLinker.inject_links(p, meta)

    # Link Normalization Pass
    normalizer = LinkNormalizer(portal_docs_path)
    normalizer.build_artifact_map()

    print(f"[Portal] Normalizing links across {len(normalizer.artifact_map)} artifacts...")
    for p in portal_docs_path.glob("**/*.md"):
        content = p.read_text()
        normalized = normalizer.normalize_content(content)
        if content != normalized:
            p.write_text(normalized)

    # Rename README.md to index.md in all copied directories for consistency
    # DO NOT rename if index.md already exists (avoid conflicts with generated indices)
    for root, dirs, files in os.walk(portal_docs_path):
        if "README.md" in files:
            readme_path = Path(root) / "README.md"
            index_path = Path(root) / "index.md"
            if not index_path.exists():
                readme_path.rename(index_path)
                print(f"[Portal] Renamed {readme_path.relative_to(portal_docs_path)} to index.md")
            else:
                # If index.md exists, README.md is redundant or conflicting
                readme_path.unlink()
                print(f"[Portal] Removed redundant README.md in {Path(root).relative_to(portal_docs_path)}")

    # 4. Fallback for other directories (generic index)
    for root, dirs, files in os.walk(portal_docs_path):
        root_path = Path(root)
        # Skip static asset directories (CSS/JS)
        if "static" in root_path.parts:
            continue
        if not (root_path / "index.md").exists():
            md_files = [f for f in files if f.endswith(".md") and f != "index.md"]
            with open(root_path / "index.md", "w") as f:
                title = root_path.name.replace("-", " ").title()
                f.write(f"# {title}\n\n")
                if md_files:
                    f.write("## Documents\n\n")
                    for md in sorted(md_files):
                        f.write(f"- [[{Path(md).stem}]]\n")
                if dirs:
                    f.write("\n## Categories\n\n")
                    for d in sorted(dirs):
                        f.write(f"- [{d.replace('-', ' ').title()}]({d}/index.md)\n")
                if not md_files and not dirs:
                    f.write("*No content available in this section yet.*\n")


    # --- Workspace & Multi-Project Evidence Model Integration (Feature 070) ---
    try:
        from cas_runner.tasks.portal.preprocessor import PortalPreprocessor
        from cas_runner.tasks.portal.evidence_processor import (
            format_evidence_domain_view,
            render_evidence_table,
            build_evidence_chain_for_metric,
            render_metric_detail_view,
        )
        from cas_runner.tasks.portal.project_context import (
            ProjectContextResolver,
            resolve_project_metric_context,
        )
        from cas_runner.tasks.portal.workspace_discovery import render_cross_project_insights_view

        portal_task = PortalPreprocessor(workspace_path, portal_docs_path)
        context = portal_task.run_discovery()

        # 1. Generate Projects Hub (portal/docs/projects/index.md) and Individual Project Context Pages
        projects_hub_path = portal_docs_path / "projects" / "index.md"
        safe_mkdir(projects_hub_path.parent, parents=True, exist_ok=True)
        projects_hub_path.write_text(portal_task.generate_projects_hub(), encoding="utf-8")

        from cas_runner.tasks.portal.project_context import render_missing_artefact_notice
        for proj in context.projects:
            pid = proj.project_id
            proj_dir = portal_docs_path / "projects" / pid
            safe_mkdir(proj_dir, parents=True, exist_ok=True)

            # Generate Project Landing Page with Project-Specific Governance Health Dashboard & Metrics
            proj_landing = generate_project_home_landing(pid, proj.display_name)
            (proj_dir / "index.md").write_text(proj_landing, encoding="utf-8")

            # Ensure project sub-directories exist and have index.md (rendering missing artefact notice if empty)
            sub_sections = ["state", "intent", "vision", "work", "alignment", "adrs", "traces", "signals", "diagrams", "evidence"]
            for sub in sub_sections:
                sub_dir = proj_dir / sub
                safe_mkdir(sub_dir, parents=True, exist_ok=True)
                sub_files = [f for f in sub_dir.glob("*.md") if f.name != "index.md"]
                if not sub_files and not (sub_dir / "index.md").exists():
                    (sub_dir / "index.md").write_text(render_missing_artefact_notice(pid, sub), encoding="utf-8")

            # Project-specific ADR index
            proj_adrs = [i for i in adr_items if f"projects/{pid}/" in str(i["path"]).replace("\\", "/")]
            if proj_adrs:
                (proj_dir / "adrs" / "index.md").write_text(generator.generate_adr_index(proj_adrs), encoding="utf-8")

            # Project-specific Operational Execution Traces index
            p_traces = [t for t in trace_items if t.get("project") == pid]
            try:
                from cas_runner.dashboard.data_access import DashboardDataAccess
                p_da = DashboardDataAccess(pid)
                p_op = p_da.get_operational_health()
                p_bd = p_op.get("step_breakdown", [])
            except Exception:
                p_bd = []
            p_trace_md = generate_project_operations_audit_index(pid, p_traces, p_bd)
            (proj_dir / "traces" / "index.md").write_text(p_trace_md, encoding="utf-8")

            # Project-specific Product Discovery Evidence index and detail pages
            p_evidence_dir = proj_dir / "evidence"
            p_metrics_dir = p_evidence_dir / "metrics"
            safe_mkdir(p_evidence_dir, parents=True, exist_ok=True)
            safe_mkdir(p_metrics_dir, parents=True, exist_ok=True)
            try:
                from cas_runner.tasks.portal.evidence_processor import (
                    render_project_evidence_matrix_table,
                    render_metric_detail_view,
                    build_evidence_chain_for_metric,
                )
                p_resolver = ProjectContextResolver(context.projects)
                p_resolver.set_active_project(pid)
                p_metric_ctx = resolve_project_metric_context(p_resolver)

                p_evidence_md = f"# Product Discovery Evidence: {proj.display_name}\n\n"
                p_evidence_md += f"Project-scoped product discovery evidence metrics and hypotheses for **{proj.display_name}** (`{pid}`).\n\n"
                p_evidence_md += render_project_evidence_matrix_table(p_metric_ctx)
                (p_evidence_dir / "index.md").write_text(p_evidence_md, encoding="utf-8")

                for pm in p_metric_ctx.metrics:
                    pm_chain = build_evidence_chain_for_metric(pm)
                    pm_view = render_metric_detail_view(pm, pm_chain, scope_target=proj.display_name)
                    (p_metrics_dir / f"{pm.metric_id}.md").write_text(pm_view, encoding="utf-8")
            except Exception as ev_err:
                print(f"[Portal][WARN] Could not render project evidence for {pid}: {ev_err}")

        # 2. Generate Product Discovery Evidence Hub (portal/docs/evidence/index.md)
        evidence_hub_path = portal_docs_path / "evidence" / "index.md"
        safe_mkdir(evidence_hub_path.parent, parents=True, exist_ok=True)
        evidence_content = format_evidence_domain_view(context.product_discovery.evidence_nodes)
        evidence_hub_path.write_text(evidence_content, encoding="utf-8")

        # 3. Generate Candidate Metrics Matrix (portal/docs/evidence/candidate_metrics.md)
        candidate_metrics_path = portal_docs_path / "evidence" / "candidate_metrics.md"
        cand_content = "# Product Discovery Candidate Metrics Matrix\n\n"
        cand_content += render_evidence_table(context.product_discovery.evidence_nodes)
        candidate_metrics_path.write_text(cand_content, encoding="utf-8")

        # 3b. Generate Metric Detail Pages (portal/docs/evidence/metrics/<metric_id>.md)
        metrics_dir = portal_docs_path / "evidence" / "metrics"
        safe_mkdir(metrics_dir, parents=True, exist_ok=True)
        dummy_resolver = ProjectContextResolver(context.projects)
        if context.projects:
            dummy_resolver.set_active_project(context.projects[0].project_id)
            sample_ctx = resolve_project_metric_context(dummy_resolver)
            for m in sample_ctx.metrics:
                chain = build_evidence_chain_for_metric(m)
                m_view = render_metric_detail_view(m, chain)
                (metrics_dir / f"{m.metric_id}.md").write_text(m_view, encoding="utf-8")

        # 4. Generate Cross-Project Insights (portal/docs/global/insights/index.md)
        insights_path = portal_docs_path / "global" / "insights" / "index.md"
        safe_mkdir(insights_path.parent, parents=True, exist_ok=True)
        insights_content = render_cross_project_insights_view(context.cross_project_insights)
        insights_path.write_text(insights_content, encoding="utf-8")

        # 4b. Generate Consolidated Architecture State Matrix (portal/docs/global/maps/index.md)
        from cas_runner.tasks.portal.navigation_builder import generate_consolidated_architecture_state_matrix
        global_maps_path = portal_docs_path / "global" / "maps" / "index.md"
        safe_mkdir(global_maps_path.parent, parents=True, exist_ok=True)
        global_maps_path.write_text(generate_consolidated_architecture_state_matrix(context), encoding="utf-8")

        # 5. Update portal/mkdocs.yml navigation dynamically
        mkdocs_yml_path = portal_docs_path.parent / "mkdocs.yml"
        if mkdocs_yml_path.exists():
            with open(mkdocs_yml_path, "r", encoding="utf-8") as f:
                mkdocs_cfg = yaml.unsafe_load(f) or {}

            nav = mkdocs_cfg.get("nav", [])
            # Rebuild Projects navigation section with embedded Product Discovery Evidence sub-items
            proj_items = [{"Projects Hub": "projects/index.md"}]
            for p in context.projects:
                proj_pages = [
                    {"Overview & Health": f"projects/{p.project_id}/index.md"},
                    {"Architecture State": f"projects/{p.project_id}/state/index.md"},
                    {"Intent Documents": f"projects/{p.project_id}/intent/index.md"},
                    {"Architecture Work": f"projects/{p.project_id}/work/index.md"},
                    {"Alignment Reports": f"projects/{p.project_id}/alignment/index.md"},
                    {"Architecture Decisions": f"projects/{p.project_id}/adrs/index.md"},
                    {"Execution Traces": f"projects/{p.project_id}/traces/index.md"},
                    {"Product Discovery Evidence": f"projects/{p.project_id}/evidence/index.md"},
                ]
                proj_items.append({p.display_name: proj_pages})

            # Update or filter navigation entries
            updated_nav = []
            projects_added = False

            for item in nav:
                if isinstance(item, dict):
                    key = list(item.keys())[0]
                    if key == "Projects":
                        updated_nav.append({"Projects": proj_items})
                        projects_added = True
                    elif key == "Product Discovery Evidence":
                        # Skip top-level Product Discovery Evidence per Feature 074
                        continue
                    else:
                        updated_nav.append(item)
                else:
                    updated_nav.append(item)

            if not projects_added:
                updated_nav.append({"Projects": proj_items})

            mkdocs_cfg["nav"] = updated_nav
            with open(mkdocs_yml_path, "w", encoding="utf-8") as f:
                yaml.dump(mkdocs_cfg, f, sort_keys=False, allow_unicode=True)

            print("[Portal] Updated mkdocs.yml navigation with discovered projects.")
    except Exception as e:
        print(f"[Portal][WARN] Feature 070 portal preprocessor step failed: {e}")

    # Global landing pages maintain workspace-wide scope without host project attribution.
    print("[Portal] Pre-processing complete.")


def inject_default_project_header(file_path: Path, project_id: str, display_name: str):
    """Injects active default project context header at top of global section landing page if not present."""
    if not file_path.exists():
        return
    text = file_path.read_text(encoding="utf-8")
    if "Project Context:" in text:
        return

    header = f"# Project Context: {display_name}\n\n"
    header += f"Welcome to the architecture and governance portal context for **{display_name}** (`{project_id}`).\n\n---\n\n"

    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            new_text = f"---{parts[1]}---\n\n{header}{parts[2].lstrip()}"
            file_path.write_text(new_text, encoding="utf-8")
            return

    file_path.write_text(f"{header}{text.lstrip()}", encoding="utf-8")


if __name__ == "__main__":
    from cas_runner import io
    prepare_portal_docs(
        knowledge_root=str(io.get_workspace_root()),
        portal_docs_root=str(Path(__file__).parent.parent.parent / "portal" / "docs")
    )
