"""Data models for CAS agent skill evaluation suites and reports."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class EvalStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    SKIPPED = "SKIPPED"


@dataclass
class SkillAssertions:
    must_include: list[str] = field(default_factory=list)
    must_not_include: list[str] = field(default_factory=list)
    expected_decision: str | None = None


@dataclass
class SkillEvalCase:
    id: str
    prompt: str
    expected_output: str
    files: list[str] = field(default_factory=list)
    assertions: SkillAssertions | None = None

    @classmethod
    def from_dict(cls, data: dict) -> SkillEvalCase:
        raw_assertions = data.get("assertions")
        assertions = None
        if raw_assertions:
            assertions = SkillAssertions(
                must_include=raw_assertions.get("must_include", []),
                must_not_include=raw_assertions.get("must_not_include", []),
                expected_decision=raw_assertions.get("expected_decision"),
            )
        return cls(
            id=data["id"],
            prompt=data["prompt"],
            expected_output=data["expected_output"],
            files=data.get("files", []),
            assertions=assertions,
        )


@dataclass
class SkillEvalSuite:
    skill_name: str
    evals: list[SkillEvalCase] = field(default_factory=list)
    suite_path: Path | None = None

    @classmethod
    def from_dict(cls, data: dict, suite_path: Path | None = None) -> SkillEvalSuite:
        return cls(
            skill_name=data["skill_name"],
            evals=[SkillEvalCase.from_dict(item) for item in data.get("evals", [])],
            suite_path=suite_path,
        )


@dataclass
class SkillEvalResult:
    skill_name: str
    eval_id: str
    status: EvalStatus
    tier: str = "deterministic"
    score: float | None = None
    failure_reasons: list[str] = field(default_factory=list)
    duration_ms: float = 0.0


@dataclass
class SkillEvalReport:
    results: list[SkillEvalResult] = field(default_factory=list)
    total_duration_s: float = 0.0

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def passed(self) -> int:
        return sum(1 for r in self.results if r.status == EvalStatus.PASS)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if r.status == EvalStatus.FAIL)

    @property
    def skipped(self) -> int:
        return sum(1 for r in self.results if r.status == EvalStatus.SKIPPED)

    @property
    def is_success(self) -> bool:
        return self.failed == 0

    def render_terminal_table(self) -> str:
        lines = [
            "=" * 85,
            "Skill                       Eval ID                          Tier           Status   Time",
            "-" * 85,
        ]
        for r in self.results:
            skill_col = f"{r.skill_name:<27}"[:27]
            eval_col = f"{r.eval_id:<32}"[:32]
            tier_col = f"{r.tier:<14}"[:14]
            status_col = f"{r.status.value:<8}"
            time_col = f"{r.duration_ms:.0f}ms"
            lines.append(f"{skill_col} {eval_col} {tier_col} {status_col} {time_col}")
            if r.failure_reasons:
                for reason in r.failure_reasons:
                    lines.append(f"  ↳ Assertion Failed: {reason}")
        lines.append("-" * 85)
        res_str = "SUCCESS" if self.is_success else "FAILURE"
        code_str = "0" if self.is_success else "1"
        lines.append(
            f"Total: {self.total} | Passed: {self.passed} | Failed: {self.failed} | Skipped: {self.skipped} | Duration: {self.total_duration_s:.2f}s"
        )
        lines.append(f"Result: {res_str} (Exit Code: {code_str})")
        return "\n".join(lines)

    def render_markdown_summary(self) -> str:
        # Group by skill
        skill_counts: dict[str, dict[str, int]] = {}
        for r in self.results:
            s = skill_counts.setdefault(
                r.skill_name, {"total": 0, "passed": 0, "failed": 0, "skipped": 0}
            )
            s["total"] += 1
            if r.status == EvalStatus.PASS:
                s["passed"] += 1
            elif r.status == EvalStatus.FAIL:
                s["failed"] += 1
            elif r.status == EvalStatus.SKIPPED:
                s["skipped"] += 1

        md_lines = [
            "### 🛡️ CAS Skill Evaluation Summary",
            "",
            "| Skill | Total | Passed | Failed | Skipped | Status |",
            "|:---|:---:|:---:|:---:|:---:|:---:|",
        ]
        for skill_name, counts in sorted(skill_counts.items()):
            status_icon = (
                "✅ PASS"
                if counts["failed"] == 0 and counts["passed"] > 0
                else ("⚪ SKIPPED" if counts["passed"] == 0 and counts["failed"] == 0 else "❌ FAIL")
            )
            md_lines.append(
                f"| `{skill_name}` | {counts['total']} | {counts['passed']} | {counts['failed']} | {counts['skipped']} | {status_icon} |"
            )

        overall_status = "✅ PASS" if self.is_success else "❌ FAIL"
        md_lines.append(
            f"| **Total** | **{self.total}** | **{self.passed}** | **{self.failed}** | **{self.skipped}** | **{overall_status}** |"
        )
        md_lines.append("")
        md_lines.append(f"*Duration: {self.total_duration_s:.2f}s*")
        return "\n".join(md_lines)
