"""Zero-dependency local web cockpit UI package for CAS."""
