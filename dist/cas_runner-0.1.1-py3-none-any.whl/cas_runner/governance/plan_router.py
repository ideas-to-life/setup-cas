"""Stage 3 Proportionate Governance Plan Router.

Classifies implementation plans into:
- Path A (Governed Reuse): Approved patterns with invariants satisfied -> autonomous build unlocked.
- Path B (Architectural Novelty): Unmapped dependency or novel pattern -> pauses auto-mode, scaffolds candidate ADR.
- Path C (Architectural Exception): Intentional deviation -> validates schema, architect approval, and expiry date.
"""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import jsonschema
import yaml

from cas_runner.governance.candidate_adr_generator import generate_candidate_adr
from cas_runner.governance.models import GovernancePath, PlanRoutingDecision
from cas_runner.governance.sdlc_profile import SDLCProfileResolver

EXCEPTION_SCHEMA_PATH = Path(
    "src/cas_runner/schemas/architecture-exception.schema.json"
)


class PlanRouter:
    """Routes implementation plans to Path A, Path B, or Path C."""

    EXCEPTION_PATTERN = re.compile(r"(?i)(?:exception|exc):\s*([a-zA-Z0-9_-]+)")
    PATTERN_REF_PATTERN = re.compile(r"(?i)(?:pattern|pattern_id):\s*([a-zA-Z0-9_-]+)")

    def __init__(
        self, target_dir: Path | str = Path("."), project: str | None = None
    ) -> None:
        self.target_dir = Path(target_dir).resolve()
        self.project = project or "ideas-to-life-cas"
        self.resolver = SDLCProfileResolver(target_dir=self.target_dir)
        self.patterns_catalogue = self._load_patterns_catalogue()
        self.exception_schema = self._load_exception_schema()

    def _load_patterns_catalogue(self) -> dict[str, Any]:
        """Loads patterns from .cas/patterns/patterns-catalogue.yaml or built-ins."""
        candidates = [
            self.target_dir / ".cas" / "patterns" / "patterns-catalogue.yaml",
            Path("src/cas_skills/patterns/patterns-catalogue.yaml"),
        ]
        for path in candidates:
            if path.is_file():
                try:
                    data = yaml.safe_load(path.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        raw_patterns = data.get("patterns", [])
                        if isinstance(raw_patterns, list):
                            return {
                                p["id"]: p
                                for p in raw_patterns
                                if isinstance(p, dict) and "id" in p
                            }
                        elif isinstance(raw_patterns, dict):
                            return raw_patterns
                except Exception:
                    pass
        return {}

    def _load_exception_schema(self) -> dict[str, Any]:
        """Loads architecture-exception.schema.json."""
        if EXCEPTION_SCHEMA_PATH.is_file():
            try:
                return json.loads(EXCEPTION_SCHEMA_PATH.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {}

    def resolve_plan_file(self) -> Path | None:
        """Locates the active implementation plan via SDLCProfileResolver."""
        try:
            artifacts = self.resolver.resolve()
            for rel in artifacts.plan_files:
                p = self.target_dir / rel
                if p.is_file():
                    return p
        except Exception:
            pass

        for candidate in ["plan.md"]:
            candidate_path = self.target_dir / candidate
            if candidate_path.is_file():
                return candidate_path

        return None

    def route_plan_file(self, plan_path: Path) -> PlanRoutingDecision:
        """Classifies a specific plan file into Path A, Path B, or Path C."""
        if not plan_path.is_file():
            return PlanRoutingDecision(
                plan_path=str(plan_path),
                path=GovernancePath.PATH_A,
                status="blocked",
                reasons=[f"Plan file not found: {plan_path}"],
            )

        content = plan_path.read_text(encoding="utf-8")
        return self.route_plan_content(content, plan_path=plan_path, dry_run=False)

    def route_plan_content(
        self,
        content: str,
        plan_path: Path | None = None,
        dry_run: bool = True,
    ) -> PlanRoutingDecision:
        """Classify plan markdown content into Path A, Path B, or Path C.

        When ``dry_run`` is True, Path B returns ``escalated`` with
        ``candidate_adr_path=None`` and writes nothing to disk.
        """
        effective_path = plan_path or (self.target_dir / "plan.md")

        # 1. Check for Path C (Architectural Exception declared)
        exc_match = self.EXCEPTION_PATTERN.search(content)
        if exc_match:
            exc_id = exc_match.group(1).strip()
            return self._evaluate_exception(effective_path, exc_id)

        # 2. Check for Pattern References in Plan
        patterns = self._extract_referenced_patterns(content)

        if patterns:
            novel_patterns = [p for p in patterns if p not in self.patterns_catalogue]
            if novel_patterns:
                # Path B: Architectural Novelty
                first_novel = novel_patterns[0]
                candidate_adr_path: str | None = None
                if not dry_run:
                    slug = (
                        effective_path.parent.name
                        if effective_path.parent.name != "plans"
                        else first_novel
                    )
                    candidate_adr_path = str(
                        generate_candidate_adr(
                            self.target_dir, self.project, first_novel, slug=slug
                        )
                    )
                return PlanRoutingDecision(
                    plan_path=str(effective_path),
                    path=GovernancePath.PATH_B,
                    status="escalated",
                    unmapped_dependencies=novel_patterns,
                    candidate_adr_path=candidate_adr_path,
                    reasons=[
                        f"Proposed pattern or component '{first_novel}' is not ratified in patterns-catalogue.yaml"
                    ],
                )
            # Path A: Governed Reuse
            return PlanRoutingDecision(
                plan_path=str(effective_path),
                path=GovernancePath.PATH_A,
                status="approved",
                matched_patterns=patterns,
                reasons=[
                    "All referenced patterns are ratified in patterns-catalogue.yaml."
                ],
            )

        # Default: Path A if no explicit exceptions or unapproved patterns
        return PlanRoutingDecision(
            plan_path=str(effective_path),
            path=GovernancePath.PATH_A,
            status="approved",
            matched_patterns=["governed-standard-structure"],
            reasons=["Plan aligns with established codebase structure."],
        )

    def _extract_referenced_patterns(self, content: str) -> list[str]:
        """Extracts declared pattern references from plan markdown."""
        found: list[str] = []
        for line in content.splitlines():
            for match in self.PATTERN_REF_PATTERN.finditer(line):
                val = match.group(1).strip()
                if val and val not in found:
                    found.append(val)
        return found

    def _evaluate_exception(self, plan_path: Path, exc_id: str) -> PlanRoutingDecision:
        """Evaluates an exception record against schema, approval, and expiration."""
        # Normalize exc_id to include exc- if needed
        if not exc_id.startswith("exc-"):
            exc_id = f"exc-{exc_id}"

        # Look in knowledge/projects/<project>/exceptions/
        exc_candidates = [
            self.target_dir
            / "knowledge"
            / "projects"
            / self.project
            / "exceptions"
            / f"{exc_id}.yaml",
            self.target_dir
            / "knowledge"
            / "projects"
            / self.project
            / "exceptions"
            / f"{exc_id}.yml",
            self.target_dir / ".cas" / "exceptions" / f"{exc_id}.yaml",
        ]

        exc_file: Path | None = None
        for cand in exc_candidates:
            if cand.is_file():
                exc_file = cand
                break

        if not exc_file:
            return PlanRoutingDecision(
                plan_path=str(plan_path),
                path=GovernancePath.PATH_C,
                status="blocked",
                reasons=[
                    f"Referenced architectural exception record '{exc_id}' not found under "
                    f"knowledge/projects/{self.project}/exceptions/"
                ],
            )

        try:
            exc_data = yaml.safe_load(exc_file.read_text(encoding="utf-8"))
        except Exception as exc:
            return PlanRoutingDecision(
                plan_path=str(plan_path),
                path=GovernancePath.PATH_C,
                status="blocked",
                exception_record_path=str(exc_file),
                reasons=[f"Cannot parse exception YAML '{exc_file}': {exc}"],
            )

        # Validate against schema if schema is loaded
        if self.exception_schema:
            try:
                jsonschema.validate(instance=exc_data, schema=self.exception_schema)
            except jsonschema.ValidationError as val_err:
                return PlanRoutingDecision(
                    plan_path=str(plan_path),
                    path=GovernancePath.PATH_C,
                    status="blocked",
                    exception_record_path=str(exc_file),
                    reasons=[
                        f"Exception '{exc_id}' failed schema validation: {val_err.message}"
                    ],
                )

        # Check approval
        status_val = exc_data.get("status", "").lower()
        if status_val != "approved":
            return PlanRoutingDecision(
                plan_path=str(plan_path),
                path=GovernancePath.PATH_C,
                status="blocked",
                exception_record_path=str(exc_file),
                reasons=[
                    f"Exception '{exc_id}' is not approved (current status: '{status_val}')"
                ],
            )

        # Check expiration date
        valid_until_str = exc_data.get("valid_until")
        if valid_until_str:
            try:
                valid_until = datetime.strptime(str(valid_until_str), "%Y-%m-%d").date()
                today = datetime.now(UTC).date()
                if valid_until < today:
                    return PlanRoutingDecision(
                        plan_path=str(plan_path),
                        path=GovernancePath.PATH_C,
                        status="blocked",
                        exception_record_path=str(exc_file),
                        reasons=[
                            f"Architectural exception '{exc_id}' expired on {valid_until}"
                        ],
                    )
            except ValueError:
                pass

        return PlanRoutingDecision(
            plan_path=str(plan_path),
            path=GovernancePath.PATH_C,
            status="approved",
            exception_record_path=str(exc_file),
            reasons=[
                f"Valid, approved, and active architectural exception '{exc_id}' confirmed."
            ],
        )

    def route(self) -> PlanRoutingDecision:
        """Classifies the active plan for the target directory."""
        plan_path = self.resolve_plan_file()
        if not plan_path:
            decision = PlanRoutingDecision(
                plan_path="<none>",
                path=GovernancePath.PATH_A,
                status="approved",
                reasons=["No plan.md resolved; defaulting to standard governed flow."],
            )
        else:
            decision = self.route_plan_file(plan_path)

        try:
            from .sdlc_state import SDLCStatePublisher

            status_label = decision.path.value.replace(" ", "_").upper()
            details = f"{decision.path.value} ({decision.status.upper()})"
            publisher = SDLCStatePublisher(target_dir=self.target_dir)
            publisher.record_gate(
                gate_name="route_plan",
                status=status_label,
                details=details,
                stage=3,
                checklist_updates={"plan_md": bool(plan_path)},
            )
        except Exception:
            pass

        return decision
