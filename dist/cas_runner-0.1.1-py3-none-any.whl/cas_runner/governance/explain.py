"""CAS Dynamic Architecture Discovery Engine (`cas explain`).

Provides dynamic, schema-grounded introspection of registered flows, pattern
invariants, SDLC contracts, control loops, and unified ADRs across global
and project knowledge workspaces.
"""

from __future__ import annotations

import difflib
import json
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from io import StringIO
from pathlib import Path
from typing import Any

import yaml
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from cas_runner.steps.registry import FLOWS


class ExplainTarget(StrEnum):
    OVERVIEW = "overview"
    CONTROL_LOOPS = "control-loops"
    FLOWS = "flows"
    FLOW = "flow"
    PATTERN = "pattern"
    SDLC = "sdlc"
    AI_NATIVE_SDLC = "ai-native-sdlc"
    ADRS = "adrs"
    ADR = "adr"


@dataclass
class FlowMetadata:
    name: str
    steps: list[str]
    step_count: int
    description: str = ""


@dataclass
class PatternMetadata:
    id: str
    description: str
    invariants: list[str]
    anti_patterns: list[str]
    status: str = "ratified"


@dataclass
class ADRMetadata:
    id: str
    title: str
    scope: str  # "global" or "project"
    status: str
    date: str
    decision_target: str | None = None
    rationale: str = ""
    file_path: str = ""


@dataclass
class ControlLoopMetadata:
    name: str
    purpose: str
    mechanisms: list[str]
    cli_gates: list[str]
    artifacts: list[str]


@dataclass
class SDLCContractMetadata:
    stage_number: int
    stage_name: str
    gate_checks: list[str]
    routing_classification: str
    verification_tools: list[str]


def find_close_matches(
    word: str, possibilities: list[str], n: int = 3, cutoff: float = 0.4
) -> list[str]:
    """Return fuzzy suggestions for misspelled targets or entity identifiers."""
    return difflib.get_close_matches(word, possibilities, n=n, cutoff=cutoff)


def get_console() -> Console:
    """Create a Rich Console respecting TTY and headless piping."""
    is_tty = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
    return Console(
        force_terminal=is_tty,
        no_color=not is_tty,
        highlight=is_tty,
        soft_wrap=not is_tty,
    )


def get_patterns_catalogue_path() -> Path:
    """Resolve the canonical patterns-catalogue.yaml path."""
    return (
        Path(__file__).resolve().parent.parent.parent
        / "cas_skills"
        / "patterns"
        / "patterns-catalogue.yaml"
    )


def load_patterns_catalogue() -> list[dict[str, Any]]:
    """Load all patterns declared in patterns-catalogue.yaml."""
    cat_path = get_patterns_catalogue_path()
    if not cat_path.exists():
        return []
    with open(cat_path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return data.get("patterns", [])


def extract_frontmatter(content: str) -> dict[str, Any]:
    """Extract YAML frontmatter from markdown document content."""
    if not content.startswith("---"):
        return {}
    parts = content.split("---", 2)
    if len(parts) < 3:
        return {}
    try:
        return yaml.safe_load(parts[1]) or {}
    except Exception:
        return {}


def explain_overview(target_dir: str | Path | None = None) -> dict[str, Any]:
    """Produce platform overview, control loop summary, and target command catalogue."""
    return {
        "platform": "Continuous Architecture System (CAS)",
        "version": "1.0",
        "description": "Transforms software architecture from static documentation into a continuously updated, queryable, and governed system asset. Anchors all decisions in authoritative ADRs, provides AI agent guidance, and detects/corrects architectural drift.",
        "control_loops": [
            {
                "name": "Prevent",
                "purpose": "Stops architectural drift before code changes land using agent skills and automated gates.",
                "cli_gates": [
                    "cas governance verify-intent",
                    "cas governance route-plan",
                    "cas governance verify-diff",
                    "cas governance review-pr",
                ],
            },
            {
                "name": "Detect",
                "purpose": "Continuously measures repository AST structure against statistical control bands and architectural invariants.",
                "cli_gates": [
                    "cas governance lint",
                    "cas governance bands",
                    "cas run forensic-diagnostic-flow",
                ],
            },
            {
                "name": "Correct",
                "purpose": "Reconciles detected drift by promoting heuristics into ADRs and steering projections.",
                "cli_gates": [
                    "cas governance publish",
                    "cas governance sync",
                    "cas steering apply",
                    "cas run continuous-architecture-loop",
                ],
            },
        ],
        "targets": [
            {
                "name": "overview",
                "syntax": "cas explain",
                "description": "Platform capability overview, operational loops, and command catalog",
            },
            {
                "name": "control-loops",
                "syntax": "cas explain control-loops",
                "description": "Detailed breakdown of Prevent, Detect, and Correct operational loops",
            },
            {
                "name": "flows",
                "syntax": "cas explain flows",
                "description": "Dynamic list of all 24 registered orchestration flows with step sequences",
            },
            {
                "name": "flow",
                "syntax": "cas explain flow <name>",
                "description": "Step sequence, inputs, and outputs of a specific named flow",
            },
            {
                "name": "pattern",
                "syntax": "cas explain pattern <id>",
                "description": "Invariants, anti-patterns, and description from patterns catalog",
            },
            {
                "name": "sdlc",
                "syntax": "cas explain sdlc",
                "description": "6-stage AI-Native SDLC contract ([A]/[P]/[Q], Path A/B/C, Verifier, Bands)",
            },
            {
                "name": "adrs",
                "syntax": "cas explain adrs",
                "description": "Unified discovery of Global and Project Architecture Decision Records",
            },
            {
                "name": "adr",
                "syntax": "cas explain adr <id>",
                "description": "Detailed rationale, consequences, and metadata for a specific decision",
            },
        ],
    }


def explain_control_loops(target_dir: str | Path | None = None) -> dict[str, Any]:
    """Produce detailed breakdown of the 3 operational control loops."""
    return {
        "overview": "CAS operates three closed-loop control mechanisms to guarantee that software architectures evolve predictably alongside autonomous AI coding agents:",
        "loops": [
            {
                "name": "Prevent",
                "purpose": "Enforce architectural rules and pattern invariants during feature design and generation before code changes land.",
                "mechanisms": [
                    "Zero-Hallucination Intent Triage: Enforces verified [A] anchors, tracks [P] presumptions, resolves all [Q] open questions",
                    "Pattern Alignment & Invariant Checks: Validates structural choices against patterns-catalogue.yaml",
                    "Proportionate Governance Routing: Fast-tracks Path A (Governed Reuse), gates Path B (Novelty -> ADR) and Path C (Exception -> exc-*.yaml)",
                    "Isolated Fresh-Context Verifier: Independent verification subagent (.cas/agents/verifier.md)",
                    "PreToolUse Runtime Guardrails: Deterministic file and production protection hooks",
                ],
                "cli_gates": [
                    "cas governance verify-intent",
                    "cas governance route-plan",
                    "cas governance verify-diff",
                    "cas governance review-pr",
                ],
                "artifacts": [
                    "spec.md",
                    "plan.md",
                    "tasks.md",
                    ".cas/config.yaml",
                    "REVIEW.md",
                ],
            },
            {
                "name": "Detect",
                "purpose": "Continuously inspect repository codebase to extract living architectural state, compute AST metrics, and detect structural drift.",
                "mechanisms": [
                    "Forensic AST Extraction: Analyzes modules, imports, function calls, and container boundaries",
                    "Robert C. Martin Coupling Metrics: Calculates Ca, Ce, Instability (I), Abstractness (A), and Normalized Distance (D)",
                    "Western Electric Statistical Rules: Identifies out-of-control metric shifts across 1, 2, and 3-sigma bands",
                    "Deterministic Linter: Enforces ARCH-LINT-001 through ARCH-LINT-004 rules in CI",
                ],
                "cli_gates": [
                    "cas governance lint",
                    "cas governance bands",
                    "cas governance check-env",
                    "cas run forensic-diagnostic-flow",
                ],
                "artifacts": [
                    "ARCHITECTURE.md",
                    "knowledge/projects/<project>/control-bands.json",
                    "state/architecture-state.yaml",
                ],
            },
            {
                "name": "Correct",
                "purpose": "Reconcile detected drift by promoting heuristics into ratified patterns, synchronizing with enterprise review, and projecting steering instructions.",
                "mechanisms": [
                    "Pattern Proposal Engine: Extracts emerging structural patterns from source code deltas",
                    "4-Tier Transitive Lineage Promotion: Pattern Proposal → Promotion Recommendation → Promotion Decision → ADR",
                    "Bidirectional ArchGov Review Sync: Publishes reference architectures and synchronizes remote board decisions",
                    "Managed Steering Projection: Projects ratified patterns into AGENTS.md, GEMINI.md, and CLAUDE.md",
                ],
                "cli_gates": [
                    "cas governance publish",
                    "cas governance sync",
                    "cas steering apply",
                    "cas run continuous-architecture-loop",
                ],
                "artifacts": [
                    "knowledge/global/patterns/structural-pattern-proposals.yaml",
                    "knowledge/projects/<project>/adrs/",
                    "AGENTS.md",
                    "GEMINI.md",
                ],
            },
        ],
    }


def explain_flows(target_dir: str | Path | None = None) -> dict[str, Any]:
    """Dynamically list all registered flows from src/cas_runner/steps/registry.py."""
    flow_list = []
    for flow_name in sorted(FLOWS.keys()):
        steps = FLOWS[flow_name]
        flow_list.append(
            {
                "name": flow_name,
                "steps": steps,
                "step_count": len(steps),
            }
        )
    return {
        "total_flows": len(FLOWS),
        "flows": flow_list,
    }


def explain_flow(
    flow_name: str, target_dir: str | Path | None = None
) -> dict[str, Any]:
    """Inspect the step sequence of a specific registered flow."""
    if flow_name in FLOWS:
        steps = FLOWS[flow_name]
        return {
            "name": flow_name,
            "steps": steps,
            "step_count": len(steps),
        }

    # Fuzzy match on unknown flow name
    matches = find_close_matches(flow_name, list(FLOWS.keys()))
    raise KeyError(
        f"Unknown flow '{flow_name}'. Did you mean: {', '.join(matches)}?"
        if matches
        else f"Unknown flow '{flow_name}'. Run 'cas explain flows' to view all registered flows."
    )


def explain_pattern(
    pattern_id: str, target_dir: str | Path | None = None
) -> dict[str, Any]:
    """Extract description, invariants, anti-patterns, and status for a pattern from patterns-catalogue.yaml."""
    patterns = load_patterns_catalogue()
    for p in patterns:
        if p.get("id") == pattern_id:
            return {
                "id": pattern_id,
                "description": p.get("description", ""),
                "invariants": p.get("invariants", []),
                "anti_patterns": p.get("anti_patterns", []),
                "status": p.get("status", "ratified"),
            }

    # Fuzzy match on unknown pattern id
    avail_ids = [p.get("id") for p in patterns if "id" in p]
    matches = find_close_matches(pattern_id, avail_ids)
    raise KeyError(
        f"Unknown pattern '{pattern_id}'. Did you mean: {', '.join(matches)}?"
        if matches
        else f"Unknown pattern '{pattern_id}'. Consult 'src/cas_skills/patterns/patterns-catalogue.yaml' for available patterns."
    )


def explain_sdlc(target_dir: str | Path | None = None) -> dict[str, Any]:
    """Visualize the 6-stage AI-Native SDLC contract."""
    stages = [
        {
            "stage_number": 1,
            "stage_name": "Intent Triage",
            "gate_checks": [
                "[A] Anchors verified",
                "[P] Presumptions tracked",
                "[Q] Open questions resolved (= 0)",
            ],
            "routing_classification": "Zero-Hallucination Gate",
            "verification_tools": ["cas governance verify-intent"],
        },
        {
            "stage_number": 2,
            "stage_name": "Spec & Pattern Alignment",
            "gate_checks": [
                "Pattern catalogue invariants satisfied",
                "Zero anti-patterns introduced",
            ],
            "routing_classification": "Pattern Invariant Gate",
            "verification_tools": [
                "cas explain pattern <id>",
                "patterns-catalogue.yaml",
            ],
        },
        {
            "stage_number": 3,
            "stage_name": "Plan Routing",
            "gate_checks": [
                "Proportionate Governance Authority",
                "Scope and boundary classification",
            ],
            "routing_classification": "Path A (Governed Reuse) | Path B (Novelty -> ADR) | Path C (Exception -> exc-*.yaml)",
            "verification_tools": ["cas governance route-plan"],
        },
        {
            "stage_number": 4,
            "stage_name": "Tasks & Autonomous TDD",
            "gate_checks": [
                "Red-Green-Refactor loop",
                "Zero weakened assertions ([bugfix])",
            ],
            "routing_classification": "Autonomous Execution (Path A)",
            "verification_tools": ["uv run pytest", "cas governance watch"],
        },
        {
            "stage_number": 5,
            "stage_name": "Fresh-Context Verification",
            "gate_checks": [
                "Isolated Verifier review",
                "3-pass diff verification gate",
            ],
            "routing_classification": "Pre-Merge Gate",
            "verification_tools": [
                "cas governance verify-diff",
                "cas governance review-pr",
                ".cas/agents/verifier.md",
            ],
        },
        {
            "stage_number": 6,
            "stage_name": "Maintain & Control Bands",
            "gate_checks": [
                "AST Martin metrics stability (Ca, Ce, I, A, D)",
                "Western Electric 3-sigma rules",
            ],
            "routing_classification": "Closed-Loop Statistical Gate",
            "verification_tools": [
                "cas governance lint",
                "cas governance bands",
                "cas governance check-env",
            ],
        },
    ]
    return {
        "title": "6-Stage AI-Native SDLC Contract",
        "stages": stages,
    }


def _resolve_knowledge_root(target_dir: str | Path | None = None) -> tuple[Path, str]:
    """Resolve knowledge workspace path and project name using CASConfig with fallback to repo roots."""
    import os

    from cas_runner.config import load_config
    from cas_runner.io import get_default_base

    base_dir = Path(target_dir or ".").resolve()
    eff = load_config(base_dir)
    ws_str = eff.config.knowledge.workspace_path
    ws_path = Path(ws_str).expanduser()
    project = eff.config.project.name

    if not ws_path.exists():
        # Fall back to standard runtime and repository locations:
        # 1. Environment variable CAS_KNOWLEDGE_WORKSPACE (if present)
        env_ws = os.getenv("CAS_KNOWLEDGE_WORKSPACE")
        if env_ws and Path(env_ws).expanduser().exists():
            ws_path = Path(env_ws).expanduser().resolve()
        # 2. Local repository symlinks or checkouts (knowledge/ or cas-knowledge/)
        elif (base_dir / "knowledge").exists():
            ws_path = (base_dir / "knowledge").resolve()
        elif (base_dir / "cas-knowledge").exists():
            ws_path = (base_dir / "cas-knowledge").resolve()
        elif Path("knowledge").resolve().exists():
            ws_path = Path("knowledge").resolve()
        elif Path("cas-knowledge").resolve().exists():
            ws_path = Path("cas-knowledge").resolve()
        else:
            default_base = get_default_base()
            if default_base.exists():
                ws_path = default_base

    return ws_path, project


def explain_adrs(target_dir: str | Path | None = None) -> dict[str, Any]:
    """Index and display decisions from global/decisions/ and projects/<project>/adrs/."""
    ws_path, project = _resolve_knowledge_root(target_dir)

    global_dir = ws_path / "global" / "decisions"
    project_dir = ws_path / "projects" / project / "adrs"

    adrs: list[dict[str, Any]] = []

    # 1. Global decisions
    if global_dir.exists():
        for f in sorted(global_dir.glob("adr-*.md")):
            try:
                fm = extract_frontmatter(f.read_text(encoding="utf-8"))
            except Exception:
                fm = {}
            adrs.append(
                {
                    "id": fm.get("id") or f.stem,
                    "title": fm.get("title")
                    or f.stem.replace("adr-", "").replace("-", " ").title(),
                    "scope": "global",
                    "status": fm.get("decision", {}).get("status")
                    if isinstance(fm.get("decision"), dict)
                    else fm.get("status", "accepted"),
                    "date": str(fm.get("date", "unknown")),
                    "decision_target": fm.get("decision_target")
                    or fm.get("pattern_id"),
                    "rationale": (
                        fm.get("decision", {}).get("rationale", {}).get("summary")
                        if isinstance(fm.get("decision"), dict)
                        and isinstance(fm.get("decision", {}).get("rationale"), dict)
                        else (
                            fm.get("decision", {}).get("rationale")
                            if isinstance(fm.get("decision"), dict)
                            else fm.get("rationale", "")
                        )
                    )
                    or "",
                    "file_path": str(f),
                }
            )

    # 2. Project decisions
    if project_dir.exists():
        for f in sorted(project_dir.glob("adr-*.md")):
            try:
                fm = extract_frontmatter(f.read_text(encoding="utf-8"))
            except Exception:
                fm = {}
            adrs.append(
                {
                    "id": fm.get("id") or f.stem,
                    "title": fm.get("title")
                    or f.stem.replace("adr-", "").replace("-", " ").title(),
                    "scope": "project",
                    "status": fm.get("decision", {}).get("status")
                    if isinstance(fm.get("decision"), dict)
                    else fm.get("status", "accepted"),
                    "date": str(fm.get("date", "unknown")),
                    "decision_target": fm.get("decision_target")
                    or fm.get("pattern_id"),
                    "rationale": (
                        fm.get("decision", {}).get("rationale", {}).get("summary")
                        if isinstance(fm.get("decision"), dict)
                        and isinstance(fm.get("decision", {}).get("rationale"), dict)
                        else (
                            fm.get("decision", {}).get("rationale")
                            if isinstance(fm.get("decision"), dict)
                            else fm.get("rationale", "")
                        )
                    )
                    or "",
                    "file_path": str(f),
                }
            )

    # Sort deterministically by id
    adrs.sort(key=lambda x: (x["scope"], x["id"]))

    global_count = sum(1 for a in adrs if a["scope"] == "global")
    project_count = sum(1 for a in adrs if a["scope"] == "project")

    return {
        "workspace_path": str(ws_path),
        "project": project,
        "total_adrs": len(adrs),
        "global_count": global_count,
        "project_count": project_count,
        "adrs": adrs,
    }


def explain_adr(adr_id: str, target_dir: str | Path | None = None) -> dict[str, Any]:
    """Inspect detailed rationale and metadata for a specific decision record."""
    adrs_data = explain_adrs(target_dir)
    adrs = adrs_data.get("adrs", [])

    # Exact match on id or filename
    norm_id = adr_id.removesuffix(".md")
    for a in adrs:
        if a.get("id") == norm_id or a.get("id") == f"adr-{norm_id}":
            return a

    # Fuzzy match on unknown ADR id
    avail_ids = [a.get("id") for a in adrs if "id" in a]
    matches = find_close_matches(norm_id, avail_ids)
    raise KeyError(
        f"Unknown ADR '{adr_id}'. Did you mean: {', '.join(matches)}?"
        if matches
        else f"Unknown ADR '{adr_id}'. Run 'cas explain adrs' to list all available decisions."
    )


def render_json(payload: dict[str, Any]) -> str:
    """Format payload as standardized JSON adhering to cli-explain.schema.json."""
    return json.dumps(payload, indent=2)


def render_markdown(payload: dict[str, Any]) -> str:
    """Format payload as GitHub Flavored Markdown."""
    target = payload.get("target", "overview")
    data = payload.get("data", {})
    buf = StringIO()

    buf.write(f"# CAS Architecture Discovery: {target.upper()}\n\n")

    if target == "overview":
        buf.write(
            f"> **Platform**: {data.get('platform', 'Continuous Architecture System (CAS)')}\n\n"
        )
        buf.write(f"{data.get('description', '')}\n\n")
        buf.write("## Operational Control Loops\n\n")
        for loop in data.get("control_loops", []):
            buf.write(f"### {loop.get('name')} Loop\n")
            buf.write(f"- **Purpose**: {loop.get('purpose')}\n")
            buf.write(
                f"- **CLI Gates**: {', '.join(f'`{g}`' for g in loop.get('cli_gates', []))}\n\n"
            )
        buf.write("## Available Discovery Targets\n\n")
        buf.write("| Target | Syntax | Description |\n| :--- | :--- | :--- |\n")
        for t in data.get("targets", []):
            buf.write(
                f"| `{t.get('name')}` | `{t.get('syntax')}` | {t.get('description')} |\n"
            )

    elif target == "control-loops":
        buf.write(f"{data.get('overview', '')}\n\n")
        for loop in data.get("loops", []):
            buf.write(f"## {loop.get('name')} Loop\n")
            buf.write(f"**Purpose**: {loop.get('purpose')}\n\n")
            buf.write("### Key Mechanisms\n")
            for m in loop.get("mechanisms", []):
                buf.write(f"- {m}\n")
            buf.write("\n### CLI Gates\n")
            for g in loop.get("cli_gates", []):
                buf.write(f"- `{g}`\n")
            buf.write("\n### Governed Artifacts\n")
            for a in loop.get("artifacts", []):
                buf.write(f"- `{a}`\n")
            buf.write("\n---\n\n")

    elif target == "flows":
        buf.write(f"**Total Registered Flows**: {data.get('total_flows', 0)}\n\n")
        buf.write(
            "| Flow Name | Step Count | Step Sequence |\n| :--- | :---: | :--- |\n"
        )
        for f in data.get("flows", []):
            steps_str = " → ".join(f.get("steps", []))
            buf.write(f"| `{f.get('name')}` | {f.get('step_count')} | {steps_str} |\n")

    elif target == "flow":
        buf.write(f"## Flow: `{data.get('name')}`\n\n")
        buf.write(f"- **Step Count**: {data.get('step_count')}\n\n")
        buf.write("### Execution Step Sequence\n\n")
        for idx, step in enumerate(data.get("steps", []), 1):
            buf.write(f"{idx}. `{step}`\n")

    elif target == "pattern":
        buf.write(f"## Pattern: `{data.get('id')}`\n\n")
        buf.write(f"- **Status**: `{data.get('status', 'ratified')}`\n\n")
        buf.write(f"### Description\n{data.get('description', '')}\n\n")
        buf.write("### Invariants (Mandatory Rules)\n")
        for inv in data.get("invariants", []):
            buf.write(f"- {inv}\n")
        buf.write("\n### Anti-Patterns (Forbidden Practices)\n")
        for anti in data.get("anti_patterns", []):
            buf.write(f"- {anti}\n")

    elif target in ("sdlc", "ai-native-sdlc"):
        buf.write("## 6-Stage AI-Native SDLC Contract\n\n")
        buf.write(
            "| Stage | Stage Name | Gate Checks | Routing Classification | Verification Tools |\n"
        )
        buf.write("| :---: | :--- | :--- | :--- | :--- |\n")
        for stage in data.get("stages", []):
            gates = ", ".join(stage.get("gate_checks", []))
            tools = ", ".join(f"`{t}`" for t in stage.get("verification_tools", []))
            buf.write(
                f"| {stage.get('stage_number')} | {stage.get('stage_name')} | {gates} | {stage.get('routing_classification')} | {tools} |\n"
            )

    elif target == "adrs":
        buf.write(f"**Knowledge Workspace**: `{data.get('workspace_path', '')}`\n\n")
        buf.write(f"- Global Decisions: {data.get('global_count', 0)}\n")
        buf.write(f"- Project Decisions: {data.get('project_count', 0)}\n\n")
        buf.write(
            "| ID | Scope | Status | Date | Target / Topic | Rationale Summary |\n| :--- | :---: | :---: | :---: | :--- | :--- |\n"
        )
        for adr in data.get("adrs", []):
            buf.write(
                f"| `{adr.get('id')}` | `{adr.get('scope')}` | `{adr.get('status')}` | {adr.get('date')} | {adr.get('decision_target') or '—'} | {adr.get('rationale')} |\n"
            )

    elif target == "adr":
        buf.write(f"## Decision: `{data.get('id')}`\n\n")
        buf.write(f"- **Title**: {data.get('title')}\n")
        buf.write(f"- **Scope**: `{data.get('scope')}`\n")
        buf.write(f"- **Status**: `{data.get('status')}`\n")
        buf.write(f"- **Date**: {data.get('date')}\n")
        buf.write(f"- **Target**: `{data.get('decision_target') or '—'}`\n")
        buf.write(f"- **File Path**: `{data.get('file_path')}`\n\n")
        buf.write(f"### Rationale\n{data.get('rationale')}\n")

    return buf.getvalue()


def render_text(payload: dict[str, Any]) -> str:
    """Format payload with Rich tables and ANSI formatting or plain text fallback."""
    console = get_console()
    target = payload.get("target", "overview")
    data = payload.get("data", {})
    buf = StringIO()
    string_console = Console(
        file=buf,
        force_terminal=console.is_terminal,
        no_color=console.no_color,
        width=120,
    )

    if target == "overview":
        string_console.print(
            Panel.fit(
                "[bold cyan]Continuous Architecture System (CAS) — Capability & Loop Overview[/bold cyan]"
            )
        )
        string_console.print(f"\n{data.get('description', '')}\n")

        loop_table = Table(
            title="Operational Control Loops",
            show_header=True,
            header_style="bold magenta",
        )
        loop_table.add_column("Loop", style="bold green", width=12)
        loop_table.add_column("Purpose", width=45)
        loop_table.add_column("CLI Gates", style="cyan", width=45)
        for loop in data.get("control_loops", []):
            loop_table.add_row(
                loop.get("name"),
                loop.get("purpose"),
                ", ".join(loop.get("cli_gates", [])),
            )
        string_console.print(loop_table)
        string_console.print("")

        target_table = Table(
            title="Available Discovery Targets",
            show_header=True,
            header_style="bold yellow",
        )
        target_table.add_column("Target", style="bold cyan", width=16)
        target_table.add_column("Command Syntax", style="green", width=40)
        target_table.add_column("Description", width=55)
        for t in data.get("targets", []):
            target_table.add_row(t.get("name"), t.get("syntax"), t.get("description"))
        string_console.print(target_table)

    elif target == "control-loops":
        string_console.print(
            Panel.fit("[bold cyan]CAS Three-Tier Operational Control Loops[/bold cyan]")
        )
        string_console.print(f"\n{data.get('overview', '')}\n")
        for loop in data.get("loops", []):
            table = Table(
                title=f"{loop.get('name')} Loop",
                show_header=True,
                header_style="bold magenta",
            )
            table.add_column("Category", style="bold", width=20)
            table.add_column("Details", width=90)
            table.add_row("Purpose", loop.get("purpose", ""))
            table.add_row(
                "Key Mechanisms",
                "\n".join(f"• {m}" for m in loop.get("mechanisms", [])),
            )
            table.add_row("CLI Gates", ", ".join(loop.get("cli_gates", [])))
            table.add_row("Governed Artifacts", ", ".join(loop.get("artifacts", [])))
            string_console.print(table)
            string_console.print("")

    elif target == "flows":
        table = Table(
            title=f"Registered Flows ({data.get('total_flows', 0)} total)",
            show_header=True,
            header_style="bold cyan",
        )
        table.add_column("Flow Name", style="bold green", width=35)
        table.add_column("Steps", justify="right", width=8)
        table.add_column("Step Sequence", style="white", width=70)
        for f in data.get("flows", []):
            table.add_row(
                f.get("name"), str(f.get("step_count")), " → ".join(f.get("steps", []))
            )
        string_console.print(table)

    elif target == "flow":
        string_console.print(
            Panel.fit(
                f"[bold green]Flow: {data.get('name')}[/bold green] (Total Steps: {data.get('step_count')})"
            )
        )
        table = Table(
            title="Execution Steps", show_header=True, header_style="bold cyan"
        )
        table.add_column("#", justify="right", width=5)
        table.add_column("Step Name", style="bold white", width=50)
        for idx, step in enumerate(data.get("steps", []), 1):
            table.add_row(str(idx), step)
        string_console.print(table)

    elif target == "pattern":
        string_console.print(
            Panel.fit(
                f"[bold cyan]Pattern: {data.get('id')}[/bold cyan] [green]({data.get('status', 'ratified')})[/green]"
            )
        )
        string_console.print(
            f"\n[bold]Description:[/bold]\n{data.get('description', '')}\n"
        )

        inv_table = Table(
            title="Invariants (Mandatory Structural Rules)",
            show_header=True,
            header_style="bold green",
        )
        inv_table.add_column("#", justify="right", width=5)
        inv_table.add_column("Invariant", width=105)
        for idx, inv in enumerate(data.get("invariants", []), 1):
            inv_table.add_row(str(idx), inv)
        string_console.print(inv_table)
        string_console.print("")

        anti_table = Table(
            title="Anti-Patterns (Explicitly Forbidden)",
            show_header=True,
            header_style="bold red",
        )
        anti_table.add_column("#", justify="right", width=5)
        anti_table.add_column("Anti-Pattern", width=105)
        for idx, anti in enumerate(data.get("anti_patterns", []), 1):
            anti_table.add_row(str(idx), anti)
        string_console.print(anti_table)

    elif target in ("sdlc", "ai-native-sdlc"):
        string_console.print(
            Panel.fit("[bold cyan]The 6-Stage AI-Native SDLC Contract[/bold cyan]")
        )
        table = Table(
            title="SDLC Stages & Governance Gates",
            show_header=True,
            header_style="bold magenta",
        )
        table.add_column("Stage", justify="center", width=8)
        table.add_column("Name", style="bold green", width=25)
        table.add_column("Gate Checks", width=25)
        table.add_column("Routing Classification", width=28)
        table.add_column("Verification Tools", style="cyan", width=28)
        for s in data.get("stages", []):
            table.add_row(
                str(s.get("stage_number")),
                s.get("stage_name"),
                "\n".join(s.get("gate_checks", [])),
                s.get("routing_classification"),
                ", ".join(s.get("verification_tools", [])),
            )
        string_console.print(table)

    elif target == "adrs":
        string_console.print(
            Panel.fit(
                f"[bold cyan]Unified ADR Knowledge Index[/bold cyan] (Global: {data.get('global_count', 0)}, Project: {data.get('project_count', 0)})"
            )
        )
        string_console.print(
            f"[dim]Workspace: {data.get('workspace_path', '')}[/dim]\n"
        )
        table = Table(
            title="Decisions Registry", show_header=True, header_style="bold cyan"
        )
        table.add_column("ID", style="bold green", width=38)
        table.add_column("Scope", justify="center", width=10)
        table.add_column("Status", justify="center", width=12)
        table.add_column("Date", justify="center", width=12)
        table.add_column("Target", width=32)
        table.add_column("Rationale Summary", width=40)
        for a in data.get("adrs", []):
            table.add_row(
                a.get("id"),
                a.get("scope"),
                a.get("status"),
                a.get("date"),
                a.get("decision_target") or "—",
                a.get("rationale") or "—",
            )
        string_console.print(table)

    elif target == "adr":
        string_console.print(
            Panel.fit(
                f"[bold cyan]Decision Record: {data.get('id')}[/bold cyan] [green]({data.get('status')})[/green]"
            )
        )
        table = Table(show_header=False, box=None)
        table.add_column("Field", style="bold magenta", width=20)
        table.add_column("Value", width=95)
        table.add_row("Title", data.get("title", ""))
        table.add_row("Scope", data.get("scope", ""))
        table.add_row("Status", data.get("status", ""))
        table.add_row("Date", data.get("date", ""))
        table.add_row("Target", data.get("decision_target") or "—")
        table.add_row("File Path", data.get("file_path", ""))
        table.add_row("Rationale", data.get("rationale", ""))
        string_console.print(table)

    return buf.getvalue()


def render_output(payload: dict[str, Any], output_format: str = "text") -> str:
    """Format payload according to requested format."""
    if output_format == "json":
        return render_json(payload)
    elif output_format == "markdown":
        return render_markdown(payload)
    return render_text(payload)


def run_explain(
    target: str = "overview",
    identifier: str | None = None,
    output_format: str = "text",
    target_dir: str | Path | None = None,
) -> int:
    """Main CLI execution router for cas explain."""
    norm_target = (target or "overview").strip().lower()

    try:
        if norm_target in ("overview", ""):
            data = explain_overview(target_dir)
            resolved_target = "overview"
        elif norm_target in ("control-loops", "control_loops", "loops"):
            data = explain_control_loops(target_dir)
            resolved_target = "control-loops"
        elif norm_target in ("flows", "flow_list"):
            data = explain_flows(target_dir)
            resolved_target = "flows"
        elif norm_target == "flow":
            if not identifier:
                print(
                    "[CAS][ERROR] Missing flow name. Usage: cas explain flow <name>",
                    file=sys.stderr,
                )
                return 1
            data = explain_flow(identifier, target_dir)
            resolved_target = "flow"
        elif norm_target == "pattern":
            if not identifier:
                print(
                    "[CAS][ERROR] Missing pattern ID. Usage: cas explain pattern <id>",
                    file=sys.stderr,
                )
                return 1
            data = explain_pattern(identifier, target_dir)
            resolved_target = "pattern"
        elif norm_target in ("sdlc", "ai-native-sdlc"):
            data = explain_sdlc(target_dir)
            resolved_target = "sdlc"
        elif norm_target in ("adrs", "decisions"):
            data = explain_adrs(target_dir)
            resolved_target = "adrs"
        elif norm_target in ("adr", "decision"):
            if not identifier:
                print(
                    "[CAS][ERROR] Missing ADR ID. Usage: cas explain adr <id>",
                    file=sys.stderr,
                )
                return 1
            data = explain_adr(identifier, target_dir)
            resolved_target = "adr"
        else:
            # Check if user typed a flow name, pattern id, or adr directly as target
            if norm_target in FLOWS:
                data = explain_flow(norm_target, target_dir)
                resolved_target = "flow"
            else:
                patterns = load_patterns_catalogue()
                pat_ids = [p.get("id") for p in patterns if "id" in p]
                if norm_target in pat_ids:
                    data = explain_pattern(norm_target, target_dir)
                    resolved_target = "pattern"
                else:
                    valid_targets = [
                        "overview",
                        "control-loops",
                        "flows",
                        "flow",
                        "pattern",
                        "sdlc",
                        "adrs",
                        "adr",
                    ]
                    matches = find_close_matches(
                        norm_target, valid_targets + list(FLOWS.keys())
                    )
                    suggestion = (
                        f" Did you mean: {', '.join(matches)}?" if matches else ""
                    )
                    print(
                        f"[CAS][ERROR] Unknown explain target '{target}'.{suggestion}\nSupported targets: {', '.join(valid_targets)}",
                        file=sys.stderr,
                    )
                    return 1

        payload = {
            "target": resolved_target,
            "format": output_format,
            "timestamp": datetime.now(UTC).isoformat(),
            "query": identifier,
            "data": data,
        }

        output = render_output(payload, output_format=output_format)
        print(output)
        return 0

    except KeyError as e:
        print(f"[CAS][ERROR] {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[CAS][ERROR] Failed to execute explain: {e}", file=sys.stderr)
        return 1
