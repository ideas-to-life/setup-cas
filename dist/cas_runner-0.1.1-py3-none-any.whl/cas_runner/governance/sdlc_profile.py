from __future__ import annotations

import fnmatch
import re
import subprocess
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml

VALID_PROFILES = ("auto", "speckit", "anthropic-native", "superpowers", "agent-skills")
CANONICAL_PLAN_CONCERNS = ("files_that_change", "order_of_work", "risks", "proof")

DEFAULT_SDLC_PROFILE_YAML = """# CAS Pluggable SDD/TDD Profile Configuration
# Resolves canonical lifecycle artifacts (intent, spec, plan, tasks, tests) across
# Speckit, Anthropic Playbook Native, Superpowers, and Agent-Skills workflows.
version: "1.0"
active_profile: auto # auto | speckit | anthropic-native | superpowers | agent-skills
enforcement: strict  # strict | advisory

auto_precedence:
  - speckit
  - anthropic-native
  - superpowers
  - agent-skills

profiles:
  speckit:
    artifacts:
      intent:
        - "specs/*-*/intent.md"
        - ".specify/assessments/*/intake.md"
        - ".specify/assessments/*/decision.md"
      spec:
        - "specs/*-*/spec.md"
      plan:
        - "specs/*-*/plan.md"
      tasks:
        - "specs/*-*/tasks.md"
      tests:
        - "tests/**/test_*.py"
        - "tests/**/*_test.py"
    plan_required_sections:
      files_that_change:
        - "Files that change"
        - "Project Structure"
        - "Source Code"
        - "Affected CAS Surfaces"
      order_of_work:
        - "Order of work"
        - "Phases"
        - "Implementation"
        - "Tasks"
      risks:
        - "Risks"
        - "Constitution Check"
        - "Complexity Tracking"
        - "Constraints"
      proof:
        - "Proof"
        - "Verification"
        - "Testing"
        - "Quickstart"

  anthropic-native:
    artifacts:
      intent:
        - "intent.md"
        - "specs/*/intent.md"
      spec:
        - "spec.md"
        - "specs/*/spec.md"
      plan:
        - "plan.md"
        - "specs/*/plan.md"
      tasks:
        - "tasks.md"
        - "plan.md"
      tests:
        - "tests/**/test_*.py"
        - "tests/**/*_test.py"
    plan_required_sections:
      files_that_change:
        - "Files that change"
        - "Project Structure"
      order_of_work:
        - "Order of work"
        - "Steps"
        - "Phases"
      risks:
        - "Risks"
        - "Trade-offs"
      proof:
        - "Proof"
        - "Verification"

  superpowers:
    artifacts:
      intent:
        - "docs/plans/*-design.md"
      spec:
        - "docs/plans/*-design.md"
      plan:
        - "docs/plans/*-plan.md"
        - "docs/plans/*.md"
      tasks:
        - "docs/plans/*-plan.md"
        - "docs/plans/*.md"
      tests:
        - "tests/**/test_*.py"
        - "tests/**/*_test.py"
    plan_required_sections:
      files_that_change:
        - "Files"
        - "Files that change"
        - "Architecture"
      order_of_work:
        - "Tasks"
        - "Task 1"
        - "Order of work"
        - "Steps"
      risks:
        - "Risks"
        - "Constraints"
        - "Trade-offs"
      proof:
        - "Verification"
        - "Proof"
        - "Testing"

  agent-skills:
    artifacts:
      intent:
        - "docs/specs/*-intent.md"
        - "docs/specs/*.md"
      spec:
        - "docs/specs/*-spec.md"
        - "docs/specs/*.md"
      plan:
        - "docs/plans/*-plan.md"
        - "docs/plans/*.md"
      tasks:
        - "docs/plans/*-tasks.md"
        - "docs/plans/*-plan.md"
      tests:
        - "tests/**/test_*.py"
        - "tests/**/*_test.py"
    plan_required_sections:
      files_that_change:
        - "Files that change"
        - "Files"
        - "Modules"
      order_of_work:
        - "Order of work"
        - "Tasks"
        - "Slices"
      risks:
        - "Risks"
        - "Assumptions"
        - "Trade-offs"
      proof:
        - "Proof"
        - "Verification"
        - "Tests"
"""


@dataclass
class SDLCProfileSpec:
    """Declarative specification for a single SDD/TDD profile."""

    name: str
    artifacts: dict[str, list[str]] = field(default_factory=dict)
    plan_required_sections: dict[str, list[str]] = field(default_factory=dict)


@dataclass
class SDLCProfileConfig:
    """Typed representation of SDLC profile configuration within .cas/config.yaml."""

    version: str = "1.0"
    active_profile: str = "auto"
    enforcement: str = "strict"
    auto_precedence: list[str] = field(
        default_factory=lambda: [
            "speckit",
            "anthropic-native",
            "superpowers",
            "agent-skills",
        ]
    )
    profiles: dict[str, SDLCProfileSpec] = field(default_factory=dict)


@dataclass
class ResolvedSDLCArtifacts:
    """Resolved lifecycle artifacts and plan section completeness for an active change."""

    profile_name: str
    detection_source: str
    feature_dir: str | None = None
    intent_files: list[str] = field(default_factory=list)
    spec_files: list[str] = field(default_factory=list)
    plan_files: list[str] = field(default_factory=list)
    tasks_files: list[str] = field(default_factory=list)
    test_files: list[str] = field(default_factory=list)
    missing_plan_sections: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def render_sdlc_profile_yaml(
    active_profile: str = "auto", enforcement: str = "strict"
) -> str:
    """Renders SDLC profile section in YAML format."""
    profile_val = active_profile if active_profile in VALID_PROFILES else "auto"
    enforcement_val = enforcement if enforcement in ("strict", "advisory") else "strict"
    text = re.sub(
        r"^active_profile:\s*\S+",
        f"active_profile: {profile_val}",
        DEFAULT_SDLC_PROFILE_YAML,
        count=1,
        flags=re.MULTILINE,
    )
    text = re.sub(
        r"^enforcement:\s*\S+",
        f"enforcement: {enforcement_val}",
        text,
        count=1,
        flags=re.MULTILINE,
    )
    return text


class SDLCProfileResolver:
    """
    Framework-agnostic SDD/TDD artifact resolver.
    Maps Speckit, Anthropic-Native, Superpowers, and Agent-Skills artifacts to canonical CAS slots.
    """

    def __init__(
        self,
        target_dir: str | Path = ".",
        profile_override: str | None = None,
    ):
        self.target_path = Path(target_dir).resolve()
        self.profile_override = profile_override
        self.config = self._load_config()

    def _load_config(self) -> SDLCProfileConfig:
        from cas_runner.config import load_config

        cli_overrides = {}
        if self.profile_override:
            cli_overrides["active_profile"] = self.profile_override

        effective = load_config(target_dir=self.target_path, cli_overrides=cli_overrides)
        gov = effective.config.governance

        profiles: dict[str, SDLCProfileSpec] = {}
        for name, spec in gov.profiles.items():
            profiles[name] = SDLCProfileSpec(
                name=name,
                artifacts={k: list(v) for k, v in spec.artifacts.items()},
                plan_required_sections={
                    k: list(v) for k, v in spec.plan_required_sections.items()
                },
            )

        active = self.profile_override or gov.active_profile
        if active not in VALID_PROFILES:
            active = "auto"

        return SDLCProfileConfig(
            version=effective.config.version,
            active_profile=active,
            enforcement=gov.enforcement,
            auto_precedence=[str(p) for p in gov.auto_precedence if str(p) in profiles],
            profiles=profiles,
        )

    def resolve(
        self,
        changed_files: list[str] | None = None,
        branch_name: str | None = None,
    ) -> ResolvedSDLCArtifacts:
        """
        Resolves the active SDLC profile and maps concrete artifact paths for intent, spec, plan, tasks, and tests.
        """
        diff_files = (
            [self._normalize_rel(f) for f in changed_files]
            if changed_files is not None
            else self.get_git_changed_files()
        )
        branch = branch_name if branch_name is not None else self.get_git_branch()

        active_profile = self.profile_override or self.config.active_profile
        detection_source = "explicit"

        if active_profile == "auto":
            detected_profile, detection_source = self._detect_profile_auto(
                diff_files, branch
            )
        else:
            detected_profile = active_profile

        profile_spec = self.config.profiles.get(
            detected_profile, self.config.profiles["speckit"]
        )

        feature_dir = self._resolve_feature_dir(detected_profile, diff_files, branch)
        intent_files = self._collect_slot_files(
            profile_spec, "intent", diff_files, feature_dir
        )
        spec_files = self._collect_slot_files(
            profile_spec, "spec", diff_files, feature_dir
        )
        plan_files = self._collect_slot_files(
            profile_spec, "plan", diff_files, feature_dir
        )
        tasks_files = self._collect_slot_files(
            profile_spec, "tasks", diff_files, feature_dir
        )
        test_files = self._collect_slot_files(profile_spec, "tests", diff_files, None)

        missing_sections: list[str] = []
        if plan_files:
            primary_plan = self.target_path / plan_files[0]
            if primary_plan.exists():
                missing_sections = self.validate_plan_sections(
                    primary_plan, profile_spec
                )

        return ResolvedSDLCArtifacts(
            profile_name=detected_profile,
            detection_source=detection_source,
            feature_dir=feature_dir,
            intent_files=intent_files,
            spec_files=spec_files,
            plan_files=plan_files,
            tasks_files=tasks_files,
            test_files=test_files,
            missing_plan_sections=missing_sections,
        )

    def _detect_profile_auto(
        self, diff_files: list[str], branch: str | None
    ) -> tuple[str, str]:
        # 1. Diff-first detection using explicit profile discriminators in precedence order
        if diff_files:
            for prof_name in self.config.auto_precedence:
                if self._diff_matches_profile(prof_name, diff_files):
                    return prof_name, "diff"

        # 2. Branch-name match for speckit (`specs/<branch>`)
        if branch and (self.target_path / "specs" / branch).is_dir():
            return "speckit", "branch"

        # 3. Fallback: inspect existing files on disk in precedence order
        for prof_name in self.config.auto_precedence:
            spec = self.config.profiles[prof_name]
            if self._disk_has_profile_artifacts(prof_name, spec):
                return prof_name, "fallback"

        return "speckit", "fallback"

    def _diff_matches_profile(self, prof_name: str, diff_files: list[str]) -> bool:
        if prof_name == "speckit":
            return any(
                f.startswith("specs/") or f.startswith(".specify/") for f in diff_files
            )
        if prof_name == "anthropic-native":
            return any(
                f in ("intent.md", "spec.md", "plan.md", "tasks.md") for f in diff_files
            )
        if prof_name == "superpowers":
            has_docs_specs = any(f.startswith("docs/specs/") for f in diff_files)
            if has_docs_specs:
                return False
            return any(f.startswith("docs/plans/") for f in diff_files)
        if prof_name == "agent-skills":
            return any(f.startswith("docs/specs/") for f in diff_files)

        spec = self.config.profiles.get(prof_name)
        if not spec:
            return False
        for slot in ("spec", "plan", "intent"):
            for pattern in spec.artifacts.get(slot, []):
                if any(self._match_glob(f, pattern) for f in diff_files):
                    return True
        return False

    def _disk_has_profile_artifacts(
        self, prof_name: str, spec: SDLCProfileSpec
    ) -> bool:
        if prof_name == "speckit":
            specs_dir = self.target_path / "specs"
            return specs_dir.is_dir() and any(specs_dir.glob("*-*/spec.md"))
        if prof_name == "anthropic-native":
            return (self.target_path / "spec.md").is_file() or (
                self.target_path / "plan.md"
            ).is_file()
        if prof_name == "superpowers":
            plans_dir = self.target_path / "docs" / "plans"
            return plans_dir.is_dir() and any(plans_dir.glob("*-design.md"))
        if prof_name == "agent-skills":
            specs_dir = self.target_path / "docs" / "specs"
            return specs_dir.is_dir() and any(specs_dir.glob("*.md"))
        return False

    def _resolve_feature_dir(
        self, prof_name: str, diff_files: list[str], branch: str | None
    ) -> str | None:
        if prof_name != "speckit":
            return None

        # 1. Check diff for specs/<feature-dir>/...
        for f in diff_files:
            parts = Path(f).parts
            if len(parts) >= 2 and parts[0] == "specs":
                candidate = self.target_path / "specs" / parts[1]
                if candidate.is_dir():
                    return f"specs/{parts[1]}"

        # 2. Check .specify/feature.json if present
        feature_json = self.target_path / ".specify" / "feature.json"
        if feature_json.is_file():
            try:
                import json

                data = json.loads(feature_json.read_text(encoding="utf-8"))
                fdir = data.get("feature_directory")
                if isinstance(fdir, str) and (self.target_path / fdir).is_dir():
                    return fdir
            except Exception:
                pass

        # 3. Check branch name
        if branch and (self.target_path / "specs" / branch).is_dir():
            return f"specs/{branch}"

        # 4. Fallback to highest numbered / most recently modified specs/* directory
        specs_root = self.target_path / "specs"
        if specs_root.is_dir():
            subdirs = sorted([d for d in specs_root.iterdir() if d.is_dir()])
            if subdirs:
                return f"specs/{subdirs[-1].name}"
        return None

    def _collect_slot_files(
        self,
        profile_spec: SDLCProfileSpec,
        slot: str,
        diff_files: list[str],
        feature_dir: str | None,
    ) -> list[str]:
        patterns = profile_spec.artifacts.get(slot, [])
        if not patterns:
            return []

        matched: list[str] = []

        # 1. Prefer files present in diff_files that match the slot globs (in pattern priority order)
        for pat in patterns:
            for f in diff_files:
                if feature_dir and slot in ("intent", "spec", "plan", "tasks"):
                    if f.startswith("specs/") and not f.startswith(f"{feature_dir}/"):
                        continue
                if (
                    slot == "plan"
                    and f.endswith("-design.md")
                    and pat == "docs/plans/*.md"
                ):
                    continue
                if self._match_glob(f, pat):
                    if f not in matched and (self.target_path / f).exists():
                        matched.append(f)

        # 2. If feature_dir is known (Speckit), also resolve sibling artifacts in that feature_dir
        if feature_dir and slot in ("intent", "spec", "plan", "tasks"):
            fdir_path = self.target_path / feature_dir
            if fdir_path.is_dir():
                slot_filename = f"{slot}.md"
                candidate_rel = f"{feature_dir}/{slot_filename}"
                if (
                    self.target_path / candidate_rel
                ).is_file() and candidate_rel not in matched:
                    matched.append(candidate_rel)

        # 3. Otherwise scan disk for matching files
        if not matched:
            for pat in patterns:
                for p in sorted(self.target_path.glob(pat)):
                    if p.is_file():
                        rel = self._normalize_rel(str(p.relative_to(self.target_path)))
                        if feature_dir and slot in ("intent", "spec", "plan", "tasks"):
                            if rel.startswith("specs/") and not rel.startswith(
                                f"{feature_dir}/"
                            ):
                                continue
                        if rel not in matched:
                            matched.append(rel)

        return matched

    def validate_plan_sections(
        self, plan_path: Path, profile_spec: SDLCProfileSpec
    ) -> list[str]:
        """
        Verifies that the plan markdown file contains headings satisfying all 4 canonical plan concerns:
        files_that_change, order_of_work, risks, and proof.
        """
        content = plan_path.read_text(encoding="utf-8", errors="ignore")
        headings = [
            m.group(1).strip().lower()
            for m in re.finditer(r"^#{1,4}\s+(.+)$", content, flags=re.MULTILINE)
        ]

        missing: list[str] = []
        for concern in CANONICAL_PLAN_CONCERNS:
            aliases = profile_spec.plan_required_sections.get(concern, [concern])
            satisfied = False
            for alias in aliases:
                alias_lower = alias.strip().lower()
                if any(alias_lower in h for h in headings):
                    satisfied = True
                    break
            if not satisfied:
                missing.append(concern)
        return missing

    def get_plan_files_section_text(
        self, plan_path: Path, profile_spec: SDLCProfileSpec | None = None
    ) -> str:
        """
        Extracts the raw text content of the 'Files that change' section from the plan.
        """
        if not plan_path.is_file():
            return ""
        content = plan_path.read_text(encoding="utf-8", errors="ignore")
        lines = content.splitlines()

        aliases = [
            "files that change",
            "project structure",
            "source code",
            "affected cas surfaces",
            "files",
        ]
        if profile_spec and "files_that_change" in profile_spec.plan_required_sections:
            aliases = [
                a.lower()
                for a in profile_spec.plan_required_sections["files_that_change"]
            ]

        in_section = False
        section_lines: list[str] = []
        section_level = 2

        for line in lines:
            header_match = re.match(r"^(#{1,4})\s+(.+)$", line)
            if header_match:
                level = len(header_match.group(1))
                title = header_match.group(2).strip().lower()
                if in_section:
                    if level <= section_level:
                        break
                if any(alias in title for alias in aliases):
                    in_section = True
                    section_level = level
                    continue
            elif in_section:
                section_lines.append(line)

        return "\n".join(section_lines)

    @staticmethod
    def _match_glob(rel_path: str, pattern: str) -> bool:
        if fnmatch.fnmatch(rel_path, pattern):
            return True
        if "**/" in pattern:
            collapsed = pattern.replace("**/", "")
            if fnmatch.fnmatch(rel_path, collapsed):
                return True
        return False

    @staticmethod
    def _normalize_rel(path_str: str) -> str:
        return path_str.strip().lstrip("./").replace("\\", "/")

    def get_git_changed_files(self, base_ref: str | None = None) -> list[str]:
        changed: set[str] = set()
        try:
            if base_ref:
                res = subprocess.run(
                    ["git", "diff", "--name-only", f"{base_ref}...HEAD"],
                    cwd=self.target_path,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if res.returncode == 0:
                    for line in res.stdout.splitlines():
                        if line.strip():
                            changed.add(self._normalize_rel(line))

            # Also include staged and unstaged working tree modifications
            for cmd in (
                ["git", "diff", "--name-only", "HEAD"],
                ["git", "diff", "--name-only", "--cached"],
                ["git", "ls-files", "--others", "--exclude-standard"],
            ):
                res = subprocess.run(
                    cmd,
                    cwd=self.target_path,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if res.returncode == 0:
                    for line in res.stdout.splitlines():
                        if line.strip():
                            changed.add(self._normalize_rel(line))
        except Exception:
            pass
        return sorted(changed)

    def get_git_branch(self) -> str | None:
        try:
            res = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=self.target_path,
                capture_output=True,
                text=True,
                check=False,
            )
            if res.returncode == 0 and res.stdout.strip():
                return res.stdout.strip()
        except Exception:
            pass
        return None
