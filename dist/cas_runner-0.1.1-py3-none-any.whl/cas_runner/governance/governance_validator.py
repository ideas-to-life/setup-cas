import json
from pathlib import Path
from typing import Any

import jsonschema
import yaml

from ..io import get_provider, get_workspace_root


class GovernanceValidator:
    """
    Automated governance validation engine for CAS.
    Validates structural integrity, traceability, lifecycle, and governance state.
    """

    def __init__(self, project: str):
        self.project = project
        self.provider = get_provider()
        self.workspace_root = get_workspace_root()
        self.schema_dir = Path(__file__).parent.parent / "schemas"
        self.metrics_obj = None
        self.report = {
            "status": "pass",
            "errors": [],
            "warnings": [],
            "summary": {
                "proposals": 0,
                "recommendations": 0,
                "decisions": 0,
                "adrs": 0,
                "patterns": 0
            },
            "findings": []
        }

    def _load_schema(self, schema_name: str) -> dict[str, Any]:
        schema_path = self.schema_dir / schema_name
        if not schema_path.exists():
            raise FileNotFoundError(f"Schema not found: {schema_path}")
        with open(schema_path) as f:
            return json.load(f)

    def validate(self) -> dict[str, Any]:
        """Runs the full governance validation suite."""
        print(f"[CAS][GOVERNANCE] Starting validation for project: {self.project}")

        # 1. Discover and Load Artifacts
        self.artifacts = self._discover_artifacts()

        # 2. Schema Validation
        self._validate_schemas(self.artifacts)

        # 3. Traceability Validation
        self._validate_traceability(self.artifacts)

        # 4. Lifecycle Validation
        self._validate_lifecycle(self.artifacts)

        # 5. Governance State Validation
        self._validate_governance_state(self.artifacts)

        # 6. Compliance Validation
        from .compliance_engine import ComplianceEngine
        compliance_engine = ComplianceEngine(self.project)
        comp_findings, comp_metrics = compliance_engine.evaluate(self.artifacts)

        # Merge compliance findings into report
        from dataclasses import asdict
        for f in comp_findings:
            self._add_finding(f.severity, f"compliance_{f.validation_type}", f.description)

        self.report["compliance"] = {
            "metrics": asdict(comp_metrics),
            "findings": [asdict(f) for f in comp_findings]
        }
        compliance_engine.save_report(comp_metrics)

        # 7. Finalize Status
        if self.report["errors"]:
            self.report["status"] = "fail"

        # 8. Calculate Metrics
        from .governance_metrics import GovernanceMetricsEngine
        engine = GovernanceMetricsEngine(self.project, self.artifacts, self.report)
        metrics = engine.calculate()
        metrics.compliance = comp_metrics # Inject compliance metrics
        self.metrics_obj = metrics
        self.report["metrics"] = asdict(metrics)

        return self.report

    def _discover_artifacts(self) -> dict[str, list[dict[str, Any]]]:
        """Discovers all governance artifacts for the project."""
        # Use a more comprehensive discovery than the provider's default methods
        # which might filter by status.

        discovery = {
            "proposals": self.provider.load_pattern_proposals(self.project),
            "recommendations": self._load_all_recommendations(),
            "decisions": self._load_all_decisions(),
            "adrs": self._load_all_adrs(),
            "patterns": self._load_all_patterns()
        }

        self.report["summary"]["proposals"] = len(discovery["proposals"])
        self.report["summary"]["recommendations"] = len(discovery["recommendations"])
        self.report["summary"]["decisions"] = len(discovery["decisions"])
        self.report["summary"]["adrs"] = len(discovery["adrs"])
        self.report["summary"]["patterns"] = len(discovery["patterns"])

        return discovery

    def _load_all_recommendations(self) -> list[dict[str, Any]]:
        # Usually stored in a single YAML/JSON file per project
        path = self.workspace_root / "projects" / self.project / "governance" / "pattern-promotion-recommendations.yaml"
        if path.exists():
            with open(path) as f:
                data = yaml.safe_load(f)
                if data: return [data]
        return []

    def _load_all_decisions(self) -> list[dict[str, Any]]:
        directory = self.workspace_root / "projects" / self.project / "governance" / "promotion-decisions"
        if not directory.exists(): return []
        decisions = []
        for f in directory.glob("*.yaml"):
            with open(f) as fh:
                decisions.append(yaml.safe_load(fh))
        return decisions

    def _load_all_adrs(self) -> list[dict[str, Any]]:
        directory = self.workspace_root / "projects" / self.project / "adrs"
        if not directory.exists(): return []
        adrs = []
        for f in directory.glob("*.md"):
            # Use private method from provider if available or implement basic parsing
            # For simplicity, we implement basic parsing here
            adrs.append(self._parse_md(f))
        return adrs

    def _load_all_patterns(self) -> list[dict[str, Any]]:
        patterns = []
        seen_ids = set()

        # 1. Project-specific patterns
        directory = self.workspace_root / "projects" / self.project / "patterns"
        if directory.exists():
            for f in directory.glob("*.md"):
                pat = self._parse_md(f)
                pat_id = pat.get("id")
                if pat_id:
                    seen_ids.add(pat_id)
                patterns.append(pat)

        # 2. Global patterns associated with this project
        global_dir = self.workspace_root / "global" / "patterns"
        if global_dir.exists():
            project_adrs_dir = self.workspace_root / "projects" / self.project / "adrs"
            project_adr_ids = set()
            if project_adrs_dir.exists():
                for f in project_adrs_dir.glob("*.md"):
                    project_adr_ids.add(f.stem)
                    project_adr_ids.add(f.stem.removeprefix("adr-"))

            for f in global_dir.glob("*.md"):
                if f.name.startswith(".") or f.name.lower() == "readme.md":
                    continue
                pat = self._parse_md(f)
                pat_id = pat.get("id")
                if pat_id and pat_id in seen_ids:
                    continue

                pat_project = pat.get("project")
                pat_adr = pat.get("source_traceability", {}).get("architecture_decision_record")

                is_project_pattern = (
                    pat_project == self.project
                    or (pat_adr and (pat_adr in project_adr_ids or pat_adr.removeprefix("adr-") in project_adr_ids))
                )
                if is_project_pattern:
                    if pat_id:
                        seen_ids.add(pat_id)
                    patterns.append(pat)

        return patterns


    def _parse_md(self, path: Path) -> dict[str, Any]:
        content = path.read_text()
        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                _, yaml_block, body = parts
                data = yaml.safe_load(yaml_block) or {}
                data["_path"] = str(path)

                # Extract sections from body to align with canonical schema
                sections = {}
                current_section = None
                for line in body.split("\n"):
                    if line.startswith("## ") or line.startswith("# "):
                        level = 3 if line.startswith("## ") else 2
                        current_section = line[level:].lower().replace(" ", "_").strip()
                        sections[current_section] = ""
                    elif current_section:
                        sections[current_section] += line + "\n"

                # Canonical schemas expect sections to be objects with a 'summary' property
                # when they are strings in the markdown projection.
                inflated_sections = {}
                for k, v in sections.items():
                    v_clean = v.strip()
                    if v_clean:
                        inflated_sections[k] = {"summary": v_clean}

                data["sections"] = inflated_sections
                return data
        return {"_path": str(path), "sections": {}}

    def _validate_schemas(self, artifacts: dict[str, list[dict[str, Any]]]):
        """Validates all discovered artifacts against their schemas."""
        print("[CAS][GOVERNANCE] Validating schemas...")

        schema_map = {
            "proposals": "pattern_proposal_schema.json",
            "recommendations": "pattern_promotion_recommendation_schema.json",
            "decisions": "promotion_decision_schema.json",
            "adrs": "architecture_decision_record_schema.json",
            "patterns": "pattern_schema.json"
        }

        for category, schema_file in schema_map.items():
            try:
                schema = self._load_schema(schema_file)
                allowed_properties = set(schema.get("properties", {}).keys())
                section_properties = set(schema.get("properties", {}).get("sections", {}).get("properties", {}).keys())

                for item in artifacts[category]:
                    # Handle Pattern Proposals which is a list in a wrapper
                    if category == "proposals":
                        try:
                            # The schema expects a wrapper object
                            jsonschema.validate(instance={"pattern_proposals": [item]}, schema=schema)
                        except jsonschema.ValidationError as e:
                            self._add_finding("error", "schema_violation", f"Invalid Pattern Proposal {item.get('pattern_id', item.get('id', 'unknown'))}: {e.message}")
                    else:
                        try:
                            # 1. Infer missing mandatory fields if they can be derived from context
                            # This aligns with the 'implemented architecture' where folder structure
                            # and conventions imply certain metadata.
                            if "project" not in item:
                                item["project"] = self.project
                            if "version" not in item:
                                item["version"] = 1
                            if category == "patterns" and "classification" not in item:
                                item["classification"] = "project"

                            # 2. Filter top-level properties to match "canonical" schema
                            val_item = {k: v for k, v in item.items() if k in allowed_properties}

                            # 3. Handle projections vs canonical representations
                            # Projections (Markdown) have narrative sections that don't match
                            # the strict structured schema of the canonical representation.
                            # We remove 'sections' from schema validation for projections and
                            # ensure it's not required for this validation pass.
                            if category in ["adrs", "patterns"]:
                                val_item.pop("sections", None)

                                # Locally remove 'sections' from required list for this item
                                # without modifying the global schema
                                projection_schema = schema.copy()
                                if "required" in projection_schema:
                                    projection_schema["required"] = [
                                        r for r in projection_schema["required"]
                                        if r != "sections"
                                    ]
                                jsonschema.validate(instance=val_item, schema=projection_schema)
                            else:
                                jsonschema.validate(instance=val_item, schema=schema)
                        except jsonschema.ValidationError as e:
                            self._add_finding("error", "schema_violation", f"Invalid {category} artifact {item.get('id', item.get('pattern_id', 'unknown'))}: {e.message}")
            except Exception as e:
                self._add_finding("error", "schema_load_failure", f"Failed to validate {category}: {e}")

    def _validate_traceability(self, artifacts: dict[str, list[dict[str, Any]]]):
        """Ensures governance lineage remains intact."""
        print("[CAS][GOVERNANCE] Validating traceability...")

        # Build indexes for fast lookup
        proposals = {}
        for p in artifacts.get("proposals", []):
            p_id = p.get("pattern_id")
            if not p_id:
                self._add_finding("error", "invalid_artifact", f"Proposal missing pattern_id: {p}")
                p_id = p.get("id")
            if p_id:
                proposals[p_id] = p
                clean_id = p_id.removeprefix("pattern-")
                proposals[clean_id] = p
                proposals[f"pattern-{clean_id}"] = p

        # Recommendations index: allow lookup by both pattern_id and synthetic ID
        # Recommendations live in a shared YAML file with multiple candidate lists
        recommendations = {}
        for r in artifacts.get("recommendations", []):
            for list_key in ["promotion_candidates", "deferred_candidates", "rejected_candidates"]:
                for cand in r.get(list_key, []):
                    p_id = cand.get("pattern_id")
                    if not p_id:
                        self._add_finding("error", "invalid_artifact", f"Recommendation candidate in {list_key} missing pattern_id: {cand}")
                        p_id = cand.get("id")
                    if p_id:
                        recommendations[p_id] = cand
                        recommendations[f"recommendation-{p_id}"] = cand
                        clean_id = p_id.removeprefix("pattern-")
                        recommendations[clean_id] = cand
                        recommendations[f"recommendation-{clean_id}"] = cand

            # Also index duplicate_overlapping_promotion_candidates
            for item in r.get("duplicate_overlapping_promotion_candidates", []):
                for p_id in item.get("patterns_involved", []):
                    recommendations[p_id] = item
                    recommendations[f"recommendation-{p_id}"] = item
                    clean_id = p_id.removeprefix("pattern-")
                    recommendations[clean_id] = item
                    recommendations[f"recommendation-{clean_id}"] = item

            # Also index promotion_preconditions_not_met
            for item in r.get("promotion_preconditions_not_met", []):
                p_id = item.get("pattern_id") or item.get("id")
                if p_id:
                    recommendations[p_id] = item
                    recommendations[f"recommendation-{p_id}"] = item
                    clean_id = p_id.removeprefix("pattern-")
                    recommendations[clean_id] = item
                    recommendations[f"recommendation-{clean_id}"] = item

        decisions = {}
        for d in artifacts.get("decisions", []):
            p_id = d.get("pattern_id")
            if not p_id:
                self._add_finding("error", "invalid_artifact", f"Promotion decision missing pattern_id: {d}")
                p_id = d.get("id")
            if p_id:
                decisions[p_id] = d

        adrs = {a.get("pattern_id"): a for a in artifacts.get("adrs", []) if a.get("pattern_id")}

        # Validate Decisions -> Proposals/Recommendations
        for p_id, decision in decisions.items():
            trace = decision.get("source_traceability", {})

            # Check Proposal ref
            prop_ref = trace.get("pattern_proposal", {}).get("id")
            if not prop_ref or prop_ref not in proposals:
                self._add_finding("error", "broken_reference", f"Decision for {p_id} has broken/missing proposal reference: {prop_ref}")

            # Check Recommendation ref
            rec_ref = trace.get("promotion_recommendation", {}).get("id")
            if not rec_ref or rec_ref not in recommendations:
                self._add_finding("error", "broken_reference", f"Decision for {p_id} has broken/missing recommendation reference: {rec_ref}")

        # Validate ADRs -> Decisions
        for adr in artifacts["adrs"]:
            decision_status = adr.get("decision", {}).get("status")
            if decision_status == "proposed":
                continue

            p_id = adr.get("pattern_id")
            trace = adr.get("source_traceability", {})

            # ADR must reference decision
            dec_ref = trace.get("promotion_decision")
            # Usually decision doesn't have a stable ID other than pattern_id based filename
            # but let's check if it exists in our index
            if not dec_ref or dec_ref not in [d.get("id") for d in artifacts["decisions"]]:
                self._add_finding("error", "broken_reference", f"ADR {adr.get('id')} has broken/missing decision reference: {dec_ref}")

        # Validate Patterns -> ADRs
        valid_adr_ids = set()
        for a in artifacts.get("adrs", []):
            a_id = a.get("id")
            if a_id:
                valid_adr_ids.add(a_id)
                valid_adr_ids.add(a_id.removeprefix("adr-"))
                valid_adr_ids.add(f"adr-{a_id.removeprefix('adr-')}")

        for pattern in artifacts["patterns"]:
            trace = pattern.get("source_traceability", {})
            adr_ref = trace.get("architecture_decision_record")
            if not adr_ref or adr_ref not in valid_adr_ids:
                self._add_finding("error", "broken_reference", f"Pattern {pattern.get('id')} has broken/missing ADR reference: {adr_ref}")

    def _validate_lifecycle(self, artifacts: dict[str, list[dict[str, Any]]]):
        """Ensures governance artifacts respect lifecycle progression."""
        print("[CAS][GOVERNANCE] Validating lifecycle...")

        # ADR Creation Rule: ADR allowed only when Promotion Decision status = accepted
        decisions = {}
        for d in artifacts.get("decisions", []):
            p_id = d.get("pattern_id") or d.get("id")
            if p_id:
                decisions[p_id] = d
        for adr in artifacts["adrs"]:
            decision_status = adr.get("decision", {}).get("status")
            if decision_status == "proposed":
                continue

            p_id = adr.get("pattern_id")
            if p_id in decisions:
                if decisions[p_id].get("decision", {}).get("status") != "accepted":
                    self._add_finding("error", "lifecycle_violation", f"ADR {adr.get('id')} exists for pattern {p_id} but decision is NOT accepted")
            else:
                self._add_finding("warning", "lifecycle_violation", f"ADR {adr.get('id')} exists but no promotion decision found for pattern {p_id}")

        # Pattern Creation Rule: Pattern allowed only when ADR governance.status = approved or forum_status = accepted/conditional
        adrs = {}
        for a in artifacts.get("adrs", []):
            a_id = a.get("id")
            if a_id:
                adrs[a_id] = a
                adrs[a_id.removeprefix("adr-")] = a
                adrs[f"adr-{a_id.removeprefix('adr-')}"] = a

        for pattern in artifacts["patterns"]:
            trace = pattern.get("source_traceability", {})
            adr_id = trace.get("architecture_decision_record")
            if adr_id in adrs:
                adr_gov = adrs[adr_id].get("governance", {})
                forum_status = adr_gov.get("forum_status")
                decision_status = adrs[adr_id].get("decision", {}).get("status")
                top_status = adrs[adr_id].get("status")
                is_accepted = any(
                    s in ["accepted", "approved", "conditional"]
                    for s in [forum_status, decision_status, top_status]
                )
                if not is_accepted:
                    self._add_finding("error", "lifecycle_violation", f"Pattern {pattern.get('id')} exists but ADR {adr_id} is NOT accepted")
            else:
                self._add_finding("error", "lifecycle_violation", f"Pattern {pattern.get('id')} exists but ADR reference {adr_id} is missing or invalid")


    def _validate_governance_state(self, artifacts: dict[str, list[dict[str, Any]]]):
        """Validate governance consistency."""
        print("[CAS][GOVERNANCE] Validating governance state...")

        # Pattern Consistency: governance.status = approved
        for pattern in artifacts["patterns"]:
            if pattern.get("governance", {}).get("status") != "approved":
                self._add_finding("error", "state_inconsistency", f"Institutionalized Pattern {pattern.get('id')} status is NOT approved")

        # ADR Consistency: governance.forum_status
        for adr in artifacts["adrs"]:
            if not adr.get("governance", {}).get("forum_status"):
                self._add_finding("error", "state_inconsistency", f"ADR {adr.get('id')} is missing forum_status")

    def _add_finding(self, severity: str, type: str, message: str):
        finding = {
            "severity": severity,
            "type": type,
            "message": message
        }
        self.report["findings"].append(finding)
        if severity == "error":
            self.report["errors"].append(message)
        else:
            self.report["warnings"].append(message)

    def save_report(self):
        """Saves the governance health report to the knowledge layer."""
        base_dir = self.workspace_root / "global" / "governance"

        # Save Health
        health_dir = base_dir / "health"
        health_dir.mkdir(parents=True, exist_ok=True)

        # Save JSON
        json_path = health_dir / "report.json"
        with open(json_path, "w") as f:
            json.dump(self.report, f, indent=2)

        # Save Markdown
        if self.metrics_obj:
            from .markdown_renderer import render_decision_inbox, render_health_report
            md_content = render_health_report(self.metrics_obj, self.report)
            md_path = health_dir / "index.md"
            with open(md_path, "w") as f:
                f.write(md_content)

            # Generate Decision Inbox
            from .governance_action_service import GovernanceActionService
            action_service = GovernanceActionService(self.project)
            pending_actions = action_service.get_pending_actions(self.artifacts)
            inbox_md = render_decision_inbox(pending_actions)

            inbox_dir = base_dir / "decisions"
            inbox_dir.mkdir(parents=True, exist_ok=True)
            inbox_path = inbox_dir / "index.md"
            with open(inbox_path, "w") as f:
                f.write(inbox_md)

        print(f"[CAS][GOVERNANCE] Health report and Decisions Inbox saved to {base_dir}")
