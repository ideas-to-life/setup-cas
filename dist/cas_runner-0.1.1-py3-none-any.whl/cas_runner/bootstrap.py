import json
import os
import shutil
import stat
from pathlib import Path
from typing import Any

from cas_runner.governance.control_bands import render_bands_yaml
from cas_runner.governance.env_checker import resolve_github_repo_slug
from cas_runner.governance.sdlc_profile import VALID_PROFILES
from cas_runner.io import safe_mkdir

CAS_BEGIN_MARKER = "<!-- CAS-GOVERNANCE:BEGIN -->"
CAS_END_MARKER = "<!-- CAS-GOVERNANCE:END -->"


def merge_cas_governance_block(existing_content: str | None, cas_content: str) -> str:
    """
    Merges CAS governance block into existing file content additively and idempotently.
    """
    formatted_cas_block = (
        f"{CAS_BEGIN_MARKER}\n{cas_content.strip()}\n{CAS_END_MARKER}\n"
    )

    if existing_content is None or not existing_content.strip():
        return formatted_cas_block

    if CAS_BEGIN_MARKER in existing_content and CAS_END_MARKER in existing_content:
        # Replace existing CAS block while preserving all surrounding text
        start_idx = existing_content.find(CAS_BEGIN_MARKER)
        end_idx = existing_content.find(CAS_END_MARKER) + len(CAS_END_MARKER)
        if end_idx < len(existing_content) and existing_content[end_idx] == "\n":
            end_idx += 1

        prefix = existing_content[:start_idx]
        suffix = existing_content[end_idx:]
        return f"{prefix}{formatted_cas_block}{suffix}"

    # Append to existing content cleanly
    separator = "" if existing_content.endswith("\n") else "\n"
    return f"{existing_content}{separator}\n{formatted_cas_block}"


def merge_claude_settings(existing_raw: str | None, template_raw: str) -> str:
    """
    Merges CAS PreToolUse hooks into an existing .claude/settings.json non-destructively.
    """
    try:
        template_data: dict[str, Any] = json.loads(template_raw)
    except Exception:
        template_data = {}

    if not existing_raw or not existing_raw.strip():
        return json.dumps(template_data, indent=2) + "\n"

    try:
        existing_data: dict[str, Any] = json.loads(existing_raw)
        if not isinstance(existing_data, dict):
            return json.dumps(template_data, indent=2) + "\n"
    except Exception:
        return json.dumps(template_data, indent=2) + "\n"

    hooks_section = existing_data.setdefault("hooks", {})
    if not isinstance(hooks_section, dict):
        hooks_section = {}
        existing_data["hooks"] = hooks_section

    pre_tool_list = hooks_section.setdefault("PreToolUse", [])
    if not isinstance(pre_tool_list, list):
        pre_tool_list = []
        hooks_section["PreToolUse"] = pre_tool_list

    existing_commands = set()
    for entry in pre_tool_list:
        if isinstance(entry, dict):
            for h in entry.get("hooks", []):
                if isinstance(h, dict) and h.get("command"):
                    existing_commands.add(h["command"])

    for tmpl_entry in template_data.get("hooks", {}).get("PreToolUse", []):
        if isinstance(tmpl_entry, dict):
            cmds = [
                h.get("command")
                for h in tmpl_entry.get("hooks", [])
                if isinstance(h, dict) and h.get("command")
            ]
            if not any(c in existing_commands for c in cmds):
                pre_tool_list.append(tmpl_entry)

    return json.dumps(existing_data, indent=2) + "\n"


def _create_symlink_or_copy(
    link_path: Path, rel_target: Path, abs_source: Path, force: bool = False
) -> None:
    if force and (link_path.is_symlink() or link_path.exists()):
        if link_path.is_symlink() or link_path.is_file():
            link_path.unlink()
        elif link_path.is_dir():
            shutil.rmtree(link_path)

    if not link_path.exists() and not link_path.is_symlink():
        safe_mkdir(link_path.parent, parents=True, exist_ok=True)
        try:
            link_path.symlink_to(rel_target, target_is_directory=abs_source.is_dir())
        except (OSError, NotImplementedError):
            if abs_source.is_dir():
                shutil.copytree(abs_source, link_path)
            else:
                shutil.copy2(abs_source, link_path)


def bootstrap(
    target_dir: str,
    force: bool = False,
    minimal: bool = False,
    no_ci: bool = False,
    sdlc_profile: str = "auto",
) -> bool:
    """
    Initializes or updates CAS governance substrate in the target directory.
    Default behavior is non-destructive and additive.
    """
    target_path = Path(target_dir).resolve()
    template_base = Path(__file__).parent / "templates" / "onboarding" / "substrate"

    if not template_base.exists():
        print(f"[CAS][ERROR] Substrate templates not found at {template_base}")
        return False

    if sdlc_profile not in VALID_PROFILES:
        print(
            f"[CAS][WARN] Unknown SDLC profile '{sdlc_profile}', defaulting to 'auto'"
        )
        sdlc_profile = "auto"

    print(f"[CAS][INFO] Initializing CAS governance substrate in: {target_path}")

    # Core agent instruction files to integrate
    core_files = [
        "AGENTS.md",
        "GEMINI.md",
        "CLAUDE.md",
        ".github/copilot-instructions.md",
    ]
    skill_dirs = [".cas"]
    ci_dirs = [".github"]

    # Process core guidance files additively unless force is specified
    for filename in core_files:
        src = template_base / filename
        if not src.exists() and filename == ".github/copilot-instructions.md":
            src = template_base / "AGENTS.md"

        dest = target_path / filename
        safe_mkdir(dest.parent, parents=True, exist_ok=True)

        if src.exists():
            template_text = src.read_text(encoding="utf-8")

            if force:
                dest.write_text(
                    merge_cas_governance_block(None, template_text), encoding="utf-8"
                )
                print(f"[CAS][OK] Overwrote {filename} (--force)")
            else:
                existing_text = (
                    dest.read_text(encoding="utf-8") if dest.exists() else None
                )
                merged_text = merge_cas_governance_block(existing_text, template_text)
                dest.write_text(merged_text, encoding="utf-8")
                action = (
                    "Updated"
                    if (existing_text and CAS_BEGIN_MARKER in existing_text)
                    else ("Added CAS block to" if existing_text else "Created")
                )
                print(f"[CAS][OK] {action} {filename}")

    # Provision REVIEW.md multi-pass PR contract
    review_src = template_base / "REVIEW.md"
    review_dest = target_path / "REVIEW.md"
    if review_src.exists():
        if not review_dest.exists() or force:
            review_dest.write_text(
                review_src.read_text(encoding="utf-8"), encoding="utf-8"
            )
            print("[CAS][OK] Provisioned REVIEW.md")

    # Copy portable .cas/ substrate (merging missing subdirectories/files additively when .cas/ already exists)
    for dirname in skill_dirs:
        src = template_base / dirname
        dest = target_path / dirname

        if dest.exists():
            if force:
                shutil.rmtree(dest)
                shutil.copytree(src, dest)
                print(f"[CAS][OK] Updated {dirname}/")
            else:
                # Non-destructively copy any new substrate files (.cas/agents/, .cas/hooks/, .cas/config.yaml)
                for item in src.rglob("*"):
                    rel_item = item.relative_to(src)
                    target_item = dest / rel_item
                    if item.is_dir():
                        safe_mkdir(target_item, parents=True, exist_ok=True)
                    elif not target_item.exists():
                        safe_mkdir(target_item.parent, parents=True, exist_ok=True)
                        shutil.copy2(item, target_item)
                print(f"[CAS][OK] Verified/merged {dirname}/")
        else:
            if src.exists():
                shutil.copytree(src, dest)
                print(f"[CAS][OK] Created {dirname}/")

    target_cas_dir = target_path / ".cas"
    safe_mkdir(target_cas_dir, parents=True, exist_ok=True)

    # Write or update .cas/config.yaml with requested sdlc_profile
    config_path = target_cas_dir / "config.yaml"
    template_config = template_base / ".cas" / "config.yaml"
    if force and template_config.exists():
        cfg_text = template_config.read_text(encoding="utf-8")
        if sdlc_profile != "auto":
            cfg_text = cfg_text.replace(
                'active_profile: "auto"', f'active_profile: "{sdlc_profile}"'
            )
        config_path.write_text(cfg_text, encoding="utf-8")
        print(
            f"[CAS][OK] Provisioned .cas/config.yaml (active_profile: {sdlc_profile})"
        )
    elif config_path.exists() and sdlc_profile != "auto":
        cfg_text = config_path.read_text(encoding="utf-8")
        if 'active_profile: "auto"' in cfg_text:
            cfg_text = cfg_text.replace(
                'active_profile: "auto"', f'active_profile: "{sdlc_profile}"'
            )
            config_path.write_text(cfg_text, encoding="utf-8")
            print(
                f"[CAS][OK] Configured .cas/config.yaml (active_profile: {sdlc_profile})"
            )
    elif not config_path.exists() and template_config.exists():
        cfg_text = template_config.read_text(encoding="utf-8")
        if sdlc_profile != "auto":
            cfg_text = cfg_text.replace(
                'active_profile: "auto"', f'active_profile: "{sdlc_profile}"'
            )
        config_path.write_text(cfg_text, encoding="utf-8")
        print(
            f"[CAS][OK] Provisioned .cas/config.yaml (active_profile: {sdlc_profile})"
        )

    # Write or update .cas/bands.yaml non-destructively (or overwrite on force=True)
    bands_path = target_cas_dir / "bands.yaml"
    if force or not bands_path.exists():
        bands_path.write_text(render_bands_yaml(), encoding="utf-8")
        print("[CAS][OK] Provisioned .cas/bands.yaml")

    # Ensure hook scripts under .cas/hooks/ are executable
    hooks_dir = target_cas_dir / "hooks"
    if hooks_dir.exists():
        for hook_script in hooks_dir.glob("*.sh"):
            current_mode = hook_script.stat().st_mode
            hook_script.chmod(current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    # Provision coding agent skill discovery for both .agents/skills and .claude/skills
    agents_skills_dir = target_path / ".agents" / "skills"
    claude_skills_dir = target_path / ".claude" / "skills"
    safe_mkdir(agents_skills_dir, parents=True, exist_ok=True)
    safe_mkdir(claude_skills_dir, parents=True, exist_ok=True)

    if target_cas_dir.exists():
        for skill_dir in sorted(target_cas_dir.iterdir()):
            if skill_dir.is_dir() and (skill_dir / "SKILL.md").exists():
                rel_skill_target = Path("..") / ".." / ".cas" / skill_dir.name
                _create_symlink_or_copy(
                    agents_skills_dir / skill_dir.name,
                    rel_skill_target,
                    skill_dir,
                    force=force,
                )
                print(
                    f"[CAS][OK] Provisioned agent skill link: .agents/skills/{skill_dir.name}"
                )
                _create_symlink_or_copy(
                    claude_skills_dir / skill_dir.name,
                    rel_skill_target,
                    skill_dir,
                    force=force,
                )
                print(
                    f"[CAS][OK] Provisioned Claude skill link: .claude/skills/{skill_dir.name}"
                )

    # Project Fresh-Context Verifier subagent (.cas/agents/verifier.md -> .claude/agents/verifier.md and .agents/subagents/verifier.md)
    verifier_src = target_cas_dir / "agents" / "verifier.md"
    if verifier_src.exists():
        rel_verifier_target = Path("..") / ".." / ".cas" / "agents" / "verifier.md"
        _create_symlink_or_copy(
            target_path / ".claude" / "agents" / "verifier.md",
            rel_verifier_target,
            verifier_src,
            force=force,
        )
        _create_symlink_or_copy(
            target_path / ".agents" / "subagents" / "verifier.md",
            rel_verifier_target,
            verifier_src,
            force=force,
        )
        print(
            "[CAS][OK] Provisioned Fresh-Context Verifier subagent links (.claude/agents/verifier.md & .agents/subagents/verifier.md)"
        )

    # Provision or non-destructively merge .claude/settings.json
    claude_settings_tmpl = template_base / ".claude" / "settings.json"
    claude_settings_dest = target_path / ".claude" / "settings.json"
    if claude_settings_tmpl.exists():
        safe_mkdir(claude_settings_dest.parent, parents=True, exist_ok=True)
        tmpl_raw = claude_settings_tmpl.read_text(encoding="utf-8")
        if force or not claude_settings_dest.exists():
            claude_settings_dest.write_text(
                merge_claude_settings(None, tmpl_raw), encoding="utf-8"
            )
            print("[CAS][OK] Provisioned .claude/settings.json")
        else:
            existing_raw = claude_settings_dest.read_text(encoding="utf-8")
            claude_settings_dest.write_text(
                merge_claude_settings(existing_raw, tmpl_raw), encoding="utf-8"
            )
            print("[CAS][OK] Merged CAS PreToolUse hooks into .claude/settings.json")

    # Handle CI workflows (unless --no-ci or --minimal is set)
    if not (no_ci or minimal):
        for dirname in ci_dirs:
            src = template_base / dirname
            dest = target_path / dirname

            if src.exists():
                if dest.exists() and not force:
                    print(
                        f"[CAS][INFO] {dirname}/ already exists. Adding CAS workflows..."
                    )
                    workflows_src = src / "workflows"
                    workflows_dest = dest / "workflows"
                    if workflows_src.exists():
                        safe_mkdir(workflows_dest, parents=True, exist_ok=True)
                        for wf in sorted(workflows_src.glob("*.yml")):
                            target_wf = workflows_dest / wf.name
                            if not target_wf.exists() or force:
                                shutil.copy2(wf, target_wf)
                                print(
                                    f"[CAS][OK] Created {target_wf.relative_to(target_path)}"
                                )
                else:
                    if dest.exists() and force:
                        workflows_dir = dest / "workflows"
                        if workflows_dir.exists():
                            shutil.rmtree(workflows_dir)
                    shutil.copytree(src, dest, dirs_exist_ok=True)
                    print(f"[CAS][OK] Created {dirname}/")

    # Provision substrate developer helper scripts (e.g. scripts/install-cas.sh)
    scripts_src_dir = template_base / "scripts"
    scripts_dest_dir = target_path / "scripts"
    if scripts_src_dir.exists():
        safe_mkdir(scripts_dest_dir, parents=True, exist_ok=True)
        for script_file in sorted(scripts_src_dir.glob("*.sh")):
            target_script = scripts_dest_dir / script_file.name
            if force or not target_script.exists():
                shutil.copy2(script_file, target_script)
                target_script.chmod(0o755)
                print(
                    f"[CAS][OK] Provisioned {target_script.relative_to(target_path)} (executable)"
                )
            else:
                target_script.chmod(0o755)

    print("[CAS][SUCCESS] CAS Governance substrate initialized.")
    print(render_onboarding_checklist(target_path))
    return True


def render_onboarding_checklist(target_path: Path) -> str:
    """Renders the post-onboarding GitHub variables and secrets checklist (FR-CLI-001)."""
    repo_slug = resolve_github_repo_slug(target_path)
    secrets_url = f"https://github.com/{repo_slug}/settings/secrets/actions"
    variables_url = f"https://github.com/{repo_slug}/settings/variables/actions"

    return (
        "\n=== CAS Post-Onboarding GitHub Configuration Checklist ===\n"
        f"1. Configure Repository Secrets ({secrets_url}):\n"
        "   - [Required] CAS_KNOWLEDGE_BRAIN : Fine-grained PAT with read/write access to cas-brain/knowledge\n"
        "   - [Required] OPENAI_API_KEY      : API key for OpenAI synthesis/evaluation (when provider=openai)\n"
        "   - [Optional] GEMINI_API_KEY      : API key for Gemini synthesis/evaluation (when provider=gemini)\n"
        "   - [Optional] HF_TOKEN            : Hugging Face token for pattern embeddings\n"
        "   - [Optional] OTEL_EXPORTER_OTLP_HEADERS : Authorization headers for OTLP telemetry\n"
        "\n"
        f"2. Configure Repository Variables ({variables_url}):\n"
        f"   - [Optional] CAS_PROJECT          : Project identifier (default: {target_path.name})\n"
        "   - [Optional] KNOWLEDGE_REPO_NAME  : Central knowledge repo slug (default: cas-brain/knowledge)\n"
        "   - [Optional] CAS_DEFAULT_PROVIDER : Default LLM provider (default: openai)\n"
        "   - [Optional] CAS_DEFAULT_MODEL    : Default LLM model (default: gpt-6.1-sol)\n"
        "   - [Optional] CAS_MAX_TOKENS       : Generation token limit (default: 10000)\n"
        "   - [Optional] CAS_TEMPERATURE      : Sampling temperature (default: 1.0)\n"
        "\n"
        "3. Verify Environment Readiness:\n"
        "   Run: cas governance check-env --target-dir ."
    )


def init_workspace(
    target_dir: str,
    project_name: str,
    force: bool = False,
    provider: str = "local",
    workspace_root_path: str | None = None,
) -> bool:
    """
    Initializes the CAS Knowledge Workspace (Understanding & Evolution) using an "Attach" model.
    """
    project_root = Path(target_dir).resolve()
    template_base = Path(__file__).parent / "templates" / "onboarding" / "workspace"

    if not template_base.exists():
        print(f"[CAS][ERROR] Workspace templates not found at {template_base}")
        return False

    if workspace_root_path:
        workspace_root = Path(workspace_root_path).expanduser().resolve()
    else:
        env_root = os.getenv("CAS_KNOWLEDGE_WORKSPACE")
        if env_root:
            workspace_root = Path(env_root).expanduser().resolve()
        else:
            workspace_root = (project_root / "cas-knowledge").resolve()

    print(
        f"[CAS][INFO] Attaching project '{project_name}' to workspace: {workspace_root}"
    )

    def copy_and_rename(src: Path, dest: Path, is_project_specific: bool):
        new_name = src.name.replace("__PROJECT_NAME__", project_name)
        dest_item = dest / new_name

        if src.is_dir():
            safe_mkdir(dest_item, parents=True, exist_ok=True)

            for item in src.iterdir():
                child_is_project_specific = (
                    is_project_specific or "__PROJECT_NAME__" in src.name
                )
                copy_and_rename(item, dest_item, child_is_project_specific)
        else:
            if dest_item.exists() and not force:
                return

            try:
                content = src.read_text()
                content = content.replace("__PROJECT_NAME__", project_name)
                dest_item.write_text(content)
                try:
                    display_path = dest_item.relative_to(project_root)
                except ValueError:
                    display_path = dest_item
                print(f"[CAS][OK] Created {display_path}")
            except UnicodeDecodeError:
                shutil.copy2(src, dest_item)
                try:
                    display_path = dest_item.relative_to(project_root)
                except ValueError:
                    display_path = dest_item
                print(f"[CAS][OK] Copied {display_path}")

    for item in template_base.iterdir():
        if item.name == "cas-config.yaml":
            config_dest = project_root / "cas-config.yaml"
            if not config_dest.exists() or force:
                try:
                    rel_workspace_path = str(workspace_root.relative_to(project_root))
                except ValueError:
                    rel_workspace_path = str(workspace_root)

                config_content = f"project: {project_name}\nknowledge_provider:\n  type: {provider}\n  workspace_root: {rel_workspace_path}\n  evidence_root: .\n"
                config_dest.write_text(config_content)
                print(f"[CAS][OK] Created {config_dest.name}")
        elif item.name == "cas-knowledge" and item.is_dir():
            safe_mkdir(workspace_root, parents=True, exist_ok=True)
            for subitem in item.iterdir():
                is_project_specific = "__PROJECT_NAME__" in subitem.name
                copy_and_rename(subitem, workspace_root, is_project_specific)
        else:
            copy_and_rename(item, project_root, False)

    print("[CAS][SUCCESS] CAS Knowledge Workspace initialized (Project Attached).")
    return True
