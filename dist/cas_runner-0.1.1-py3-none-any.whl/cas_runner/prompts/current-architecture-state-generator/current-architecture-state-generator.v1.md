---
cas.prompt_schema: "current_architecture_state_schema.json"
---

# Current Architecture State Generator

## Problem

CAS currently contains multiple governance artifacts that describe architectural intent, architectural evolution, governance decisions, implementation progress, and alignment status.

Examples include:
* Architecture Work
* Architecture Evolution Maps (AEM)
* Architecture Intent Documents (AID)
* Alignment Reports
* ADRs
* Governance Models

However, no single artifact provides an authoritative summary of "Where are we today?". This leads to inconsistent reasoning and duplicated interpretation across workflows.

---

## Objective

Create a **Current Architecture State** artifact: an evidence-based synthesis generated from existing authoritative governance artifacts.

The resulting artifact must answer: **What is the current architectural state of this project?**

---

## Architectural Principles

- **Derived Intelligence**: This is generated intelligence, not a primary source of truth. Sources remain ADRs, AEM, etc.
- **Evidence-Based**: Derive all conclusions from available evidence. If evidence is incomplete, explicitly state uncertainty.
- **Evidence Attribution**: Every significant conclusion must be traceable. For major findings, provide confidence, evidence, and rationale.
- **Governance-Aware**: Reflect architecture, governance, capabilities, and maturity rather than implementation details.

---

## Inputs

The workflow receives optional context supplied by CAS Runner:
* Architecture Work, AEM, AID, Alignment Reports, ADRs, Governance Models, Project Metadata, etc.

Synthesize the best possible representation from the available evidence. If evidence conflicts, identify the conflict and reduce confidence accordingly.

---

## Key Questions to Answer

1. **Executive State**: What are the most important conclusions for immediate understanding?
2. **Capability State**: What architectural capabilities currently exist?
3. **Initiative State**: What is the status of major initiatives?
4. **Governance State**: What capabilities exist and what gaps remain?
5. **Architecture State**: What major structures and patterns are established?
6. **Intelligence State**: What intelligence capabilities are available or planned?
7. **Operational State**: What is the automation and operational governance maturity?

---

## Synthesis Rules

- **Capability Identification**: For each capability, determine status (absent, emerging, active, operational, mature), confidence, and category.
- **Initiative Identification**: For each initiative, determine lifecycle state, confidence, and evidence.
- **Architectural Maturity**: Assess maturity across Governance, Intelligence, Automation, and Knowledge.
- **Strategic Gaps**: Identify major gaps between current and intended architecture, supported by evidence.
- **Confidence Assessment**: Use High, Medium, or Low based on evidence quality.
- **Metrics**: Generate summary metrics (ADR counts, initiative counts, etc.) to support dashboards.
- **Strategic Identity**: Identify the primary architectural identity of the platform. Support the conclusion with evidence. Avoid selecting more than one primary identity. Examples:
  * Governance Platform
  * Architecture Intelligence Platform
  * Knowledge Platform
  * Delivery Platform

## Output Requirements

Generate the Current Architecture State in **strictly valid JSON** format matching the schema.

### JSON Structure

#### `frontmatter`
- `id`: "cas-state-<project>-<date>"
- `knowledgeType`: "current_architecture_state"
- `project`: "<project-name>"
- `date`: "<YYYY-MM-DD>"
- `status`: "generated"
- `confidence`: "high | medium | low"
- `sources`: array of artifact types used

#### `sections`
- `executive_summary`: High-level synthesis.
- `evolution_summary`: Significant observable architectural changes.
- `architecture_evolution`: Maturity trends and trajectory.
- `capability_landscape`: Identified capabilities with status.
- `capability_dependencies`: Major capability relationships.
- `initiative_landscape`: Status of major initiatives.
- `governance_state`: Governance maturity and gaps.
- `architecture_state`: Patterns and structures in operation.
- `intelligence_state`: Intelligence tools and capabilities.
- `operational_state`: Automation and operational maturity.
- `metrics`: Quantitative data (counts, findings).
- `strategic_gaps`: Evidence-backed gaps.
- `observed_state`: Observed capabilities and structures.
- `interpreted_state`: Conclusions from evidence.
- `hypothesised_state`: Potential conclusions with low confidence.
- `confidence_assessment`: Breakdown of evidence quality.
- `major_findings`: Array of objects:
    - `title`: String
    - `confidence`: "high | medium | low"
    - `evidence`: String (comma-separated list of artifact references)
    - `rationale`: String
- `evidence_sources`: Synthesis of sources used.

---

## Example Output Format (One-Shot)

```json
{
  "frontmatter": {
    "id": "cas-state-example-2026-01-01",
    "knowledgeType": "current_architecture_state",
    "project": "example-project",
    "date": "2026-01-01",
    "status": "generated",
    "confidence": "high",
    "sources": ["architecture_work", "aem"]
  },
  "sections": {
    "executive_summary": "Summary text here...",
    "evolution_summary": "Evolution text here...",
    "architecture_evolution": "Trajectory text here...",
    "capability_landscape": "Capabilities here...",
    "capability_dependencies": "Dependencies here...",
    "initiative_landscape": "Initiatives here...",
    "governance_state": "Governance here...",
    "architecture_state": "Architecture here...",
    "intelligence_state": "Intelligence here...",
    "operational_state": "Operational here...",
    "metrics": "Metrics here...",
    "strategic_gaps": "Gaps here...",
    "observed_state": "Observations here...",
    "interpreted_state": "Interpretations here...",
    "hypothesised_state": "Hypotheses here...",
    "confidence_assessment": "Assessment here...",
    "major_findings": [
      {
        "title": "Example Finding",
        "confidence": "high",
        "evidence": "aem-2026-01-01, adr-001",
        "rationale": "Example rationale..."
      }
    ],
    "evidence_sources": "Sources here..."
  }
}
```

**CRITICAL**: Ensure the output is valid JSON. Pay special attention to commas in arrays and objects to avoid parsing failures. Do not skip any required fields.
