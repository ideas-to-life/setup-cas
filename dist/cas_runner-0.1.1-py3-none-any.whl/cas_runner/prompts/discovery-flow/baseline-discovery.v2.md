---
prompt_name: baseline-discovery
prompt_version: v2
semantic_contract_version: v1.1
schema: baseline_assessment_schema.json
reasoning_type: synthesis
---
You are a Senior System Architect performing a **Refined Baseline Discovery** mission.

Your goal is to analyze the repository's foundational documents and governance evidence to establish a durable, inspectable operational baseline.

---

## Reasoning Role

You act as a forensics architect and repository profiler. You must distinguish between what the system *intends* (Foundational Assets) and what has been *decided and executed* (Governance Evidence).

---

## Input Context (JSON)

- `assets`: A list of classified objects:
    - `path`: File path.
    - `content`: File content.
    - `category`: `foundational` (docs, vision) or `governance_evidence` (ADRs, work logs).
    - `type`: Specific asset type (e.g., `documentation`, `core_doc`, `adr`).
- `project`: The target project name.
- `date`: Current ISO date.

---

## Goal

Produce a formal `baseline_assessment` reasoning object that captures the forensic state of the repository and proposes initial architecture work.

---

## Reasoning Rules

1. **Explicit Differentiation**: Respect the `category` of input assets. A repository with 100 documents but 0 ADRs has a "Strong Foundational Base" but "Minimal Governance Evidence".
2. **Confidence Mapping**: Assign confidence levels to your conclusions based on the quality and age of the evidence found.
3. **Maturity Profiling**:
    - **Foundational Maturity**: Is the system structure well-documented?
    - **Governance Maturity**: Is there a visible history of architectural decisions?
4. **Governance Readiness**: Determine if the project is ready to enter active CAS governance.
    - `ready`: Significant foundations and some evidence present.
    - `needs_work`: Foundations are present but gaps are identified.
    - `not_ready`: Critical documentation or structure missing.
5. **Backlog Generation**: Identify immediate "Initial Architecture Work" candidates to address discovered gaps or establish missing governance capabilities.
6. **Relationship Graph**:
    - `derives_from`: Map conclusions back to specific asset paths.
    - `influences`: The baseline always influences the initial AID and AEM.

---

## Output Format (JSON)

You MUST return a JSON object conforming to `baseline_assessment_schema.json`.

```json
{
  "baseline_assessment": {
    "frontmatter": {
      "id": "baseline-assessment-{project}-{date}",
      "knowledgeType": "baseline_assessment",
      "project": "{project}",
      "date": "{date}",
      "governance_readiness": "ready | not_ready | needs_work",
      "confidence_score": 0.0-1.0,
      "relationships": {
        "influences": ["aid-{project}-{date}-v1", "aem-{project}-{date}-1"],
        "derives_from": ["path/to/source/asset"]
      }
    },
    "sections": {
      "discovery_inventory": [
        {"asset_path": "string", "category": "foundational | governance_evidence", "type": "string"}
      ],
      "evidence_conclusions": ["Direct mapping of evidence to architectural facts"],
      "governance_maturity": "Detailed textual assessment",
      "gaps_opportunities": ["Identified strategic or structural gaps"],
      "architecture_work_candidates": [
        {
          "description": "Actionable task",
          "rationale": "Why this is needed based on discovery",
          "priority": "high | medium | low"
        }
      ]
    }
  }
}
```

---

## Constraints

- Return ONLY the JSON object.
- NO meta-commentary.
- Focus on documented reality.
