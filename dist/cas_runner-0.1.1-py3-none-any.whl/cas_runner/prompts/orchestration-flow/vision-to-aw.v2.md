# vision-to-architecture-work.v1.md

## Purpose

Transform Vision artifacts into Architecture Work.

The objective is to identify architectural initiatives, capabilities, governance investments, and platform evolution required to move from the current state toward the intended future state.

This workflow is part of the Architecture Work generation ecosystem:

Conversation         ↓ Architecture Work  Discovery         ↓ Architecture Work  Vision         ↓ Architecture Work  Alignment         ↓ Architecture Work

Vision focuses on:

Where are we going?

Architecture Work focuses on:

What architectural evolution is required to get there?

---

## Inputs

The workflow receives context supplied by CAS Runner.

Inputs are provided through the workflow context contract and must not be discovered through repository scanning or local knowledge workspace inspection.

Expected context includes:

- vision artifacts
- future vision artifacts
- project vision documents
- strategic architecture direction
- governance vision documents
- platform evolution models
- capability roadmaps
- future-state architecture descriptions
- project metadata
- existing architecture work (optional)
- architecture evolution information (optional)
- current architecture state information (optional)
- architecture intent information (optional)
- applicable governance context and rules (optional)
- execution metadata (optional)

Context may originate from Knowledge Providers, runtime orchestration, manual execution, or future automation capabilities.

---

## Objective

Review the Vision artifacts and identify:

- strategic architectural initiatives
- future capabilities
- governance evolution opportunities
- platform evolution opportunities
- operational intelligence capabilities
- automation opportunities
- lifecycle evolution opportunities
- reasoning capabilities
- architectural investments

Generate Architecture Work required to move from the current state toward the intended future state.

---

## Workflow Execution Model Compliance

This workflow conforms to the CAS Workflow Execution Model.

Responsibilities:

- Reason about vision and future-state direction
- Identify architectural evolution opportunities
- Classify architecture work
- Produce architecture work artifacts

This workflow is not responsible for:

- repository discovery
- folder scanning
- knowledge loading
- dependency resolution
- orchestration
- output persistence

Those responsibilities belong to CAS Runner and associated Knowledge Providers.

---

## Vision Analysis Principles

Vision describes:

Desired Future State

Architecture Work describes:

Required Evolution

The purpose of this workflow is to bridge the gap.

When current-state information is available:

Current State
→ Desired Future State
→ Evolution Gap
→ Architecture Work

When current-state information is not available:

Desired Future State
→ Architectural Evolution Hypothesis
→ Architecture Work

Clearly distinguish confirmed gaps from inferred gaps.

---

## Architecture Work Generation Criteria

### Context Usage Rules

- Use only the context provided to the workflow.
- Do not assume access to repository structures.
- Do not assume access to local folders.
- Do not perform knowledge discovery.
- Treat supplied context as authoritative.

Generate Architecture Work when the Vision identifies:

The existence of a vision concept alone is not sufficient.

Generate Architecture Work only when:

- a meaningful architectural gap exists
- the gap is supported by available evidence
- the gap materially contributes to achievement of the Vision
- architectural evolution is required

### New Capability

Examples:

- capability does not yet exist
- capability exists only partially
- capability requires substantial evolution

### Strategic Initiative

Examples:

- platform evolution
- governance evolution
- operational intelligence evolution
- reasoning evolution
- lifecycle evolution

### Architectural Investment

Examples:

- foundational capabilities
- platform capabilities
- knowledge capabilities
- governance capabilities

### Operational Improvement

Examples:

- reduced onboarding effort
- increased automation
- increased governance maturity
- improved architectural visibility

### Future Architecture Direction

Examples:

- new operating models
- new governance models
- new platform capabilities
- future knowledge providers
- future intelligence capabilities

---

## Exclude

Do not generate Architecture Work for:

- aspirational statements lacking architectural significance
- generic goals
- marketing language
- implementation details
- completed capabilities already operating successfully
- capabilities that appear already implemented unless a clear evolution gap exists
- work items created solely because a vision references an existing capability
- documentation catch-up activities
- ADR creation activities where the architecture already exists
- schema migration activities that do not materially change architecture
- governance housekeeping activities
- administrative governance improvements
- process improvements without architectural impact
- compliance-only activities unless they unlock significant architectural evolution

---

## Capability Gap Assessment

For each vision element determine:

### Current State

If current-state evidence exists, assess whether the capability is:

- absent
- emerging
- partially implemented
- operational
- mature

If current-state evidence does not exist:

- classify the assessment as inferred
- avoid assuming absence
- avoid assuming implementation status

### Desired State

Describe the intended future capability.

### Evolution Gap

Describe the architectural gap between current and desired states.

Only generate Architecture Work when meaningful architectural evolution is required.

---

## Gap Severity Assessment

Before generating Architecture Work, assess the significance of the identified gap.

Evaluate:

### Strategic Impact

Does the gap materially affect achievement of the Vision?

### Current Maturity

Assess whether the capability is:

- absent
- emerging
- partially implemented
- operational
- mature

### Urgency

Would the project fail, slow down, or significantly limit achievement of the Vision if the gap remains unresolved?

### Foundational Importance

Does the capability unlock future capabilities, workflows, governance models, or intelligence capabilities?

### Architectural Significance

Is the gap architectural in nature or merely an implementation improvement?

Only generate Architecture Work when the gap represents meaningful architectural evolution.

Not every identified vision gap requires Architecture Work generation.

---

## Architecture Work Threshold

Before generating Architecture Work, determine whether completion of the work would materially change:

- platform capability
- governance capability
- intelligence capability
- automation capability
- architecture operating model
- architectural decision-making capability

If the answer is NO, do not generate Architecture Work.

Instead classify the item as one of:

- governance maintenance
- documentation maintenance
- operational maintenance
- implementation improvement

and exclude it from Architecture Work generation.

Architecture Work should represent meaningful architectural evolution rather than routine governance upkeep.

---

## Architecture Work Classification

Only classify items that pass the Architecture Work Threshold.

Items failing the threshold are not Architecture Work and should be excluded.

### Category

Use one of:

- capability
- governance
- workflow
- model
- automation
- documentation

### Lifecycle State

Use one of:

- new
- active
- completed
- superseded

Classification guidance:

#### New

When:

- initiative is not yet started
- capability is aspirational
- no implementation evidence exists

#### Active

When:

- capability is already evolving
- implementation appears underway
- architectural investment is ongoing

#### Completed

When:

- the vision objective has effectively been achieved
- supporting capabilities already exist and operate successfully

#### Superseded

When:

- a newer architectural direction replaces the vision element
- the capability has been absorbed into another initiative

---

## Initiative Identification

Vision-derived work should strongly favour initiative grouping.

Examples:

- Governance Foundation
- ReasoningOps
- GovernanceOps
- Knowledge Provider
- Shared Workspace
- Operational Intelligence
- Bootstrap Evolution
- Discovery Evolution
- Lifecycle Evolution

Populate initiative whenever a broader strategic theme exists.

---

## Deduplication Rules

Before generating Architecture Work:

Determine whether the vision item already exists as:

- Architecture Work
- active initiative
- implemented capability
- completed initiative
- Current Architecture State capability

When possible:

- update existing initiative understanding
- reference related work
- populate related_work
- avoid generating duplicate Architecture Work

---

## Strategic Prioritisation

Assess each work item according to:

Priority should favour architectural transformation over governance maintenance.

Work that introduces new architectural capabilities, intelligence capabilities, automation capabilities, operating models, or platform evolution should generally rank above documentation and governance hygiene improvements.

### Architectural Impact

How significantly does this change the architecture?

### Strategic Importance

How strongly does it contribute to the Vision?

### Foundational Value

Does it unlock future capabilities?

### Governance Value

Does it improve governance participation, understanding, or intelligence?

### Reasoning Value

Does it improve the system's ability to reason about architecture?

### Existing Capability Weighting

Reduce priority when:

- the capability is already operational
- the capability is already mature
- the Vision references the capability without requiring substantial evolution

Strongly reduce priority when the identified gap primarily represents:

- missing documentation
- missing ADRs
- metadata normalisation
- governance administration

unless completion would unlock significant architectural evolution.

Increase priority when:

- a significant evolution gap exists
- the capability is foundational to future architecture
- multiple future capabilities depend on it

---

## Confidence Assessment

Confidence should reflect the quality of evidence available.

Use:

### High

When:

- current-state evidence exists
- vision evidence is explicit
- evolution gap is clearly observable

### Medium

When:

- vision evidence is explicit
- current-state evidence is incomplete

### Low

When:

- work is derived primarily from inferred future-state needs
- current-state information is unavailable

Confidence should not be used as a proxy for priority.

A work item may have:

- high confidence and low priority
- medium confidence and high priority

Assess confidence and priority independently.

---

## Output Requirements

Generate one Architecture Work markdown document per work item.

Each output must contain the following frontmatter.

```yaml
---
id: "aw-<project>-<date>-<N>"
knowledgeType: "architecture_work"

project: "<project-name>"

initiative: ""
category: ""
related_work: []

date: "<YYYY-MM-DD>"

source: "vision"
origin_ref: "<vision-section | null>"

type: ""                # decision | refactor | pattern_update | governance_update

lifecycle_state: "new"

priority: ""            # high | medium | low

status: "proposed"

confidence: "medium"

current_maturity: "emerging"   # absent | emerging | partially_implemented | operational | mature
architectural_significance: "medium"  # high | medium | low
---
```

These fields should reflect the assessed gap rather than the visibility of the capability within the Vision.

---

## Document Structure

Each Architecture Work artifact should contain:

# Title

## Vision Driver

Describe the vision element that generated the work.

Indicate whether the work is:

- gap-driven (vision + current-state evidence)
- hypothesis-driven (vision only)

## Current State

Describe current architectural reality.

## Desired Future State

Describe the intended future capability.

## Evolution Gap

Describe the gap between current and desired states.

Include:

- gap severity
- current maturity
- architectural significance

## Gap Severity Assessment

Summarise:

- strategic impact
- urgency
- foundational importance
- architectural significance

Explain why the gap does or does not justify Architecture Work generation.

Explicitly state whether the item passed the Architecture Work Threshold.

If the threshold is passed, explain why the work materially changes architectural capability.

## Why This Matters

Describe:

- strategic impact
- architectural impact
- governance impact
- operational impact

## Expected Outcomes

Describe:

- capability outcomes
- governance outcomes
- lifecycle outcomes
- operational outcomes

## Dependencies

List:

- related initiatives
- related capabilities
- prerequisite work

## Vision Evidence

Reference the specific vision elements that led to the Architecture Work.

## Recommended Next Step

Describe the next architectural action.

Focus on:

- architectural evolution
- governance evolution
- capability evolution
- lifecycle evolution

Avoid implementation design.

---

## Extraction Principles

- Vision references are not automatically Architecture Work
- Vision concepts must be validated against current-state evidence when available
- Prefer identifying the most important evolution gaps over generating work for every future capability mentioned in the Vision
- Prioritise architectural transformation over governance housekeeping activities
- Prefer strategic platform evolution over governance maintenance
- Prefer capability creation over documentation creation
- Prefer intelligence and automation evolution over compliance activities
- Architecture Work should change the architecture, not merely describe it
- Vision describes direction
- Architecture Work describes evolution
- Architecture Work is the authoritative architectural change backlog
- AEM summarizes Architecture Work rather than acting as the source of truth
- Focus on WHAT and WHY
- Avoid implementation design
- Prioritise strategic architectural evolution
- Prefer fewer meaningful initiatives over many small work items

---

## Final Validation

Before generating a work item ask:

1. Does this work materially evolve the architecture?
2. Does this work unlock future capabilities or architectural options?
3. Would the platform meaningfully differ if this work were completed?

If the answer to all three questions is NO, do not generate Architecture Work.

---

## Expected Outcome

The resulting Architecture Work should answer:

text Given the intended future state, what architectural evolution must occur to move from today's reality to tomorrow's vision?

while remaining consistent with:

- Architecture Work Registry
- Governance Foundation
- Project Lifecycle Model
- Project Bootstrap Model
- Baseline Discovery
- Architecture Evolution Maps
- Architecture Intent Documents
- Alignment Engine
- Future Vision artifacts

---

## Runtime Onboarding Notes

Workflow Category:
- Ingestion Workflow

Primary Input:
- Vision Context

Primary Output:
- Architecture Work

Output Schema:
- architecture_work

Execution Model:
- CAS Runner supplies context.
- Workflow performs reasoning.
- Output validation and persistence occur outside the workflow.
