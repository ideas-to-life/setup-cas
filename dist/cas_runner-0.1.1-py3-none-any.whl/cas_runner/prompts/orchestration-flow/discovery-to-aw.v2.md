# discovery-to-architecture-work.v1.md

## Purpose

Transform Baseline Discovery findings into Architecture Work artifacts.

The objective is to identify architectural evolution opportunities emerging from the discovered current state and convert them into actionable Architecture Work.

This workflow is part of the Architecture Work generation ecosystem:

text Conversation         ↓ Architecture Work  Discovery         ↓ Architecture Work  Vision         ↓ Architecture Work  Alignment         ↓ Architecture Work 

Discovery focuses on:

text What exists today? 

Architecture Work focuses on:

text What architectural evolution is required? 

---

## Inputs

The workflow receives context supplied by CAS Runner.

Inputs are provided through the workflow context contract and must not be discovered through repository scanning or local knowledge workspace inspection.

Expected context includes:

- baseline discovery findings
- discovery reports
- repository assessments
- governance readiness assessments
- onboarding findings
- capability inventories
- operational observations
- project metadata
- existing architecture work (optional)
- applicable governance context and rules (optional)
- execution metadata (optional)

Context may originate from Knowledge Providers, runtime orchestration, manual execution, or future automation capabilities.

---

## Objective

Review Discovery findings and identify:

- capability gaps
- governance gaps
- lifecycle gaps
- onboarding gaps
- documentation gaps
- operational gaps
- automation opportunities
- model evolution opportunities
- architectural inconsistencies

Generate Architecture Work only when architectural evolution is justified.

Do not generate Architecture Work for informational observations that require no architectural action.

---

## Workflow Execution Model Compliance

This workflow conforms to the CAS Workflow Execution Model.

Responsibilities:

- Reason about discovery findings
- Identify architectural evolution opportunities
- Classify architecture work
- Produce architecture work artifacts

This workflow is not responsible for:

- repository discovery
- folder scanning
- knowledge loading
- dependency resolution
- orchestration
- output persistence

Those responsibilities belong to CAS Runner and associated Knowledge Providers.

## Architecture Work Generation Criteria

### Context Usage Rules

- Use only the context provided to the workflow.
- Do not assume access to repository structures.
- Do not assume access to local folders.
- Do not perform knowledge discovery.
- Treat supplied context as authoritative.

Generate Architecture Work when findings indicate:

### Missing Capability

Examples:

- capability does not exist
- capability is partially implemented
- capability is insufficient for intended lifecycle

### Governance Gap

Examples:

- governance participation unavailable
- governance visibility incomplete
- governance persistence missing
- governance workflows incomplete

### Lifecycle Gap

Examples:

- lifecycle transition unsupported
- bootstrap incomplete
- discovery incomplete
- rehydration unsupported

### Structural Gap

Examples:

- missing workspace structures
- missing governance artifacts
- missing knowledge organization

### Operational Friction

Examples:

- onboarding complexity
- manual repetitive work
- duplicated governance effort
- unnecessary operational burden

### Evolution Opportunity

Examples:

- architecture evolution identified
- governance maturity opportunity
- platform capability expansion
- operational intelligence opportunity

---

## Ignore Findings That Do Not Require Action

Do not generate Architecture Work for:

- informational observations
- implementation details
- completed capabilities
- historical notes
- observations without architectural impact

---

## Architecture Work Classification

For each generated Architecture Work item determine:

### Category

Use one of:

- capability
- governance
- workflow
- model
- automation
- documentation

### Lifecycle State

Use one of:

- new
- active
- completed
- superseded

Classification guidance:

#### New

When:

- capability is first identified
- work has not started
- no implementation evidence exists

#### Active

When:

- implementation appears underway
- capability is evolving
- refinement is occurring

#### Completed

When:

- capability is operational
- implementation is confirmed
- discovery verifies successful adoption

#### Superseded

When:

- capability has been replaced
- architectural direction has changed
- newer work invalidates older work

---

## Initiative Identification

Attempt to identify broader initiatives.

Examples:

- Governance Foundation
- Bootstrap v2
- Knowledge Provider
- Shared Workspace
- Baseline Discovery
- ReasoningOps
- GovernanceOps
- Operational Intelligence

Populate initiative when a larger architectural theme is clearly present.

Otherwise use:

yaml initiative: "" 

---

## Deduplication Rules

Before generating new Architecture Work:

Determine whether the discovery finding appears to relate to:

- existing Architecture Work
- active initiatives
- completed capabilities
- superseded capabilities

When possible:

- reference existing work
- populate related_work
- avoid generating duplicate Architecture Work

---

## Output Requirements

Generate one Architecture Work markdown document per work item.

Each output must contain the following frontmatter.

```yaml
---
id: "aw-<project>-<date>-<N>"
knowledgeType: "architecture_work"

project: "<project-name>"

initiative: ""
category: ""
related_work: []

date: "<YYYY-MM-DD>"

source: "baseline_discovery"
origin_ref: "<finding-id | null>"

type: ""                # decision | refactor | pattern_update | governance_update

lifecycle_state: "new"

priority: ""            # high | medium | low

status: "proposed"      # proposed | accepted | in_progress | done | rejected

confidence: "medium"
---
```
---

## Document Structure

Each Architecture Work artifact should contain:

# Title

## Problem Statement

Describe:

- current state
- discovery finding
- observed gap

## Why This Matters

Describe:

- architectural impact
- governance impact
- operational impact

## Expected Outcomes

Describe:

- desired future state
- success indicators
- lifecycle improvements

## Dependencies

List:

- related capabilities
- related initiatives
- prerequisite work

## Discovery Evidence

Reference the findings that led to the Architecture Work.

## Recommended Next Step

Describe the next architectural action.

Focus on:

- architectural evolution
- governance evolution
- lifecycle evolution

Avoid implementation details.

---

## Extraction Principles

- Discovery identifies reality
- Architecture Work identifies evolution
- Architecture Work is the authoritative architectural change backlog
- AEM summarizes Architecture Work rather than serving as the source of truth
- Focus on WHAT and WHY
- Avoid implementation design
- Prefer fewer high-quality Architecture Work items over many low-value items
- Only generate work when architectural evolution is justified

---

## Expected Outcome

The resulting Architecture Work should answer:

text Based on the discovered current state, what architectural evolution should occur next? 

while maintaining consistency with:

- Architecture Work Registry
- Governance Foundation
- Project Lifecycle Model
- Project Bootstrap Model
- Baseline Discovery
- Architecture Evolution Maps
- Architecture Intent Documents
- Alignment Engine

---

## Runtime Onboarding Notes

Workflow Category:
- Ingestion Workflow

Primary Input:
- Baseline Discovery Context

Primary Output:
- Architecture Work

Output Schema:
- architecture_work

Execution Model:
- CAS Runner supplies context.
- Workflow performs reasoning.
- Output validation and persistence occur outside the workflow.
