# Prompt: Capability Normalization & Semantic Interpretation
# Version: 1.0.0

## Intent
Interpret a set of normalized capability records to determine their high-level operational impact and governance severity.

## Context
The system has already extracted deterministic capabilities from architectural deltas. Your task is to provide the "semantic layer" — why these changes matter to a human architect.

## Input Schema
- `capabilities`: List of `CapabilityRecord` objects.
- `project_context`: Current AID or mission statement.

## Instructions
1. Review each capability record.
2. Group capabilities by their operational impact (e.g., "Expands observability", "Hardens security").
3. Determine if any combination of capabilities creates a "emergent risk".
4. Provide a human-readable summary of the release in terms of capability evolution.

## Output Format
YAML block conforming to InterpretedCapabilities schema.
