---
schema: "pattern_proposal_schema.json"
semantic_contract: "v1.0"
---

# signal-to-pattern-proposals.v2

You are generating pattern proposals from architectural signals.

Purpose:

Transform architectural signals and supporting governance intelligence into structured pattern proposals for Architect review.

This workflow identifies candidate reusable patterns.

This workflow:

- proposes patterns
- identifies reusable concepts
- synthesises supporting evidence

This workflow does NOT:

- approve patterns
- promote patterns
- persist patterns
- modify governance artefacts

Pattern proposals are derived intelligence.

Pattern proposals are not authoritative architecture artefacts.

---

## Workflow Execution Model

Responsibilities:

CAS Runner:

- context loading
- orchestration
- prompt execution
- validation
- persistence

Workflow:

- pattern reasoning
- evidence synthesis
- proposal generation

Knowledge Providers:

- knowledge access

The workflow must not:

- query repositories
- scan directories
- load files directly
- persist outputs
- perform orchestration

---

## Inputs

Context is supplied by CAS Runner.

Available context may include:

### Candidate Signals

Signals identified through governance and intelligence workflows.

### Current Architecture State (optional)

Evidence-backed representation of current architectural reality.

Provides:

- capability landscape
- governance state
- intelligence state
- strategic gaps
- major findings

### Architecture Work (optional)

Provides:

- architectural evolution
- initiatives
- recurring change themes
- implementation evidence

### Alignment Findings (optional)

Provides:

- recurring alignment issues
- governance friction
- capability gaps

### Architecture Evolution Maps (optional)

Provides:

- recurring architectural transitions
- established architectural directions

### Existing Patterns (optional)

Used to prevent duplicate proposals.

---

## Pattern Discovery Principles

Patterns should represent:

- reusable architectural concepts
- recurring architectural behaviours
- recurring governance approaches
- recurring intelligence approaches
- recurring execution approaches

Patterns should not represent:

- individual implementation details
- one-off project decisions
- isolated work items
- documentation activities

A pattern must be reusable beyond the originating work item.

---

## Pattern Maturity Assessment

For each candidate pattern determine its maturity.

Pattern maturity reflects how established the pattern is within the architecture.

### Established

The pattern is already visible across multiple governance artefacts and operational capabilities.

Examples:

- Workflow Execution Model
- Knowledge Provider abstraction
- Runtime-native governance workflows

### Emerging

The pattern is visible across multiple signals but is not yet fully institutionalised.

Examples:

- Continuous Governance Loop
- Architecture State Context

### Strategic Direction

The pattern is not yet operational but is repeatedly visible across:

- Vision
- Architecture Work
- Current Architecture State
- Architecture Evolution Maps

These patterns represent recurring future architectural direction.

---

## Signal Assessment

For each candidate signal evaluate:

### Recurrence

Does the signal appear multiple times?

### Reusability

Can the concept be reused elsewhere?

### Architectural Significance

Does the signal materially affect:

- governance
- execution
- intelligence
- automation
- architectural decision-making

### Evidence Strength

Evidence strength:

#### High

Supported by:

- multiple signals
- multiple architecture work items
- current architecture state
- alignment findings

#### Medium

Supported by:

- several related artefacts

#### Low

Supported by:

- a single observation

---

## Current-State Validation

When Current Architecture State is available:

Assess:

- whether the pattern already exists
- whether the pattern is emerging
- whether the pattern represents a strategic gap
- whether the pattern reflects an established architectural direction

Do not propose patterns already institutionalised unless meaningful evolution is required.

---

## Future Direction Detection

When Current Architecture State and Vision-derived signals are available:

Assess whether recurring evidence indicates:

- emerging architectural direction
- future governance direction
- future intelligence direction
- future operating model direction

Patterns may represent:

- established architecture
- emerging architecture
- recurring future direction

Do not reject a pattern solely because it is not yet implemented.

However, future-direction patterns must demonstrate recurrence across multiple evidence sources.

---

## Pattern Deduplication

Before proposing a pattern:

Determine whether an equivalent pattern already exists.

Compare against:

- existing patterns
- promoted patterns
- active pattern proposals

Avoid:

- duplicate patterns
- renamed duplicates
- overlapping proposals

Prefer consolidation.

---

## Proposal Generation Criteria

Generate a pattern proposal when:

- recurring evidence exists
- architectural significance exists
- reuse potential exists
- sufficient evidence exists

Do not generate proposals solely because:

- a signal exists
- a work item exists
- a capability exists

Patterns require evidence of recurrence.

Generate a pattern proposal when either:

- recurring implemented evidence exists
or
- recurring strategic direction exists across multiple governance artefacts.

Patterns may emerge from:

- implementation recurrence
- governance recurrence
- strategic recurrence

---

## Pattern Classification

Classify each proposal as one of:

### Architectural Pattern

Reusable architecture structure, capability, or operating model.

### Governance Pattern

Reusable governance approach or governance operating model.

### Intelligence Pattern

Reusable intelligence generation, synthesis, or reasoning approach.

### Execution Pattern

Reusable workflow execution or orchestration approach.

---

## Confidence Assessment

Confidence should reflect evidence quality.

### High

- supported by multiple evidence sources
- visible in current architecture state
- recurring across governance artefacts

### Medium

- supported by several related observations

### Low

- supported by limited evidence

Confidence is not acceptance.

Confidence only reflects evidence strength.

Confidence reflects evidence quality.

Pattern maturity reflects architectural adoption.

Do not treat confidence and maturity as equivalent.

Examples:

- High confidence, strategic direction
- High confidence, emerging
- High confidence, established

---

## Strategic Identity Detection

Assess whether multiple pattern proposals point toward a larger architectural identity.

Examples:

- Governance Platform
- Architecture Intelligence Platform
- Knowledge Platform
- Delivery Platform

Where evidence supports it, identify the dominant architectural direction emerging from the pattern set.

Do not force an identity if evidence is weak.

---

## Output Requirements

Generate a list of pattern proposals.

Each proposal must:

- be derived from one or more signals
- represent a reusable architectural concept
- include supporting evidence
- avoid duplication
- remain independent
- include pattern maturity
- include pattern classification
- distinguish implemented patterns from future-direction patterns

The output must remain deterministic.

Pattern proposals are not patterns.

Pattern proposals are not accepted architecture.

Pattern proposals are candidates for governance review.

---

## Output Format

### Frontmatter

```yaml
---
pattern_proposals:

  - pattern_id: "<pattern-id>"

    name: "<pattern-name>"

    pattern_classification: "architectural | governance | intelligence | execution"

    pattern_maturity: "established | emerging | strategic_direction"

    knowledgeType: "signal"

    decision:
      status: "proposed"
      decided_by: "system"
      date: null

    derived_from:

      signals:
        - "<signal-name>"

      architecture_work:
        - "<aw-id>"

      supporting_evidence:
        - "current_architecture_state"
        - "alignment_findings"

    description: "<clear explanation>"

    pattern_type: "implemented | emerging | future_direction"

    applies_to:
      - "governance"
      - "execution"
      - "intelligence"
      - "automation"
      - "contracts"

    rationale:
      - "why the pattern exists"
      - "what recurring problem it addresses"

    evidence_strength: "high | medium | low"

    confidence: "high | medium | low"
---
```

## Extraction Principles

- Prefer reusable concepts over implementation details
- Prefer recurring behaviour over isolated observations
- Prefer architectural direction over project-specific optimisation
- Distinguish what exists today from what the architecture is becoming
- Patterns may describe both architectural reality and architectural trajectory
