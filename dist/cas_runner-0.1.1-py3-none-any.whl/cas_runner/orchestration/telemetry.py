import json
import os
import time
import uuid
from datetime import datetime
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, Field

# OpenTelemetry imports
try:
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import ConsoleSpanExporter, SimpleSpanProcessor
    from opentelemetry.trace import Status, StatusCode
    OTEL_AVAILABLE = True
except ImportError:
    OTEL_AVAILABLE = False


class Event(BaseModel):
    name: str
    timestamp: float = Field(default_factory=time.time)
    attributes: dict[str, Any] = Field(default_factory=dict)

class Span(BaseModel):
    name: str
    context: dict[str, Any] = Field(default_factory=dict)
    start_time: float = Field(default_factory=time.time)
    end_time: float | None = None
    attributes: dict[str, Any] = Field(default_factory=dict)
    events: list[Event] = Field(default_factory=list)
    status: str = "unset" # unset, ok, error
    status_message: str | None = None
    otel_span: Any = Field(default=None, exclude=True)

    def end(self, status: str = "ok", status_message: str | None = None):
        self.end_time = time.time()
        self.status = status
        self.status_message = status_message

        if self.otel_span:
            otel_status = StatusCode.OK if status == "ok" else StatusCode.ERROR
            self.otel_span.set_status(Status(otel_status, status_message or ""))
            self.otel_span.end()

    def add_event(self, name: str, attributes: dict[str, Any] = None):
        event = Event(name=name, attributes=attributes or {})
        self.events.append(event)
        if self.otel_span:
            self.otel_span.add_event(name, attributes or {})

    @property
    def duration_ms(self) -> float | None:
        if self.end_time:
            return (self.end_time - self.start_time) * 1000
        return None

@runtime_checkable
class TelemetryProvider(Protocol):
    def start_span(self, name: str, attributes: dict[str, Any] = None) -> Span:
        ...

    def record_event(self, name: str, attributes: dict[str, Any] = None) -> None:
        ...

class OpenTelemetryProvider:
    """A vendor-agnostic OTEL provider that also maintains local state for CAS dashboards."""
    def __init__(self, project: str):
        self.project = project
        self.trace_id = str(uuid.uuid4())
        self.spans: list[Span] = []
        self.global_attributes: dict[str, Any] = {
            "project": project,
            "trace_id": self.trace_id,
            "cas.version": "0.1.1"
        }

        if OTEL_AVAILABLE:
            self.tracer_provider = TracerProvider()
            if os.getenv("CAS_OTEL_CONSOLE_EXPORT", "false").lower() == "true":
                self.processor = SimpleSpanProcessor(ConsoleSpanExporter())
                self.tracer_provider.add_span_processor(self.processor)
            else:
                self.processor = None
            self.tracer = self.tracer_provider.get_tracer("cas.runner")
        else:
            self.processor = None
            self.tracer = None


    def start_span(self, name: str, attributes: dict[str, Any] = None) -> Span:
        all_attributes = self.global_attributes.copy()
        if attributes:
            all_attributes.update(attributes)

        otel_span = None
        if self.tracer:
            otel_span = self.tracer.start_span(name, attributes=all_attributes)

        span = Span(name=name, attributes=all_attributes, otel_span=otel_span)
        self.spans.append(span)
        return span

    def record_event(self, name: str, attributes: dict[str, Any] = None) -> None:
        if self.spans:
            self.spans[-1].add_event(name, attributes)

    def persist(self, output_dir: str):
        """Persists the captured spans to a JSON file for the Portal."""
        from pathlib import Path

        from cas_runner.io import safe_mkdir

        output_path = Path(output_dir).expanduser().resolve()
        safe_mkdir(output_path, parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        filename = f"trace-{self.project}-{timestamp}-{self.trace_id[:8]}.json"
        filepath = output_path / filename

        trace_data = {
            "trace_id": self.trace_id,
            "project": self.project,
            "timestamp": datetime.now().isoformat(),
            "spans": [span.model_dump() for span in self.spans]
        }

        try:
            with open(filepath, "w") as f:
                json.dump(trace_data, f, indent=2)
            print(f"[CAS][INFO] Telemetry (OTEL-ready) persisted to {filepath}")
        except Exception as e:
            print(f"[CAS][WARN] Failed to persist telemetry: {e}")

class LocalTelemetryProvider(OpenTelemetryProvider):
    """Legacy wrapper for LocalTelemetryProvider, now using the OTEL implementation."""
    pass

class NoOpTelemetryProvider:
    """A provider that records in-memory spans without persisting to disk, used for dry runs or tests."""

    def __init__(self):
        self.spans: list[Span] = []
        self.trace_id = "dry-run"

    def start_span(self, name: str, attributes: dict[str, Any] = None) -> Span:
        span = Span(name=name, attributes=attributes or {})
        self.spans.append(span)
        return span

    def record_event(self, name: str, attributes: dict[str, Any] = None) -> None:
        pass

