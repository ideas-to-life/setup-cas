import json
import re
from collections.abc import Mapping
from pathlib import Path
from typing import Any

import jsonschema

from .prompts import PromptRepository


class ReasoningExecutionContract:
    def __init__(self, provider: Any, prompt_repo: PromptRepository | None = None, context: dict[str, Any] | None = None):
        self.provider = provider
        self.prompt_repo = prompt_repo or PromptRepository()
        self.context = context or {}

    def reason(self, step_name: str, inputs: dict[str, Any]) -> Any:
        """Execute the reasoning step with schema validation.

        Args:
            step_name: The name of the reasoning step
            inputs: The prepared inputs dictionary.

        Returns:
            A dictionary containing the validated reasoning output.

        Raises:
            jsonschema.ValidationError: If the reasoning output fails schema validation.
        """
        flow_name = self.context.get("flow_name", "orchestration-flow")
        profile = self.context.get("execution_profile", {})
        telemetry = self.context.get("observability")

        span = None
        if telemetry:
            span = telemetry.start_span(
                name=f"reasoning.{step_name}",
                attributes={
                    "llm.provider": profile.get("provider"),
                    "llm.model": profile.get("model"),
                    "llm.temperature": profile.get("temperature"),
                    "cas.flow_name": flow_name,
                    "cas.step_name": step_name
                }
            )

        if profile:
            print(f"[CAS][DEBUG] Reasoning step '{step_name}' using profile: "
                  f"provider={profile.get('provider')}, model={profile.get('model')}, "
                  f"temperature={profile.get('temperature')}")

        # Load prompt using PromptRepository discovery logic
        definition = self.prompt_repo.get_reasoning_definition(flow_name, step_name)

        if span:
            prompt_attrs = {
                "cas.prompt_name": step_name,
                "cas.prompt_version": definition.version or "unversioned",
                "cas.prompt_path": str(definition.path) if definition.path else None,
                "cas.prompt_schema": definition.schema,
                "cas.reasoning_definition": f"{flow_name}.{step_name}",
                "cas.semantic_contract_version": definition.semantic_contract
            }
            # Remove None values
            span.attributes.update({k: v for k, v in prompt_attrs.items() if v is not None})

        if not definition.content:
            # Graceful fallback per research.md
            print(f"[CAS][WARN] Missing prompt for step '{step_name}' in flow '{flow_name}'. Skipping reasoning.")
            if span:
                span.end(status="error", status_message="Missing prompt definition")
            return {}

        try:
            # Load step-specific JSON schema if available for validation
            step_schema = self._load_schema_for_step(step_name, definition.schema)

            # Inject inputs into the prompt for reasoning
            # We wrap it in a clear block so the LLM knows it is the data to process
            context_block = f"## RUNTIME INPUT CONTEXT\n\n```json\n{json.dumps(inputs, indent=2)}\n```\n\n"
            full_prompt = context_block + definition.content

            # Execute reasoning via provider
            # Pass the original schema parameter to provider for LLM guidance (Pydantic model)
            llm_response = self.provider.generate(full_prompt, schema=step_schema, name=step_name)
            response_content = llm_response.content
            usage = llm_response.usage

            if span and usage:
                span.attributes.update({
                    "gen_ai.usage.input_tokens": usage.prompt_tokens,
                    "gen_ai.usage.output_tokens": usage.completion_tokens,
                    "llm.prompt_tokens": usage.prompt_tokens,
                    "llm.completion_tokens": usage.completion_tokens,
                    "llm.total_tokens": usage.total_tokens,
                    "llm.estimated_cost": usage.estimated_cost,
                    "llm.currency": usage.currency,
                    "llm.cost_source": usage.cost_estimation_source
                })


            # Validate and parse response into dict/list
            validated_response = self._validated_response(step_name, response_content)

            # Validate against step-specific schema (loaded from file)
            if step_schema and validated_response:
                self._validate_against_schema(validated_response, step_schema)
                if span:
                    span.add_event("schema_validation_success")
            elif not step_schema and not validated_response and isinstance(response_content, str):
                # Fallback for schema-free steps returning raw string
                if span:
                    span.end(status="ok")
                return response_content

            if span:
                span.end(status="ok")
            return validated_response
        except jsonschema.ValidationError as e:
            print(f"[CAS][ERROR] Reasoning output validation failed for step '{step_name}': {e}")
            if span:
                span.add_event("schema_validation_failure", attributes={"error": str(e)})
                span.end(status="error", status_message=f"Validation failed: {e}")
            return {}
        except Exception as e:
            print(f"[CAS][ERROR] Reasoning failed for step '{step_name}': {e}")
            if span:
                span.end(status="error", status_message=str(e))
            return {}

    def _validated_response(self, step_name: str, response: Any) -> dict[str, Any] | list[Any]:
        if response is None:
            return {}
        if isinstance(response, (dict, list)):
            return response
        if isinstance(response, Mapping):
            return dict(response)

        # Support Pydantic models
        if hasattr(response, "model_dump"):
            return response.model_dump()
        if hasattr(response, "dict"): # Pydantic v1 fallback
            return response.dict()

        if isinstance(response, str):
            clean = response.strip()
            # Try to parse markdown JSON code blocks
            json_pattern = r"```(?:json)?\s*([\s\S]*?)\s*```"
            matches = re.findall(json_pattern, clean)
            if matches:
                try:
                    parsed = json.loads(matches[0])
                    if isinstance(parsed, (dict, list)):
                        return parsed
                except json.JSONDecodeError:
                    pass

            # Try to parse response directly as JSON
            try:
                parsed = json.loads(clean)
                if isinstance(parsed, (dict, list)):
                    return parsed
            except json.JSONDecodeError:
                pass

        print(
            f"[CAS][WARN] Invalid reasoning response for step '{step_name}'. "
            f"Expected dict or list, got {type(response).__name__}. Skipping reasoning output."
        )
        return {}

    def _load_schema_for_step(self, step_name: str, definition_schema: str | None = None) -> dict[str, Any] | None:
        """Load JSON schema for a given step name."""
        # Map step names to schema file names
        schema_mapping = {
            "rules-context-loader": "rule_context_schema.json",
            "conversation-to-architecture-work": "architecture_work_list_schema.json",
            "conversation-to-aw": "architecture_work_list_schema.json",
            "discovery-to-aw": "architecture_work_list_schema.json",
            "vision-to-aw": "architecture_work_list_schema.json",
            "architecture-work-to-evolution-map": "aem_schema.json",
            "alignment-engine": "alignment_report_schema.json",
            "architecture-intent-generator": "aid_schema.json",
            "baseline-discovery": "baseline_assessment_schema.json",
            "evaluation-prompts": "evaluation_schema.json",
            "synthesis-narrative": "synthesis_schema.json",
            "synthesis-rules": "synthesis_schema.json",
            "synthesis-context": "synthesis_schema.json",
            "signal-to-pattern-proposals": "pattern_proposal_schema.json",
            "pattern-scope-classifier": "pattern_scope_classification_schema.json",
            "pattern-promotion-workflow": "pattern_promotion_recommendation_schema.json",
            "promotion-decision-capture": "promotion_decision_schema.json",
            "promotion-to-decision-records": "architecture_decision_record_schema.json",
            "approved-adr-to-pattern": "pattern_schema.json",
            "governance-exception": "governance_exception_schema.json",
            "aem-conflict-resolution": "aem_conflict_resolution_schema.json",
            "generic-conflict-resolution": "generic_conflict_resolution_schema.json",
            "architecture-work-assessment": "aw_assessment_schema.json",
            "governance-context-builder": "governance_context_matching_schema.json",
            "agentic-patterns-extractor": "agentic_patterns_catalogue_schema.json",
            "structural-patterns-extractor": "structural_patterns_catalogue_schema.json",
            "reference-architecture-generator": "reference_architecture_schema.json",
            "forensic-reconciler": "architecture_enrichment_schema.json",
        }

        schema_file = definition_schema or schema_mapping.get(step_name)
        if not schema_file:
            return None

        candidate_dirs = [
            Path("src/cas_runner/schemas"),
            Path(".cas/schemas"),
            Path(__file__).resolve().parent.parent / "schemas",
            Path(__file__).resolve().parents[2] / "schemas",
            Path(__file__).resolve().parents[2] / "src" / "cas_runner" / "schemas",
        ]
        for cdir in candidate_dirs:
            try:
                candidate_path = cdir / schema_file
                if candidate_path.exists():
                    with open(candidate_path, encoding="utf-8") as f:
                        return json.load(f)
            except Exception:
                continue
        return None

    def _validate_against_schema(self, data: Any, schema: dict[str, Any]) -> None:
        """Validate data against JSON schema."""
        if isinstance(data, list):
            for item in data:
                jsonschema.validate(instance=item, schema=schema)
        elif isinstance(data, dict) and "adrs" in data and schema.get("title") == "Architecture Decision Record":
            for item in data["adrs"]:
                jsonschema.validate(instance=item, schema=schema)
        else:
            jsonschema.validate(instance=data, schema=schema)
