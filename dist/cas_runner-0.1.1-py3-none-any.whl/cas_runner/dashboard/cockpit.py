"""Terminal Cockpit snapshot collector and text formatter for `cas dashboard` & `watch`."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from cas_runner.governance.control_bands import ControlBandsEngine
from cas_runner.governance.explain import load_patterns_catalogue
from cas_runner.governance.models import ControlBandsReport
from cas_runner.governance.sdlc_state import SDLCState, SDLCStatePublisher
from cas_runner.steps.forensic.extractor import compute_package_coupling_metrics

SDLC_BREADCRUMB = (
    "Intent [A/P/Q] → Spec → Plan [Path A/B/C] → Tasks [TDD] → Verifier → Maintain"
)


@dataclass
class MartinPackageMetric:
    """Robert C. Martin coupling and main-sequence distance for one package."""

    package: str
    ca: int = 0
    ce: int = 0
    instability: float = 0.0
    abstractness: float = 0.0
    distance: float = 0.0
    zone_violation: bool = False


@dataclass
class PatternUsageSummary:
    """Summary of ratified patterns available and active in the repository."""

    total_ratified: int = 0
    categories: dict[str, int] = field(default_factory=dict)
    active_patterns: list[str] = field(default_factory=list)


@dataclass
class TerminalCockpitSnapshot:
    """Aggregated read-only state rendered by the 4-panel Rich Terminal Cockpit."""

    sdlc_state: SDLCState
    coupling_metrics: list[MartinPackageMetric] = field(default_factory=list)
    control_bands: ControlBandsReport | None = None
    pattern_summary: PatternUsageSummary = field(default_factory=PatternUsageSummary)


def collect_cockpit_snapshot(
    target_dir: Path | str = ".",
    project: str = "ideas-to-life-cas",
) -> TerminalCockpitSnapshot:
    """Collect live SDLC state, Martin coupling, control bands, and pattern summary."""
    target_path = Path(target_dir).resolve()

    publisher = SDLCStatePublisher(project=project, target_dir=target_path)
    sdlc_state = publisher.load_or_create()

    raw_metrics = compute_package_coupling_metrics(target_path)
    coupling_metrics = [
        MartinPackageMetric(
            package=str(item.get("package", "")),
            ca=int(item.get("ca", 0)),
            ce=int(item.get("ce", 0)),
            instability=float(item.get("instability", 0.0)),
            abstractness=float(item.get("abstractness", 0.0)),
            distance=float(item.get("distance", 0.0)),
            zone_violation=float(item.get("distance", 0.0)) > 0.5,
        )
        for item in raw_metrics
    ]
    coupling_metrics.sort(key=lambda m: m.distance, reverse=True)

    control_bands = ControlBandsEngine(target_dir=target_path).evaluate()

    catalogue = load_patterns_catalogue()
    categories: dict[str, int] = {}
    active_patterns: list[str] = []
    for entry in catalogue:
        cat = str(entry.get("category") or "general")
        categories[cat] = categories.get(cat, 0) + 1
        pat_id = str(entry.get("id") or "").strip()
        if pat_id and len(active_patterns) < 8:
            active_patterns.append(pat_id)

    pattern_summary = PatternUsageSummary(
        total_ratified=len(catalogue),
        categories=categories,
        active_patterns=active_patterns,
    )

    return TerminalCockpitSnapshot(
        sdlc_state=sdlc_state,
        coupling_metrics=coupling_metrics,
        control_bands=control_bands,
        pattern_summary=pattern_summary,
    )


def format_cockpit_text(snapshot: TerminalCockpitSnapshot) -> str:
    """Render a plain-text summary of the 4-panel Terminal Cockpit."""
    lines = [
        f"CAS Terminal Cockpit — Project: {snapshot.sdlc_state.project} ({snapshot.sdlc_state.branch})",
        f"SDLC Stages: {SDLC_BREADCRUMB}",
        "",
        "Martin Coupling Gauge:",
    ]
    if not snapshot.coupling_metrics:
        lines.append("  (no Python packages analyzed)")
    else:
        for metric in snapshot.coupling_metrics[:10]:
            flag = " [FLAG D > 0.5]" if metric.zone_violation else ""
            lines.append(
                f"  - {metric.package}: Ca={metric.ca} Ce={metric.ce} "
                f"I={metric.instability:.2f} A={metric.abstractness:.2f} "
                f"D={metric.distance:.2f}{flag}"
            )

    lines.append("")
    lines.append("Control Band Monitor:")
    if snapshot.control_bands and snapshot.control_bands.results:
        lines.append(f"  Highest Band: {snapshot.control_bands.highest_band}")
        for res in snapshot.control_bands.results:
            lines.append(
                f"  - {res.metric}: {res.observed_value} "
                f"(1sigma={res.threshold_1sigma}, 2sigma={res.threshold_2sigma}, "
                f"3sigma={res.threshold_3sigma}) -> {res.band} ({res.action})"
            )
    else:
        lines.append("  (no control band evaluations)")

    lines.append("")
    lines.append(
        f"Pattern Usage Summary: {snapshot.pattern_summary.total_ratified} ratified patterns"
    )
    if snapshot.pattern_summary.categories:
        cats = ", ".join(
            f"{k}={v}" for k, v in sorted(snapshot.pattern_summary.categories.items())
        )
        lines.append(f"  Categories: {cats}")
    return "\n".join(lines)
