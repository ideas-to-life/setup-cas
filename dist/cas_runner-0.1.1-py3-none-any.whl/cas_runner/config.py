from __future__ import annotations

import os
from enum import StrEnum
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field, field_validator

DEFAULT_AUTO_PRECEDENCE = ["speckit", "anthropic-native", "superpowers", "agent-skills"]

DEFAULT_PROFILES: dict[str, dict[str, Any]] = {
    "speckit": {
        "artifacts": {
            "intent": [
                "specs/*-*/intent.md",
                ".specify/assessments/*/intake.md",
                ".specify/assessments/*/decision.md",
            ],
            "spec": ["specs/*-*/spec.md"],
            "plan": ["specs/*-*/plan.md"],
            "tasks": ["specs/*-*/tasks.md"],
            "tests": ["tests/**/test_*.py", "tests/**/*_test.py"],
        },
        "plan_required_sections": {
            "files_that_change": [
                "Files that change",
                "Project Structure",
                "Source Code",
                "Affected CAS Surfaces",
            ],
            "order_of_work": [
                "Order of work",
                "Phases",
                "Implementation",
                "Tasks",
            ],
            "risks": [
                "Risks",
                "Constitution Check",
                "Complexity Tracking",
                "Constraints",
            ],
            "proof": [
                "Proof",
                "Verification",
                "Testing",
                "Quickstart",
            ],
        },
    },
    "anthropic-native": {
        "artifacts": {
            "intent": ["intent.md", "specs/*/intent.md"],
            "spec": ["spec.md", "specs/*/spec.md"],
            "plan": ["plan.md", "specs/*/plan.md"],
            "tasks": ["tasks.md", "plan.md"],
            "tests": ["tests/**/test_*.py", "tests/**/*_test.py"],
        },
        "plan_required_sections": {
            "files_that_change": ["Files that change", "Project Structure"],
            "order_of_work": ["Order of work", "Steps", "Phases"],
            "risks": ["Risks", "Trade-offs"],
            "proof": ["Proof", "Verification"],
        },
    },
    "superpowers": {
        "artifacts": {
            "intent": ["docs/plans/*-design.md"],
            "spec": ["docs/plans/*-design.md"],
            "plan": ["docs/plans/*-plan.md", "docs/plans/*.md"],
            "tasks": ["docs/plans/*-plan.md", "docs/plans/*.md"],
            "tests": ["tests/**/test_*.py", "tests/**/*_test.py"],
        },
        "plan_required_sections": {
            "files_that_change": ["Files", "Files that change", "Architecture"],
            "order_of_work": ["Tasks", "Task 1", "Order of work", "Steps"],
            "risks": ["Risks", "Constraints", "Trade-offs"],
            "proof": ["Verification", "Proof", "Testing"],
        },
    },
    "agent-skills": {
        "artifacts": {
            "intent": ["docs/specs/*-intent.md", "docs/specs/*.md"],
            "spec": ["docs/specs/*-spec.md", "docs/specs/*.md"],
            "plan": ["docs/plans/*-plan.md", "docs/plans/*.md"],
            "tasks": ["docs/plans/*-tasks.md", "docs/plans/*-plan.md"],
            "tests": ["tests/**/test_*.py", "tests/**/*_test.py"],
        },
        "plan_required_sections": {
            "files_that_change": ["Files that change", "Files", "Modules"],
            "order_of_work": ["Order of work", "Tasks", "Slices"],
            "risks": ["Risks", "Assumptions", "Trade-offs"],
            "proof": ["Proof", "Verification", "Tests"],
        },
    },
}


class ConfigSourceTier(StrEnum):
    CLI = "cli_flag"
    LOCAL = "local_config"
    GLOBAL = "global_config"
    ENV = "env_var"
    DEFAULT = "default"


class ConfigFieldProvenance(BaseModel):
    field_path: str
    value: Any
    source_tier: ConfigSourceTier
    source_location: str


class ProjectConfig(BaseModel):
    name: str = "cas-project"
    description: str = ""


class LLMConfig(BaseModel):
    default_provider: str = "mock"
    default_model: str = "mock-model"
    fallback_provider: str | None = None
    fallback_model: str | None = None
    temperature: float = 0.0
    timeout_seconds: int = 60

    @field_validator("default_provider")
    @classmethod
    def validate_provider(cls, v: str) -> str:
        valid = {
            "anthropic",
            "gemini",
            "openai",
            "mock",
            "stub",
            "ollama",
            "huggingface",
        }
        norm = v.lower().strip()
        if norm not in valid:
            raise ValueError(
                f"Unknown LLM provider '{v}'. Valid choices: {', '.join(sorted(valid))}"
            )
        return norm

    @field_validator("temperature")
    @classmethod
    def validate_temperature(cls, v: float) -> float:
        if not (0.0 <= v <= 2.0):
            raise ValueError("Temperature must be between 0.0 and 2.0")
        return v

    @field_validator("timeout_seconds")
    @classmethod
    def validate_timeout(cls, v: int) -> int:
        if not (1 <= v <= 600):
            raise ValueError("Timeout seconds must be between 1 and 600")
        return v


class SDLCProfileSpec(BaseModel):
    artifacts: dict[str, list[str]] = Field(default_factory=dict)
    plan_required_sections: dict[str, list[str]] = Field(default_factory=dict)


class GovernanceConfig(BaseModel):
    enforcement: str = "strict"
    fail_on: str = "high"
    active_profile: str = "auto"
    bands_file: str = ".cas/bands.yaml"
    auto_precedence: list[str] = Field(
        default_factory=lambda: list(DEFAULT_AUTO_PRECEDENCE)
    )
    profiles: dict[str, SDLCProfileSpec] = Field(
        default_factory=lambda: {
            k: SDLCProfileSpec(**v) for k, v in DEFAULT_PROFILES.items()
        }
    )

    @field_validator("enforcement")
    @classmethod
    def validate_enforcement(cls, v: str) -> str:
        norm = v.lower().strip()
        if norm not in {"strict", "advisory"}:
            raise ValueError("Enforcement must be 'strict' or 'advisory'")
        return norm

    @field_validator("fail_on")
    @classmethod
    def validate_fail_on(cls, v: str) -> str:
        norm = v.lower().strip()
        if norm not in {"critical", "high", "medium", "low"}:
            raise ValueError("fail_on must be one of: critical, high, medium, low")
        return norm

    @field_validator("active_profile")
    @classmethod
    def validate_active_profile(cls, v: str) -> str:
        norm = v.lower().strip()
        valid = {"auto", "speckit", "anthropic-native", "superpowers", "agent-skills"}
        if norm not in valid:
            raise ValueError(
                f"active_profile must be one of: {', '.join(sorted(valid))}"
            )
        return norm


class KnowledgeConfig(BaseModel):
    workspace_path: str = "~/cas-knowledge"
    git_sync: bool = True


class TelemetryConfig(BaseModel):
    enabled: bool = True
    export_traces: bool = False


class CASConfig(BaseModel):
    version: str = "1.0"
    project: ProjectConfig = Field(default_factory=ProjectConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    governance: GovernanceConfig = Field(default_factory=GovernanceConfig)
    knowledge: KnowledgeConfig = Field(default_factory=KnowledgeConfig)
    telemetry: TelemetryConfig = Field(default_factory=TelemetryConfig)

    @classmethod
    def resolve(
        cls,
        target_dir: str | Path = ".",
        cli_overrides: dict[str, Any] | None = None,
        global_config_path: str | Path | None = None,
    ) -> EffectiveCASConfig:
        """
        Evaluates effective configuration across the strict 5-tier precedence cascade:
        1. Explicit CLI Flags
        2. Local Project Config (.cas/config.yaml in target project)
        3. User Global Config (~/.cas/config.yaml or CAS_GLOBAL_CONFIG_PATH)
        4. Environment Variables (e.g. CAS_PROVIDER, CAS_ENFORCEMENT)
        5. Built-in Safe Defaults
        """
        target_path = Path(target_dir).resolve()
        provenance: dict[str, ConfigFieldProvenance] = {}

        # -------------------------------------------------------------
        # Tier 5: Built-in Safe Defaults
        # -------------------------------------------------------------
        default_config = cls()
        merged_dict: dict[str, Any] = {
            "version": default_config.version,
            "project": default_config.project.model_dump(),
            "llm": default_config.llm.model_dump(),
            "governance": default_config.governance.model_dump(),
            "knowledge": default_config.knowledge.model_dump(),
            "telemetry": default_config.telemetry.model_dump(),
        }

        def record_tier(path: str, value: Any, tier: ConfigSourceTier, loc: str):
            provenance[path] = ConfigFieldProvenance(
                field_path=path,
                value=value,
                source_tier=tier,
                source_location=loc,
            )

        def walk_record_defaults(prefix: str, d: dict[str, Any]):
            for k, v in d.items():
                p = f"{prefix}.{k}" if prefix else k
                if isinstance(v, dict) and k != "profiles":
                    walk_record_defaults(p, v)
                else:
                    record_tier(p, v, ConfigSourceTier.DEFAULT, "built-in safe default")

        for section, sdict in merged_dict.items():
            if isinstance(sdict, dict):
                walk_record_defaults(section, sdict)
            else:
                record_tier(
                    section, sdict, ConfigSourceTier.DEFAULT, "built-in safe default"
                )

        # -------------------------------------------------------------
        # Tier 4: Environment Variables
        # -------------------------------------------------------------
        env_mappings = {
            "CAS_PROJECT_NAME": ("project.name", str),
            "CAS_PROJECT_DESCRIPTION": ("project.description", str),
            "CAS_DEFAULT_PROVIDER": ("llm.default_provider", str),
            "CAS_PROVIDER": ("llm.default_provider", str),
            "CAS_DEFAULT_MODEL": ("llm.default_model", str),
            "CAS_MODEL": ("llm.default_model", str),
            "CAS_FALLBACK_PROVIDER": ("llm.fallback_provider", str),
            "CAS_FALLBACK_MODEL": ("llm.fallback_model", str),
            "CAS_TEMPERATURE": ("llm.temperature", float),
            "CAS_TIMEOUT_SECONDS": ("llm.timeout_seconds", int),
            "CAS_ENFORCEMENT": ("governance.enforcement", str),
            "CAS_FAIL_ON": ("governance.fail_on", str),
            "CAS_ACTIVE_PROFILE": ("governance.active_profile", str),
            "CAS_BANDS_FILE": ("governance.bands_file", str),
            "CAS_KNOWLEDGE_WORKSPACE": ("knowledge.workspace_path", str),
            "CAS_KNOWLEDGE_WORKSPACE_PATH": ("knowledge.workspace_path", str),
            "CAS_KNOWLEDGE_GIT_SYNC": (
                "knowledge.git_sync",
                lambda x: str(x).lower() in ("1", "true", "yes"),
            ),
            "CAS_TELEMETRY_ENABLED": (
                "telemetry.enabled",
                lambda x: str(x).lower() in ("1", "true", "yes"),
            ),
            "CAS_TELEMETRY_EXPORT_TRACES": (
                "telemetry.export_traces",
                lambda x: str(x).lower() in ("1", "true", "yes"),
            ),
        }

        for env_var, (dot_path, caster) in env_mappings.items():
            val = os.getenv(env_var)
            if val is not None and val != "":
                try:
                    typed_val = caster(val)
                    _set_nested(merged_dict, dot_path, typed_val)
                    record_tier(
                        dot_path,
                        typed_val,
                        ConfigSourceTier.ENV,
                        f"Environment variable {env_var}",
                    )
                except Exception:
                    pass

        # -------------------------------------------------------------
        # Tier 3: User Global Config (~/.cas/config.yaml or CAS_GLOBAL_CONFIG_PATH)
        # -------------------------------------------------------------
        global_path_env = os.getenv("CAS_GLOBAL_CONFIG_PATH")
        if global_path_env:
            g_path = Path(global_path_env).expanduser().resolve()
        elif global_config_path:
            g_path = Path(global_config_path).expanduser().resolve()
        else:
            g_path = Path("~/.cas/config.yaml").expanduser().resolve()

        resolved_global_file: Path | None = None
        if g_path.exists() and g_path.is_file():
            resolved_global_file = g_path
            try:
                raw_g = yaml.safe_load(g_path.read_text(encoding="utf-8"))
                if isinstance(raw_g, dict):
                    _merge_dict_with_provenance(
                        merged_dict,
                        raw_g,
                        ConfigSourceTier.GLOBAL,
                        str(g_path),
                        record_tier,
                    )
            except Exception:
                pass

        # -------------------------------------------------------------
        # Tier 2: Local Project Config (.cas/config.yaml)
        # -------------------------------------------------------------
        local_config_file = target_path / ".cas" / "config.yaml"
        resolved_local_file: Path | None = None
        if local_config_file.exists() and local_config_file.is_file():
            resolved_local_file = local_config_file
            try:
                raw_l = yaml.safe_load(local_config_file.read_text(encoding="utf-8"))
                if isinstance(raw_l, dict):
                    _merge_dict_with_provenance(
                        merged_dict,
                        raw_l,
                        ConfigSourceTier.LOCAL,
                        str(local_config_file),
                        record_tier,
                    )
            except Exception:
                pass

        # -------------------------------------------------------------
        # Tier 1: Explicit CLI Flags
        # -------------------------------------------------------------
        if cli_overrides:
            cli_mappings = {
                "provider": "llm.default_provider",
                "default_provider": "llm.default_provider",
                "model": "llm.default_model",
                "default_model": "llm.default_model",
                "temperature": "llm.temperature",
                "timeout_seconds": "llm.timeout_seconds",
                "enforcement": "governance.enforcement",
                "advisory": (
                    "governance.enforcement",
                    lambda adv: "advisory" if adv else None,
                ),
                "fail_on": "governance.fail_on",
                "active_profile": "governance.active_profile",
                "sdlc_profile": "governance.active_profile",
                "bands_file": "governance.bands_file",
                "workspace_path": "knowledge.workspace_path",
            }
            for cli_key, val in cli_overrides.items():
                if val is None:
                    continue
                mapping = cli_mappings.get(cli_key)
                if not mapping:
                    continue
                if isinstance(mapping, tuple):
                    dot_path, transform = mapping
                    transformed_val = transform(val)
                    if transformed_val is not None:
                        _set_nested(merged_dict, dot_path, transformed_val)
                        record_tier(
                            dot_path,
                            transformed_val,
                            ConfigSourceTier.CLI,
                            f"CLI flag --{cli_key}",
                        )
                else:
                    dot_path = mapping
                    _set_nested(merged_dict, dot_path, val)
                    record_tier(
                        dot_path, val, ConfigSourceTier.CLI, f"CLI flag --{cli_key}"
                    )

        validated_config = cls(**merged_dict)
        return EffectiveCASConfig(
            config=validated_config,
            provenance=provenance,
            target_dir=target_path,
            local_config_file=resolved_local_file,
            global_config_file=resolved_global_file,
        )


class EffectiveCASConfig(BaseModel):
    config: CASConfig
    provenance: dict[str, ConfigFieldProvenance]
    target_dir: Path
    local_config_file: Path | None = None
    global_config_file: Path | None = None


def _set_nested(d: dict[str, Any], path: str, value: Any):
    parts = path.split(".")
    curr = d
    for p in parts[:-1]:
        if p not in curr or not isinstance(curr[p], dict):
            curr[p] = {}
        curr = curr[p]
    curr[parts[-1]] = value


def _merge_dict_with_provenance(
    target: dict[str, Any],
    source: dict[str, Any],
    tier: ConfigSourceTier,
    location: str,
    record_func,
    prefix: str = "",
):
    for k, v in source.items():
        dot_path = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict) and k != "profiles":
            if k not in target or not isinstance(target[k], dict):
                target[k] = {}
            _merge_dict_with_provenance(
                target[k], v, tier, location, record_func, prefix=dot_path
            )
        else:
            if v is not None:
                target[k] = v
                record_func(dot_path, v, tier, location)


def load_config(
    target_dir: str | Path = ".",
    cli_overrides: dict[str, Any] | None = None,
) -> EffectiveCASConfig:
    """Helper function to resolve effective CAS configuration."""
    return CASConfig.resolve(target_dir=target_dir, cli_overrides=cli_overrides)


def validate_config(target_dir: str | Path = ".") -> tuple[bool, str]:
    """Validates local .cas/config.yaml against CASConfig schema."""
    target_path = Path(target_dir).resolve()
    config_file = target_path / ".cas" / "config.yaml"
    if not config_file.exists():
        return False, f"No .cas/config.yaml found in {target_path}"

    try:
        raw = yaml.safe_load(config_file.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            return (
                False,
                f"Invalid YAML structure in {config_file}: expected key-value mapping",
            )
        CASConfig(**raw)
        return True, f"Configuration at {config_file} is valid."
    except Exception as e:
        return False, f"Configuration validation failed for {config_file}: {e}"
