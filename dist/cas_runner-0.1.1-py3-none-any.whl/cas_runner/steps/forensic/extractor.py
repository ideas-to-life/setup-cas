import ast
import os
import re
from pathlib import Path
from typing import Any

import yaml

from ...io import TargetProjectContext

IGNORED_DIRS = {
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    "dist",
    "build",
    ".specify",
    ".claude",
    "tests",
    "fixtures",
    "templates",
}

MANIFEST_FILENAMES = {
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    "requirements.txt",
    "package.json",
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
    "go.mod",
    "go.sum",
    "Cargo.toml",
    "Cargo.lock",
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    "Dockerfile",
    "docker-compose.yml",
    "docker-compose.yaml",
    "Makefile",
}


def extract_manifest_evidence(repo_root: Path) -> list[dict[str, Any]]:
    """Extracts manifest files and package definitions from the repository."""
    evidence = []
    repo_root = repo_root.resolve()

    for item in repo_root.rglob("*"):
        if not item.is_file():
            continue
        if any(part in IGNORED_DIRS for part in item.relative_to(repo_root).parts):
            continue

        if item.name in MANIFEST_FILENAMES:
            rel_path = str(item.relative_to(repo_root))
            snippet = ""
            try:
                content = item.read_text(encoding="utf-8", errors="replace")
                snippet = "\n".join(content.splitlines()[:20])
            except Exception:
                pass

            evidence.append(
                {
                    "id": f"ev-manifest-{abs(hash(rel_path)) % 1000000}",
                    "path": rel_path,
                    "type": "manifest",
                    "reference": item.name,
                    "snippet": snippet,
                    "confidence": "high",
                }
            )

    return evidence


def extract_workflow_evidence(repo_root: Path) -> list[dict[str, Any]]:
    """Extracts CI/CD workflow and pipeline evidence."""
    evidence = []
    repo_root = repo_root.resolve()
    wf_dir = repo_root / ".github" / "workflows"

    if wf_dir.exists() and wf_dir.is_dir():
        for wf_file in wf_dir.glob("*.y*ml"):
            rel_path = str(wf_file.relative_to(repo_root))
            snippet = ""
            try:
                content = wf_file.read_text(encoding="utf-8", errors="replace")
                snippet = "\n".join(content.splitlines()[:25])
            except Exception:
                pass

            evidence.append(
                {
                    "id": f"ev-wf-{abs(hash(rel_path)) % 1000000}",
                    "path": rel_path,
                    "type": "workflow",
                    "reference": wf_file.name,
                    "snippet": snippet,
                    "confidence": "high",
                }
            )

    return evidence


def extract_skill_evidence(repo_root: Path) -> list[dict[str, Any]]:
    """Extracts agent and domain skill evidence from SKILL.md files."""
    evidence = []
    repo_root = repo_root.resolve()
    seen_canonical_paths: set[Path] = set()
    seen_skill_slugs: set[str] = set()

    for item in repo_root.rglob("SKILL.md"):
        if not item.is_file():
            continue

        canonical_path = item.resolve()
        if canonical_path in seen_canonical_paths:
            continue
        seen_canonical_paths.add(canonical_path)

        rel_parts = item.relative_to(repo_root).parts
        if any(part in IGNORED_DIRS for part in rel_parts):
            continue

        rel_path = str(item.relative_to(repo_root))
        try:
            content = item.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue

        # Parse YAML frontmatter if present
        meta: dict[str, Any] = {}
        fm_match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)$", content, re.DOTALL)
        body = content
        if fm_match:
            raw_fm = fm_match.group(1)
            body = fm_match.group(2)
            try:
                parsed_fm = yaml.safe_load(raw_fm)
                if isinstance(parsed_fm, dict):
                    meta = parsed_fm
            except Exception:
                pass

        skill_name = meta.get("name")
        if not skill_name:
            # Fallback to parent directory name
            skill_name = item.parent.name

        slug = re.sub(r"[^a-z0-9_.-]+", "-", skill_name.lower()).strip("-")

        # Option A (Prefix and Substrate Rule - FR-007):
        is_governance = (
            slug.startswith("cas-")
            or skill_name.startswith("cas-")
            or rel_path.startswith(".cas/")
            or rel_path.startswith("src/cas_skills/")
            or ".cas" in rel_parts
            or "cas_skills" in rel_parts
        )
        is_domain = (
            not is_governance
            and (
                rel_path.startswith("skills/")
                or (len(rel_parts) > 0 and rel_parts[0] == "skills")
            )
        )

        if not is_governance and not is_domain:
            continue

        if slug in seen_skill_slugs:
            continue
        seen_skill_slugs.add(slug)

        category = "governance" if is_governance else "domain"

        description = meta.get("description", "")
        if not description:
            # Try to grab first markdown paragraph
            for line in body.splitlines():
                stripped = line.strip()
                if stripped and not stripped.startswith("#"):
                    description = stripped
                    break

        snippet = description if description else f"Skill: {skill_name}"
        ev_id = f"ev-skill-{slug}"

        evidence.append(
            {
                "id": ev_id,
                "path": rel_path,
                "type": "skill",
                "reference": skill_name,
                "snippet": snippet[:200],
                "confidence": "high",
                "metadata": {
                    "name": skill_name,
                    "description": description,
                    "category": category,
                    "compatibility": meta.get("compatibility", ""),
                    "tags": meta.get("tags", []),
                },
            }
        )

    return evidence


def extract_python_ast_symbols(
    file_path: Path, repo_root: Path
) -> list[dict[str, Any]]:
    """Parses a Python file using the standard library AST module."""
    symbols = []
    rel_path = str(file_path.relative_to(repo_root))

    try:
        source = file_path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(file_path))
    except Exception:
        return symbols

    # Extract module docstring
    module_doc = ast.get_docstring(tree) or ""

    # Extract imports
    module_imports = []
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                module_imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            mod = node.module or ""
            for alias in node.names:
                module_imports.append(f"{mod}.{alias.name}" if mod else alias.name)

    # Extract top-level classes and functions
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            methods = [
                n.name
                for n in node.body
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
            ]
            symbols.append(
                {
                    "name": node.name,
                    "type": "class",
                    "path": rel_path,
                    "docstring": ast.get_docstring(node) or module_doc,
                    "methods": methods,
                    "imports": module_imports,
                }
            )
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            symbols.append(
                {
                    "name": node.name,
                    "type": "function",
                    "path": rel_path,
                    "docstring": ast.get_docstring(node) or "",
                    "methods": [],
                    "imports": module_imports,
                }
            )

    return symbols


def extract_polyglot_imports(file_path: Path, repo_root: Path) -> list[str]:
    """Extracts external imports from non-Python files using pattern matching."""
    imports = []
    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return imports

    # JS/TS imports: import ... from '...' or require('...')
    for match in re.finditer(
        r"""(?:import\s+.*?from\s+['"]([^'"]+)['"]|require\s*\(\s*['"]([^'"]+)['"]\))""",
        content,
    ):
        target = match.group(1) or match.group(2)
        if target and target not in imports:
            imports.append(target)

    # Go imports: import ( "..." ) or import "..."
    for match in re.finditer(r"""import\s+["']([^"']+)["']""", content):
        target = match.group(1)
        if target and target not in imports:
            imports.append(target)

    return imports


PYTHONIC_ABSTRACT_BASES = {
    "ABC",
    "abc.ABC",
    "Protocol",
    "typing.Protocol",
    "TypedDict",
    "typing.TypedDict",
    "NamedTuple",
    "typing.NamedTuple",
    "BaseModel",
    "pydantic.BaseModel",
    "Enum",
    "enum.Enum",
    "StrEnum",
    "enum.StrEnum",
    "IntEnum",
    "enum.IntEnum",
}

PYTHONIC_ABSTRACT_DECORATORS = {
    "dataclass",
    "dataclasses.dataclass",
    "abstractmethod",
    "abc.abstractmethod",
}


def _expr_to_dotted_name(node: ast.AST) -> str:
    """Converts an AST Name, Attribute, or Call node to a dotted string name."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = _expr_to_dotted_name(node.value)
        return f"{prefix}.{node.attr}" if prefix else node.attr
    if isinstance(node, ast.Subscript):
        return _expr_to_dotted_name(node.value)
    if isinstance(node, ast.Call):
        return _expr_to_dotted_name(node.func)
    return ""


def _is_abstract_or_contract_class(cls_node: ast.ClassDef) -> bool:
    """Determines whether a Python ClassDef qualifies as abstract or a structural contract."""
    # 1. Check base classes (ABC, Protocol, TypedDict, BaseModel, Enum, etc.)
    for base in cls_node.bases:
        base_name = _expr_to_dotted_name(base)
        short_base = base_name.split(".")[-1] if base_name else ""
        if (
            base_name in PYTHONIC_ABSTRACT_BASES
            or short_base in PYTHONIC_ABSTRACT_BASES
        ):
            return True

    # 2. Check metaclass=ABCMeta
    for kw in cls_node.keywords:
        if kw.arg == "metaclass":
            meta_name = _expr_to_dotted_name(kw.value)
            if meta_name.endswith("ABCMeta"):
                return True

    # 3. Check class decorators (@dataclass, @abstractmethod)
    for dec in cls_node.decorator_list:
        dec_name = _expr_to_dotted_name(dec)
        short_dec = dec_name.split(".")[-1] if dec_name else ""
        if (
            dec_name in PYTHONIC_ABSTRACT_DECORATORS
            or short_dec in PYTHONIC_ABSTRACT_DECORATORS
        ):
            return True

    # 4. Check methods for @abstractmethod or raise NotImplementedError / ...
    for stmt in cls_node.body:
        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for dec in stmt.decorator_list:
                dec_name = _expr_to_dotted_name(dec)
                if dec_name.endswith("abstractmethod"):
                    return True
            for sub in ast.walk(stmt):
                if isinstance(sub, ast.Raise) and sub.exc is not None:
                    exc_name = _expr_to_dotted_name(sub.exc)
                    if exc_name.endswith("NotImplementedError"):
                        return True
            # Method body consisting solely of Ellipsis (...)
            non_doc_stmts = [
                s
                for s in stmt.body
                if not (
                    isinstance(s, ast.Expr)
                    and isinstance(s.value, ast.Constant)
                    and isinstance(s.value.value, str)
                )
            ]
            if (
                len(non_doc_stmts) == 1
                and isinstance(non_doc_stmts[0], ast.Expr)
                and isinstance(non_doc_stmts[0].value, ast.Constant)
                and non_doc_stmts[0].value.value is Ellipsis
            ):
                return True

    return False


def _resolve_package_for_file(
    file_path: Path, repo_root: Path
) -> tuple[str, str] | None:
    """Returns (package_dotted_name, repo_relative_dir_path) for a Python source file."""
    rel = file_path.relative_to(repo_root)
    parts = list(rel.parts)
    if not parts:
        return None

    # Exclude tests and hidden/ignored directories
    if parts[0] in ("tests", "test", "docs", "specs") or any(
        p in IGNORED_DIRS or p.startswith(".") for p in parts
    ):
        return None

    if parts[0] == "src":
        pkg_parts = parts[1:-1]
        if not pkg_parts:
            return None
        if len(pkg_parts) > 2:
            pkg_parts = pkg_parts[:2]
        pkg_name = ".".join(pkg_parts)
        pkg_rel_dir = "/".join(["src", *pkg_parts])
        return pkg_name, pkg_rel_dir

    # Repo without src/ layout: group by directory if inside a subpackage
    if len(parts) >= 2:
        pkg_parts = parts[:-1]
        pkg_name = ".".join(pkg_parts)
        pkg_rel_dir = "/".join(parts[:-1])
        return pkg_name, pkg_rel_dir

    return None


def compute_package_coupling_metrics(repo_root: Path) -> list[dict[str, Any]]:
    """
    Computes Robert C. Martin package coupling metrics per Python package directory:
    - Ca (Afferent Coupling)
    - Ce (Efferent Coupling)
    - Instability I = Ce / (Ca + Ce)
    - Pythonic Abstractness A = Na / Nc
    - Normalized Distance from Main Sequence D = |A + I - 1| (0.0 when Ca + Ce == 0)
    """
    repo_root = Path(repo_root).resolve()
    packages: dict[str, dict[str, Any]] = {}

    # Pass 1: Discover all Python files and group by package
    py_files_by_pkg: dict[str, list[Path]] = {}
    for item in sorted(repo_root.rglob("*.py")):
        if not item.is_file():
            continue
        resolved = _resolve_package_for_file(item, repo_root)
        if not resolved:
            continue
        pkg_name, pkg_rel_dir = resolved
        if pkg_name not in packages:
            packages[pkg_name] = {
                "package": pkg_name,
                "path": pkg_rel_dir,
                "abstract_classes": 0,
                "total_classes": 0,
                "raw_imports": [],
                "anchor_file": str(item.relative_to(repo_root)),
                "anchor_line": 1,
                "has_non_init_anchor": False,
            }
        py_files_by_pkg.setdefault(pkg_name, []).append(item)

    if not packages:
        return []

    known_pkg_names = sorted(packages.keys(), key=len, reverse=True)

    # Pass 2: Parse AST for classes, abstractness, imports, and valid anchor lines
    for pkg_name, file_list in py_files_by_pkg.items():
        pkg_info = packages[pkg_name]
        for file_path in file_list:
            rel_file = str(file_path.relative_to(repo_root))
            try:
                source = file_path.read_text(encoding="utf-8", errors="replace")
                tree = ast.parse(source, filename=str(file_path))
            except Exception:
                continue

            # Record a valid AST statement line for [A] path:line provenance
            if not pkg_info["has_non_init_anchor"] or file_path.name != "__init__.py":
                for stmt in tree.body:
                    if isinstance(
                        stmt,
                        (
                            ast.ClassDef,
                            ast.FunctionDef,
                            ast.AsyncFunctionDef,
                            ast.Assign,
                            ast.AnnAssign,
                            ast.Import,
                            ast.ImportFrom,
                        ),
                    ) and hasattr(stmt, "lineno"):
                        if (
                            file_path.name != "__init__.py"
                            or not pkg_info["has_non_init_anchor"]
                        ):
                            pkg_info["anchor_file"] = rel_file
                            pkg_info["anchor_line"] = int(stmt.lineno)
                            if file_path.name != "__init__.py":
                                pkg_info["has_non_init_anchor"] = True
                            break

            # Inspect classes and imports
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    pkg_info["total_classes"] += 1
                    if _is_abstract_or_contract_class(node):
                        pkg_info["abstract_classes"] += 1
                elif isinstance(node, ast.Import):
                    for alias in node.names:
                        pkg_info["raw_imports"].append((alias.name, 0, file_path))
                elif isinstance(node, ast.ImportFrom):
                    mod = node.module or ""
                    level = node.level or 0
                    if mod:
                        pkg_info["raw_imports"].append((mod, level, file_path))
                    for alias in node.names:
                        combined = f"{mod}.{alias.name}" if mod else alias.name
                        pkg_info["raw_imports"].append((combined, level, file_path))

    # Pass 3: Resolve internal package-to-package dependencies (Ce and Ca)
    efferent_map: dict[str, set[str]] = {p: set() for p in packages}
    afferent_map: dict[str, set[str]] = {p: set() for p in packages}

    def _match_known_package(candidate_mod: str) -> str | None:
        for known in known_pkg_names:
            if candidate_mod == known or candidate_mod.startswith(f"{known}."):
                return known
        return None

    for pkg_name, pkg_info in packages.items():
        for target_mod, level, file_path in pkg_info["raw_imports"]:
            resolved_target: str | None = None
            if level > 0:
                rel_parts = list(file_path.relative_to(repo_root).parts)
                file_pkg_parts = (
                    rel_parts[1:-1]
                    if rel_parts and rel_parts[0] == "src"
                    else rel_parts[:-1]
                )
                # Relative import: climb up (level - 1) package segments from the file's directory
                up = max(0, level - 1)
                base_parts = file_pkg_parts[: max(0, len(file_pkg_parts) - up)]
                full_mod = (
                    ".".join([*base_parts, target_mod])
                    if target_mod
                    else ".".join(base_parts)
                )
                resolved_target = _match_known_package(full_mod)
            else:
                resolved_target = _match_known_package(target_mod)

            if resolved_target and resolved_target != pkg_name:
                efferent_map[pkg_name].add(resolved_target)
                afferent_map[resolved_target].add(pkg_name)

    # Pass 4: Compute Ca, Ce, I, A, D per package
    results: list[dict[str, Any]] = []
    for pkg_name in sorted(packages.keys()):
        pkg_info = packages[pkg_name]
        aff = sorted(afferent_map[pkg_name])
        eff = sorted(efferent_map[pkg_name])
        ca = len(aff)
        ce = len(eff)
        total_coupling = ca + ce
        instability = round(ce / total_coupling, 4) if total_coupling > 0 else 0.0

        nc = pkg_info["total_classes"]
        na = pkg_info["abstract_classes"]
        abstractness = round(na / nc, 4) if nc > 0 else 0.0

        # Isolated packages with zero internal coupling (Ca + Ce == 0) have distance 0.0
        distance = (
            round(abs(abstractness + instability - 1.0), 4)
            if total_coupling > 0
            else 0.0
        )

        results.append(
            {
                "package": pkg_name,
                "path": pkg_info["path"],
                "ca": ca,
                "ce": ce,
                "instability": instability,
                "abstractness": abstractness,
                "distance": distance,
                "abstract_classes": na,
                "total_classes": nc,
                "afferent_packages": aff,
                "efferent_packages": eff,
                "anchor_file": pkg_info["anchor_file"],
                "anchor_line": pkg_info["anchor_line"],
            }
        )

    return results


class ForensicExtractor:
    """Orchestrates deterministic and structural extraction across a repository."""

    def __init__(self, target_dir: Path):
        self.target_dir = Path(target_dir).resolve()

    def extract_all(self) -> dict[str, Any]:
        manifests = extract_manifest_evidence(self.target_dir)
        workflows = extract_workflow_evidence(self.target_dir)
        skills = extract_skill_evidence(self.target_dir)

        evidence = list(manifests) + list(workflows) + list(skills)
        ast_symbols = []

        # Walk code files
        for item in self.target_dir.rglob("*"):
            if not item.is_file():
                continue
            if any(
                part in IGNORED_DIRS for part in item.relative_to(self.target_dir).parts
            ):
                continue

            rel_path = str(item.relative_to(self.target_dir))

            # Python AST parsing
            if item.suffix == ".py":
                symbols = extract_python_ast_symbols(item, self.target_dir)
                if symbols:
                    ast_symbols.extend(symbols)
                    evidence.append(
                        {
                            "id": f"ev-ast-{abs(hash(rel_path)) % 1000000}",
                            "path": rel_path,
                            "type": "ast_symbol",
                            "reference": f"{len(symbols)} symbols",
                            "confidence": "high",
                        }
                    )
            # Non-python code imports
            elif item.suffix in {".js", ".ts", ".jsx", ".tsx", ".go", ".java", ".rs"}:
                poly_imports = extract_polyglot_imports(item, self.target_dir)
                if poly_imports:
                    evidence.append(
                        {
                            "id": f"ev-code-{abs(hash(rel_path)) % 1000000}",
                            "path": rel_path,
                            "type": "code_import",
                            "reference": f"{len(poly_imports)} imports",
                            "snippet": ", ".join(poly_imports[:5]),
                            "confidence": "medium",
                        }
                    )

        package_metrics = compute_package_coupling_metrics(self.target_dir)

        return {
            "evidence": evidence,
            "manifests": manifests,
            "workflows": workflows,
            "skills": skills,
            "ast_symbols": ast_symbols,
            "package_metrics": package_metrics,
        }


CODE_DIR_NAMES = {"src", "lib", "app", "skills", ".cas", ".agents", "pkg", "cmd"}
CODE_FILE_EXTENSIONS = {
    ".py",
    ".ts",
    ".js",
    ".go",
    ".rs",
    ".java",
    ".c",
    ".cpp",
    ".cs",
    ".rb",
    ".php",
}


def validate_target_repository(
    target_dir: str | Path, project_id: str | None = None
) -> None:
    """Validates that target directory exists and contains recognizable source code, manifests, or git root."""
    path = Path(target_dir).resolve()
    if not path.exists():
        raise ValueError(
            f"Target directory '{path}' does not exist. Please specify a valid repository path using '--target-dir /path/to/repo'."
        )
    if not path.is_dir():
        raise ValueError(
            f"Target directory '{path}' is not a directory. Please specify a valid repository path using '--target-dir /path/to/repo'."
        )

    # 1. Check for .git
    if (path / ".git").exists():
        return

    # 2. Check for manifests
    for m in MANIFEST_FILENAMES:
        if (path / m).exists():
            return

    # 3. Check for standard code directories containing files
    for cd in CODE_DIR_NAMES:
        c_path = path / cd
        if c_path.exists() and c_path.is_dir():
            try:
                if any(c_path.iterdir()):
                    return
            except PermissionError:
                pass

    # 4. Check for code or skill files in tree (bounded shallow search up to 3 levels)
    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if d not in IGNORED_DIRS]
        for f in files:
            if f == "SKILL.md" or any(f.endswith(ext) for ext in CODE_FILE_EXTENSIONS):
                return
        rel = Path(root).relative_to(path)
        if len(rel.parts) >= 3:
            dirs.clear()

    raise ValueError(
        f"Target directory '{path}' does not appear to be a valid code repository root (no source code, package manifests, or .git found). "
        f"Please specify the path to the repository using '--target-dir /path/to/repo'."
    )


class ForensicExtractorStep:
    """CAS Runner step for deterministic and structural evidence extraction."""

    name = "forensic-extractor"

    def prepare_inputs(self, context: dict) -> dict:
        project_context = context.get("project_context")
        if isinstance(project_context, TargetProjectContext):
            target_dir = project_context.evidence_root or project_context.project_root
            project_id = project_context.project_id
        else:
            project_id = str(context.get("project", "default-project"))
            target_dir = Path(context.get("target_dir", Path.cwd()))

        target_path = Path(target_dir).resolve()
        validate_target_repository(target_path, project_id=project_id)

        return {
            "project": project_id,
            "target_dir": target_path,
        }

    def execute(self, inputs: dict, reasoning_engine: Any = None) -> dict:
        target_dir = inputs["target_dir"]
        extractor = ForensicExtractor(target_dir=target_dir)
        extracted_data = extractor.extract_all()

        return {
            "project": inputs["project"],
            "target_dir": str(target_dir),
            "extracted_evidence": extracted_data,
        }

    def validate(self, output: dict):
        assert "extracted_evidence" in output
        assert "evidence" in output["extracted_evidence"]
