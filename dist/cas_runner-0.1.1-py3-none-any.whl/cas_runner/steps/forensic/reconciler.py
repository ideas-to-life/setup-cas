import copy
import json
import re
from datetime import date
from pathlib import Path
from typing import Any

import jsonschema

from cas_runner.steps.forensic.flow_extractor import extract_all_flows


def _slugify(text: str) -> str:
    slug = text.lower().strip()
    slug = re.sub(r"[^a-z0-9_.-]+", "-", slug)
    return slug.strip("-") or "unknown"


def reconcile_discovered_flows(
    raw_flows: list[dict[str, Any]],
    components: list[dict[str, Any]] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """
    Reconciles raw discovered flows from various extractors into normalized,
    evidence-backed Flow and Step entities with stable deterministic slug IDs.
    """
    reconciled: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = []
    contradictions: list[dict[str, Any]] = []
    comp_list = components or []

    # Map of command name -> cli_command_map for cross-layer reconciliation
    cli_command_map: dict[str, str] = {}
    for flow in raw_flows:
        if flow.get("type") == "cli":
            cmd = flow.get("trigger", {}).get("event") or flow.get("name")
            if cmd:
                cli_command_map[cmd.lower()] = flow.get("id")

    seen_flow_ids: set[str] = set()
    for raw in raw_flows:
        flow_type = raw.get("type", "unknown")
        entry_path = raw.get("entrypoint", {}).get("path", "main")
        entry_slug = _slugify(Path(entry_path).stem)
        name_slug = _slugify(raw.get("name", "flow"))

        # Build stable hierarchical slug if not already adhering to pattern
        existing_id = raw.get("id", "")
        if existing_id.startswith("flow:") and len(existing_id.split(":")) >= 4:
            flow_id = existing_id
        else:
            flow_id = f"flow:{flow_type}:{entry_slug}:{name_slug}"

        if flow_id in seen_flow_ids:
            continue
        seen_flow_ids.add(flow_id)

        steps: list[dict[str, Any]] = []
        raw_steps = raw.get("steps", [])
        for idx, s in enumerate(raw_steps):
            if isinstance(s, str):
                s_name = s
                s_id = f"step:{idx + 1}:{_slugify(s)[:30]}"
                step_obj = {
                    "id": s_id,
                    "name": s_name,
                    "sequence": idx + 1,
                    "depends_on": [steps[-1]["id"]] if steps else [],
                    "evidence_ids": raw.get("evidence_ids", []),
                    "confidence": raw.get("confidence", "high"),
                }
            elif isinstance(s, dict):
                s_name = s.get("name", f"Step {idx + 1}")
                s_id = s.get("id")
                if not s_id or not s_id.startswith("step:"):
                    s_id = f"step:{idx + 1}:{_slugify(str(s_name))[:30]}"

                # FR-007: Do not fabricate depends_on if flow is declared_flow or if depends_on is explicitly set
                existing_dep = s.get("depends_on")
                if existing_dep is None:
                    if flow_type == "declared_flow":
                        deps = []
                    else:
                        deps = [steps[-1]["id"]] if steps and idx > 0 else []
                else:
                    deps = existing_dep

                step_obj = {
                    "id": s_id,
                    "name": str(s_name),
                    "sequence": s.get("sequence", idx + 1),
                    "depends_on": deps,
                    "implementation": s.get("implementation", ""),
                    "evidence_ids": s.get("evidence_ids", raw.get("evidence_ids", [])),
                    "confidence": s.get("confidence", "high"),
                }
                if "inputs" in s:
                    step_obj["inputs"] = s["inputs"]
                if "outputs" in s:
                    step_obj["outputs"] = s["outputs"]
                if "artefacts" in s:
                    step_obj["artefacts"] = s["artefacts"]
                if "component_id" in s:
                    step_obj["component_id"] = s["component_id"]
                if "control_roles" in s:
                    step_obj["control_roles"] = s["control_roles"]
            else:
                continue

            # Component resolution heuristic
            impl = step_obj.get("implementation", "")
            if not step_obj.get("component_id") and impl and comp_list:
                for comp in comp_list:
                    c_path = comp.get("path", "")
                    c_name = comp.get("name", "")
                    if c_path and (c_path in impl or impl in c_path):
                        step_obj["component_id"] = comp.get("id")
                        break
                    elif c_name and c_name.lower() in impl.lower():
                        step_obj["component_id"] = comp.get("id")
                        break

            # Control role classification heuristic
            text_to_check = f"{step_obj.get('name', '')} {impl}".lower()
            inferred_roles = []
            if any(
                k in text_to_check
                for k in ("prevent", "rule", "gate", "enforce", "check")
            ):
                inferred_roles.append("Prevent")
            if any(
                k in text_to_check
                for k in ("detect", "validate", "test", "audit", "lint")
            ):
                inferred_roles.append("Detect")
            if any(
                k in text_to_check for k in ("generate", "build", "create", "render")
            ):
                inferred_roles.append("Generate")
            if any(
                k in text_to_check
                for k in ("correct", "sync", "apply", "fix", "reconcile")
            ):
                inferred_roles.append("Correct")

            if inferred_roles:
                existing_roles = step_obj.get("control_roles", [])
                step_obj["control_roles"] = list(set(existing_roles + inferred_roles))

            # Cross-layer link: check if this step invokes a known CLI command
            for cmd_key, target_flow_id in cli_command_map.items():
                if cmd_key in impl.lower() and target_flow_id != flow_id:
                    step_obj["invokes_flow_id"] = target_flow_id

            steps.append(step_obj)

        # Aggregate flow-level attributes
        comp_ids = list({s["component_id"] for s in steps if s.get("component_id")})
        all_roles = list({r for s in steps for r in s.get("control_roles", [])})

        # Artefacts
        artefacts = raw.get("artefacts", [])
        if not artefacts:
            # Infer from steps
            for s in steps:
                if "artefacts" in s:
                    artefacts.extend(s["artefacts"])

        rec_flow = {
            "id": flow_id,
            "name": raw.get("name", flow_id),
            "type": flow_type,
            "description": raw.get("description", f"Flow {raw.get('name')}"),
            "trigger": raw.get(
                "trigger",
                {
                    "type": "unknown",
                    "event": "unknown",
                    "source": "unknown",
                    "evidence_id": raw.get("evidence_ids", ["ev-unknown"])[0]
                    if raw.get("evidence_ids")
                    else "ev-unknown",
                },
            ),
            "entrypoint": raw.get(
                "entrypoint",
                {
                    "path": entry_path,
                    "evidence_id": raw.get("evidence_ids", ["ev-unknown"])[0]
                    if raw.get("evidence_ids")
                    else "ev-unknown",
                },
            ),
            "steps": steps,
            "component_ids": comp_ids or raw.get("component_ids", []),
            "control_roles": all_roles or raw.get("control_roles", []),
            "artefacts": artefacts,
            "implementation": raw.get("implementation", [entry_path]),
            "evidence_ids": raw.get("evidence_ids", []),
            "confidence": raw.get("confidence", "high"),
            "status": raw.get("status", "discovered"),
        }
        reconciled.append(rec_flow)

    return reconciled, candidates, contradictions


class ForensicReconcilerStep:
    name = "forensic-reconciler"

    def __init__(self, schema_path: Path | None = None):
        if schema_path is None:
            self.schema_path = (
                Path(__file__).resolve().parent.parent.parent
                / "schemas"
                / "architecture_state_schema.json"
            )
        else:
            self.schema_path = Path(schema_path)

    def prepare_inputs(self, context: dict[str, Any]) -> dict[str, Any]:
        return {
            "project": context.get("project", "default-project"),
            "date": context.get("date", date.today().isoformat()),
            "extracted_evidence": context.get("extracted_evidence", {}),
            "target_dir": context.get("target_dir", "."),
        }

    def execute(
        self, inputs: dict[str, Any], reasoning_engine: Any | None = None
    ) -> dict[str, Any]:
        project = inputs.get("project", "default-project")
        today = inputs.get("date", date.today().isoformat())
        extracted_evidence = inputs.get("extracted_evidence", {})

        target_dir = inputs.get("target_dir", ".")
        det_state = self._deterministic_reconcile(
            project, today, extracted_evidence, target_dir=target_dir
        )

        # Check provider; for stub or mock provider, use deterministic reconciliation directly
        is_stub = False
        if reasoning_engine is not None and hasattr(reasoning_engine, "context"):
            profile = reasoning_engine.context.get("execution_profile", {})
            if profile.get("provider", "").lower() in ("stub", "mock"):
                is_stub = True

        state = None
        is_lean_response = False
        llm_lean_enrichment: dict[str, Any] | None = None

        if not is_stub and reasoning_engine is not None:
            try:
                # Option A: pass pruned deterministic_architecture_state in inputs to reasoning engine (FR-002)
                pruned_flows = []
                for f in det_state.get("flows", []):
                    if not isinstance(f, dict):
                        continue
                    entrypoint = f.get("entrypoint")
                    entry_path = (
                        entrypoint.get("path")
                        if isinstance(entrypoint, dict)
                        else str(entrypoint or "")
                    )
                    pruned_flows.append(
                        {
                            "id": f.get("id"),
                            "name": f.get("name"),
                            "type": f.get("type"),
                            "entrypoint": entry_path,
                            "steps_count": len(f.get("steps", [])),
                            "component_ids": f.get("component_ids", []),
                            "control_roles": f.get("control_roles", []),
                        }
                    )
                pruned_det_state = {
                    "id": det_state.get("id"),
                    "project": det_state.get("project"),
                    "system_boundary": det_state.get("system_boundary"),
                    "containers": [
                        {"id": c.get("id"), "name": c.get("name"), "type": c.get("type")}
                        for c in det_state.get("containers", [])
                        if isinstance(c, dict) and "id" in c
                    ],
                    "components": [
                        {"id": c.get("id"), "name": c.get("name"), "type": c.get("type")}
                        for c in det_state.get("components", [])
                        if isinstance(c, dict) and "id" in c
                    ],
                    "controls": [
                        {
                            "id": ctrl.get("id"),
                            "name": ctrl.get("name"),
                            "type": ctrl.get("type"),
                        }
                        for ctrl in det_state.get("controls", [])
                        if isinstance(ctrl, dict) and "id" in ctrl
                    ],
                    "flows": pruned_flows,
                }
                engine_inputs = dict(inputs)
                engine_inputs["deterministic_architecture_state"] = pruned_det_state

                llm_response = reasoning_engine.reason(self.name, engine_inputs)
                if isinstance(llm_response, dict):
                    if "enriched_flows" in llm_response or (
                        "diagnostics" in llm_response
                        and "architecture_state" not in llm_response
                        and "containers" not in llm_response
                        and "flows" not in llm_response
                    ):
                        is_lean_response = True
                        llm_lean_enrichment = llm_response
                    elif "architecture_state" in llm_response and isinstance(
                        llm_response["architecture_state"], dict
                    ):
                        state = llm_response["architecture_state"]
                    elif (
                        "system_boundary" in llm_response
                        and "containers" in llm_response
                    ):
                        state = llm_response
                    elif "flows" in llm_response:
                        state = llm_response
            except Exception as e:
                print(f"[WARNING] Forensic reconciliation reasoning failed: {e!s}")

        if is_lean_response and llm_lean_enrichment is not None:
            state = copy.deepcopy(det_state)
            if "system_boundary" in llm_lean_enrichment:
                state["system_boundary"] = llm_lean_enrichment["system_boundary"]

            det_flows = det_state.get("flows", [])
            det_flow_map: dict[str, dict[str, Any]] = {
                f["id"]: dict(f) for f in det_flows if isinstance(f, dict) and "id" in f
            }
            unmatched_semantic_flows: list[dict[str, Any]] = []

            for s_flow in llm_lean_enrichment.get("enriched_flows", []):
                if not isinstance(s_flow, dict):
                    continue
                s_id = s_flow.get("id")
                if s_id and s_id in det_flow_map:
                    target = det_flow_map[s_id]
                    if (
                        s_flow.get("description")
                        and s_flow["description"] != f"Flow {target.get('name')}"
                    ):
                        target["description"] = s_flow["description"]
                    if s_flow.get("component_ids"):
                        existing_comps = set(target.get("component_ids", []))
                        for c in s_flow["component_ids"]:
                            if c not in existing_comps:
                                target.setdefault("component_ids", []).append(c)
                    if s_flow.get("control_roles"):
                        existing_roles = set(target.get("control_roles", []))
                        for r in s_flow["control_roles"]:
                            if r not in existing_roles:
                                target.setdefault("control_roles", []).append(r)
                    if s_flow.get("confidence") and target.get("confidence") != "high":
                        target["confidence"] = s_flow["confidence"]
                else:
                    unmatched_semantic_flows.append(s_flow)

            state["flows"] = list(det_flow_map.values())

            # Merge diagnostics and record unmatched semantic flows into unknowns (R4)
            state_diag = state.setdefault("diagnostics", {})
            det_diag = det_state.get("diagnostics", {})
            lean_diag = llm_lean_enrichment.get("diagnostics", {})

            contradictions = list(det_diag.get("contradictions", []))
            existing_contra_ids = {
                c.get("id") for c in contradictions if isinstance(c, dict)
            }
            for c in lean_diag.get("contradictions", []):
                if isinstance(c, dict) and c.get("id") not in existing_contra_ids:
                    contradictions.append(c)
                    existing_contra_ids.add(c.get("id"))
            state_diag["contradictions"] = contradictions

            unknowns = list(det_diag.get("unknowns", []))
            existing_unknown_ids = {
                u.get("id") for u in unknowns if isinstance(u, dict)
            }
            for u in lean_diag.get("unknowns", []):
                if isinstance(u, dict) and u.get("id") not in existing_unknown_ids:
                    unknowns.append(u)
                    existing_unknown_ids.add(u.get("id"))

            for uf in unmatched_semantic_flows:
                u_id = uf.get("id", "flow:unmatched:semantic")
                u_name = uf.get("name", u_id)
                cand_id = f"candidate:unresolved-flow:{u_id}"
                if cand_id not in existing_unknown_ids:
                    unknowns.append(
                        {
                            "id": cand_id,
                            "description": f"Semantic flow '{u_name}' inferred by reasoning engine without deterministic code evidence",
                            "suspected_impact": f"Flow '{u_id}' may represent undocumented or proposed runtime behavior",
                            "confidence": "low",
                            "evidence_id": "ev-unknown",
                        }
                    )
                    existing_unknown_ids.add(cand_id)
            state_diag["unknowns"] = unknowns
        elif state is None:
            state = det_state
        else:
            # R1, R6: Deterministic Evidence Authority: deterministic discovery owns entity existence
            # canonical_flows = deterministic_flows + permitted_semantic_enrichment
            det_flows = det_state.get("flows", [])
            semantic_flows = state.get("flows", [])

            # Map deterministic flows by ID
            det_flow_map: dict[str, dict[str, Any]] = {
                f["id"]: dict(f) for f in det_flows if isinstance(f, dict) and "id" in f
            }

            # Enrich matching flows and isolate unmatched semantic flows (R2, R3, R4, R7)
            unmatched_semantic_flows: list[dict[str, Any]] = []

            for s_flow in semantic_flows:
                if not isinstance(s_flow, dict):
                    continue
                s_id = s_flow.get("id")
                if s_id and s_id in det_flow_map:
                    target = det_flow_map[s_id]
                    # Permitted enrichment: augment description, components, control roles, metadata
                    if (
                        s_flow.get("description")
                        and s_flow["description"] != f"Flow {target.get('name')}"
                    ):
                        target["description"] = s_flow["description"]
                    if s_flow.get("component_ids"):
                        existing_comps = set(target.get("component_ids", []))
                        for c in s_flow["component_ids"]:
                            if c not in existing_comps:
                                target.setdefault("component_ids", []).append(c)
                    if s_flow.get("control_roles"):
                        existing_roles = set(target.get("control_roles", []))
                        for r in s_flow["control_roles"]:
                            if r not in existing_roles:
                                target.setdefault("control_roles", []).append(r)
                    if s_flow.get("confidence") and target.get("confidence") != "high":
                        target["confidence"] = s_flow["confidence"]
                else:
                    unmatched_semantic_flows.append(s_flow)

            # Invariant: canonical flows must retain all deterministic flows
            state["flows"] = list(det_flow_map.values())

            # Ensure baseline structures from deterministic discovery are preserved if omitted by LLM
            for key in (
                "containers",
                "components",
                "dependencies",
                "controls",
                "evidence",
            ):
                if not state.get(key) and det_state.get(key):
                    state[key] = det_state[key]

            # Invariant R1/R6: Ensure deterministic components and controls are always present
            existing_comp_ids = {
                c["id"]
                for c in state.get("components", [])
                if isinstance(c, dict) and "id" in c
            }
            for det_comp in det_state.get("components", []):
                if (
                    isinstance(det_comp, dict)
                    and det_comp.get("id") not in existing_comp_ids
                ):
                    state.setdefault("components", []).append(det_comp)

            existing_ctrl_ids = {
                c["id"]
                for c in state.get("controls", [])
                if isinstance(c, dict) and "id" in c
            }
            for det_ctrl in det_state.get("controls", []):
                if (
                    isinstance(det_ctrl, dict)
                    and det_ctrl.get("id") not in existing_ctrl_ids
                ):
                    state.setdefault("controls", []).append(det_ctrl)

            # Merge diagnostics and record unmatched semantic flows into unknowns (R4)
            state_diag = state.setdefault("diagnostics", {})
            det_diag = det_state.get("diagnostics", {})
            if "contradictions" not in state_diag:
                state_diag["contradictions"] = det_diag.get("contradictions", [])

            existing_unknown_ids = {
                u.get("id")
                for u in state_diag.get("unknowns", [])
                if isinstance(u, dict)
            }
            for u in det_diag.get("unknowns", []):
                if isinstance(u, dict) and u.get("id") not in existing_unknown_ids:
                    state_diag.setdefault("unknowns", []).append(u)

            for uf in unmatched_semantic_flows:
                u_id = uf.get("id", "flow:unmatched:semantic")
                u_name = uf.get("name", u_id)
                cand_id = f"candidate:unresolved-flow:{u_id}"
                if cand_id not in existing_unknown_ids:
                    state_diag.setdefault("unknowns", []).append(
                        {
                            "id": cand_id,
                            "description": f"Semantic flow '{u_name}' inferred by reasoning engine without deterministic code evidence",
                            "suspected_impact": f"Flow '{u_id}' may represent undocumented or proposed runtime behavior",
                            "confidence": "low",
                            "evidence_id": "ev-unknown",
                        }
                    )
                    existing_unknown_ids.add(cand_id)

        # Normalize required metadata
        if "id" not in state:
            state["id"] = f"cas-arch-state-{project}-{today}"
        if "project" not in state:
            state["project"] = project
        if "date" not in state:
            state["date"] = today
        if "status" not in state:
            state["status"] = "discovered"
        if "confidence" not in state:
            state["confidence"] = "medium"

        output = {"architecture_state": state}
        return output

    def _deterministic_reconcile(
        self,
        project: str,
        today: str,
        extracted_evidence: dict[str, Any],
        target_dir: str | Path = ".",
    ) -> dict[str, Any]:
        evidence_list = list(extracted_evidence.get("evidence", []))
        evidence_ids = [e.get("id") for e in evidence_list if "id" in e]

        # Containers
        container_id = f"{project}-core"
        containers = [
            {
                "id": container_id,
                "name": f"{project.replace('-', ' ').title()} Core",
                "type": "application",
                "technology": "Python",
                "evidence_ids": [evidence_ids[0]] if evidence_ids else [],
                "status": "active",
            }
        ]

        # Components
        components = []
        ast_symbols = extracted_evidence.get("ast_symbols", [])
        for i, sym in enumerate(ast_symbols[:20]):
            comp_id = f"comp-{sym.get('name', f'unnamed-{i}').lower()}"
            components.append(
                {
                    "id": comp_id,
                    "container_id": container_id,
                    "name": sym.get("name", f"Component {i}"),
                    "path": sym.get("path", "unknown"),
                    "responsibilities": [sym.get("docstring")]
                    if sym.get("docstring")
                    else ["Core system responsibility"],
                    "interfaces": [
                        m.get("name") if isinstance(m, dict) else str(m)
                        for m in sym.get("methods", [])
                    ]
                    if sym.get("methods")
                    else [],
                    "evidence_ids": [sym.get("evidence_id")]
                    if sym.get("evidence_id")
                    else (evidence_ids[:1] if evidence_ids else []),
                    "confidence": "high",
                }
            )

        # Domain Skills as Components
        skill_evidence_list = [e for e in evidence_list if e.get("type") == "skill"]
        target_path_obj = Path(target_dir).resolve() if target_dir else None

        for sk_ev in skill_evidence_list:
            meta = sk_ev.get("metadata", {})
            sk_path = sk_ev.get("path", "")
            sk_name = (
                meta.get("name") or sk_ev.get("reference") or Path(sk_path).parent.name
            )
            sk_slug = _slugify(sk_name)

            # Option A (Prefix and Substrate Rule - FR-007):
            is_governance = (
                meta.get("category") == "governance"
                or sk_slug.startswith("cas-")
                or sk_name.startswith("cas-")
                or sk_path.startswith(".cas/")
                or sk_path.startswith("src/cas_skills/")
            )
            is_domain = (
                not is_governance
                and (meta.get("category") == "domain" or sk_path.startswith("skills/"))
            )

            if is_domain:
                comp_id = f"comp-skill-{sk_slug}"
                sk_content = ""
                if target_path_obj:
                    skill_file = target_path_obj / sk_path
                    if skill_file.exists():
                        try:
                            sk_content = skill_file.read_text(
                                encoding="utf-8", errors="replace"
                            )
                        except Exception:
                            pass

                # Hybrid code linking heuristic:
                linked_interfaces = []
                linked_ev_ids = []
                for sym in ast_symbols:
                    s_name = sym.get("name", "")
                    s_path = sym.get("path", "")
                    if s_name and (
                        s_name in sk_content or s_name in sk_ev.get("snippet", "")
                    ):
                        if s_name not in linked_interfaces:
                            linked_interfaces.append(s_name)
                        if (
                            sym.get("evidence_id")
                            and sym["evidence_id"] not in linked_ev_ids
                        ):
                            linked_ev_ids.append(sym["evidence_id"])
                    elif sk_slug.replace("-", "_") in s_path.lower():
                        if s_name and s_name not in linked_interfaces:
                            linked_interfaces.append(s_name)
                        if (
                            sym.get("evidence_id")
                            and sym["evidence_id"] not in linked_ev_ids
                        ):
                            linked_ev_ids.append(sym["evidence_id"])

                sk_desc = (
                    meta.get("description")
                    or sk_ev.get("snippet")
                    or f"{sk_name} domain capability"
                )
                components.append(
                    {
                        "id": comp_id,
                        "container_id": container_id,
                        "name": f"{sk_name.replace('-', ' ').title()} Skill",
                        "path": sk_path,
                        "responsibilities": [sk_desc],
                        "interfaces": linked_interfaces
                        if linked_interfaces
                        else ["Skill Contract (Agent Prompt)"],
                        "evidence_ids": list({sk_ev.get("id"), *linked_ev_ids}),
                        "confidence": "high",
                    }
                )

        if not components:
            components.append(
                {
                    "id": f"{project}-main-comp",
                    "container_id": container_id,
                    "name": f"{project.replace('-', ' ').title()} Component",
                    "path": "src/",
                    "responsibilities": ["Primary system capability"],
                    "interfaces": ["main()"],
                    "evidence_ids": evidence_ids[:1] if evidence_ids else [],
                    "confidence": "medium",
                }
            )

        # Dependencies
        dependencies = []
        imports = extracted_evidence.get("imports", [])
        for imp in imports[:30]:
            dependencies.append(
                {
                    "source_id": imp.get("source_module", container_id),
                    "target_id": imp.get("imported_module", "external"),
                    "type": "import",
                    "evidence_ids": [imp.get("evidence_id")]
                    if imp.get("evidence_id")
                    else (evidence_ids[:1] if evidence_ids else []),
                }
            )

        # Discover flows from target_dir if available
        raw_flows: list[dict[str, Any]] = []
        flow_candidates: list[dict[str, Any]] = []
        try:
            target_path = Path(target_dir).resolve()
            if target_path.exists() and target_path.is_dir():
                raw_flows, flow_ev, flow_cand = extract_all_flows(target_path)
                for fe in flow_ev:
                    if not any(e.get("id") == fe.get("id") for e in evidence_list):
                        evidence_list.append(fe)
                flow_candidates.extend(flow_cand)
        except Exception as e:
            print(f"[WARNING] Flow extraction encountered an error: {e!s}")

        # If no flows discovered from target_dir, fallback to extracted_evidence workflows
        if not raw_flows:
            workflows = extracted_evidence.get("workflows", [])
            for wf in workflows:
                flow_id = f"flow-{Path(wf.get('path', 'workflow')).stem}"
                raw_flows.append(
                    {
                        "id": flow_id,
                        "name": wf.get("name", flow_id),
                        "type": "lifecycle",
                        "steps": [
                            step.get("name", "step") for step in wf.get("steps", [])
                        ]
                        or ["Execute", "Verify"],
                        "evidence_ids": [wf.get("evidence_id")]
                        if wf.get("evidence_id")
                        else [],
                    }
                )

        # Reconcile flows with components
        if raw_flows:
            flows, candidates, contradictions = reconcile_discovered_flows(
                raw_flows, components=components
            )
            flow_candidates.extend(candidates)
        else:
            flows = [
                {
                    "id": "lifecycle-pipeline",
                    "name": "Lifecycle Pipeline",
                    "type": "lifecycle",
                    "steps": ["Build", "Test", "Deploy"],
                }
            ]
            contradictions = []

        # Controls
        controls = []
        workflows = extracted_evidence.get("workflows", [])
        for wf in workflows:
            controls.append(
                {
                    "id": f"ctrl-{Path(wf.get('path', 'workflow')).stem}",
                    "type": "prevent",
                    "enforcement_point": wf.get("path", ".github/workflows/ci.yml"),
                    "evidence_ids": [wf.get("evidence_id")]
                    if wf.get("evidence_id")
                    else (evidence_ids[:1] if evidence_ids else []),
                }
            )

        for sk_ev in skill_evidence_list:
            meta = sk_ev.get("metadata", {})
            sk_path = sk_ev.get("path", "")
            sk_name = (
                meta.get("name")
                or sk_ev.get("reference")
                or Path(sk_path).parent.name
            )
            sk_slug = _slugify(sk_name)

            # Option A (Prefix and Substrate Rule - FR-007):
            is_governance = (
                meta.get("category") == "governance"
                or sk_slug.startswith("cas-")
                or sk_name.startswith("cas-")
                or sk_path.startswith(".cas/")
                or sk_path.startswith("src/cas_skills/")
            )
            if is_governance:
                controls.append(
                    {
                        "id": f"ctrl-skill-{sk_slug}",
                        "type": "prevent",
                        "enforcement_point": sk_path,
                        "evidence_ids": [sk_ev["id"]]
                        if sk_ev.get("id")
                        else (evidence_ids[:1] if evidence_ids else []),
                    }
                )

        if not controls:
            controls.append(
                {
                    "id": "ctrl-governance",
                    "type": "prevent",
                    "enforcement_point": "AGENTS.md",
                    "evidence_ids": evidence_ids[:1] if evidence_ids else [],
                }
            )

        # Unknowns from flow candidates
        unknowns = []
        for fc in flow_candidates:
            unknowns.append(
                {
                    "id": fc.get("id", "cand-unknown"),
                    "description": fc.get("reason", "Unresolved flow candidate"),
                    "suspected_impact": f"Flow execution trace in {fc.get('source_path', 'unknown')} not fully mapped",
                }
            )

        total_entities = len(containers) + len(components) + len(flows)
        evidenced = (
            sum(1 for c in components if c.get("evidence_ids"))
            + sum(1 for c in containers if c.get("evidence_ids"))
            + sum(1 for f in flows if (isinstance(f, dict) and f.get("evidence_ids")))
        )
        pct = (evidenced / total_entities * 100.0) if total_entities > 0 else 100.0

        return {
            "id": f"cas-arch-state-{project}-{today}",
            "project": project,
            "date": today,
            "status": "discovered",
            "confidence": "high",
            "system_boundary": {
                "name": f"{project.replace('-', ' ').title()} System",
                "description": f"Architecture state reconstruction for {project}",
                "external_actors": ["User", "Architect"],
                "external_systems": ["GitHub", "CI/CD Pipeline"],
            },
            "containers": containers,
            "components": components,
            "dependencies": dependencies,
            "flows": flows,
            "controls": controls,
            "evidence": evidence_list,
            "diagnostics": {
                "contradictions": contradictions,
                "unknowns": unknowns,
                "coverage_summary": {
                    "total_entities": total_entities,
                    "evidenced_entities_percentage": round(pct, 1),
                },
            },
        }

    def validate(self, output: dict[str, Any]) -> None:
        if not isinstance(output, dict) or "architecture_state" not in output:
            raise ValueError("Output must contain 'architecture_state'")
        state = output["architecture_state"]

        if self.schema_path.exists():
            with open(self.schema_path, encoding="utf-8") as f:
                schema = json.load(f)
            jsonschema.validate(instance=state, schema=schema)
        else:
            raise FileNotFoundError(f"Schema file not found at {self.schema_path}")
