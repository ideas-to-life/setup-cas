"""Two-tier skill evaluation engine for CAS agent skills."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import jsonschema

from cas_runner.io import get_workspace_root
from cas_runner.skills.models import (
    EvalStatus,
    SkillEvalCase,
    SkillEvalReport,
    SkillEvalResult,
    SkillEvalSuite,
)


class SkillEvaluator:
    """Evaluates CAS agent skills against test fixtures using deterministic assertions

    and optional LLM-as-judge scoring.
    """

    def __init__(
        self,
        root_dir: Path | str | None = None,
        target_skill: str | None = None,
        fail_fast: bool = False,
        strict: bool = False,
        provider: str | None = None,
        model: str | None = None,
        llm_client=None,
    ):
        if root_dir is not None:
            r = Path(root_dir)
            if (r / "src" / "cas_skills").exists():
                self.root_dir = r / "src" / "cas_skills"
            elif (r / ".cas").exists():
                self.root_dir = r / ".cas"
            else:
                self.root_dir = r
        else:
            cwd_skills = Path.cwd() / "src" / "cas_skills"
            cwd_cas = Path.cwd() / ".cas"
            repo_skills = Path(__file__).resolve().parents[2] / "cas_skills"
            if cwd_skills.exists():
                self.root_dir = cwd_skills
            elif cwd_cas.exists():
                self.root_dir = cwd_cas
            elif repo_skills.exists():
                self.root_dir = repo_skills
            else:
                self.root_dir = get_workspace_root() / "src" / "cas_skills"

        self.target_skill = target_skill
        self.fail_fast = fail_fast
        self.strict = strict
        self.provider = provider
        self.model = model
        self.llm_client = llm_client

        self._schema = self._load_schema()

    def _load_schema(self) -> dict:
        schema_path = (
            Path(__file__).resolve().parents[1]
            / "schemas"
            / "skill-evals.schema.json"
        )
        if schema_path.exists():
            with open(schema_path, encoding="utf-8") as f:
                return json.load(f)
        return {}

    def discover_suites(self) -> dict[str, SkillEvalSuite | None]:
        """Discovers all skills under root_dir and loads evals.json suites if present."""
        suites: dict[str, SkillEvalSuite | None] = {}

        if not self.root_dir.exists():
            return suites

        # Find potential skill directories
        candidate_dirs = [
            d for d in sorted(self.root_dir.iterdir())
            if d.is_dir() and not d.name.startswith((".", "_")) and (
                (d / "SKILL.md").exists() or d.name.startswith("cas-")
            )
        ]

        for skill_dir in candidate_dirs:
            skill_name = skill_dir.name
            if self.target_skill and skill_name != self.target_skill:
                continue

            evals_file = skill_dir / "evals" / "evals.json"
            if evals_file.exists():
                try:
                    with open(evals_file, encoding="utf-8") as f:
                        data = json.load(f)
                    if self._schema:
                        jsonschema.validate(instance=data, schema=self._schema)
                    suites[skill_name] = SkillEvalSuite.from_dict(data, suite_path=evals_file)
                except Exception as e:
                    # Treat schema error as invalid suite
                    err_case = SkillEvalCase(
                        id="schema-validation",
                        prompt="Validate evals.json schema",
                        expected_output="Valid schema conformance",
                    )
                    invalid_suite = SkillEvalSuite(
                        skill_name=skill_name,
                        evals=[err_case],
                        suite_path=evals_file,
                    )
                    # We store it and let evaluator fail it with the parse error
                    invalid_suite._error = str(e)  # type: ignore[attr-defined]
                    suites[skill_name] = invalid_suite
            else:
                suites[skill_name] = None

        return suites

    def evaluate(self) -> SkillEvalReport:
        """Executes skill evaluation across discovered suites."""
        start_time = time.perf_counter()
        suites = self.discover_suites()
        results: list[SkillEvalResult] = []

        should_abort = False
        for skill_name, suite in suites.items():
            if should_abort:
                break

            if suite is None:
                # Skill has no evals fixture
                if self.strict:
                    results.append(
                        SkillEvalResult(
                            skill_name=skill_name,
                            eval_id="(no evals fixture)",
                            status=EvalStatus.FAIL,
                            tier="deterministic",
                            failure_reasons=["Missing evals/evals.json fixture suite (--strict enabled)"],
                            duration_ms=0.0,
                        )
                    )
                    if self.fail_fast:
                        should_abort = True
                        break
                else:
                    results.append(
                        SkillEvalResult(
                            skill_name=skill_name,
                            eval_id="(no evals fixture)",
                            status=EvalStatus.SKIPPED,
                            tier="deterministic",
                            duration_ms=0.0,
                        )
                    )
                continue

            # Check if suite had a load/schema error
            if hasattr(suite, "_error"):
                results.append(
                    SkillEvalResult(
                        skill_name=skill_name,
                        eval_id="schema-validation",
                        status=EvalStatus.FAIL,
                        tier="deterministic",
                        failure_reasons=[f"Schema validation error: {suite._error}"],  # type: ignore[attr-defined]
                        duration_ms=0.0,
                    )
                )
                if self.fail_fast:
                    should_abort = True
                    break
                continue

            # Evaluate each case
            for case in suite.evals:
                t0 = time.perf_counter()
                if self.provider:
                    res = self._evaluate_tier2_case(skill_name, case)
                else:
                    res = self._evaluate_tier1_case(skill_name, case)
                res.duration_ms = (time.perf_counter() - t0) * 1000.0
                results.append(res)

                if res.status == EvalStatus.FAIL and self.fail_fast:
                    should_abort = True
                    break

        total_duration = time.perf_counter() - start_time
        report = SkillEvalReport(results=results, total_duration_s=total_duration)

        # Write to $GITHUB_STEP_SUMMARY if available
        step_summary_path = os.environ.get("GITHUB_STEP_SUMMARY")
        if step_summary_path:
            try:
                with open(step_summary_path, "a", encoding="utf-8") as f:
                    f.write(report.render_markdown_summary() + "\n")
            except Exception:
                pass

        return report

    def _evaluate_tier1_case(self, skill_name: str, case: SkillEvalCase) -> SkillEvalResult:
        """Evaluates a test case using fast deterministic assertions."""
        failure_reasons: list[str] = []

        # 1. Verify referenced files exist
        workspace_root = get_workspace_root()
        repo_root = Path.cwd()
        for fpath in case.files:
            p = Path(fpath)
            if p.is_absolute():
                target_file = p
            elif (repo_root / p).exists():
                target_file = repo_root / p
            elif (workspace_root / p).exists():
                target_file = workspace_root / p
            elif (self.root_dir.parent.parent / p).exists():
                target_file = self.root_dir.parent.parent / p
            else:
                target_file = repo_root / p

            if not target_file.exists():
                failure_reasons.append(f"Referenced fixture file not found: {fpath}")

        # 2. Check assertions if defined
        if case.assertions:
            # must_include
            for token in case.assertions.must_include:
                if token.lower() not in case.expected_output.lower():
                    failure_reasons.append(f"Required keyword '{token}' missing from expected output")

            # must_not_include
            for forbidden in case.assertions.must_not_include:
                if forbidden.lower() in case.expected_output.lower():
                    failure_reasons.append(f"Forbidden anti-pattern found: '{forbidden}' in output")

            # expected_decision
            if case.assertions.expected_decision:
                exp_dec = case.assertions.expected_decision.lower()
                if exp_dec == "rejected":
                    if "rejected" not in case.expected_output.lower():
                        failure_reasons.append("Expected decision status 'rejected' not expressed in output")
                elif exp_dec == "accepted":
                    if "rejected" in case.expected_output.lower() and "decision.status: accepted" not in case.expected_output.lower():
                        failure_reasons.append("Expected decision status 'accepted' but output indicates rejection")

        status = EvalStatus.FAIL if failure_reasons else EvalStatus.PASS
        return SkillEvalResult(
            skill_name=skill_name,
            eval_id=case.id,
            status=status,
            tier="deterministic",
            failure_reasons=failure_reasons,
        )

    def _get_llm_client(self):
        """Resolves or initializes the LLM client for Tier 2 evaluation."""
        if self.llm_client is not None:
            return self.llm_client

        if not self.provider:
            return None

        p = self.provider.strip().lower()
        if p in ("mock", "stub"):
            from cas_runner.llm.mock_client import MockLLMClient
            self.llm_client = MockLLMClient()
            return self.llm_client

        provider_name = self.provider
        model_name = self.model

        if "/" in self.provider and not model_name:
            parts = self.provider.split("/", 1)
            provider_name = parts[0]
            model_name = self.provider
        elif not model_name:
            from cas_runner.config import load_config
            effective = load_config(cli_overrides={"provider": provider_name})
            if effective.config.llm.default_provider == provider_name and effective.config.llm.default_model != "mock-model":
                model_name = effective.config.llm.default_model
            else:
                defaults = {
                    "gemini": "gemini/gemini-2.5-flash",
                    "anthropic": "anthropic/claude-3-7-sonnet-20250219",
                    "openai": "gpt-4o-mini",
                    "huggingface": "Qwen/Qwen3.5-27B",
                }
                model_name = defaults.get(provider_name.lower(), f"{provider_name}/default")

        from cas_runner.llm import get_llm_client
        from cas_runner.orchestration.config import ExecutionProfile

        profile = ExecutionProfile(
            provider=provider_name,
            model=model_name,
            temperature=0.0,
        )
        self.llm_client = get_llm_client(profile)
        return self.llm_client

    def _evaluate_tier2_case(self, skill_name: str, case: SkillEvalCase) -> SkillEvalResult:
        """Evaluates a test case using LLM-as-judge grading."""
        try:
            client = self._get_llm_client()
            if client is None:
                return self._evaluate_tier1_case(skill_name, case)
        except Exception as e:
            return SkillEvalResult(
                skill_name=skill_name,
                eval_id=case.id,
                status=EvalStatus.FAIL,
                tier="llm_judge",
                failure_reasons=[f"LLM client initialization error: {e}"],
            )

        is_negative_test = bool(
            case.assertions and (case.assertions.expected_decision or "").lower() == "rejected"
        )

        if is_negative_test:
            rubric = """This is a NEGATIVE governance test case. The user prompt requests changes that deliberately violate architectural rules or introduce anti-patterns.
Expected Decision: 'rejected'

Grade the response on:
1. Anti-Pattern Detection (1-5): Did the evaluation accurately detect the architectural violation?
2. Invariant Protection (1-5): Does the specification enforce pattern invariants by rejecting the proposal?
3. Rationale Quality (1-5): Is the reason for rejection clear and grounded in architectural guidelines?

Passing Criterion:
If the evaluation correctly concludes that this feature plan must be REJECTED and identifies the violated invariant or anti-pattern, assign score >= 4.0 and passed: true.
If the plan was erroneously approved or fails to identify the violation, assign score < 4.0 and passed: false."""
        else:
            rubric = """Grade the response on:
1. Prompt Adherence (1-5)
2. Invariant Compliance (1-5)
3. Anti-Pattern Avoidance (1-5)

Passing Criterion:
If the plan adheres to the prompt, complies with pattern invariants, and avoids anti-patterns, assign score >= 4.0 and passed: true. Otherwise assign score < 4.0 and passed: false."""

        judge_prompt = f"""You are an architectural evaluator grading an AI agent feature plan.
Test Case ID: {case.id}
User Prompt: {case.prompt}
Expected Specification: {case.expected_output}

{rubric}

Output a JSON object with:
{{
  "score": <float 1.0 to 5.0>,
  "passed": <true if score >= 4.0 else false>,
  "diagnostics": "<reasoning>"
}}
"""
        try:
            response = client.generate(judge_prompt)
            raw_content = response.content if hasattr(response, "content") else response
            score = 5.0
            passed = True
            diagnostics = ""

            if isinstance(raw_content, dict):
                if "_mock" in raw_content:
                    score = float(raw_content.get("score", 5.0))
                    passed = bool(raw_content.get("passed", score >= 4.0))
                    diagnostics = str(raw_content.get("diagnostics", "Mock/Stub evaluation passed"))
                else:
                    score = float(raw_content.get("score", 5.0))
                    passed = bool(raw_content.get("passed", score >= 4.0))
                    diagnostics = str(raw_content.get("diagnostics", ""))
            elif isinstance(raw_content, str):
                if "{" in raw_content:
                    start_idx = raw_content.find("{")
                    end_idx = raw_content.rfind("}") + 1
                    data = json.loads(raw_content[start_idx:end_idx])
                    score = float(data.get("score", 5.0))
                    passed = bool(data.get("passed", score >= 4.0))
                    diagnostics = str(data.get("diagnostics", ""))
                else:
                    score = 0.0
                    passed = False
                    diagnostics = f"LLM judge returned non-JSON output: {raw_content[:200]}"
            else:
                score = 0.0
                passed = False
                diagnostics = f"Unexpected response type from LLM client: {type(raw_content)}"

            if is_negative_test and not passed:
                diag_lower = diagnostics.lower()
                if any(
                    phrase in diag_lower
                    for phrase in [
                        "should be rejected",
                        "must be rejected",
                        "recommend rejection",
                        "plan should be rejected",
                        "plan must be rejected",
                    ]
                ):
                    passed = True
                    score = max(score, 4.5)
                    diagnostics = f"Negative governance test passed (rejection identified): {diagnostics}"

            status = EvalStatus.PASS if passed else EvalStatus.FAIL
            failure_reasons = [] if passed else [diagnostics or f"LLM judge score {score} < 4.0"]
            return SkillEvalResult(
                skill_name=skill_name,
                eval_id=case.id,
                status=status,
                tier="llm_judge",
                score=score,
                failure_reasons=failure_reasons,
            )
        except Exception as e:
            return SkillEvalResult(
                skill_name=skill_name,
                eval_id=case.id,
                status=EvalStatus.FAIL,
                tier="llm_judge",
                failure_reasons=[f"LLM judge invocation error: {e}"],
            )
