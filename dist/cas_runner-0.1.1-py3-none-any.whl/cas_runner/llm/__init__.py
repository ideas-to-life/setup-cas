from pathlib import Path
from typing import Any, Optional

# We import inside to avoid potential circular dependencies if needed,
# but currently it should be fine.
from cas_runner.orchestration.config import ExecutionProfile

from .base import LLMCapabilities, LLMClient, LLMResponse, LLMUsage
from .errors import StructuredOutputError
from .litellm_client import LiteLLMClient
from .mock_client import MockLLMClient


def get_llm_client(
    profile: ExecutionProfile | None = None,
    target_dir: str | Path = ".",
    cli_overrides: dict[str, Any] | None = None,
) -> LLMClient:
    """
    Factory function to get the appropriate LLM client using CASConfig or an ExecutionProfile.
    """
    from cas_runner.config import load_config

    effective = load_config(target_dir=target_dir, cli_overrides=cli_overrides)
    llm_cfg = effective.config.llm

    provider = (profile.provider if profile and profile.provider else llm_cfg.default_provider)
    model = (profile.model if profile and profile.model else llm_cfg.default_model)
    temperature = (
        profile.temperature
        if profile and profile.temperature is not None
        else llm_cfg.temperature
    )
    max_tokens = profile.max_tokens if profile else None
    api_base = profile.api_base if profile else None
    extra_params = dict(profile.extra_params) if profile else {}

    if provider.lower() in ["mock", "stub"]:
        return MockLLMClient(**extra_params)

    return LiteLLMClient(
        model_name=model,
        provider=provider,
        temperature=temperature,
        max_tokens=max_tokens,
        api_base=api_base,
        fallback_provider=llm_cfg.fallback_provider,
        fallback_model=llm_cfg.fallback_model,
        **extra_params,
    )
