import logging
import os
import textwrap
import time
from typing import Any

from .base import LLMCapabilities, LLMClient, LLMResponse, LLMUsage
from .errors import StructuredOutputError
from .structured import get_json_instruction, validate_structured_output

# Global LiteLLM configuration to prevent atexit worker errors
# MUST BE SET BEFORE IMPORTING LITELLM
os.environ["LITELLM_TELEMETRY"] = "False"
import litellm

litellm.telemetry = False
litellm.drop_params = True


logger = logging.getLogger(__name__)

class LiteLLMClient(LLMClient):
    """
    LLMClient implementation using LiteLLM for multi-provider support.
    """

    @property
    def capabilities(self) -> LLMCapabilities:
        return LLMCapabilities()

    def __init__(
        self,
        model_name: str,
        provider: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        api_base: str | None = None,
        fallback_provider: str | None = None,
        fallback_model: str | None = None,
        **kwargs,
    ):
        self.model_name = model_name
        self.provider = provider
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.api_base = api_base
        self.fallback_provider = fallback_provider
        self.fallback_model = fallback_model
        self.extra_params = kwargs

        if os.getenv("LITELLM_DEBUG", "false").lower() == "true":
            # Using the recommended way to enable logging
            os.environ["LITELLM_LOG"] = "DEBUG"
            # litellm.set_verbose = True
            logger.info("LiteLLM verbose logging enabled via LITELLM_LOG=DEBUG")

        # LiteLLM uses provider prefixes (e.g., 'gemini/gemini-pro')
        self.full_model_name = model_name

        # 1. Special case for Hugging Face Router vs Inference API
        # Only set if not already provided via api_base
        if provider == "huggingface" and not self.api_base:
            self.api_base = "https://router.huggingface.co/v1"

            # Native HF Inference API (not OpenAI compatible)
            if not model_name.startswith("huggingface/"):
                if model_name.startswith("openai/"):
                    self.full_model_name = f"huggingface/{model_name}"
                elif "/" in model_name:
                    self.full_model_name = f"huggingface/{model_name}"
                else:
                    self.full_model_name = f"huggingface/openai/{model_name}"
        elif provider and not model_name.startswith(f"{provider}/"):
            self.full_model_name = f"{provider}/{model_name}"


    def generate(
        self,
        prompt: str,
        *,
        instruction: str | None = None,
        schema: dict[str, Any] | None = None,
        temperature: float | None = None,
        metadata: dict[str, Any] | None = None,
        name: str | None = None,
    ) -> LLMResponse:

        messages = []
        if instruction:
            messages.append({"role": "system", "content": textwrap.dedent(instruction).strip()})

        messages.append({"role": "user", "content": textwrap.dedent(prompt).strip()})

        return self.chat(
            messages,
            instruction=None,  # Already added
            schema=schema,
            temperature=temperature,
            metadata=metadata,
            name=name
        )

    def chat(
        self,
        messages: list[dict[str, str]],
        *,
        instruction: str | None = None,
        schema: dict[str, Any] | None = None,
        temperature: float | None = None,
        metadata: dict[str, Any] | None = None,
        name: str | None = None,
    ) -> LLMResponse:

        # Consolidate all system messages into a single system message at index 0
        system_parts = []
        if instruction:
            system_parts.append(textwrap.dedent(instruction).strip())

        other_messages = []
        for msg in messages:
            content = textwrap.dedent(msg.get("content", "")).strip()
            if msg.get("role") == "system":
                system_parts.append(content)
            else:
                other_messages.append({
                    "role": msg["role"],
                    "content": content
                })

        # Inject JSON instructions if schema is provided
        if schema:
            json_instruction = get_json_instruction(schema)
            system_parts.append(json_instruction)

        chat_messages = []
        if system_parts:
            chat_messages.append({
                "role": "system",
                "content": "\n\n".join(part for part in system_parts if part)
            })
        chat_messages.extend(other_messages)

        completion_kwargs = {
            "model": self.full_model_name,
            "messages": chat_messages,
            "temperature": temperature if temperature is not None else self.temperature,
            "max_tokens": self.max_tokens,
            **self.extra_params,
            "api_base": self.api_base if self.api_base else None,
        }
        completion_kwargs.pop("num_retries", None)

        # If we have a schema, try to enable JSON mode if supported
        if schema:
            completion_kwargs["response_format"] = {"type": "json_object"}

        if self.fallback_model:
            fb_name = self.fallback_model
            if self.fallback_provider and not fb_name.startswith(f"{self.fallback_provider}/"):
                fb_name = f"{self.fallback_provider}/{fb_name}"
            completion_kwargs["fallbacks"] = [fb_name]

        retries = int(self.extra_params.get("num_retries", 3))
        response = None
        for attempt in range(max(1, retries)):
            try:
                logger.info(f"[CAS] Calling LLM: {self.full_model_name}")
                response = litellm.completion(**completion_kwargs)
                break
            except (litellm.RateLimitError, litellm.ServiceUnavailableError) as e:
                if attempt == retries - 1:
                    logger.error(f"[CAS] LiteLLM call failed after {retries} retries: {e}")
                    raise
                wait_time = 2 ** (attempt + 1)
                logger.warning(f"[CAS] Rate limit or service unavailable, retrying in {wait_time}s... ({e})")
                time.sleep(wait_time)
            except Exception as e:
                logger.error(f"[CAS] LiteLLM call failed: {e}")
                raise

        response_text = response.choices[0].message.content

        # Extract usage metadata safely
        usage_raw = getattr(response, "usage", None)
        prompt_tokens = getattr(usage_raw, "prompt_tokens", 0) if usage_raw else 0
        completion_tokens = getattr(usage_raw, "completion_tokens", 0) if usage_raw else 0
        total_tokens = getattr(usage_raw, "total_tokens", 0) if usage_raw else 0

        # Calculate cost via LiteLLM helper
        estimated_cost = getattr(usage_raw, "estimated_cost", None)
        cost_estimation_source = None
        if estimated_cost is None:
            try:
                estimated_cost = litellm.completion_cost(completion_response=response)
                cost_estimation_source = "litellm"
            except Exception as e:
                logger.warning(f"[CAS] Could not calculate cost for {self.full_model_name}: {e}")

        usage = LLMUsage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            estimated_cost=estimated_cost,
            cost_estimation_source=cost_estimation_source,
        )

        choice = response.choices[0] if (response and response.choices) else None
        finish_reason = getattr(choice, "finish_reason", None) if choice else None
        if isinstance(choice, dict):
            finish_reason = choice.get("finish_reason")

        # Inspect truncation for structured output requests (FR-008)
        if schema and finish_reason in ("length", "max_tokens"):
            prompt_id = name or (messages[-1]["content"][:20] if messages else "unknown")
            logger.error(
                f"[CAS] Output token ceiling exceeded for {self.provider or 'litellm'}/{self.model_name} "
                f"(Prompt: {prompt_id}, finish_reason: {finish_reason}, "
                f"prompt_tokens: {prompt_tokens}, completion_tokens: {completion_tokens})"
            )
            raise StructuredOutputError(
                provider=self.provider or "litellm",
                model=self.model_name,
                prompt_id=prompt_id,
                raw_output=response_text or "",
                reason="Output Token Ceiling Exceeded (Truncated JSON)",
                details={
                    "finish_reason": finish_reason,
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": completion_tokens,
                    "total_tokens": total_tokens,
                },
            )

        if not response_text:
            return LLMResponse(content="", usage=usage)

        if not schema:
            return LLMResponse(content=response_text, usage=usage)

        prompt_id = name or (messages[-1]["content"][:20] if messages else "unknown")
        content = validate_structured_output(
            text=response_text,
            provider=self.provider or "litellm",
            model=self.model_name,
            prompt_id=prompt_id,
        )
        return LLMResponse(content=content, usage=usage)

