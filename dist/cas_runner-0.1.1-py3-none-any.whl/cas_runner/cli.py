import argparse
import glob
import json
import sys
from pathlib import Path

import yaml

from .io import (
    get_workspace_root,
    promote_architecture_state_baseline,
    resolve_target_project_context,
)
from .runner import FlowRunner
from .steering.models import ManagedSectionProposal
from .steering.section_apply import ManagedSectionApplier
from .steering.section_renderer import STEERING_ARTIFACTS
from .steering.section_validation import ManagedSectionValidator
from .steps.registry import FLOWS


def main(argv: list[str] | None = None):
    BASE = get_workspace_root()

    parser = argparse.ArgumentParser(prog="cas")
    subparsers = parser.add_subparsers(dest="command", help="CAS Commands")

    # Run Command
    run_parser = subparsers.add_parser("run", help="Execute a CAS flow")
    run_parser.add_argument(
        "target",
        choices=list(FLOWS.keys()),
        metavar="flow_name",
        help=f"Flow name to execute. Choices: {', '.join(FLOWS.keys())}",
    )
    run_parser.add_argument("--project", default=None, help="Target project identifier")
    run_parser.add_argument(
        "--target-dir", help="Explicit target project repository directory"
    )
    run_parser.add_argument("--provider", help="LLM provider")
    run_parser.add_argument("--model", help="Specific model name")
    run_parser.add_argument("--temperature", type=float, help="Sampling temperature")
    run_parser.add_argument("--dry-run", action="store_true")
    run_parser.add_argument(
        "--override",
        help="JSON string representing context overrides (e.g. architect_decision)",
    )
    run_parser.add_argument(
        "--publish-root",
        action="store_true",
        help="Publish consolidated ARCHITECTURE.md to target project repository root",
    )
    run_parser.add_argument(
        "--publish-external",
        action="store_true",
        help="Publish generated reference architectures to external governance system (ArchGov)",
    )
    run_parser.add_argument(
        "--archgov-url",
        help="Override ArchGov base URL (default: http://archgov.pbo-tech.net)",
    )
    run_parser.add_argument(
        "--owner", help="Override owner email for external artifact publication"
    )
    run_parser.add_argument(
        "--domain-id",
        type=int,
        help="Override domain ID for external artifact publication",
    )
    run_parser.add_argument(
        "--initiative-id",
        type=int,
        help="Override initiative ID for external artifact publication",
    )
    run_parser.add_argument(
        "--skip-evaluation",
        action="store_true",
        help="Skip post-flow telemetry evaluation to conserve LLM tokens/rate limits",
    )

    # Evaluate Command
    eval_parser = subparsers.add_parser("evaluate", help="Evaluate a trace")
    eval_parser.add_argument("target", help="Trace ID prefix")
    eval_parser.add_argument("--project", default="ideas-to-life-cas")
    eval_parser.add_argument("--provider", help="LLM provider")

    # Bootstrap Command
    boot_parser = subparsers.add_parser(
        "bootstrap", help="Initialize CAS governance in a repository"
    )
    boot_parser.add_argument(
        "target", nargs="?", default=".", help="Target directory (default: current)"
    )
    boot_parser.add_argument(
        "--force", action="store_true", help="Overwrite existing files"
    )
    boot_parser.add_argument(
        "--minimal", action="store_true", help="Install minimal governance substrate"
    )
    boot_parser.add_argument(
        "--no-ci", action="store_true", help="Skip CI workflow creation"
    )
    boot_parser.add_argument(
        "--sdlc-profile",
        choices=["auto", "speckit", "anthropic-native", "superpowers", "agent-skills"],
        default="auto",
        help="SDLC profile for artifact resolution (default: auto)",
    )

    # Init Workspace Command
    init_parser = subparsers.add_parser(
        "init-workspace", help="Initialize or attach to a CAS knowledge workspace"
    )
    init_parser.add_argument(
        "--project", required=True, help="Project name for workspace mapping"
    )
    init_parser.add_argument(
        "target", nargs="?", default=".", help="Target directory (default: current)"
    )
    init_parser.add_argument(
        "--force", action="store_true", help="Overwrite existing files"
    )
    init_parser.add_argument(
        "--provider", default="local", help="Knowledge provider type (default: local)"
    )
    init_parser.add_argument(
        "--workspace-root", help="Path to a shared knowledge workspace root"
    )

    # Dashboard Command
    dash_parser = subparsers.add_parser("dashboard", help="Show governance dashboard")
    dash_parser.add_argument("--project", default="ideas-to-life-cas")
    dash_parser.add_argument(
        "--format", choices=["json", "markdown"], default="markdown"
    )

    # Watch Command (Live Run Progress & Telemetry HUD)
    watch_parser = subparsers.add_parser(
        "watch", help="Watch live progress of active CAS flow or skill run"
    )
    watch_parser.add_argument(
        "--project", default="ideas-to-life-cas", help="Project name"
    )
    watch_parser.add_argument(
        "--refresh-rate",
        type=float,
        default=5.0,
        help="Refresh rate in Hz (default: 5.0)",
    )
    watch_parser.add_argument(
        "--file", help="Path to custom active-run.json state file"
    )

    # Governance Command
    gov_parser = subparsers.add_parser("governance", help="Governance operations")
    gov_subparsers = gov_parser.add_subparsers(dest="action", help="Governance Actions")

    # Governance Validate
    gov_validate_parser = gov_subparsers.add_parser(
        "validate", help="Validate governance artifacts integrity"
    )
    gov_validate_parser.add_argument(
        "--project", default="ideas-to-life-cas", help="Project name to validate"
    )
    gov_validate_parser.add_argument(
        "--provider", help="LLM provider (optional for validation)"
    )

    # Governance Lint (Deterministic Architecture & Anti-Pattern Gate)
    gov_lint_parser = gov_subparsers.add_parser(
        "lint",
        help="Run deterministic architecture and anti-pattern linter on a target repository",
    )
    gov_lint_parser.add_argument(
        "--target-dir",
        default=".",
        help="Target repository directory to lint (default: current directory)",
    )
    gov_lint_parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )

    # Governance Verify-Diff & Review-PR (3-Pass Deterministic + Optional LLM Critic)
    for verify_cmd, verify_help in (
        ("verify-diff", "Run 3-pass fresh-context verification on active git diff"),
        ("review-pr", "Run 3-pass automated PR review gate against REVIEW.md contract"),
    ):
        v_parser = gov_subparsers.add_parser(verify_cmd, help=verify_help)
        v_parser.add_argument(
            "--target-dir",
            default=".",
            help="Target repository directory (default: current directory)",
        )
        v_parser.add_argument(
            "--base-ref",
            help="Optional base git reference for diff calculation (e.g. origin/main)",
        )
        v_parser.add_argument(
            "--sdlc-profile",
            choices=[
                "auto",
                "speckit",
                "anthropic-native",
                "superpowers",
                "agent-skills",
            ],
            help="Override SDLC profile for artifact resolution",
        )
        v_parser.add_argument(
            "--fail-on",
            choices=["critical", "high", "medium", "low", "none"],
            default="high",
            help="Severity threshold that triggers exit code 1 (default: high)",
        )
        v_parser.add_argument(
            "--advisory",
            action="store_true",
            help="Run in advisory mode (emit full report and severity tally, always exit 0)",
        )
        v_parser.add_argument(
            "--provider",
            help="Optional LLM provider for semantic critic pass",
        )
        v_parser.add_argument(
            "--model",
            help="Optional LLM model name for semantic critic pass",
        )
        v_parser.add_argument(
            "--format",
            choices=["markdown", "json"],
            default="markdown",
            help="Output format (default: markdown)",
        )

    # Governance Verify-Intent (Stage 1 Zero-Hallucination Intent Triage)
    gov_intent_parser = gov_subparsers.add_parser(
        "verify-intent",
        help="Verify Stage 1 intent provenance ([A] anchors, [P] presumptions, [Q] questions)",
    )
    gov_intent_parser.add_argument(
        "--target-dir",
        default=".",
        help="Target repository directory (default: current directory)",
    )
    gov_intent_parser.add_argument(
        "--project",
        default="ideas-to-life-cas",
        help="Target project name for knowledge lookup",
    )
    gov_intent_parser.add_argument(
        "--advisory",
        action="store_true",
        help="Run in advisory mode (always exit 0)",
    )
    gov_intent_parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )

    # Governance Route-Plan (Stage 3 Proportionate Governance Routing)
    gov_route_parser = gov_subparsers.add_parser(
        "route-plan",
        help="Classify active plan into Path A (Governed Reuse), Path B (Novelty), or Path C (Exception)",
    )
    gov_route_parser.add_argument(
        "--target-dir",
        default=".",
        help="Target repository directory (default: current directory)",
    )
    gov_route_parser.add_argument(
        "--project",
        default="ideas-to-life-cas",
        help="Target project name for knowledge lookup",
    )
    gov_route_parser.add_argument(
        "--advisory",
        action="store_true",
        help="Run in advisory mode (always exit 0)",
    )
    gov_route_parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )

    # Governance Watch (Interactive Terminal HUD)
    gov_watch_parser = gov_subparsers.add_parser(
        "watch",
        help="Launch real-time interactive terminal HUD for active SDLC state",
    )
    gov_watch_parser.add_argument(
        "--target-dir",
        default=".",
        help="Target repository directory (default: current directory)",
    )
    gov_watch_parser.add_argument(
        "--project",
        default="ideas-to-life-cas",
        help="Project identifier (default: ideas-to-life-cas)",
    )
    gov_watch_parser.add_argument(
        "--interval",
        type=float,
        default=0.5,
        help="Poll/refresh interval in seconds (default: 0.5)",
    )
    gov_watch_parser.add_argument(
        "--once",
        action="store_true",
        help="Print a single snapshot of the HUD and exit immediately",
    )

    # Governance Check-Bands (Stage 6 Statistical Control Bands & Closed-Loop Feedback)
    gov_bands_parser = gov_subparsers.add_parser(
        "check-bands",
        help="Evaluate repository telemetry against .cas/bands.yaml and auto-draft Stage 1 intent.md on 3sigma anomalies",
    )
    gov_bands_parser.add_argument(
        "--target-dir",
        default=".",
        help="Target repository directory (default: current directory)",
    )
    gov_bands_parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )
    gov_bands_parser.add_argument(
        "--advisory",
        action="store_true",
        help="Run in advisory mode (always exit 0 even when fail-on threshold is breached)",
    )
    gov_bands_parser.add_argument(
        "--fail-on",
        choices=["3sigma", "2sigma", "1sigma", "none"],
        default="3sigma",
        help="Band severity that triggers a non-zero exit code (default: 3sigma)",
    )

    # Governance Check-Env (Pre-flight Onboarding Variables & Secrets Diagnostics)
    gov_env_parser = gov_subparsers.add_parser(
        "check-env",
        help="Inspect local and CI environment variables, secrets, and cas-brain/knowledge configuration",
    )
    gov_env_parser.add_argument(
        "--target-dir",
        default=".",
        help="Target repository directory (default: current directory)",
    )
    gov_env_parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )
    gov_env_parser.add_argument(
        "--strict",
        action="store_true",
        help="Exit with code 1 if required continuous loop secrets are missing",
    )

    # Governance Actions
    gov_approve_parser = gov_subparsers.add_parser(
        "approve", help="Approve a governance artifact"
    )
    gov_approve_parser.add_argument("artifact_id", help="ID of the artifact")
    gov_approve_parser.add_argument("--rationale", help="Rationale for approval")
    gov_approve_parser.add_argument("--project", default="ideas-to-life-cas")
    gov_approve_parser.add_argument(
        "--push-external",
        action="store_true",
        help="Push decision to ArchGov if configured",
    )
    gov_approve_parser.add_argument(
        "--no-chain",
        action="store_true",
        help="Do not trigger downstream ADR generation",
    )
    gov_approve_parser.add_argument(
        "--provider", help="LLM provider for downstream generation"
    )

    gov_reject_parser = gov_subparsers.add_parser(
        "reject", help="Reject a governance artifact"
    )
    gov_reject_parser.add_argument("artifact_id", help="ID of the artifact")
    gov_reject_parser.add_argument(
        "--rationale", help="Rationale for rejection", required=True
    )
    gov_reject_parser.add_argument("--project", default="ideas-to-life-cas")
    gov_reject_parser.add_argument(
        "--push-external",
        action="store_true",
        help="Push decision to ArchGov if configured",
    )

    gov_defer_parser = gov_subparsers.add_parser(
        "defer", help="Defer a governance artifact"
    )
    gov_defer_parser.add_argument("artifact_id", help="ID of the artifact")
    gov_defer_parser.add_argument(
        "--rationale", help="Rationale for deferral", required=True
    )
    gov_defer_parser.add_argument("--project", default="ideas-to-life-cas")
    gov_defer_parser.add_argument(
        "--push-external",
        action="store_true",
        help="Push decision to ArchGov if configured",
    )

    gov_reopen_parser = gov_subparsers.add_parser(
        "reopen", help="Reopen a deferred artifact"
    )
    gov_reopen_parser.add_argument("artifact_id", help="ID of the artifact")
    gov_reopen_parser.add_argument("--rationale", help="Rationale for reopening")
    gov_reopen_parser.add_argument("--project", default="ideas-to-life-cas")
    gov_reopen_parser.add_argument(
        "--push-external",
        action="store_true",
        help="Push decision to ArchGov if configured",
    )

    # Governance Resolve Conflicts
    gov_resolve_parser = gov_subparsers.add_parser(
        "resolve-conflicts",
        help="Resolve git conflicts in knowledge artifacts using Agentic Merger",
    )
    gov_resolve_parser.add_argument("--project", default="ideas-to-life-cas")
    gov_resolve_parser.add_argument("--provider", help="LLM provider")

    # Governance Assess
    gov_assess_parser = gov_subparsers.add_parser(
        "assess", help="Assess Architecture Work implementation coverage"
    )
    gov_assess_parser.add_argument("--project", default="ideas-to-life-cas")
    gov_assess_parser.add_argument("--provider", help="LLM provider")

    # Governance Publish
    gov_publish_parser = gov_subparsers.add_parser(
        "publish", help="Publish an artifact to external governance (ArchGov)"
    )
    gov_publish_parser.add_argument(
        "--project", default="ideas-to-life-cas", help="Project identifier"
    )
    gov_publish_parser.add_argument(
        "--artifact", required=False, help="Path to markdown artifact file"
    )
    gov_publish_parser.add_argument(
        "--all-unpublished",
        action="store_true",
        help="Batch-publish all local artifacts of --type that are not yet tracked in ArchGov",
    )
    gov_publish_parser.add_argument(
        "--type",
        dest="artifact_type",
        choices=["reference_arch", "adr", "principle", "hld", "lld"],
        default="reference_arch",
        help="Artifact type",
    )
    gov_publish_parser.add_argument(
        "--review-type",
        choices=["design_authority", "adr", "arb", "infosec", "cab"],
        help="Review type (defaults by artifact type)",
    )
    gov_publish_parser.add_argument(
        "--reviewer", help="Reviewer email (defaults to artifact owner)"
    )
    gov_publish_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate publishing without HTTP requests",
    )
    gov_publish_parser.add_argument("--archgov-url", help="Override ArchGov base URL")
    gov_publish_parser.add_argument("--owner", help="Override artifact owner email")
    gov_publish_parser.add_argument("--domain-id", type=int, help="Override domain ID")
    gov_publish_parser.add_argument(
        "--initiative-id", type=int, help="Override initiative ID"
    )

    # Governance Sync
    gov_sync_parser = gov_subparsers.add_parser(
        "sync", help="Synchronize external ArchGov reviews into local Git repository"
    )
    gov_sync_parser.add_argument(
        "--project", default="ideas-to-life-cas", help="Project identifier"
    )
    gov_sync_parser.add_argument("--archgov-url", help="Override ArchGov base URL")
    gov_sync_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate sync without updating files on disk",
    )
    gov_sync_parser.add_argument(
        "--no-chain",
        action="store_true",
        help="Do not auto-chain downstream ADR generation",
    )
    gov_sync_parser.add_argument(
        "--type",
        choices=["reference_arch", "adr", "all"],
        default="all",
        help="Filter synchronization target by artifact type (default: all)",
    )
    gov_sync_parser.add_argument(
        "--provider", help="LLM provider for downstream generation"
    )

    # Governance Status
    gov_status_parser = gov_subparsers.add_parser(
        "status",
        help="Display governance review status and external twins for an artifact",
    )
    gov_status_parser.add_argument(
        "artifact_id", help="Artifact ID (e.g. reference-architecture-<pattern_id>)"
    )
    gov_status_parser.add_argument(
        "--project", default="ideas-to-life-cas", help="Project identifier"
    )

    # Steering Command
    steering_parser = subparsers.add_parser(
        "steering", help="Manage steering artifacts"
    )
    steering_subparsers = steering_parser.add_subparsers(
        dest="action", help="Steering Actions"
    )

    # Steering Validate
    validate_parser = steering_subparsers.add_parser(
        "validate", help="Validate steering artifacts"
    )
    validate_parser.add_argument(
        "--managed-sections-only", action="store_true", default=True
    )

    # Steering Apply
    apply_parser = steering_subparsers.add_parser(
        "apply", help="Apply steering projections"
    )
    apply_parser.add_argument(
        "--projection", required=True, help="Projection ID or path"
    )
    apply_parser.add_argument(
        "--managed-sections-only", action="store_true", default=True
    )
    apply_parser.add_argument("--dry-run", action="store_true")

    # Steering Bootstrap
    bootstrap_parser = steering_subparsers.add_parser(
        "bootstrap", help="One-time bootstrap of the Runtime Capability Inventory"
    )
    bootstrap_parser.add_argument(
        "--project", default="ideas-to-life-cas", help="Project name"
    )
    bootstrap_parser.add_argument(
        "--baseline-ref",
        help="Baseline Git reference to scan from (e.g. empty tree hash)",
    )
    # State Command
    state_parser = subparsers.add_parser("state", help="Architecture state operations")
    state_subparsers = state_parser.add_subparsers(
        dest="subcommand", help="State Subcommands"
    )

    state_baseline_parser = state_subparsers.add_parser(
        "baseline", help="Baseline operations"
    )
    baseline_subparsers = state_baseline_parser.add_subparsers(
        dest="action", help="Baseline Actions"
    )

    promote_parser = baseline_subparsers.add_parser(
        "promote", help="Promote architecture state to validated baseline"
    )
    promote_parser.add_argument(
        "--project", required=True, help="Target project identifier"
    )
    promote_parser.add_argument(
        "--notes", help="Promotion notes or architect rationale"
    )
    promote_parser.add_argument(
        "--target-dir", help="Explicit target project repository directory"
    )

    state_flows_parser = state_subparsers.add_parser(
        "discover-flows", help="Discover and reconstruct executable flows"
    )
    state_flows_parser.add_argument(
        "--project", required=True, help="Target project identifier"
    )
    state_flows_parser.add_argument(
        "--target-dir", help="Explicit target project repository directory"
    )
    state_flows_parser.add_argument(
        "--provider", default="stub", help="Reasoning provider"
    )
    state_flows_parser.add_argument(
        "--publish-root",
        action="store_true",
        help="Publish ARCHITECTURE.md to target-dir root",
    )

    # Skills Command Group
    skills_parser = subparsers.add_parser("skills", help="Agent skill operations")
    skills_subparsers = skills_parser.add_subparsers(
        dest="action", help="Skill action to perform"
    )
    skills_eval_parser = skills_subparsers.add_parser(
        "eval", help="Evaluate agent skills against test fixtures"
    )
    skills_eval_parser.add_argument(
        "--skill", "-s", help="Target a specific skill by name"
    )
    skills_eval_parser.add_argument(
        "--provider", "-p", help="LLM provider for Tier 2 evaluation"
    )
    skills_eval_parser.add_argument(
        "--model", "-m", help="Specific model name for Tier 2 evaluation"
    )
    skills_eval_parser.add_argument(
        "--target-dir", "-t", default=None, help="Target repository directory"
    )
    skills_eval_parser.add_argument(
        "--fail-fast",
        "-x",
        action="store_true",
        help="Abort immediately on first failed assertion",
    )
    skills_eval_parser.add_argument(
        "--strict",
        action="store_true",
        help="Treat skills lacking evals fixtures as failures",
    )

    # Config Command Group
    config_parser = subparsers.add_parser(
        "config", help="Configuration inspection and validation"
    )
    config_subparsers = config_parser.add_subparsers(
        dest="action", help="Config action to perform"
    )
    config_show_parser = config_subparsers.add_parser(
        "show", help="Display effective configuration annotated with value origins"
    )
    config_show_parser.add_argument(
        "--target-dir", "-t", default=".", help="Target repository directory"
    )
    config_show_parser.add_argument(
        "--format",
        "-f",
        choices=["text", "json", "yaml"],
        default="text",
        help="Output format (text, json, yaml)",
    )

    config_validate_parser = config_subparsers.add_parser(
        "validate", help="Validate local .cas/config.yaml against schema"
    )
    config_validate_parser.add_argument(
        "--target-dir", "-t", default=".", help="Target repository directory"
    )

    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return

    if args.command == "run":
        kwargs = {}
        kwargs["publish_root"] = getattr(args, "publish_root", False)
        kwargs["skip_evaluation"] = getattr(args, "skip_evaluation", False)
        if hasattr(args, "override") and args.override:
            try:
                override_data = json.loads(args.override)
                # Ensure the runner receives the override in its initialization
                kwargs.update(override_data)
            except json.JSONDecodeError as e:
                print(f"[CLI][ERROR] Failed to parse --override as JSON: {e}")
                sys.exit(1)

        target_dir = getattr(args, "target_dir", None)
        target_project_ctx = resolve_target_project_context(
            project=getattr(args, "project", None), target_dir=target_dir
        )

        flow_name = args.target
        if flow_name in (
            "forensic-diagnostic-flow",
            "discovery-flow",
            "flow-discovery-flow",
        ):
            effective_target = (
                target_dir
                or target_project_ctx.evidence_root
                or target_project_ctx.project_root
            )
            try:
                from .steps.forensic.extractor import validate_target_repository

                validate_target_repository(
                    effective_target, project_id=target_project_ctx.project_id
                )
            except ValueError as e:
                print(f"[CAS][ERROR] {e}")
                sys.exit(1)

        runner = FlowRunner(
            project=target_project_ctx.project_id,
            provider=args.provider,
            model=args.model,
            temperature=args.temperature,
            dry_run=args.dry_run,
            project_context=target_project_ctx,
            target_dir=target_dir,
            **kwargs,
        )

        try:
            runner.run(args.target)
            if getattr(args, "publish_external", False):
                ref_archs = runner.context.get("reference_architectures") or []
                if not ref_archs:
                    print(
                        f"[CAS][INFO] Flow '{args.target}' did not produce any reference architectures; skipping publication."
                    )
                else:
                    from .governance.governance_action_service import (
                        GovernanceActionService,
                    )

                    cli_overrides = {
                        "base_url": getattr(args, "archgov_url", None),
                        "owner": getattr(args, "owner", None),
                        "domain_id": getattr(args, "domain_id", None),
                        "initiative_id": getattr(args, "initiative_id", None),
                        "dry_run": getattr(args, "dry_run", False),
                    }
                    service = GovernanceActionService(
                        project=target_project_ctx.project_id,
                        workspace_root=target_project_ctx.knowledge_base_path,
                    )
                    for ra in ref_archs:
                        pid = ra.get("pattern_id") if isinstance(ra, dict) else str(ra)
                        if not pid:
                            continue
                        fpath = (
                            target_project_ctx.knowledge_base_path
                            / "projects"
                            / target_project_ctx.project_id
                            / "reference-architectures"
                            / f"reference-architecture-{pid}.md"
                        )
                        if not fpath.exists():
                            print(
                                f"[CAS][WARNING] Reference architecture file not found on disk: {fpath}"
                            )
                            continue

                        try:
                            service.publish_governance_artifact(
                                artifact_path=fpath,
                                artifact_type="reference_arch",
                                review_type="design_authority",
                                reviewer=getattr(args, "owner", None),
                                dry_run=getattr(args, "dry_run", False),
                                cli_overrides=cli_overrides,
                                comment=f"Auto-published via CAS flow {args.target}",
                            )
                        except Exception as pub_err:
                            print(
                                f"[CAS][WARNING] Failed publishing reference architecture {pid}: {pub_err}"
                            )
        except Exception as e:
            # Check if governance_fail_on_error is False in kwargs
            if not kwargs.get("governance_fail_on_error", True):
                print(f"[CAS][WARNING] Flow execution failed: {e}")
                print("[CAS][INFO] Continuing due to governance_fail_on_error=false")
                sys.exit(0)  # Exit cleanly to allow workflow to continue
            else:
                raise

    elif args.command == "evaluate":
        from .io import persist_evaluation
        from .llm import get_llm_client
        from .orchestration.config import ConfigLoader
        from .orchestration.evaluation import EvaluationHarness

        # Initialize provider
        config_loader = ConfigLoader()
        profile = config_loader.resolve_config(
            project=args.project, cli_overrides={"provider": args.provider}
        )
        provider = get_llm_client(profile=profile)

        harness = EvaluationHarness(project=args.project, provider=provider)

        # Find the trace file
        trace_id_prefix = args.target
        trace_pattern = (
            f"{BASE}/runtime/traces/trace-{args.project}-*-{trace_id_prefix}*.json"
        )
        trace_files = glob.glob(trace_pattern)

        if not trace_files:
            print(
                f"[CAS][ERROR] No trace found matching {trace_id_prefix} in project {args.project}"
            )
            return

        trace_file = sorted(trace_files, reverse=True)[0]
        print(f"[CAS][INFO] Evaluating trace: {trace_file}")

        with open(trace_file) as f:
            trace_data = json.load(f)

        record = harness.evaluate(trace_data)
        persist_evaluation(record.model_dump(), args.project)
        print(
            f"[CAS][INFO] Evaluation completed. Overall score: {record.overall_score}"
        )
        print(
            f"[CAS][INFO] Detailed rationale: {record.dimensions[0].rationale if record.dimensions else 'N/A'}"
        )

    elif args.command == "bootstrap":
        from .bootstrap import bootstrap

        bootstrap(
            target_dir=args.target,
            force=args.force,
            minimal=args.minimal,
            no_ci=args.no_ci,
            sdlc_profile=getattr(args, "sdlc_profile", "auto"),
        )

    elif args.command == "init-workspace":
        from .bootstrap import init_workspace

        init_workspace(
            target_dir=args.target,
            project_name=args.project,
            force=args.force,
            provider=args.provider,
            workspace_root_path=args.workspace_root or str(BASE.parent),
        )

    elif args.command == "dashboard":
        if args.format == "json":
            from .dashboard.api import DashboardAPI

            api = DashboardAPI(args.project)
            print(json.dumps(api.get_summary(), indent=2))
        else:
            from .dashboard.routes import generate_dashboard_markdown

            print(generate_dashboard_markdown(args.project))

    elif args.command == "watch":
        import time

        from rich.console import Console
        from rich.live import Live
        from rich.panel import Panel
        from rich.text import Text

        from .orchestration.hud import (
            ActiveRunState,
            get_default_state_path,
            render_hud_layout,
        )

        state_path = (
            Path(args.file) if getattr(args, "file", None) else get_default_state_path()
        )
        refresh_delay = 1.0 / max(0.5, args.refresh_rate)
        console = Console()

        console.print(
            f"[bold cyan][CAS WATCH][/] Monitoring [yellow]{state_path}[/] (refresh: {args.refresh_rate}Hz)..."
        )
        console.print("[dim]Press Ctrl+C to exit.[/]\n")

        with Live(
            console=console, refresh_per_second=int(max(1, args.refresh_rate))
        ) as live:
            try:
                last_mtime = None
                current_state = None
                while True:
                    if state_path.exists():
                        try:
                            mtime = state_path.stat().st_mtime
                            if mtime != last_mtime or current_state is None:
                                with open(state_path) as f:
                                    data = json.load(f)
                                current_state = ActiveRunState(**data)
                                last_mtime = mtime
                            if current_state:
                                live.update(render_hud_layout(current_state))
                        except (json.JSONDecodeError, OSError):
                            pass
                    else:
                        waiting_panel = Panel(
                            Text(
                                f"Waiting for active run...\n(Listening at {state_path})",
                                justify="center",
                                style="dim italic",
                            ),
                            title="CAS Watch",
                            border_style="yellow",
                        )
                        live.update(waiting_panel)
                    time.sleep(refresh_delay)
            except KeyboardInterrupt:
                pass
        console.print("\n[bold cyan][CAS WATCH][/] Detached.")
        sys.exit(0)

    elif args.command == "governance":
        if args.action == "validate":
            runner = FlowRunner(project=args.project, provider=args.provider)
            runner.run("governance-validator")
            sys.exit(0)
        elif args.action == "lint":
            from .governance.architecture_linter import ArchitectureLinter

            linter = ArchitectureLinter(target_dir=args.target_dir)
            report = linter.lint()
            if args.format == "json":
                print(report.to_json())
            else:
                if report.passed:
                    print(
                        f"[CAS][LINT][OK] Deterministic architecture lint passed for {report.target_dir} (0 violations)."
                    )
                else:
                    print(
                        f"[CAS][LINT][ERROR] Found {len(report.findings)} architectural violation(s) in {report.target_dir}:"
                    )
                    for f in report.findings:
                        print(
                            f"  - [{f.rule_id}] ({f.pattern_id}) {f.file}:{f.line} -> {f.message}"
                        )
                        print(f"    Remediation: {f.remediation}")
            sys.exit(0 if report.passed else 1)
        elif args.action in ("verify-diff", "review-pr"):
            from .governance.verifier import DiffVerifier

            verifier = DiffVerifier(
                target_dir=args.target_dir,
                mode=args.action,
                base_ref=getattr(args, "base_ref", None),
                sdlc_profile=getattr(args, "sdlc_profile", None),
                fail_on=getattr(args, "fail_on", "high"),
                advisory=getattr(args, "advisory", False),
                provider=getattr(args, "provider", None),
                model=getattr(args, "model", None),
            )
            v_report = verifier.verify()
            if getattr(args, "format", "markdown") == "json":
                print(v_report.to_json())
            else:
                print(v_report.to_markdown())
            sys.exit(v_report.exit_code)
        elif args.action == "verify-intent":
            from .governance.intent_verifier import IntentVerifier

            verifier = IntentVerifier(target_dir=args.target_dir)
            report = verifier.verify()

            if getattr(args, "format", "text") == "json":
                print(
                    json.dumps(
                        {
                            "artifact_path": report.artifact_path,
                            "artifact_status": report.artifact_status,
                            "is_valid": report.is_valid,
                            "valid_anchors_count": report.valid_anchors_count,
                            "presumptions_count": len(report.presumptions),
                            "blocking_questions_count": report.blocking_questions_count,
                            "errors": report.errors,
                            "warnings": report.warnings,
                        },
                        indent=2,
                    )
                )
            else:
                print("=== CAS Intent Provenance Verification ===")
                print(
                    f"Artifact: {report.artifact_path} (Status: {report.artifact_status})"
                )
                print("\n[A] Anchored Code Evidence:")
                if report.anchors:
                    for a in report.anchors:
                        status_char = "✓" if a.is_valid else "✗"
                        detail = f", {a.ast_node_type}" if a.ast_node_type else ""
                        print(
                            f"  {status_char} {a.raw_citation} ({'Valid' if a.is_valid else a.error_message}{detail})"
                        )
                else:
                    print("  • None")

                print(
                    f"\n[P] Heuristic Presumptions ({len(report.presumptions)} tracked):"
                )
                if report.presumptions:
                    for p in report.presumptions:
                        print(f"  • {p.raw_text}")
                else:
                    print("  • None")

                print(
                    f"\n[Q] Open Questions ({len(report.open_questions)} active, {report.blocking_questions_count} blocking):"
                )
                if report.open_questions:
                    for q in report.open_questions:
                        blocking_label = " [BLOCKING]" if q.is_blocking else ""
                        print(f"  • {q.raw_text}{blocking_label}")
                else:
                    print("  • None")

                outcome = "PASS" if report.is_valid else "FAIL"
                print(
                    f"\nResult: {outcome} ({report.valid_anchors_count} anchors verified, {len(report.presumptions)} presumptions tracked, {report.blocking_questions_count} blocking questions)"
                )

            if getattr(args, "advisory", False):
                sys.exit(0)
            sys.exit(0 if report.is_valid else 1)
        elif args.action == "check-bands":
            from dataclasses import asdict

            from .governance.control_bands import (
                BAND_SEVERITY_ORDER,
                ControlBandsEngine,
                format_control_bands_text,
            )

            engine = ControlBandsEngine(target_dir=Path(args.target_dir))
            report = engine.evaluate()

            if getattr(args, "format", "text") == "json":
                print(json.dumps(asdict(report), indent=2))
            else:
                print(format_control_bands_text(report))

            fail_on = getattr(args, "fail_on", "3sigma")
            advisory = getattr(args, "advisory", False)
            if advisory or fail_on == "none":
                return
            if BAND_SEVERITY_ORDER.get(
                report.highest_band, 0
            ) >= BAND_SEVERITY_ORDER.get(fail_on, 3):
                sys.exit(1)
            return
        elif args.action == "check-env":
            from .governance.env_checker import EnvironmentChecker

            checker = EnvironmentChecker(target_dir=args.target_dir)
            env_report = checker.check()
            if getattr(args, "format", "text") == "json":
                print(env_report.to_json())
            else:
                print(env_report.to_text())

            if (
                getattr(args, "strict", False)
                and not env_report.ready_for_continuous_loop
            ):
                sys.exit(1)
            sys.exit(0)
        elif args.action == "route-plan":
            from .governance.models import GovernancePath
            from .governance.plan_router import PlanRouter

            router = PlanRouter(
                target_dir=args.target_dir,
                project=getattr(args, "project", "ideas-to-life-cas"),
            )
            decision = router.route()

            if getattr(args, "format", "text") == "json":
                print(
                    json.dumps(
                        {
                            "plan_path": decision.plan_path,
                            "path": decision.path.value,
                            "status": decision.status,
                            "matched_patterns": decision.matched_patterns,
                            "unmapped_dependencies": decision.unmapped_dependencies,
                            "candidate_adr_path": decision.candidate_adr_path,
                            "exception_record_path": decision.exception_record_path,
                            "reasons": decision.reasons,
                        },
                        indent=2,
                    )
                )
            else:
                print("=== CAS Plan Governance Routing ===")
                print(f"Plan: {decision.plan_path}")
                print(f"\nClassification: {decision.path.value}")
                print(f"Status: {decision.status.upper()}")

                if decision.matched_patterns:
                    print("\nMatched Patterns:")
                    for p in decision.matched_patterns:
                        print(f"  ✓ {p} (Invariants satisfied)")

                if decision.unmapped_dependencies:
                    print("\nUnmapped Novel Elements:")
                    for d in decision.unmapped_dependencies:
                        print(f"  ! {d}")

                if decision.candidate_adr_path:
                    print(
                        f"\nCandidate ADR Scaffolded:\n  ✓ {decision.candidate_adr_path}"
                    )

                if decision.exception_record_path:
                    print(f"\nException Record:\n  ✓ {decision.exception_record_path}")

                if decision.reasons:
                    print("\nGovernance Details:")
                    for r in decision.reasons:
                        print(f"  • {r}")

            if getattr(args, "advisory", False):
                sys.exit(0)

            # Exit codes: 0 for Path A and Path C approved; 2 for Path B escalation; 1 for blocked/invalid
            if decision.status == "approved":
                sys.exit(0)
            elif decision.path == GovernancePath.PATH_B:
                sys.exit(2)
            else:
                sys.exit(1)
        elif args.action == "watch":
            import time

            from rich.console import Console
            from rich.live import Live

            from .governance.hud_view import render_sdlc_hud
            from .governance.sdlc_state import SDLCStatePublisher

            console = Console()
            publisher = SDLCStatePublisher(
                project=getattr(args, "project", "ideas-to-life-cas"),
                target_dir=args.target_dir,
            )

            if getattr(args, "once", False):
                state = publisher.load_or_create()
                console.print(render_sdlc_hud(state))
                sys.exit(0)

            try:
                state = publisher.load_or_create()
                with Live(
                    render_sdlc_hud(state),
                    console=console,
                    refresh_per_second=2,
                    screen=False,
                ) as live:
                    while True:
                        time.sleep(getattr(args, "interval", 0.5))
                        state = publisher.load_or_create()
                        live.update(render_sdlc_hud(state))
            except KeyboardInterrupt:
                console.print("\n[dim]CAS SDLC watch stopped.[/dim]")
                sys.exit(0)
        elif args.action == "assess":
            runner = FlowRunner(project=args.project, provider=args.provider)
            runner.run("assessment-flow")
            sys.exit(0)
        elif args.action == "resolve-conflicts":
            # 1. Initialize Reasoning Engine
            runner = FlowRunner(project=args.project, provider=args.provider)
            from .governance.agentic_merger import AgenticMerger

            merger = AgenticMerger(runner.reasoning_engine)

            # 2. Find files with git conflict markers
            knowledge_root = get_workspace_root()
            conflicted_files = []
            for ext in ["*.yaml", "*.json", "*.md"]:
                for p in knowledge_root.rglob(ext):
                    content = p.read_text()
                    if "<<<<<<<" in content and ">>>>>>>" in content:
                        conflicted_files.append(p)

            if not conflicted_files:
                print("[CAS][INFO] No git conflicts found in knowledge artifacts.")
                sys.exit(0)

            print(
                f"[CAS][INFO] Found {len(conflicted_files)} conflicted files. Starting Agentic Merge..."
            )

            for p in conflicted_files:
                content = p.read_text()
                # Basic conflict parser (this is an MVP, could be more robust)
                try:
                    parts = content.split("<<<<<<<")[1].split(">>>>>>>")
                    head_and_remote = parts[0].split("=======")

                    # Strip the first line of head_and_remote[0] (which is ' HEAD' or similar)
                    local_lines = head_and_remote[0].strip().split("\n")
                    if (
                        local_lines and ":" not in local_lines[0]
                    ):  # Likely a branch marker
                        local_v = "\n".join(local_lines[1:]).strip()
                    else:
                        local_v = "\n".join(local_lines).strip()

                    remote_v = head_and_remote[1].strip()

                    if p.suffix in [".yaml", ".json"]:
                        # AEM style merge
                        local_data = yaml.safe_load(local_v)
                        remote_data = yaml.safe_load(remote_v)
                        merged = merger.resolve_aem_conflict(local_data, remote_data)

                        if p.suffix == ".json":
                            p.write_text(json.dumps(merged, indent=2))
                        else:
                            p.write_text(yaml.dump(merged, sort_keys=False))
                    else:
                        # Text style merge (AID, ADR, etc.)
                        merged_content = merger.resolve_generic_conflict(
                            p, local_v, remote_v
                        )
                        p.write_text(merged_content)

                    print(f"[CAS][SUCCESS] Resolved conflict in {p.name}")
                except Exception as e:
                    print(f"[CAS][ERROR] Failed to resolve conflict in {p.name}: {e}")

            sys.exit(0)
        elif args.action in ["approve", "reject", "defer", "reopen"]:
            from .governance.governance_action_service import GovernanceActionService

            service = GovernanceActionService(args.project)

            # Simple heuristic for artifact_type for the MVP.
            # In a full implementation, we'd query the knowledge layer.
            a_type = "unknown"
            if "promotion-decision" in args.artifact_id:
                a_type = "promotion_decision"
            elif args.artifact_id.startswith("reference-architecture-"):
                a_type = "reference_arch"
            elif args.artifact_id.startswith("adr-"):
                a_type = "adr"
            elif args.artifact_id.startswith("exc-"):
                a_type = "governance_exception"
            elif args.artifact_id.startswith("aw-"):
                a_type = "architecture_work"
            elif service.is_pattern_or_recommendation(args.artifact_id):
                a_type = "promotion_decision"

            try:
                # Load the actual current state of the artifact from disk
                current_state = service.get_artifact_state(args.artifact_id, a_type)

                action = service.execute_action(
                    artifact_id=args.artifact_id,
                    artifact_type=a_type,
                    current_state=current_state,
                    action_type=args.action,
                    rationale=getattr(args, "rationale", None),
                )
                print(
                    f"[CAS] Successfully executed {args.action} on {args.artifact_id}."
                )
                print(f"[CAS] State transitioned to {action.new_state}.")

                # If --push-external is specified, update remote ArchGov
                if getattr(args, "push_external", False) and a_type in [
                    "reference_arch",
                    "adr",
                ]:
                    from .governance.publisher import (
                        ArchGovPublisher,
                        load_archgov_config,
                    )
                    from .io import load_archgov_sync_manifest, save_archgov_sync_record

                    manifest = load_archgov_sync_manifest(args.project)
                    if a_type == "reference_arch":
                        clean_id = args.artifact_id.removeprefix(
                            "reference-architecture-"
                        )
                        sync_key = (
                            clean_id
                            if clean_id in manifest.get("records", {})
                            else f"reference-architecture-{clean_id}"
                        )
                    else:
                        clean_id = args.artifact_id.removeprefix("adr-")
                        sync_key = (
                            f"adr-{clean_id}"
                            if f"adr-{clean_id}" in manifest.get("records", {})
                            else clean_id
                        )

                    record = manifest.get("records", {}).get(sync_key, {})
                    art_id = record.get("archgov_artifact_id")
                    rev_id = record.get("archgov_review_id")
                    if art_id and rev_id:
                        cfg = load_archgov_config(args.project, base_path=BASE)
                        publisher = ArchGovPublisher(
                            base_url=cfg.base_url, endpoints=cfg.endpoints
                        )
                        print(
                            f"[CAS][INFO] Pushing review update to ArchGov artifact {art_id} review {rev_id}..."
                        )
                        push_res = publisher.update_review_status(
                            artifact_id=int(art_id),
                            review_id=int(rev_id),
                            status=action.new_state,
                            comment=getattr(args, "rationale", None),
                            dry_run=cfg.dry_run,
                        )
                        if "error" in push_res:
                            print(
                                f"[CAS][WARNING] Push to ArchGov failed (offline/error): {push_res['error']}"
                            )
                        else:
                            print(
                                f"[CAS][SUCCESS] Remote ArchGov review updated to {action.new_state}"
                            )
                            save_archgov_sync_record(
                                args.project,
                                sync_key,
                                {"remote_status": action.new_state},
                            )
                    else:
                        print(
                            f"[CAS][INFO] No remote ArchGov artifact/review mapped for {args.artifact_id}; skipped remote push."
                        )

                # If approved and not --no-chain, trigger downstream chaining
                if action.action_type == "approve" and not getattr(
                    args, "no_chain", False
                ):
                    if a_type == "reference_arch":
                        from .io import load_archgov_sync_manifest

                        pattern_id = args.artifact_id.removeprefix(
                            "reference-architecture-"
                        )
                        manifest = load_archgov_sync_manifest(args.project)
                        record = manifest.get("records", {}).get(pattern_id, {})
                        adr_file = (
                            service.workspace_root
                            / "projects"
                            / args.project
                            / "adrs"
                            / f"adr-{pattern_id}.md"
                        )
                        if not (
                            record.get("downstream_chained", False)
                            and adr_file.exists()
                        ):
                            provider = getattr(args, "provider", None) or "stub"
                            service.trigger_downstream_adr_chaining(
                                pattern_id,
                                rationale=args.rationale,
                                provider=provider,
                            )
                    elif a_type == "adr":
                        from .io import load_archgov_sync_manifest

                        clean_id = args.artifact_id.removeprefix("adr-")
                        sync_key = f"adr-{clean_id}"
                        manifest = load_archgov_sync_manifest(args.project)
                        record = manifest.get("records", {}).get(sync_key, {})
                        pat_file = (
                            service.workspace_root
                            / "global"
                            / "patterns"
                            / f"{clean_id}.yaml"
                        )
                        if not (
                            record.get("downstream_chained", False)
                            and pat_file.exists()
                        ):
                            provider = getattr(args, "provider", None) or "stub"
                            service.trigger_downstream_pattern_chaining(
                                args.artifact_id,
                                rationale=args.rationale,
                                provider=provider,
                            )
            except Exception as e:
                print(f"[CAS][ERROR] Failed to execute action: {e}")
                sys.exit(1)

        elif args.action == "publish":
            if getattr(args, "all_unpublished", False):
                from .governance.governance_action_service import (
                    GovernanceActionService,
                )

                service = GovernanceActionService(project=args.project)
                service.workspace_root = BASE
                print(
                    f"[CAS][INFO] Batch publishing all unpublished {args.artifact_type}s for project '{args.project}'..."
                )
                stats = service.publish_all_unpublished(
                    artifact_type=args.artifact_type,
                    review_type=getattr(args, "review_type", None),
                    reviewer=getattr(args, "reviewer", None),
                    dry_run=getattr(args, "dry_run", False),
                )
                print(
                    f"[CAS][SUMMARY] Batch publication complete: {stats['published']} published, {stats['already_tracked']} already tracked, {len(stats['errors'])} errors (out of {stats['total_candidates']} total)."
                )
                sys.exit(1 if stats["errors"] else 0)

            if not getattr(args, "artifact", None):
                print(
                    "[CAS][ERROR] --artifact is required unless --all-unpublished is specified."
                )
                sys.exit(1)

            from .governance.publisher import (
                ArchGovPublisher,
                load_archgov_config,
                resolve_review_type_default,
            )

            artifact_path = Path(args.artifact)
            if not artifact_path.exists():
                print(f"[CAS][ERROR] Artifact file not found: {artifact_path}")
                sys.exit(1)

            content = artifact_path.read_text(encoding="utf-8")
            # Extract title from markdown H1 if available
            title = artifact_path.stem
            for line in content.split("\n"):
                if line.startswith("# "):
                    title = line[2:].strip()
                    break

            cli_overrides = {
                "base_url": getattr(args, "archgov_url", None),
                "owner": getattr(args, "owner", None),
                "domain_id": getattr(args, "domain_id", None),
                "initiative_id": getattr(args, "initiative_id", None),
                "dry_run": getattr(args, "dry_run", False),
            }

            cfg = load_archgov_config(
                args.project, base_path=BASE, cli_overrides=cli_overrides
            )
            publisher = ArchGovPublisher(base_url=cfg.base_url, endpoints=cfg.endpoints)

            print(
                f"[CAS][INFO] Publishing {args.artifact_type} '{title}' to {cfg.base_url}..."
            )
            art_res = publisher.publish_artifact(
                title=title,
                artifact_type=args.artifact_type,
                content=content,
                owner=cfg.default_owner,
                created_by=cfg.default_owner,
                domain_id=cfg.domain_id,
                initiative_id=cfg.initiative_id,
                dry_run=cfg.dry_run,
            )

            if "error" in art_res:
                print(f"[CAS][ERROR] Failed to publish artifact: {art_res['error']}")
                sys.exit(2)

            art_id = art_res.get("id")
            print(
                f"[CAS][SUCCESS] Artifact created with ID: {art_id} (status: {art_res.get('status')})"
            )

            review_type = getattr(
                args, "review_type", None
            ) or resolve_review_type_default(args.artifact_type)
            reviewer = (
                getattr(args, "reviewer", None)
                or cfg.default_owner
                or "alexandre.franco@mostelli.com"
            )

            print(f"[CAS][INFO] Requesting '{review_type}' review from {reviewer}...")
            rev_res = publisher.request_review(
                artifact_id=art_id,
                review_type=review_type,
                reviewer=reviewer,
                comment=f"Submitted via CAS CLI for project {args.project}",
                dry_run=cfg.dry_run,
            )

            if "error" in rev_res:
                print(f"[CAS][ERROR] Failed to request review: {rev_res['error']}")
                sys.exit(2)

            print(f"[CAS][SUCCESS] Review request submitted (ID: {rev_res.get('id')})")
            if cfg.dry_run:
                print(
                    "[CAS][INFO] Dry-run mode enabled; manifest and frontmatter left untouched."
                )
                sys.exit(0)

            if args.artifact_type == "reference_arch":
                from .io import (
                    save_archgov_sync_record,
                    update_reference_architecture_frontmatter,
                )

                pattern_id = artifact_path.stem
                if pattern_id.startswith("reference-architecture-"):
                    pattern_id = pattern_id[len("reference-architecture-") :]
                rel_path = f"knowledge/projects/{args.project}/reference-architectures/{artifact_path.name}"
                save_archgov_sync_record(
                    args.project,
                    pattern_id,
                    {
                        "artifact_path": rel_path,
                        "archgov_artifact_id": art_id,
                        "archgov_review_id": rev_res.get("id"),
                        "review_type": review_type,
                        "reviewer": reviewer,
                        "status": "in_review",
                        "remote_status": "in_review",
                    },
                )
                try:
                    update_reference_architecture_frontmatter(
                        artifact_path,
                        {
                            "status": "in_review",
                            "governance": {
                                "archgov_artifact_id": art_id,
                                "archgov_review_id": rev_res.get("id"),
                                "review_type": review_type,
                                "reviewer": reviewer,
                            },
                        },
                    )
                except Exception:
                    pass
            elif args.artifact_type == "adr":
                from .io import (
                    save_archgov_sync_record,
                    update_adr_frontmatter,
                )

                clean_id = artifact_path.stem
                if clean_id.startswith("adr-"):
                    clean_id = clean_id[len("adr-") :]
                sync_key = f"adr-{clean_id}"
                rel_path = (
                    f"knowledge/projects/{args.project}/adrs/{artifact_path.name}"
                )
                save_archgov_sync_record(
                    args.project,
                    sync_key,
                    {
                        "artifact_id": sync_key,
                        "artifact_type": "adr",
                        "pattern_id": clean_id,
                        "artifact_path": rel_path,
                        "archgov_artifact_id": art_id,
                        "archgov_review_id": rev_res.get("id"),
                        "review_type": review_type,
                        "reviewer": reviewer,
                        "status": "in_review",
                        "remote_status": "in_review",
                    },
                )
                try:
                    update_adr_frontmatter(
                        artifact_path,
                        {
                            "governance": {
                                "forum_status": "in_review",
                                "archgov_artifact_id": art_id,
                                "archgov_review_id": rev_res.get("id"),
                                "review_type": review_type,
                                "reviewer": reviewer,
                            },
                            "decision": {
                                "status": "in_review",
                            },
                        },
                    )
                except Exception:
                    pass
            sys.exit(0)

        elif args.action == "sync":
            from .governance.governance_action_service import GovernanceActionService
            from .governance.publisher import ArchGovPublisher, load_archgov_config

            cli_overrides = {
                "base_url": getattr(args, "archgov_url", None),
                "dry_run": getattr(args, "dry_run", False),
            }
            cfg = load_archgov_config(
                args.project, base_path=BASE, cli_overrides=cli_overrides
            )
            publisher = ArchGovPublisher(base_url=cfg.base_url, endpoints=cfg.endpoints)
            service = GovernanceActionService(args.project)

            from .orchestration.config import ConfigLoader

            resolved_provider = getattr(args, "provider", None)
            if not resolved_provider:
                try:
                    resolved_provider = (
                        ConfigLoader().resolve_config(project=args.project).provider
                    )
                except Exception:
                    resolved_provider = "stub"

            service.sync_project_reviews(
                publisher=publisher,
                dry_run=cfg.dry_run,
                no_chain=getattr(args, "no_chain", False),
                provider=resolved_provider,
                artifact_type_filter=getattr(args, "type", "all"),
            )
            sys.exit(0)

        elif args.action == "status":
            from .governance.governance_action_service import GovernanceActionService
            from .io import load_archgov_sync_manifest

            service = GovernanceActionService(args.project)
            artifact_id = args.artifact_id
            manifest = load_archgov_sync_manifest(args.project)

            if artifact_id.startswith("adr-"):
                clean_id = artifact_id.removeprefix("adr-")
                sync_key = (
                    f"adr-{clean_id}"
                    if f"adr-{clean_id}" in manifest.get("records", {})
                    else (
                        artifact_id
                        if artifact_id in manifest.get("records", {})
                        else clean_id
                    )
                )
                rec = manifest.get("records", {}).get(sync_key, {})
                current_state = service.get_artifact_state(artifact_id, "adr")
                pat_id = rec.get("pattern_id") or clean_id
                art_id = rec.get("archgov_artifact_id", "Not published")
                rev_id = rec.get("archgov_review_id", "None")
                reviewer = rec.get("reviewer", "Unassigned")
                last_synced = rec.get("last_synced_at", "Never")
                pattern_info = rec.get("downstream_pattern_id") or "None"
                if rec.get("downstream_chained"):
                    pattern_info += " (institutionalized)"

                print(f"[CAS] Artifact Status: {artifact_id}")
                print("Type: adr")
                print(f"Current State: {current_state}")
                print(f"Underlying Pattern ID: {pat_id}")
                print(f"ArchGov Artifact ID: {art_id}")
                print(f"ArchGov Review ID: {rev_id}")
                print(f"Reviewer: {reviewer}")
                print(f"Last Synced: {last_synced}")
                print(f"Downstream Pattern: {pattern_info}")
                sys.exit(0)
            else:
                pattern_id = artifact_id.removeprefix("reference-architecture-")
                sync_key = (
                    f"reference-architecture-{pattern_id}"
                    if f"reference-architecture-{pattern_id}"
                    in manifest.get("records", {})
                    else pattern_id
                )
                rec = manifest.get("records", {}).get(sync_key, {})

                current_state = service.get_artifact_state(
                    artifact_id, "reference_arch"
                )
                rec_id = rec.get("recommendation_id") or f"recommendation-{pattern_id}"
                art_id = rec.get("archgov_artifact_id", "Not published")
                rev_id = rec.get("archgov_review_id", "None")
                reviewer = rec.get("reviewer", "Unassigned")
                last_synced = rec.get("last_synced_at", "Never")
                adr_info = rec.get("downstream_adr_id") or "None"
                if rec.get("downstream_chained"):
                    adr_info += " (synthesized)"

                print(f"[CAS] Artifact Status: {artifact_id}")
                print("Type: reference_arch")
                print(f"Current State: {current_state}")
                print(f"Traceable Recommendation: {rec_id}")
                print(f"ArchGov Artifact ID: {art_id}")
                print(f"ArchGov Review ID: {rev_id}")
                print(f"Reviewer: {reviewer}")
                print(f"Last Synced: {last_synced}")
                print(f"Downstream ADR: {adr_info}")
                sys.exit(0)

    elif args.command == "steering":
        if args.action == "validate":
            validator = ManagedSectionValidator()
            report = validator.validate_artifacts(list(STEERING_ARTIFACTS))
            if report.status == "passed":
                print(
                    f"[CAS][INFO] Managed steering section validation PASSED for {len(report.sections)} sections."
                )
                sys.exit(0)
            else:
                print("[CAS][ERROR] Managed steering section validation FAILED.")
                for error in report.errors:
                    print(f"  - {error}")
                sys.exit(1)

        elif args.action == "apply":
            # 1. Load projection
            input_val = args.projection
            proj_path = Path(input_val)

            # Helper to check if a path exists
            def find_projection(base_dir: Path, name: str) -> Path | None:
                # 1. As is
                p = base_dir / name
                if p.exists():
                    return p
                # 2. Add .md
                p = base_dir / f"{name}.md"
                if p.exists():
                    return p
                # 3. Add prefix
                p = base_dir / f"steering-projection-{name}"
                if p.exists():
                    return p
                # 4. Add prefix + .md
                p = base_dir / f"steering-projection-{name}.md"
                if p.exists():
                    return p

                # If name has .md, try stripping it and repeating prefix checks
                if name.endswith(".md"):
                    stripped = name[:-3]
                    p = base_dir / f"steering-projection-{stripped}.md"
                    if p.exists():
                        return p
                return None

            # Try absolute/relative to CWD first
            resolved = find_projection(Path("."), input_val)
            if not resolved:
                # Try in projections dir
                projections_dir = BASE / "governance" / "steering" / "projections"
                resolved = find_projection(projections_dir, input_val)

            if not resolved:
                print(f"[CAS][ERROR] Projection not found: {input_val}")
                print(
                    f"[CAS][DEBUG] Searched in: {BASE / 'governance/steering/projections'}"
                )
                sys.exit(1)

            proj_path = resolved

            # Extract frontmatter for proposals
            content = proj_path.read_text()
            if not content.startswith("---"):
                print(
                    f"[CAS][ERROR] Invalid projection format (missing frontmatter): {proj_path}"
                )
                sys.exit(1)

            parts = content.split("---")
            if len(parts) < 3:
                print(
                    f"[CAS][ERROR] Invalid projection format (malformed frontmatter): {proj_path}"
                )
                sys.exit(1)

            fm = yaml.safe_load(parts[1])

            proposals_data = fm.get("managed_section_proposals", [])
            proposals = [ManagedSectionProposal(**p) for p in proposals_data]

            applier = ManagedSectionApplier()
            try:
                plan = applier.plan(proposals, dry_run=args.dry_run)

                if args.dry_run:
                    print(
                        f"[CAS][INFO] Dry-run: Managed steering section apply plan for {len(plan.replacements)} replacements."
                    )
                    for r in plan.replacements:
                        print(f"\n--- {r.artifact} ({r.section_id}) ---")
                        print(r.diff)
                    sys.exit(0)

                applier.apply(plan)
                print(
                    f"[CAS][INFO] Successfully applied {len(plan.replacements)} managed steering sections."
                )
                sys.exit(0)
            except Exception as e:
                print(f"[CAS][ERROR] Failed to apply steering sections: {e}")
                sys.exit(1)

        elif args.action == "bootstrap":
            from .steering.bootstrap import bootstrap_inventory

            try:
                bootstrap_inventory(
                    project=args.project, baseline_ref=args.baseline_ref
                )
                sys.exit(0)
            except Exception as e:
                print(f"[CAS][ERROR] Bootstrap failed: {e}")
                sys.exit(1)

    elif args.command == "state":
        if getattr(args, "subcommand", None) == "baseline":
            if getattr(args, "action", None) == "promote":
                target_project_ctx = resolve_target_project_context(
                    project=args.project, target_dir=getattr(args, "target_dir", None)
                )
                try:
                    snapshot_path = promote_architecture_state_baseline(
                        project=target_project_ctx, notes=getattr(args, "notes", None)
                    )
                    print(
                        f"[CAS][INFO] Successfully promoted architecture state to validated-baseline for project '{target_project_ctx.project_id}'. Snapshot: {snapshot_path}"
                    )
                    sys.exit(0)
                except Exception as e:
                    print(
                        f"[CAS][ERROR] Failed to promote architecture state baseline: {e}"
                    )
                    sys.exit(1)
            else:
                state_baseline_parser.print_help()
                sys.exit(1)
        elif getattr(args, "subcommand", None) == "discover-flows":
            target_project_ctx = resolve_target_project_context(
                project=args.project, target_dir=getattr(args, "target_dir", None)
            )
            runner = FlowRunner(
                project=target_project_ctx.project_id,
                provider=getattr(args, "provider", "stub"),
                target_dir=str(
                    target_project_ctx.evidence_root or target_project_ctx.project_root
                ),
                publish_root=getattr(args, "publish_root", False),
                project_context=target_project_ctx,
            )
            runner.run("flow-discovery-flow")
            print(
                f"[CAS][INFO] Flow discovery completed successfully for project '{target_project_ctx.project_id}'."
            )
            sys.exit(0)
        else:
            state_parser.print_help()
            sys.exit(1)

    elif args.command == "skills":
        if getattr(args, "action", None) == "eval":
            from .skills.evaluator import SkillEvaluator

            evaluator = SkillEvaluator(
                root_dir=args.target_dir,
                target_skill=args.skill,
                fail_fast=args.fail_fast,
                strict=args.strict,
                provider=args.provider,
                model=args.model,
            )
            print("[CAS][INFO] Evaluating CAS Agent Skills...")
            report = evaluator.evaluate()
            print(report.render_terminal_table())
            sys.exit(0 if report.is_success else 1)
        else:
            skills_parser.print_help()
            sys.exit(1)

    elif args.command == "config":
        action = getattr(args, "action", None)
        target_dir = getattr(args, "target_dir", ".")
        from .config import load_config, validate_config

        if action == "show":
            out_format = getattr(args, "format", "text")
            effective = load_config(target_dir=target_dir)

            if out_format == "json":
                data = {
                    "effective": effective.config.model_dump(),
                    "_provenance": {
                        k: {
                            "value": v.value,
                            "source_tier": v.source_tier.value,
                            "source_location": v.source_location,
                        }
                        for k, v in effective.provenance.items()
                    },
                }
                print(json.dumps(data, indent=2))
                return 0
            elif out_format == "yaml":
                print(yaml.dump(effective.config.model_dump(), sort_keys=False))
                return 0
            else:
                from rich.console import Console
                from rich.table import Table

                console = Console()
                console.print("[bold cyan][CAS] Effective Configuration[/bold cyan]")
                console.print(f"Target Directory: [dim]{effective.target_dir}[/dim]")
                local_status = (
                    f"[green]Found ({effective.local_config_file})[/green]"
                    if effective.local_config_file
                    else "[yellow]Not Found[/yellow]"
                )
                global_status = (
                    f"[green]Found ({effective.global_config_file})[/green]"
                    if effective.global_config_file
                    else "[yellow]Not Found[/yellow]"
                )
                console.print(f"Local Config: {local_status}")
                console.print(f"Global Config: {global_status}\n")

                table = Table(
                    title="Resolved Configuration & Provenance",
                    show_header=True,
                    header_style="bold magenta",
                )
                table.add_column("Field", style="cyan")
                table.add_column("Effective Value", style="green")
                table.add_column("Source Tier", style="bold")
                table.add_column("Source Location", style="dim")

                tier_styles = {
                    "cli_flag": "[bold red]CLI[/bold red]",
                    "local_config": "[bold green]LOCAL[/bold green]",
                    "global_config": "[bold blue]GLOBAL[/bold blue]",
                    "env_var": "[bold yellow]ENV[/bold yellow]",
                    "default": "[dim]DEFAULT[/dim]",
                }

                for field_path in sorted(effective.provenance.keys()):
                    prov = effective.provenance[field_path]
                    tier_str = tier_styles.get(
                        prov.source_tier.value, prov.source_tier.value
                    )
                    val_str = str(prov.value)
                    if len(val_str) > 60:
                        val_str = val_str[:57] + "..."
                    table.add_row(field_path, val_str, tier_str, prov.source_location)

                console.print(table)
                return 0
        elif action == "validate":
            valid, msg = validate_config(target_dir=target_dir)
            if valid:
                print(f"[CAS][OK] {msg}")
                return 0
            else:
                print(f"[CAS][ERROR] {msg}")
                sys.exit(1)
        else:
            config_parser.print_help()
            sys.exit(1)


cli = main

if __name__ == "__main__":
    main()
